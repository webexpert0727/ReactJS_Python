--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: blog_category; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE blog_category (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    slug character varying(50) NOT NULL
);


ALTER TABLE blog_category OWNER TO admin;

--
-- Name: blog_category_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE blog_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_category_id_seq OWNER TO admin;

--
-- Name: blog_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE blog_category_id_seq OWNED BY blog_category.id;


--
-- Name: blog_post; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE blog_post (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    preview character varying(512) NOT NULL,
    content text NOT NULL,
    date_added timestamp with time zone NOT NULL,
    date_published timestamp with time zone NOT NULL,
    author character varying(32) NOT NULL,
    img character varying(100) NOT NULL,
    category_id integer,
    slug character varying(128) NOT NULL
);


ALTER TABLE blog_post OWNER TO admin;

--
-- Name: blog_post_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE blog_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_post_id_seq OWNER TO admin;

--
-- Name: blog_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE blog_post_id_seq OWNED BY blog_post.id;


--
-- Name: blog_post_tags; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE blog_post_tags (
    id integer NOT NULL,
    post_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE blog_post_tags OWNER TO admin;

--
-- Name: blog_post_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE blog_post_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_post_tags_id_seq OWNER TO admin;

--
-- Name: blog_post_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE blog_post_tags_id_seq OWNED BY blog_post_tags.id;


--
-- Name: blog_tag; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE blog_tag (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    slug character varying(50) NOT NULL
);


ALTER TABLE blog_tag OWNER TO admin;

--
-- Name: blog_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE blog_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_tag_id_seq OWNER TO admin;

--
-- Name: blog_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE blog_tag_id_seq OWNED BY blog_tag.id;


--
-- Name: coffees_brewmethod; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_brewmethod (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    img character varying(100) NOT NULL,
    name_en character varying(32),
    name_zh_hans character varying(32),
    slug character varying(20) NOT NULL
);


ALTER TABLE coffees_brewmethod OWNER TO admin;

--
-- Name: coffees_brewmethod_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_brewmethod_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_brewmethod_id_seq OWNER TO admin;

--
-- Name: coffees_brewmethod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_brewmethod_id_seq OWNED BY coffees_brewmethod.id;


--
-- Name: coffees_coffeegear; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_coffeegear (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    essentials boolean NOT NULL,
    model character varying(32) NOT NULL,
    description character varying(512) NOT NULL,
    link character varying(256) NOT NULL,
    price numeric(6,2) NOT NULL,
    description_en character varying(512),
    description_zh_hans character varying(512),
    in_stock boolean NOT NULL,
    link_en character varying(256),
    link_zh_hans character varying(256),
    model_en character varying(32),
    model_zh_hans character varying(32),
    more_info text NOT NULL,
    more_info_en text,
    more_info_zh_hans text,
    name_en character varying(64),
    name_zh_hans character varying(64),
    special character varying(30) NOT NULL,
    allow_choice_package boolean NOT NULL,
    weight integer NOT NULL,
    available boolean NOT NULL,
    recommend boolean NOT NULL,
    the_order integer NOT NULL,
    CONSTRAINT coffees_coffeegear_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE coffees_coffeegear OWNER TO admin;

--
-- Name: coffees_coffeegear_brew_methods; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_coffeegear_brew_methods (
    id integer NOT NULL,
    coffeegear_id integer NOT NULL,
    brewmethod_id integer NOT NULL
);


ALTER TABLE coffees_coffeegear_brew_methods OWNER TO admin;

--
-- Name: coffees_coffeegear_brew_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_coffeegear_brew_methods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_coffeegear_brew_methods_id_seq OWNER TO admin;

--
-- Name: coffees_coffeegear_brew_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_coffeegear_brew_methods_id_seq OWNED BY coffees_coffeegear_brew_methods.id;


--
-- Name: coffees_coffeegear_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_coffeegear_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_coffeegear_id_seq OWNER TO admin;

--
-- Name: coffees_coffeegear_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_coffeegear_id_seq OWNED BY coffees_coffeegear.id;


--
-- Name: coffees_coffeegearcolor; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_coffeegearcolor (
    id integer NOT NULL,
    name character varying(30) NOT NULL
);


ALTER TABLE coffees_coffeegearcolor OWNER TO admin;

--
-- Name: coffees_coffeegearcolor_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_coffeegearcolor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_coffeegearcolor_id_seq OWNER TO admin;

--
-- Name: coffees_coffeegearcolor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_coffeegearcolor_id_seq OWNED BY coffees_coffeegearcolor.id;


--
-- Name: coffees_coffeegearimage; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_coffeegearimage (
    id integer NOT NULL,
    image character varying(100) NOT NULL,
    coffee_gear_id integer NOT NULL,
    color_id integer
);


ALTER TABLE coffees_coffeegearimage OWNER TO admin;

--
-- Name: coffees_coffeegearimage_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_coffeegearimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_coffeegearimage_id_seq OWNER TO admin;

--
-- Name: coffees_coffeegearimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_coffeegearimage_id_seq OWNED BY coffees_coffeegearimage.id;


--
-- Name: coffees_coffeesticker; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_coffeesticker (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    description character varying(256) NOT NULL,
    caption character varying(256) NOT NULL,
    hashtag character varying(256) NOT NULL,
    sticker character varying(100) NOT NULL,
    coffee_id integer NOT NULL
);


ALTER TABLE coffees_coffeesticker OWNER TO admin;

--
-- Name: coffees_coffeesticker_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_coffeesticker_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_coffeesticker_id_seq OWNER TO admin;

--
-- Name: coffees_coffeesticker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_coffeesticker_id_seq OWNED BY coffees_coffeesticker.id;


--
-- Name: coffees_coffeetype; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_coffeetype (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    maker character varying(128) NOT NULL,
    region character varying(64) NOT NULL,
    country character varying(2) NOT NULL,
    taste character varying(128) NOT NULL,
    more_taste character varying(512) NOT NULL,
    body integer NOT NULL,
    roasted_on date,
    shipping_till date,
    amount numeric(6,2) NOT NULL,
    profile hstore NOT NULL,
    img character varying(100) NOT NULL,
    description character varying(2048) NOT NULL,
    altitude character varying(32) NOT NULL,
    varietal character varying(64) NOT NULL,
    process character varying(32) NOT NULL,
    mode boolean NOT NULL,
    special boolean NOT NULL,
    label character varying(100) NOT NULL,
    label_drip character varying(100) NOT NULL,
    label_position integer NOT NULL,
    amount_one_off numeric(6,2) NOT NULL,
    intensity integer NOT NULL,
    decaf boolean NOT NULL,
    altitude_en character varying(32),
    altitude_zh_hans character varying(32),
    description_en character varying(2048),
    description_zh_hans character varying(2048),
    maker_en character varying(128),
    maker_zh_hans character varying(128),
    more_taste_en character varying(512),
    more_taste_zh_hans character varying(512),
    process_en character varying(32),
    process_zh_hans character varying(32),
    region_en character varying(64),
    region_zh_hans character varying(64),
    taste_en character varying(128),
    taste_zh_hans character varying(128),
    varietal_en character varying(64),
    varietal_zh_hans character varying(64),
    weight integer NOT NULL,
    acidity character varying(16) NOT NULL,
    blend boolean NOT NULL,
    discovery boolean NOT NULL,
    unavailable boolean NOT NULL,
    img_moreinfo character varying(100)
);


ALTER TABLE coffees_coffeetype OWNER TO admin;

--
-- Name: coffees_coffeetype_brew_method; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_coffeetype_brew_method (
    id integer NOT NULL,
    coffeetype_id integer NOT NULL,
    brewmethod_id integer NOT NULL
);


ALTER TABLE coffees_coffeetype_brew_method OWNER TO admin;

--
-- Name: coffees_coffeetype_brew_method_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_coffeetype_brew_method_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_coffeetype_brew_method_id_seq OWNER TO admin;

--
-- Name: coffees_coffeetype_brew_method_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_coffeetype_brew_method_id_seq OWNED BY coffees_coffeetype_brew_method.id;


--
-- Name: coffees_coffeetype_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_coffeetype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_coffeetype_id_seq OWNER TO admin;

--
-- Name: coffees_coffeetype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_coffeetype_id_seq OWNED BY coffees_coffeetype.id;


--
-- Name: coffees_farmphotos; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_farmphotos (
    id integer NOT NULL,
    photo1 character varying(100) NOT NULL,
    photo2 character varying(100) NOT NULL,
    photo3 character varying(100) NOT NULL,
    photo4 character varying(100) NOT NULL,
    photo5 character varying(100) NOT NULL,
    coffee_id integer NOT NULL
);


ALTER TABLE coffees_farmphotos OWNER TO admin;

--
-- Name: coffees_farmphotos_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_farmphotos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_farmphotos_id_seq OWNER TO admin;

--
-- Name: coffees_farmphotos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_farmphotos_id_seq OWNED BY coffees_farmphotos.id;


--
-- Name: coffees_flavor; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_flavor (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    img character varying(100) NOT NULL,
    name_en character varying(32),
    name_zh_hans character varying(32)
);


ALTER TABLE coffees_flavor OWNER TO admin;

--
-- Name: coffees_flavor_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_flavor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_flavor_id_seq OWNER TO admin;

--
-- Name: coffees_flavor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_flavor_id_seq OWNED BY coffees_flavor.id;


--
-- Name: coffees_rawbean; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_rawbean (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    stock numeric(6,2) NOT NULL,
    status boolean NOT NULL,
    created_date timestamp with time zone NOT NULL
);


ALTER TABLE coffees_rawbean OWNER TO admin;

--
-- Name: coffees_rawbean_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_rawbean_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_rawbean_id_seq OWNER TO admin;

--
-- Name: coffees_rawbean_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_rawbean_id_seq OWNED BY coffees_rawbean.id;


--
-- Name: coffees_sharedcoffeesticker; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE coffees_sharedcoffeesticker (
    id integer NOT NULL,
    "user" bigint NOT NULL,
    post bigint NOT NULL,
    hashtag character varying(256) NOT NULL,
    created timestamp with time zone NOT NULL,
    customer_id integer
);


ALTER TABLE coffees_sharedcoffeesticker OWNER TO admin;

--
-- Name: coffees_sharedcoffeesticker_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE coffees_sharedcoffeesticker_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coffees_sharedcoffeesticker_id_seq OWNER TO admin;

--
-- Name: coffees_sharedcoffeesticker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE coffees_sharedcoffeesticker_id_seq OWNED BY coffees_sharedcoffeesticker.id;


--
-- Name: content_brewguide; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_brewguide (
    id integer NOT NULL,
    name character varying(20) NOT NULL,
    name_en character varying(20),
    name_zh_hans character varying(20),
    description text NOT NULL,
    description_en text,
    description_zh_hans text,
    video character varying(20) NOT NULL,
    required_list text NOT NULL,
    required_list_en text,
    required_list_zh_hans text,
    brew_time character varying(50) NOT NULL,
    brew_time_en character varying(50),
    brew_time_zh_hans character varying(50),
    img character varying(100) NOT NULL,
    banner character varying(100) NOT NULL,
    slug character varying(20) NOT NULL,
    banner_img_bcolor character varying(7) NOT NULL,
    banner_txt_bcolor character varying(7) NOT NULL,
    subtitle character varying(20) NOT NULL,
    subtitle_en character varying(20),
    subtitle_zh_hans character varying(20)
);


ALTER TABLE content_brewguide OWNER TO admin;

--
-- Name: content_brewguide_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_brewguide_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_brewguide_id_seq OWNER TO admin;

--
-- Name: content_brewguide_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_brewguide_id_seq OWNED BY content_brewguide.id;


--
-- Name: content_brewguidestep; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_brewguidestep (
    id integer NOT NULL,
    img character varying(100),
    description text NOT NULL,
    description_en text,
    description_zh_hans text,
    brew_guide_id integer NOT NULL
);


ALTER TABLE content_brewguidestep OWNER TO admin;

--
-- Name: content_brewguidestep_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_brewguidestep_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_brewguidestep_id_seq OWNER TO admin;

--
-- Name: content_brewguidestep_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_brewguidestep_id_seq OWNED BY content_brewguidestep.id;


--
-- Name: content_career; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_career (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    description character varying(1024) NOT NULL,
    active boolean NOT NULL,
    img character varying(100) NOT NULL,
    description_en character varying(1024),
    description_zh_hans character varying(1024),
    title_en character varying(128),
    title_zh_hans character varying(128)
);


ALTER TABLE content_career OWNER TO admin;

--
-- Name: content_career_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_career_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_career_id_seq OWNER TO admin;

--
-- Name: content_career_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_career_id_seq OWNED BY content_career.id;


--
-- Name: content_greeting; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_greeting (
    id integer NOT NULL,
    time_of_day character varying(16) NOT NULL,
    line1 character varying(128) NOT NULL,
    line1_en character varying(128),
    line1_zh_hans character varying(128),
    line2 character varying(256) NOT NULL,
    line2_en character varying(256),
    line2_zh_hans character varying(256),
    line3 character varying(512) NOT NULL,
    line3_en character varying(512),
    line3_zh_hans character varying(512)
);


ALTER TABLE content_greeting OWNER TO admin;

--
-- Name: content_greeting_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_greeting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_greeting_id_seq OWNER TO admin;

--
-- Name: content_greeting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_greeting_id_seq OWNED BY content_greeting.id;


--
-- Name: content_instagrampost; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_instagrampost (
    id integer NOT NULL,
    url character varying(256) NOT NULL,
    data hstore NOT NULL
);


ALTER TABLE content_instagrampost OWNER TO admin;

--
-- Name: content_instagrampost_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_instagrampost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_instagrampost_id_seq OWNER TO admin;

--
-- Name: content_instagrampost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_instagrampost_id_seq OWNED BY content_instagrampost.id;


--
-- Name: content_post; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_post (
    id integer NOT NULL,
    title character varying(128) NOT NULL,
    message character varying(1536) NOT NULL,
    section_id integer NOT NULL,
    message_en character varying(1536),
    message_zh_hans character varying(1536),
    title_en character varying(128),
    title_zh_hans character varying(128)
);


ALTER TABLE content_post OWNER TO admin;

--
-- Name: content_post_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_post_id_seq OWNER TO admin;

--
-- Name: content_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_post_id_seq OWNED BY content_post.id;


--
-- Name: content_review; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_review (
    id integer NOT NULL,
    author character varying(128) NOT NULL,
    message character varying(1536) NOT NULL,
    author_en character varying(128),
    author_zh_hans character varying(128),
    message_en character varying(1536),
    message_zh_hans character varying(1536),
    is_workplace boolean NOT NULL,
    logo character varying(100)
);


ALTER TABLE content_review OWNER TO admin;

--
-- Name: content_review_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_review_id_seq OWNER TO admin;

--
-- Name: content_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_review_id_seq OWNED BY content_review.id;


--
-- Name: content_section; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_section (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    name_en character varying(32),
    name_zh_hans character varying(32)
);


ALTER TABLE content_section OWNER TO admin;

--
-- Name: content_section_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_section_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_section_id_seq OWNER TO admin;

--
-- Name: content_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_section_id_seq OWNED BY content_section.id;


--
-- Name: content_topbar; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE content_topbar (
    id integer NOT NULL,
    block_text character varying(256) NOT NULL,
    button_text character varying(36) NOT NULL,
    link character varying(256) NOT NULL,
    visible boolean NOT NULL
);


ALTER TABLE content_topbar OWNER TO admin;

--
-- Name: content_topbar_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE content_topbar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE content_topbar_id_seq OWNER TO admin;

--
-- Name: content_topbar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE content_topbar_id_seq OWNED BY content_topbar.id;


--
-- Name: customauth_login; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customauth_login (
    id integer NOT NULL,
    username character varying(32) NOT NULL,
    password character varying(255) NOT NULL,
    accesstoken character varying(255) NOT NULL,
    created timestamp with time zone NOT NULL
);


ALTER TABLE customauth_login OWNER TO admin;

--
-- Name: customauth_login_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customauth_login_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customauth_login_id_seq OWNER TO admin;

--
-- Name: customauth_login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customauth_login_id_seq OWNED BY customauth_login.id;


--
-- Name: customauth_myuser; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customauth_myuser (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    email character varying(255) NOT NULL,
    is_active boolean NOT NULL,
    is_admin boolean NOT NULL,
    is_superuser boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE customauth_myuser OWNER TO admin;

--
-- Name: customauth_myuser_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customauth_myuser_groups (
    id integer NOT NULL,
    myuser_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE customauth_myuser_groups OWNER TO admin;

--
-- Name: customauth_myuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customauth_myuser_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customauth_myuser_groups_id_seq OWNER TO admin;

--
-- Name: customauth_myuser_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customauth_myuser_groups_id_seq OWNED BY customauth_myuser_groups.id;


--
-- Name: customauth_myuser_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customauth_myuser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customauth_myuser_id_seq OWNER TO admin;

--
-- Name: customauth_myuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customauth_myuser_id_seq OWNED BY customauth_myuser.id;


--
-- Name: customauth_myuser_user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customauth_myuser_user_permissions (
    id integer NOT NULL,
    myuser_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE customauth_myuser_user_permissions OWNER TO admin;

--
-- Name: customauth_myuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customauth_myuser_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customauth_myuser_user_permissions_id_seq OWNER TO admin;

--
-- Name: customauth_myuser_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customauth_myuser_user_permissions_id_seq OWNED BY customauth_myuser_user_permissions.id;


--
-- Name: customers_address; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_address (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    recipient_name character varying(255) NOT NULL,
    country character varying(2) NOT NULL,
    line1 character varying(255) NOT NULL,
    line2 character varying(255) NOT NULL,
    postcode character varying(13) NOT NULL,
    is_primary boolean NOT NULL,
    customer_id integer NOT NULL
);


ALTER TABLE customers_address OWNER TO admin;

--
-- Name: customers_address_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_address_id_seq OWNER TO admin;

--
-- Name: customers_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_address_id_seq OWNED BY customers_address.id;


--
-- Name: customers_cardfingerprint; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_cardfingerprint (
    id integer NOT NULL,
    fingerprint character varying(128) NOT NULL,
    customer_id integer
);


ALTER TABLE customers_cardfingerprint OWNER TO admin;

--
-- Name: customers_cardfingerprint_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_cardfingerprint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_cardfingerprint_id_seq OWNER TO admin;

--
-- Name: customers_cardfingerprint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_cardfingerprint_id_seq OWNED BY customers_cardfingerprint.id;


--
-- Name: customers_charge; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_charge (
    id integer NOT NULL,
    amount character varying(32) NOT NULL,
    description character varying(255) NOT NULL,
    metadata hstore NOT NULL,
    date timestamp with time zone NOT NULL,
    stripe_id character varying(255) NOT NULL,
    customer_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE customers_charge OWNER TO admin;

--
-- Name: customers_charge_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_charge_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_charge_id_seq OWNER TO admin;

--
-- Name: customers_charge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_charge_id_seq OWNED BY customers_charge.id;


--
-- Name: customers_coffeereview; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_coffeereview (
    id integer NOT NULL,
    rating integer,
    comment text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    coffee_id integer NOT NULL,
    order_id integer NOT NULL
);


ALTER TABLE customers_coffeereview OWNER TO admin;

--
-- Name: customers_coffeereview_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_coffeereview_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_coffeereview_id_seq OWNER TO admin;

--
-- Name: customers_coffeereview_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_coffeereview_id_seq OWNED BY customers_coffeereview.id;


--
-- Name: customers_customer; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_customer (
    id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    line1 character varying(255) NOT NULL,
    line2 character varying(255) NOT NULL,
    postcode character varying(13) NOT NULL,
    stripe_id character varying(255) NOT NULL,
    user_id integer NOT NULL,
    card_details character varying(10),
    phone character varying(10) NOT NULL,
    amount integer NOT NULL,
    country character varying(2) NOT NULL,
    extra hstore,
    discounts hstore NOT NULL
);


ALTER TABLE customers_customer OWNER TO admin;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_customer_id_seq OWNER TO admin;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_customer_id_seq OWNED BY customers_customer.id;


--
-- Name: customers_customer_received_coffee_samples; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_customer_received_coffee_samples (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    coffeetype_id integer NOT NULL
);


ALTER TABLE customers_customer_received_coffee_samples OWNER TO admin;

--
-- Name: customers_customer_received_coffee_samples_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_customer_received_coffee_samples_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_customer_received_coffee_samples_id_seq OWNER TO admin;

--
-- Name: customers_customer_received_coffee_samples_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_customer_received_coffee_samples_id_seq OWNED BY customers_customer_received_coffee_samples.id;


--
-- Name: customers_customer_vouchers; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_customer_vouchers (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    voucher_id integer NOT NULL
);


ALTER TABLE customers_customer_vouchers OWNER TO admin;

--
-- Name: customers_customer_vouchers_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_customer_vouchers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_customer_vouchers_id_seq OWNER TO admin;

--
-- Name: customers_customer_vouchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_customer_vouchers_id_seq OWNED BY customers_customer_vouchers.id;


--
-- Name: customers_facebookcustomer; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_facebookcustomer (
    id integer NOT NULL,
    facebook_id character varying(255) NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    gender character varying(255) NOT NULL,
    customer_id integer
);


ALTER TABLE customers_facebookcustomer OWNER TO admin;

--
-- Name: customers_facebookcustomer_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_facebookcustomer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_facebookcustomer_id_seq OWNER TO admin;

--
-- Name: customers_facebookcustomer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_facebookcustomer_id_seq OWNED BY customers_facebookcustomer.id;


--
-- Name: customers_gearorder; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_gearorder (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    shipping_date timestamp with time zone,
    price numeric(6,2) NOT NULL,
    status character varying(16) NOT NULL,
    details hstore,
    customer_id integer NOT NULL,
    gear_id integer NOT NULL,
    tracking_number character varying(30) NOT NULL,
    voucher_id integer,
    address_id integer
);


ALTER TABLE customers_gearorder OWNER TO admin;

--
-- Name: customers_gearorder_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_gearorder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_gearorder_id_seq OWNER TO admin;

--
-- Name: customers_gearorder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_gearorder_id_seq OWNED BY customers_gearorder.id;


--
-- Name: customers_order; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_order (
    id integer NOT NULL,
    different boolean NOT NULL,
    date timestamp with time zone NOT NULL,
    shipping_date timestamp with time zone,
    amount numeric(6,2) NOT NULL,
    "interval" integer NOT NULL,
    recurrent boolean NOT NULL,
    status character varying(16) NOT NULL,
    package character varying(16) NOT NULL,
    brew_id integer NOT NULL,
    coffee_id integer NOT NULL,
    customer_id integer NOT NULL,
    voucher_id integer,
    feedback character varying(16),
    details hstore NOT NULL,
    resent boolean NOT NULL,
    custom_price boolean NOT NULL,
    address_id integer,
    CONSTRAINT customers_order_interval_check CHECK (("interval" >= 0))
);


ALTER TABLE customers_order OWNER TO admin;

--
-- Name: customers_order_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_order_id_seq OWNER TO admin;

--
-- Name: customers_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_order_id_seq OWNED BY customers_order.id;


--
-- Name: customers_plan; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_plan (
    id integer NOT NULL,
    plan character varying(32) NOT NULL,
    name character varying(255) NOT NULL,
    currency character varying(4) NOT NULL,
    amount integer NOT NULL,
    metadata hstore NOT NULL,
    "interval" character varying(16) NOT NULL,
    interval_count integer NOT NULL,
    stripe_id character varying(64) NOT NULL
);


ALTER TABLE customers_plan OWNER TO admin;

--
-- Name: customers_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_plan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_plan_id_seq OWNER TO admin;

--
-- Name: customers_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_plan_id_seq OWNED BY customers_plan.id;


--
-- Name: customers_postcard; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_postcard (
    id integer NOT NULL,
    customer_postcard character varying(100) NOT NULL
);


ALTER TABLE customers_postcard OWNER TO admin;

--
-- Name: customers_postcard_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_postcard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_postcard_id_seq OWNER TO admin;

--
-- Name: customers_postcard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_postcard_id_seq OWNED BY customers_postcard.id;


--
-- Name: customers_preferences; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_preferences (
    id integer NOT NULL,
    package character varying(16) NOT NULL,
    decaf boolean NOT NULL,
    different boolean NOT NULL,
    cups integer NOT NULL,
    intense integer NOT NULL,
    "interval" integer NOT NULL,
    force_coffee boolean NOT NULL,
    brew_id integer,
    coffee_id integer,
    customer_id integer NOT NULL,
    present_next boolean NOT NULL,
    different_pods boolean NOT NULL,
    force_coffee_pods boolean NOT NULL,
    interval_pods integer NOT NULL,
    CONSTRAINT customers_preferences_cups_check CHECK ((cups >= 0)),
    CONSTRAINT customers_preferences_intense_check CHECK ((intense >= 0)),
    CONSTRAINT customers_preferences_interval_check CHECK (("interval" >= 0)),
    CONSTRAINT customers_preferences_interval_pods_check CHECK ((interval_pods >= 0))
);


ALTER TABLE customers_preferences OWNER TO admin;

--
-- Name: customers_preferences_flavor; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_preferences_flavor (
    id integer NOT NULL,
    preferences_id integer NOT NULL,
    flavor_id integer NOT NULL
);


ALTER TABLE customers_preferences_flavor OWNER TO admin;

--
-- Name: customers_preferences_flavor_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_preferences_flavor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_preferences_flavor_id_seq OWNER TO admin;

--
-- Name: customers_preferences_flavor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_preferences_flavor_id_seq OWNED BY customers_preferences_flavor.id;


--
-- Name: customers_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_preferences_id_seq OWNER TO admin;

--
-- Name: customers_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_preferences_id_seq OWNED BY customers_preferences.id;


--
-- Name: customers_reference; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_reference (
    id integer NOT NULL,
    referred_id integer NOT NULL,
    referrer_id integer NOT NULL
);


ALTER TABLE customers_reference OWNER TO admin;

--
-- Name: customers_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_reference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_reference_id_seq OWNER TO admin;

--
-- Name: customers_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_reference_id_seq OWNED BY customers_reference.id;


--
-- Name: customers_referral; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_referral (
    id integer NOT NULL,
    aim character varying(16) NOT NULL,
    code character varying(64),
    status character varying(16) NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE customers_referral OWNER TO admin;

--
-- Name: customers_referral_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_referral_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_referral_id_seq OWNER TO admin;

--
-- Name: customers_referral_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_referral_id_seq OWNED BY customers_referral.id;


--
-- Name: customers_shoppingcart; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_shoppingcart (
    customer_id integer NOT NULL,
    content text NOT NULL,
    last_modified timestamp with time zone NOT NULL,
    first_reminder boolean NOT NULL,
    second_reminder boolean NOT NULL,
    voucher_id integer
);


ALTER TABLE customers_shoppingcart OWNER TO admin;

--
-- Name: customers_subscription; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_subscription (
    id integer NOT NULL,
    metadata hstore NOT NULL,
    stripe_id character varying(255) NOT NULL,
    status character varying(32) NOT NULL,
    customer_id integer NOT NULL,
    plan_id integer NOT NULL
);


ALTER TABLE customers_subscription OWNER TO admin;

--
-- Name: customers_subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_subscription_id_seq OWNER TO admin;

--
-- Name: customers_subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_subscription_id_seq OWNED BY customers_subscription.id;


--
-- Name: customers_voucher; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_voucher (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    discount integer NOT NULL,
    count smallint NOT NULL,
    discount2 integer NOT NULL,
    mode boolean NOT NULL,
    category_id integer NOT NULL,
    email character varying(64),
    personal boolean NOT NULL,
    CONSTRAINT customers_voucher_count_check CHECK ((count >= 0))
);


ALTER TABLE customers_voucher OWNER TO admin;

--
-- Name: customers_voucher_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_voucher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_voucher_id_seq OWNER TO admin;

--
-- Name: customers_voucher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_voucher_id_seq OWNED BY customers_voucher.id;


--
-- Name: customers_vouchercategory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE customers_vouchercategory (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    "desc" text NOT NULL
);


ALTER TABLE customers_vouchercategory OWNER TO admin;

--
-- Name: customers_vouchercategory_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE customers_vouchercategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE customers_vouchercategory_id_seq OWNER TO admin;

--
-- Name: customers_vouchercategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE customers_vouchercategory_id_seq OWNED BY customers_vouchercategory.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_migrations_copy1; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE django_migrations_copy1 (
    id integer DEFAULT nextval('django_migrations_id_seq'::regclass) NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp(6) with time zone NOT NULL
);


ALTER TABLE django_migrations_copy1 OWNER TO admin;

--
-- Name: django_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO admin;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE django_site OWNER TO admin;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_site_id_seq OWNER TO admin;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: get_started_getstartedresponse; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE get_started_getstartedresponse (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    email character varying(254) NOT NULL,
    form_details hstore NOT NULL,
    created timestamp with time zone NOT NULL,
    ct_id integer,
    sent_emails text
);


ALTER TABLE get_started_getstartedresponse OWNER TO admin;

--
-- Name: get_started_getstartedresponse_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE get_started_getstartedresponse_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE get_started_getstartedresponse_id_seq OWNER TO admin;

--
-- Name: get_started_getstartedresponse_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE get_started_getstartedresponse_id_seq OWNED BY get_started_getstartedresponse.id;


--
-- Name: get_started_giftvoucher; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE get_started_giftvoucher (
    id integer NOT NULL,
    used boolean NOT NULL,
    recipient character varying(64) NOT NULL,
    amount integer NOT NULL,
    code character varying(32) NOT NULL,
    created timestamp with time zone NOT NULL,
    sender_email character varying(64) NOT NULL,
    sender_fname character varying(64) NOT NULL,
    sender_lname character varying(64) NOT NULL
);


ALTER TABLE get_started_giftvoucher OWNER TO admin;

--
-- Name: get_started_giftvoucher_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE get_started_giftvoucher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE get_started_giftvoucher_id_seq OWNER TO admin;

--
-- Name: get_started_giftvoucher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE get_started_giftvoucher_id_seq OWNED BY get_started_giftvoucher.id;


--
-- Name: get_started_podsearlybird; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE get_started_podsearlybird (
    id integer NOT NULL,
    email character varying(64) NOT NULL,
    date timestamp with time zone NOT NULL
);


ALTER TABLE get_started_podsearlybird OWNER TO admin;

--
-- Name: get_started_podsearlybird_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE get_started_podsearlybird_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE get_started_podsearlybird_id_seq OWNER TO admin;

--
-- Name: get_started_podsearlybird_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE get_started_podsearlybird_id_seq OWNED BY get_started_podsearlybird.id;


--
-- Name: get_started_referralvoucher; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE get_started_referralvoucher (
    id integer NOT NULL,
    used boolean NOT NULL,
    recipient_email character varying(64) NOT NULL,
    discount_percent integer NOT NULL,
    discount_sgd integer NOT NULL,
    code character varying(32) NOT NULL,
    date timestamp with time zone NOT NULL,
    sender_id integer NOT NULL
);


ALTER TABLE get_started_referralvoucher OWNER TO admin;

--
-- Name: get_started_referralvoucher_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE get_started_referralvoucher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE get_started_referralvoucher_id_seq OWNER TO admin;

--
-- Name: get_started_referralvoucher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE get_started_referralvoucher_id_seq OWNED BY get_started_referralvoucher.id;


--
-- Name: loyale_coffeetypepoints; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_coffeetypepoints (
    id integer NOT NULL,
    status character varying(32),
    points integer NOT NULL,
    coffee_type_id integer NOT NULL
);


ALTER TABLE loyale_coffeetypepoints OWNER TO admin;

--
-- Name: loyale_coffeetypepoints_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_coffeetypepoints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_coffeetypepoints_id_seq OWNER TO admin;

--
-- Name: loyale_coffeetypepoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_coffeetypepoints_id_seq OWNED BY loyale_coffeetypepoints.id;


--
-- Name: loyale_grantpointlog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_grantpointlog (
    id integer NOT NULL,
    points integer NOT NULL,
    added timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE loyale_grantpointlog OWNER TO admin;

--
-- Name: loyale_grantpointlog_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_grantpointlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_grantpointlog_id_seq OWNER TO admin;

--
-- Name: loyale_grantpointlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_grantpointlog_id_seq OWNED BY loyale_grantpointlog.id;


--
-- Name: loyale_helper; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_helper (
    id integer NOT NULL,
    emails_rewards_sent boolean NOT NULL,
    emails_rewards_sent_count integer NOT NULL
);


ALTER TABLE loyale_helper OWNER TO admin;

--
-- Name: loyale_helper_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_helper_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_helper_id_seq OWNER TO admin;

--
-- Name: loyale_helper_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_helper_id_seq OWNED BY loyale_helper.id;


--
-- Name: loyale_item; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_item (
    id integer NOT NULL,
    name character varying(200),
    description character varying(200),
    points integer NOT NULL,
    added timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    img character varying(100) NOT NULL,
    in_stock boolean NOT NULL
);


ALTER TABLE loyale_item OWNER TO admin;

--
-- Name: loyale_item_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_item_id_seq OWNER TO admin;

--
-- Name: loyale_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_item_id_seq OWNED BY loyale_item.id;


--
-- Name: loyale_orderpoints; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_orderpoints (
    id integer NOT NULL,
    sub_regular integer NOT NULL,
    sub_special integer NOT NULL,
    one_regular integer NOT NULL,
    one_special integer NOT NULL,
    credits integer NOT NULL,
    one_pod integer NOT NULL,
    sub_pod integer NOT NULL
);


ALTER TABLE loyale_orderpoints OWNER TO admin;

--
-- Name: loyale_orderpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_orderpoints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_orderpoints_id_seq OWNER TO admin;

--
-- Name: loyale_orderpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_orderpoints_id_seq OWNED BY loyale_orderpoints.id;


--
-- Name: loyale_point; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_point (
    id integer NOT NULL,
    points integer NOT NULL,
    added timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE loyale_point OWNER TO admin;

--
-- Name: loyale_point_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_point_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_point_id_seq OWNER TO admin;

--
-- Name: loyale_point_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_point_id_seq OWNED BY loyale_point.id;


--
-- Name: loyale_redemitem; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_redemitem (
    id integer NOT NULL,
    status character varying(32) NOT NULL,
    points integer NOT NULL,
    shipping_date timestamp with time zone,
    added timestamp with time zone NOT NULL,
    item_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE loyale_redemitem OWNER TO admin;

--
-- Name: loyale_redemitem_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_redemitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_redemitem_id_seq OWNER TO admin;

--
-- Name: loyale_redemitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_redemitem_id_seq OWNED BY loyale_redemitem.id;


--
-- Name: loyale_redempointlog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_redempointlog (
    id integer NOT NULL,
    points integer NOT NULL,
    added timestamp with time zone NOT NULL,
    item_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE loyale_redempointlog OWNER TO admin;

--
-- Name: loyale_redempointlog_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_redempointlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_redempointlog_id_seq OWNER TO admin;

--
-- Name: loyale_redempointlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_redempointlog_id_seq OWNED BY loyale_redempointlog.id;


--
-- Name: loyale_setpoint; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE loyale_setpoint (
    id integer NOT NULL,
    status character varying(32) NOT NULL,
    points integer NOT NULL
);


ALTER TABLE loyale_setpoint OWNER TO admin;

--
-- Name: loyale_setpoint_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE loyale_setpoint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE loyale_setpoint_id_seq OWNER TO admin;

--
-- Name: loyale_setpoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE loyale_setpoint_id_seq OWNED BY loyale_setpoint.id;


--
-- Name: manager_churnratedata; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_churnratedata (
    id integer NOT NULL,
    month_year character varying(255) NOT NULL,
    proportion_churned numeric(10,6) NOT NULL
);


ALTER TABLE manager_churnratedata OWNER TO admin;

--
-- Name: manager_churnratedata_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_churnratedata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_churnratedata_id_seq OWNER TO admin;

--
-- Name: manager_churnratedata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_churnratedata_id_seq OWNED BY manager_churnratedata.id;


--
-- Name: manager_clusterdf; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_clusterdf (
    id integer NOT NULL,
    data text NOT NULL
);


ALTER TABLE manager_clusterdf OWNER TO admin;

--
-- Name: manager_clusterdf_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_clusterdf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_clusterdf_id_seq OWNER TO admin;

--
-- Name: manager_clusterdf_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_clusterdf_id_seq OWNED BY manager_clusterdf.id;


--
-- Name: manager_customercluster; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_customercluster (
    id integer NOT NULL,
    cluster_number integer NOT NULL,
    cluster_name character varying(255) NOT NULL,
    cluster_description character varying(255) NOT NULL,
    mean_orders numeric(6,2) NOT NULL,
    mean_ratio_amount_time numeric(6,2) NOT NULL,
    mean_vouchers_used numeric(6,2) NOT NULL,
    mean_interval numeric(6,2) NOT NULL,
    mean_total_spending numeric(6,2) NOT NULL,
    mean_one_off_orders numeric(6,2) NOT NULL,
    cluster_revenue numeric(10,2) NOT NULL,
    customers hstore NOT NULL,
    percentage_brew_methods hstore NOT NULL
);


ALTER TABLE manager_customercluster OWNER TO admin;

--
-- Name: manager_customercluster_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_customercluster_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_customercluster_id_seq OWNER TO admin;

--
-- Name: manager_customercluster_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_customercluster_id_seq OWNED BY manager_customercluster.id;


--
-- Name: manager_fyporderstats; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_fyporderstats (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    order_id integer NOT NULL
);


ALTER TABLE manager_fyporderstats OWNER TO admin;

--
-- Name: manager_fyporderstats_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_fyporderstats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_fyporderstats_id_seq OWNER TO admin;

--
-- Name: manager_fyporderstats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_fyporderstats_id_seq OWNED BY manager_fyporderstats.id;


--
-- Name: manager_intercomlocal; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_intercomlocal (
    id integer NOT NULL,
    event character varying(255) NOT NULL,
    data text NOT NULL,
    added_timestamp timestamp with time zone NOT NULL,
    customer_id integer NOT NULL
);


ALTER TABLE manager_intercomlocal OWNER TO admin;

--
-- Name: manager_intercomlocal_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_intercomlocal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_intercomlocal_id_seq OWNER TO admin;

--
-- Name: manager_intercomlocal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_intercomlocal_id_seq OWNED BY manager_intercomlocal.id;


--
-- Name: manager_mailchimpcampaignstats; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_mailchimpcampaignstats (
    id integer NOT NULL,
    action character varying(16) NOT NULL,
    email character varying(255) NOT NULL,
    campaign_id character varying(255) NOT NULL,
    order_id integer
);


ALTER TABLE manager_mailchimpcampaignstats OWNER TO admin;

--
-- Name: manager_mailchimpcampaignstats_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_mailchimpcampaignstats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_mailchimpcampaignstats_id_seq OWNER TO admin;

--
-- Name: manager_mailchimpcampaignstats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_mailchimpcampaignstats_id_seq OWNED BY manager_mailchimpcampaignstats.id;


--
-- Name: manager_rawbeanstats; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_rawbeanstats (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    raw_bean_id integer NOT NULL,
    status boolean NOT NULL,
    stock numeric(6,2) NOT NULL
);


ALTER TABLE manager_rawbeanstats OWNER TO admin;

--
-- Name: manager_rawbeanstats_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_rawbeanstats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_rawbeanstats_id_seq OWNER TO admin;

--
-- Name: manager_rawbeanstats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_rawbeanstats_id_seq OWNED BY manager_rawbeanstats.id;


--
-- Name: manager_recommendation; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_recommendation (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    facebook_advertising_cost numeric(10,2) NOT NULL,
    adwords_cost numeric(10,2) NOT NULL,
    new_coffees integer NOT NULL,
    email_campaigns integer NOT NULL,
    roadshows integer NOT NULL,
    blog_posts integer NOT NULL,
    budget integer NOT NULL,
    expected_demand double precision NOT NULL,
    demand_actualising double precision NOT NULL
);


ALTER TABLE manager_recommendation OWNER TO admin;

--
-- Name: manager_recommendation_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_recommendation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_recommendation_id_seq OWNER TO admin;

--
-- Name: manager_recommendation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_recommendation_id_seq OWNED BY manager_recommendation.id;


--
-- Name: manager_reportcard; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_reportcard (
    id integer NOT NULL,
    date timestamp with time zone NOT NULL,
    active_customers integer NOT NULL,
    orders integer NOT NULL,
    churn integer NOT NULL,
    new_signups integer NOT NULL,
    expected_demand double precision NOT NULL,
    demand_actualising double precision NOT NULL,
    deviation double precision NOT NULL,
    actions hstore NOT NULL,
    percentage_changes hstore NOT NULL
);


ALTER TABLE manager_reportcard OWNER TO admin;

--
-- Name: manager_reportcard_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_reportcard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_reportcard_id_seq OWNER TO admin;

--
-- Name: manager_reportcard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_reportcard_id_seq OWNED BY manager_reportcard.id;


--
-- Name: manager_threshold; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE manager_threshold (
    id integer NOT NULL,
    amount numeric(6,2) NOT NULL,
    date timestamp with time zone NOT NULL
);


ALTER TABLE manager_threshold OWNER TO admin;

--
-- Name: manager_threshold_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE manager_threshold_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE manager_threshold_id_seq OWNER TO admin;

--
-- Name: manager_threshold_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE manager_threshold_id_seq OWNED BY manager_threshold.id;


--
-- Name: reminders_reminder; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE reminders_reminder (
    id integer NOT NULL,
    username character varying(32) NOT NULL,
    email character varying(254) NOT NULL,
    from_email character varying(100) NOT NULL,
    subject character varying(100) NOT NULL,
    template_name character varying(100) NOT NULL,
    created timestamp with time zone NOT NULL,
    resumed timestamp with time zone,
    scheduled timestamp with time zone NOT NULL,
    completed boolean NOT NULL,
    order_id integer,
    voucher_id integer,
    recommended_coffee_id integer
);


ALTER TABLE reminders_reminder OWNER TO admin;

--
-- Name: reminders_reminder_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE reminders_reminder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reminders_reminder_id_seq OWNER TO admin;

--
-- Name: reminders_reminder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE reminders_reminder_id_seq OWNED BY reminders_reminder.id;


--
-- Name: wholesale_plan; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE wholesale_plan (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    goal_1 character varying(128) NOT NULL,
    goal_2 character varying(128),
    goal_2_note character varying(128),
    description_1 character varying(128) NOT NULL,
    description_2 character varying(128),
    description_2_note character varying(128),
    comments character varying(256) NOT NULL,
    price numeric(6,2),
    img character varying(100) NOT NULL,
    comments_en character varying(256),
    comments_zh_hans character varying(256),
    description_1_en character varying(128),
    description_1_zh_hans character varying(128),
    description_2_en character varying(128),
    description_2_note_en character varying(128),
    description_2_note_zh_hans character varying(128),
    description_2_zh_hans character varying(128),
    goal_1_en character varying(128),
    goal_1_zh_hans character varying(128),
    goal_2_en character varying(128),
    goal_2_note_en character varying(128),
    goal_2_note_zh_hans character varying(128),
    goal_2_zh_hans character varying(128),
    name_en character varying(64),
    name_zh_hans character varying(64),
    office_type character varying(48),
    the_order integer NOT NULL,
    CONSTRAINT wholesale_plan_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE wholesale_plan OWNER TO admin;

--
-- Name: wholesale_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE wholesale_plan_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE wholesale_plan_id_seq OWNER TO admin;

--
-- Name: wholesale_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE wholesale_plan_id_seq OWNED BY wholesale_plan.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: blog_category id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_category ALTER COLUMN id SET DEFAULT nextval('blog_category_id_seq'::regclass);


--
-- Name: blog_post id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post ALTER COLUMN id SET DEFAULT nextval('blog_post_id_seq'::regclass);


--
-- Name: blog_post_tags id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post_tags ALTER COLUMN id SET DEFAULT nextval('blog_post_tags_id_seq'::regclass);


--
-- Name: blog_tag id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_tag ALTER COLUMN id SET DEFAULT nextval('blog_tag_id_seq'::regclass);


--
-- Name: coffees_brewmethod id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_brewmethod ALTER COLUMN id SET DEFAULT nextval('coffees_brewmethod_id_seq'::regclass);


--
-- Name: coffees_coffeegear id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegear ALTER COLUMN id SET DEFAULT nextval('coffees_coffeegear_id_seq'::regclass);


--
-- Name: coffees_coffeegear_brew_methods id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegear_brew_methods ALTER COLUMN id SET DEFAULT nextval('coffees_coffeegear_brew_methods_id_seq'::regclass);


--
-- Name: coffees_coffeegearcolor id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegearcolor ALTER COLUMN id SET DEFAULT nextval('coffees_coffeegearcolor_id_seq'::regclass);


--
-- Name: coffees_coffeegearimage id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegearimage ALTER COLUMN id SET DEFAULT nextval('coffees_coffeegearimage_id_seq'::regclass);


--
-- Name: coffees_coffeesticker id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeesticker ALTER COLUMN id SET DEFAULT nextval('coffees_coffeesticker_id_seq'::regclass);


--
-- Name: coffees_coffeetype id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeetype ALTER COLUMN id SET DEFAULT nextval('coffees_coffeetype_id_seq'::regclass);


--
-- Name: coffees_coffeetype_brew_method id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeetype_brew_method ALTER COLUMN id SET DEFAULT nextval('coffees_coffeetype_brew_method_id_seq'::regclass);


--
-- Name: coffees_farmphotos id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_farmphotos ALTER COLUMN id SET DEFAULT nextval('coffees_farmphotos_id_seq'::regclass);


--
-- Name: coffees_flavor id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_flavor ALTER COLUMN id SET DEFAULT nextval('coffees_flavor_id_seq'::regclass);


--
-- Name: coffees_rawbean id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_rawbean ALTER COLUMN id SET DEFAULT nextval('coffees_rawbean_id_seq'::regclass);


--
-- Name: coffees_sharedcoffeesticker id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_sharedcoffeesticker ALTER COLUMN id SET DEFAULT nextval('coffees_sharedcoffeesticker_id_seq'::regclass);


--
-- Name: content_brewguide id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_brewguide ALTER COLUMN id SET DEFAULT nextval('content_brewguide_id_seq'::regclass);


--
-- Name: content_brewguidestep id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_brewguidestep ALTER COLUMN id SET DEFAULT nextval('content_brewguidestep_id_seq'::regclass);


--
-- Name: content_career id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_career ALTER COLUMN id SET DEFAULT nextval('content_career_id_seq'::regclass);


--
-- Name: content_greeting id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_greeting ALTER COLUMN id SET DEFAULT nextval('content_greeting_id_seq'::regclass);


--
-- Name: content_instagrampost id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_instagrampost ALTER COLUMN id SET DEFAULT nextval('content_instagrampost_id_seq'::regclass);


--
-- Name: content_post id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_post ALTER COLUMN id SET DEFAULT nextval('content_post_id_seq'::regclass);


--
-- Name: content_review id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_review ALTER COLUMN id SET DEFAULT nextval('content_review_id_seq'::regclass);


--
-- Name: content_section id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_section ALTER COLUMN id SET DEFAULT nextval('content_section_id_seq'::regclass);


--
-- Name: content_topbar id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_topbar ALTER COLUMN id SET DEFAULT nextval('content_topbar_id_seq'::regclass);


--
-- Name: customauth_login id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_login ALTER COLUMN id SET DEFAULT nextval('customauth_login_id_seq'::regclass);


--
-- Name: customauth_myuser id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser ALTER COLUMN id SET DEFAULT nextval('customauth_myuser_id_seq'::regclass);


--
-- Name: customauth_myuser_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_groups ALTER COLUMN id SET DEFAULT nextval('customauth_myuser_groups_id_seq'::regclass);


--
-- Name: customauth_myuser_user_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_user_permissions ALTER COLUMN id SET DEFAULT nextval('customauth_myuser_user_permissions_id_seq'::regclass);


--
-- Name: customers_address id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_address ALTER COLUMN id SET DEFAULT nextval('customers_address_id_seq'::regclass);


--
-- Name: customers_cardfingerprint id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_cardfingerprint ALTER COLUMN id SET DEFAULT nextval('customers_cardfingerprint_id_seq'::regclass);


--
-- Name: customers_charge id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_charge ALTER COLUMN id SET DEFAULT nextval('customers_charge_id_seq'::regclass);


--
-- Name: customers_coffeereview id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_coffeereview ALTER COLUMN id SET DEFAULT nextval('customers_coffeereview_id_seq'::regclass);


--
-- Name: customers_customer id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer ALTER COLUMN id SET DEFAULT nextval('customers_customer_id_seq'::regclass);


--
-- Name: customers_customer_received_coffee_samples id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_received_coffee_samples ALTER COLUMN id SET DEFAULT nextval('customers_customer_received_coffee_samples_id_seq'::regclass);


--
-- Name: customers_customer_vouchers id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_vouchers ALTER COLUMN id SET DEFAULT nextval('customers_customer_vouchers_id_seq'::regclass);


--
-- Name: customers_facebookcustomer id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_facebookcustomer ALTER COLUMN id SET DEFAULT nextval('customers_facebookcustomer_id_seq'::regclass);


--
-- Name: customers_gearorder id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_gearorder ALTER COLUMN id SET DEFAULT nextval('customers_gearorder_id_seq'::regclass);


--
-- Name: customers_order id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_order ALTER COLUMN id SET DEFAULT nextval('customers_order_id_seq'::regclass);


--
-- Name: customers_plan id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_plan ALTER COLUMN id SET DEFAULT nextval('customers_plan_id_seq'::regclass);


--
-- Name: customers_postcard id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_postcard ALTER COLUMN id SET DEFAULT nextval('customers_postcard_id_seq'::regclass);


--
-- Name: customers_preferences id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences ALTER COLUMN id SET DEFAULT nextval('customers_preferences_id_seq'::regclass);


--
-- Name: customers_preferences_flavor id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences_flavor ALTER COLUMN id SET DEFAULT nextval('customers_preferences_flavor_id_seq'::regclass);


--
-- Name: customers_reference id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_reference ALTER COLUMN id SET DEFAULT nextval('customers_reference_id_seq'::regclass);


--
-- Name: customers_referral id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_referral ALTER COLUMN id SET DEFAULT nextval('customers_referral_id_seq'::regclass);


--
-- Name: customers_subscription id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_subscription ALTER COLUMN id SET DEFAULT nextval('customers_subscription_id_seq'::regclass);


--
-- Name: customers_voucher id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_voucher ALTER COLUMN id SET DEFAULT nextval('customers_voucher_id_seq'::regclass);


--
-- Name: customers_vouchercategory id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_vouchercategory ALTER COLUMN id SET DEFAULT nextval('customers_vouchercategory_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: get_started_getstartedresponse id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_getstartedresponse ALTER COLUMN id SET DEFAULT nextval('get_started_getstartedresponse_id_seq'::regclass);


--
-- Name: get_started_giftvoucher id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_giftvoucher ALTER COLUMN id SET DEFAULT nextval('get_started_giftvoucher_id_seq'::regclass);


--
-- Name: get_started_podsearlybird id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_podsearlybird ALTER COLUMN id SET DEFAULT nextval('get_started_podsearlybird_id_seq'::regclass);


--
-- Name: get_started_referralvoucher id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_referralvoucher ALTER COLUMN id SET DEFAULT nextval('get_started_referralvoucher_id_seq'::regclass);


--
-- Name: loyale_coffeetypepoints id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_coffeetypepoints ALTER COLUMN id SET DEFAULT nextval('loyale_coffeetypepoints_id_seq'::regclass);


--
-- Name: loyale_grantpointlog id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_grantpointlog ALTER COLUMN id SET DEFAULT nextval('loyale_grantpointlog_id_seq'::regclass);


--
-- Name: loyale_helper id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_helper ALTER COLUMN id SET DEFAULT nextval('loyale_helper_id_seq'::regclass);


--
-- Name: loyale_item id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_item ALTER COLUMN id SET DEFAULT nextval('loyale_item_id_seq'::regclass);


--
-- Name: loyale_orderpoints id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_orderpoints ALTER COLUMN id SET DEFAULT nextval('loyale_orderpoints_id_seq'::regclass);


--
-- Name: loyale_point id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_point ALTER COLUMN id SET DEFAULT nextval('loyale_point_id_seq'::regclass);


--
-- Name: loyale_redemitem id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redemitem ALTER COLUMN id SET DEFAULT nextval('loyale_redemitem_id_seq'::regclass);


--
-- Name: loyale_redempointlog id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redempointlog ALTER COLUMN id SET DEFAULT nextval('loyale_redempointlog_id_seq'::regclass);


--
-- Name: loyale_setpoint id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_setpoint ALTER COLUMN id SET DEFAULT nextval('loyale_setpoint_id_seq'::regclass);


--
-- Name: manager_churnratedata id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_churnratedata ALTER COLUMN id SET DEFAULT nextval('manager_churnratedata_id_seq'::regclass);


--
-- Name: manager_clusterdf id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_clusterdf ALTER COLUMN id SET DEFAULT nextval('manager_clusterdf_id_seq'::regclass);


--
-- Name: manager_customercluster id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_customercluster ALTER COLUMN id SET DEFAULT nextval('manager_customercluster_id_seq'::regclass);


--
-- Name: manager_fyporderstats id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_fyporderstats ALTER COLUMN id SET DEFAULT nextval('manager_fyporderstats_id_seq'::regclass);


--
-- Name: manager_intercomlocal id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_intercomlocal ALTER COLUMN id SET DEFAULT nextval('manager_intercomlocal_id_seq'::regclass);


--
-- Name: manager_mailchimpcampaignstats id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_mailchimpcampaignstats ALTER COLUMN id SET DEFAULT nextval('manager_mailchimpcampaignstats_id_seq'::regclass);


--
-- Name: manager_rawbeanstats id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_rawbeanstats ALTER COLUMN id SET DEFAULT nextval('manager_rawbeanstats_id_seq'::regclass);


--
-- Name: manager_recommendation id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_recommendation ALTER COLUMN id SET DEFAULT nextval('manager_recommendation_id_seq'::regclass);


--
-- Name: manager_reportcard id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_reportcard ALTER COLUMN id SET DEFAULT nextval('manager_reportcard_id_seq'::regclass);


--
-- Name: manager_threshold id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_threshold ALTER COLUMN id SET DEFAULT nextval('manager_threshold_id_seq'::regclass);


--
-- Name: reminders_reminder id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY reminders_reminder ALTER COLUMN id SET DEFAULT nextval('reminders_reminder_id_seq'::regclass);


--
-- Name: wholesale_plan id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY wholesale_plan ALTER COLUMN id SET DEFAULT nextval('wholesale_plan_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY auth_group (id, name) FROM stdin;
2	admin
1	packer
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('auth_group_id_seq', 2, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
2	2	232
4	2	233
6	2	234
7	2	235
8	2	236
9	1	232
10	1	233
11	1	234
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 11, true);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add session	5	add_session
14	Can change session	5	change_session
15	Can delete session	5	delete_session
16	Can add site	6	add_site
17	Can change site	6	change_site
18	Can delete site	6	delete_site
19	Can add registration profile	7	add_registrationprofile
20	Can change registration profile	7	change_registrationprofile
21	Can delete registration profile	7	delete_registrationprofile
22	Can add voucher	8	add_voucher
23	Can change voucher	8	change_voucher
24	Can delete voucher	8	delete_voucher
25	Can add customer	9	add_customer
26	Can change customer	9	change_customer
27	Can delete customer	9	delete_customer
28	Can add charge	10	add_charge
29	Can change charge	10	change_charge
30	Can delete charge	10	delete_charge
31	Can add plan	11	add_plan
32	Can change plan	11	change_plan
33	Can delete plan	11	delete_plan
34	Can add subscription	12	add_subscription
35	Can change subscription	12	change_subscription
36	Can delete subscription	12	delete_subscription
37	Can add preferences	13	add_preferences
38	Can change preferences	13	change_preferences
39	Can delete preferences	13	delete_preferences
40	Can add order	14	add_order
41	Can change order	14	change_order
42	Can delete order	14	delete_order
43	Can add my user	15	add_myuser
44	Can change my user	15	change_myuser
45	Can delete my user	15	delete_myuser
46	Can add brew method	16	add_brewmethod
47	Can change brew method	16	change_brewmethod
48	Can delete brew method	16	delete_brewmethod
49	Can add flavor	17	add_flavor
50	Can change flavor	17	change_flavor
51	Can delete flavor	17	delete_flavor
52	Can add coffee type	18	add_coffeetype
53	Can change coffee type	18	change_coffeetype
54	Can delete coffee type	18	delete_coffeetype
58	Can add get started response	20	add_getstartedresponse
59	Can change get started response	20	change_getstartedresponse
60	Can delete get started response	20	delete_getstartedresponse
61	Can add section	21	add_section
62	Can change section	21	change_section
63	Can delete section	21	delete_section
64	Can add post	22	add_post
65	Can change post	22	change_post
66	Can delete post	22	delete_post
70	Can add referral	24	add_referral
71	Can change referral	24	change_referral
72	Can delete referral	24	delete_referral
73	Can add reference	25	add_reference
74	Can change reference	25	change_reference
75	Can delete reference	25	delete_reference
79	Can add review	27	add_review
80	Can change review	27	change_review
81	Can delete review	27	delete_review
82	Can add career	28	add_career
83	Can change career	28	change_career
84	Can delete career	28	delete_career
88	Can add gift voucher	30	add_giftvoucher
89	Can change gift voucher	30	change_giftvoucher
90	Can delete gift voucher	30	delete_giftvoucher
91	Can add gear order	31	add_gearorder
92	Can change gear order	31	change_gearorder
93	Can delete gear order	31	delete_gearorder
94	Can add coffee gear	32	add_coffeegear
95	Can change coffee gear	32	change_coffeegear
96	Can delete coffee gear	32	delete_coffeegear
97	Can add plan	33	add_plan
98	Can change plan	33	change_plan
99	Can delete plan	33	delete_plan
100	Can add pods early bird	34	add_podsearlybird
101	Can change pods early bird	34	change_podsearlybird
102	Can delete pods early bird	34	delete_podsearlybird
103	Can add referral voucher	35	add_referralvoucher
104	Can change referral voucher	35	change_referralvoucher
105	Can delete referral voucher	35	delete_referralvoucher
106	Can add set point	36	add_setpoint
107	Can change set point	36	change_setpoint
108	Can delete set point	36	delete_setpoint
109	Can add coffee type points	37	add_coffeetypepoints
110	Can change coffee type points	37	change_coffeetypepoints
111	Can delete coffee type points	37	delete_coffeetypepoints
112	Can add User's points	38	add_point
113	Can change User's points	38	change_point
114	Can delete User's points	38	delete_point
115	Can add Redemption items	39	add_item
116	Can change Redemption items	39	change_item
117	Can delete Redemption items	39	delete_item
118	Can add Orders	40	add_redemitem
119	Can change Orders	40	change_redemitem
120	Can delete Orders	40	delete_redemitem
121	Can add redem point log	41	add_redempointlog
122	Can change redem point log	41	change_redempointlog
123	Can delete redem point log	41	delete_redempointlog
124	Can add grant point log	42	add_grantpointlog
125	Can change grant point log	42	change_grantpointlog
126	Can delete grant point log	42	delete_grantpointlog
127	Can add Settings	43	add_orderpoints
128	Can change Settings	43	change_orderpoints
129	Can delete Settings	43	delete_orderpoints
130	Can add helper	44	add_helper
131	Can change helper	44	change_helper
132	Can delete helper	44	delete_helper
133	Can add coffee sticker	45	add_coffeesticker
134	Can change coffee sticker	45	change_coffeesticker
135	Can delete coffee sticker	45	delete_coffeesticker
136	Can add shared coffee sticker	46	add_sharedcoffeesticker
137	Can change shared coffee sticker	46	change_sharedcoffeesticker
138	Can delete shared coffee sticker	46	delete_sharedcoffeesticker
139	Can add voucher category	47	add_vouchercategory
140	Can change voucher category	47	change_vouchercategory
141	Can delete voucher category	47	delete_vouchercategory
142	Can add facebook customer	48	add_facebookcustomer
143	Can change facebook customer	48	change_facebookcustomer
144	Can delete facebook customer	48	delete_facebookcustomer
145	Can add login	49	add_login
146	Can change login	49	change_login
147	Can delete login	49	delete_login
148	Can add task state	50	add_taskmeta
149	Can change task state	50	change_taskmeta
150	Can delete task state	50	delete_taskmeta
151	Can add saved group result	51	add_tasksetmeta
152	Can change saved group result	51	change_tasksetmeta
153	Can delete saved group result	51	delete_tasksetmeta
154	Can add interval	52	add_intervalschedule
155	Can change interval	52	change_intervalschedule
156	Can delete interval	52	delete_intervalschedule
157	Can add crontab	53	add_crontabschedule
158	Can change crontab	53	change_crontabschedule
159	Can delete crontab	53	delete_crontabschedule
160	Can add periodic tasks	54	add_periodictasks
161	Can change periodic tasks	54	change_periodictasks
162	Can delete periodic tasks	54	delete_periodictasks
163	Can add periodic task	55	add_periodictask
164	Can change periodic task	55	change_periodictask
165	Can delete periodic task	55	delete_periodictask
166	Can add worker	56	add_workerstate
167	Can change worker	56	change_workerstate
168	Can delete worker	56	delete_workerstate
169	Can add task	57	add_taskstate
170	Can change task	57	change_taskstate
171	Can delete task	57	delete_taskstate
172	Can add queue	58	add_queue
173	Can change queue	58	change_queue
174	Can delete queue	58	delete_queue
175	Can add message	59	add_message
176	Can change message	59	change_message
177	Can delete message	59	delete_message
181	Can add fyp order stats	61	add_fyporderstats
182	Can change fyp order stats	61	change_fyporderstats
183	Can delete fyp order stats	61	delete_fyporderstats
184	Can add reminder	62	add_reminder
185	Can change reminder	62	change_reminder
186	Can delete reminder	62	delete_reminder
187	Can add raw bean	63	add_rawbean
188	Can change raw bean	63	change_rawbean
189	Can delete raw bean	63	delete_rawbean
190	Can add mailchimp campaign stats	64	add_mailchimpcampaignstats
191	Can change mailchimp campaign stats	64	change_mailchimpcampaignstats
192	Can delete mailchimp campaign stats	64	delete_mailchimpcampaignstats
193	Can add churn rate data	65	add_churnratedata
194	Can change churn rate data	65	change_churnratedata
195	Can delete churn rate data	65	delete_churnratedata
196	Can add raw bean stats	66	add_rawbeanstats
197	Can change raw bean stats	66	change_rawbeanstats
198	Can delete raw bean stats	66	delete_rawbeanstats
199	Can add intercom local	67	add_intercomlocal
200	Can change intercom local	67	change_intercomlocal
201	Can delete intercom local	67	delete_intercomlocal
202	Can add coffee gear color	68	add_coffeegearcolor
203	Can change coffee gear color	68	change_coffeegearcolor
204	Can delete coffee gear color	68	delete_coffeegearcolor
205	Can add coffee gear image	69	add_coffeegearimage
206	Can change coffee gear image	69	change_coffeegearimage
207	Can delete coffee gear image	69	delete_coffeegearimage
208	Can add brew guide	70	add_brewguide
209	Can change brew guide	70	change_brewguide
210	Can delete brew guide	70	delete_brewguide
211	Can add brew guide step	71	add_brewguidestep
212	Can change brew guide step	71	change_brewguidestep
213	Can delete brew guide step	71	delete_brewguidestep
214	Can add threshold	72	add_threshold
215	Can change threshold	72	change_threshold
216	Can delete threshold	72	delete_threshold
217	Can add report card	73	add_reportcard
218	Can change report card	73	change_reportcard
219	Can delete report card	73	delete_reportcard
220	Can add recommendation	74	add_recommendation
221	Can change recommendation	74	change_recommendation
222	Can delete recommendation	74	delete_recommendation
223	Can add cluster df	75	add_clusterdf
224	Can change cluster df	75	change_clusterdf
225	Can delete cluster df	75	delete_clusterdf
226	Can add customer cluster	76	add_customercluster
227	Can change customer cluster	76	change_customercluster
228	Can delete customer cluster	76	delete_customercluster
229	Can add rights support	77	add_rightssupport
230	Can change rights support	77	change_rightssupport
231	Can delete rights support	77	delete_rightssupport
232	Can View the Packing Page	77	can_view_pack
233	Can View the Customer Page	77	can_view_customers
234	Can View the Inventory Page	77	can_view_inventory
235	Can View the Marketing Page	77	can_view_marketing
236	Can View the Analysis Page	77	can_view_analysis
237	Can add greeting	78	add_greeting
238	Can change greeting	78	change_greeting
239	Can delete greeting	78	delete_greeting
240	Can add address	79	add_address
241	Can change address	79	change_address
242	Can delete address	79	delete_address
243	Can add coffee review	80	add_coffeereview
244	Can change coffee review	80	change_coffeereview
245	Can delete coffee review	80	delete_coffeereview
246	Can add farm photos	81	add_farmphotos
247	Can change farm photos	81	change_farmphotos
248	Can delete farm photos	81	delete_farmphotos
249	Can add instagram post	82	add_instagrampost
250	Can change instagram post	82	change_instagrampost
251	Can delete instagram post	82	delete_instagrampost
252	Can add category	83	add_category
253	Can change category	83	change_category
254	Can delete category	83	delete_category
255	Can add tag	84	add_tag
256	Can change tag	84	change_tag
257	Can delete tag	84	delete_tag
258	Can add post	85	add_post
259	Can change post	85	change_post
260	Can delete post	85	delete_post
261	Can add shopping cart	86	add_shoppingcart
262	Can change shopping cart	86	change_shoppingcart
263	Can delete shopping cart	86	delete_shoppingcart
264	Can add postcard	87	add_postcard
265	Can change postcard	87	change_postcard
266	Can delete postcard	87	delete_postcard
270	Can add top bar	89	add_topbar
271	Can change top bar	89	change_topbar
272	Can delete top bar	89	delete_topbar
274	Can export customer	9	export_customer
275	Can export preferences	13	export_preferences
276	Can export order	14	export_order
277	Can export gear order	31	export_gearorder
278	Can export get started response	20	export_getstartedresponse
279	Can export referral voucher	35	export_referralvoucher
280	Can add card fingerprint	90	add_cardfingerprint
281	Can change card fingerprint	90	change_cardfingerprint
282	Can delete card fingerprint	90	delete_cardfingerprint
283	Can export coffee review	80	export_coffeereview
293	Can add supervised registration profile	94	add_supervisedregistrationprofile
294	Can change supervised registration profile	94	change_supervisedregistrationprofile
295	Can delete supervised registration profile	94	delete_supervisedregistrationprofile
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('auth_permission_id_seq', 295, true);


--
-- Data for Name: blog_category; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY blog_category (id, name, slug) FROM stdin;
1	Uncategorized	uncategorized
2	Coffee	coffee
3	Back to Basics	back-to-basics
4	BIY (Brew it Yourself)	biy-brew-it-yourself
5	Direct Trade	direct-trade
6	Coffee Hacks	coffee-hacks
7	Sustainable Practices	sustainable-practices
8	Coffee in Singapore	coffee-in-singapore
9	Hook Coffee News	hook-coffee-news
10	Education	education
11	Events & Collaborations	events-collaborations
12	Just for laughs!	just-for-laughs
13	from the HQ	from-the-hq
14	Recipes	recipes
15	Behind the Brew	behind-the-brew
\.


--
-- Name: blog_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('blog_category_id_seq', 15, true);


--
-- Data for Name: blog_post; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY blog_post (id, title, preview, content, date_added, date_published, author, img, category_id, slug) FROM stdin;
6	The Beginner’s Guide to Brewing with the V60	The specialty coffee realm can be intimidating to any outsider looking in, thinking of getting his toes wet. The variety of equipment, terminology and often complicated yet contradicting advice can be very hard to navigate for someone who's just in search ..	<p>The specialty coffee realm can be intimidating to any outsider looking in, thinking of getting his toes wet. The variety of equipment, terminology and often complicated yet contradicting advice can be very hard to navigate for someone who&#39;s just in search of a better cup of coffee. The <strong>Hario V60</strong> is a staple in many coffee-brewing collections due to its ease of use and affordability. Essentially, the V60 is a pour-over brew apparatus which requires you to pour hot water over a bed of coffee, allowing the water to steep and drip through the funnel into a flask or cup below. How easy is that? https://www.youtube.com/watch?v=z9jSCnXXuts We also really like it because, despite it&rsquo;s simplicity, it brings out the best qualities and nuanced flavours of each coffee (and that&#39;s why you should never judge a book by its cover!)</p>\r\n\r\n<h2>So here&rsquo;s what you&rsquo;ll need</h2>\r\n\r\n<ul>\r\n\t<li><strong>V60 Kit</strong>\r\n\r\n\t<ul>\r\n\t\t<li>V60 Dripper</li>\r\n\t\t<li>Filter paper</li>\r\n\t</ul>\r\n\t</li>\r\n</ul>\r\n\r\n<ul>\r\n\t<li><strong>Hot water </strong>Approx. 250ml of water at 95 degrees celsius. If you don&rsquo;t have a way to check the temperature, bring the water to a complete boil then let it rest for 1 minute.</li>\r\n</ul>\r\n\r\n<ul>\r\n\t<li><strong>Freshly roasted coffee from Hook Coffee </strong>Approx. 15g of medium-fine grounded coffee. We can grind it for you if you&rsquo;d like!</li>\r\n</ul>\r\n\r\n<ul>\r\n\t<li><strong>Serving flask or cup</strong></li>\r\n</ul>\r\n\r\n<p><img alt="V60 Equipment Req" class="alignnone size-full wp-image-629" src="https://hookcoffee.files.wordpress.com/2016/04/v60-equipment-req.png" style="height:900px; width:1440px" /></p>\r\n\r\n<h2>Pre-brew preparation</h2>\r\n\r\n<p>Before we get to the actual brewing, we want to rinse the paper filter to prevent any papery taste from tainting your brew.</p>\r\n\r\n<ul>\r\n\t<li>Place the&nbsp;filter in the dripper, making sure to fold along the side, so as to create a cone shape.</li>\r\n\t<li>Rinse the filter with&nbsp;some hot water onto the filter, allowing it to pass through into your serving cup. This also allows you to heat up the serving cup.</li>\r\n\t<li>Discard the water when you&rsquo;re done.</li>\r\n</ul>\r\n\r\n<p>[gallery ids=&quot;627,633&quot; type=&quot;rectangular&quot;]</p>\r\n\r\n<h2>Brew Method</h2>\r\n\r\n<ul>\r\n\t<li>Place 15g of the grounded coffee into the filter and slowly pour 30g of 95 degrees celsius water onto the coffee bed, ensuring you wet all the coffee grounds.</li>\r\n</ul>\r\n\r\n<p>[gallery ids=&quot;626,632&quot; type=&quot;columns&quot;]</p>\r\n\r\n<ul>\r\n\t<li>Wait 30 seconds, to allow the coffee to bloom. &ldquo;The Bloom&rdquo; is the fast release of gas that occurs when hot water comes in contact with the fresh coffee grounds. Watch as the grounds bubble and rise to form a pillowy mound, then slowly deflate as they take their bow.</li>\r\n</ul>\r\n\r\n<p><img alt="V60 Bloom" class="alignnone size-full wp-image-625" src="https://hookcoffee.files.wordpress.com/2016/04/v60-bloom.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>Continue pouring the remainder of the water in a slow, consistent circular motion around the coffee bed. This ensures an equal extraction of coffee from the grounds.</li>\r\n</ul>\r\n\r\n<p><img alt="V60 Finish Pour" class="alignnone size-full wp-image-631" src="https://hookcoffee.files.wordpress.com/2016/04/v60-finish-pour.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>Pour the coffee into a mug and enjoy!</li>\r\n</ul>\r\n\r\n<p><img alt="V60 Enjoy" class="alignnone size-full wp-image-628" src="https://hookcoffee.files.wordpress.com/2016/04/v60-enjoy.png" style="height:900px; width:1440px" /></p>\r\n\r\n<h2>Searching for the perfect cup</h2>\r\n\r\n<p>Brewing coffee to your liking is an ongoing journey of experiments and tweaks. If your coffee is overtly bitter, it is likely your brew is over extracted. Try&hellip;</p>\r\n\r\n<ul>\r\n\t<li>Using a coarser grind setting</li>\r\n\t<li>Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too high.</li>\r\n</ul>\r\n\r\n<p>If your coffee tastes bland or diluted, it is likely your brew is under extracted. Try&hellip;</p>\r\n\r\n<ul>\r\n\t<li>Using a finer grind setting</li>\r\n\t<li>Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too low.</li>\r\n\t<li>Using freshly roasted and ground coffee (which won&rsquo;t be a concern if you&rsquo;re getting your coffee from us!)</li>\r\n</ul>\r\n\r\n<h2>Still not satisfied?</h2>\r\n\r\n<p>The best technique and equipment can&#39;t make up for low-quality coffee beans. If you&#39;re using beans bought from the supermarket or beans roasted months ago, maybe you should check us out <a href="http://www.hookcoffee.com.sg">here</a>. We bring in some of the best beans from around the world, roasting the beans locally at our facility right before sending it to you. To further experiment, you can also try&nbsp;using other similar drip pourover equipment such as the Kalita Wave or the Chemex. Happy brewing!</p>\r\n	2017-03-12 23:18:00.758263+00	2016-04-09 06:31:46+00	hookcoffee	./beginner_guide_to_brewing_v60_hookblog_.png	3	v60-brew-guide
4	Everyone’s Goin' Crazy for this Coffee, Here’s Why	Cold brew brings a lot to the coffee table. It brings a different perspective to your coffee beans while remaining extremely versatile. It comes as a relief on hot days and it's pretty much foolproof.\n\nWhat is cold brew?\n\nIn very simple terms, it's cold co..	Cold brew brings a lot to the coffee table. It brings a different perspective to your coffee beans while remaining extremely versatile. It comes as a relief on hot days and it's pretty much foolproof.\n\n<strong>What is cold brew?</strong>\n\nIn very simple terms, it's cold coffee. <em>Not </em>iced coffee - because in Singapore's heat, you'll find yourself with a diluted brew in no time! Brewing coffee typically involves a kettle of hot water and a few minutes but at its essence, a cold brew requires  cold water and 12 to 24 hours. Increasing the time while decreasing the water temperature may seem counter-intuitive, and may also sound time-consuming, but it really makes sense especially when it's sweltering hot out there and really only requires 3-4 steps (which we'll reveal in awhile).\n\nHere are 4 reasons why we can't get enough of our cold brew coffee:\n\n<strong>Perfect for long, hot days</strong>\n\nNormally, we enjoy sipping on our hot coffees, allowing the warm waves of caffeine to calm us. But on other days, especially on seriously hot ones (like the past week), a cold brew is all we need. Sipping on a cold brew on a hot day is addictively refreshing. Cold brews also contain a higher caffeine level as all other kinds of brews (up to 20x more!) so when you're feeling terribly exhausted from the unrelenting heat, you'll want to reach out for a cold brew.\n\n<strong>Delicious cups of coffee</strong>\n\n8 in 10 people add milk or sugar to their conventional black coffee because they don't enjoy the acidic taste of black coffee. With cold brew, that's just not necessary. You can instead expect a more mellow, well-rounded cup with nary a hint of acidity. Fruity and floral notes are much clearer. The muted acidity and clarity in a cup is achieved through the sheer amount of time the coffee interacts with the water at low temperatures. For these reasons, we love making cold brew with Piña Loca and La Dulce Vida, but feel free to take your pick at www.hookcoffee.com.sg/coffees/!\n\n<strong>Versatility</strong>\n\nHere are some ways we've enjoyed our cold brews:\n<ul>\n\t<li>Adding a touch of vanilla syrup</li>\n\t<li>Adding a dash of milk</li>\n\t<li>Dousing it in frozen Baileys cubes!!!</li>\n</ul>\nHeck, some cafes even offer Nitro Coffees. It looks suspiciously like a Guinness Stout, but definitely tastes as good or better. We even want to install a nitro tap at our office just for the fun of it.\n\nCold brews are also versatile in the sense that you can enjoy anywhere. At home? At work? On-the-go? In the movies? At the beach? No problem!\n\n<strong>Foolproof</strong>\n\nCold brews are so easy to prepare and require minimal effort.\n<blockquote>Ground Coffee + Water + 12 hours (min.) = Heavenly, smooth Cold Brew</blockquote>\nHere's a video showing how making coffee can't get any simpler than cold brews:\n\n[facebook url="https://www.facebook.com/hookcoffeesg/videos/548961461934239/" /]\n\nThe real beauty of cold brew for specialty coffee beginners is this; cold water is much easier to work with than hot water. With a conventional brew, you have a few minutes to get the extraction of the coffee right. Compare this to the 12-hours cold brewing gives you. Brewing to your taste and preferences is simple when you can take it out of the fridge, take a sip and if it isn't saturated enough for you, throw it back in for another couple of hours.\n\nA well-made batch of cold brew can stay fresh in the fridge for a week, so it's ready whenever you are. Just remember to remove the coffee grounds after 24 hours - you wouldn't wanna overdo it, would you?\n\nDid we also mention that one bottle of cold brew makes 4-6 cups? If you're feeling generous, you can share your brew and if not, you can keep it for the next day!\n\nHere at Hook, simple yet effective methods take the cake and with specialty coffee, it doesn't get much simpler than cold brew.\n\n<em>- Intern S</em>	2017-03-12 23:18:00.744772+00	2016-03-18 17:08:40+00	hookcoffee		3	everyones-goin-crazy-for-this-coffee-heres-why
7	The Beginner’s Guide to Brewing with the French Press	The French Press, aka cafetière or coffee plunger, is probably one of the most popular coffee-brewing apparatus worldwide because it's ubiquitous and terribly simple. So simple that some people describe it as boring, but hey, boring's safe and reliable rig..	<p>The French Press, aka cafeti&egrave;re or coffee plunger, is probably one of the most popular coffee-brewing apparatus worldwide because it&#39;s ubiquitous and terribly simple. So simple that some people describe it as boring, but hey, boring&#39;s safe and reliable right? https://youtu.be/u6reD4wrDyg</p>\r\n\r\n<h3>So here&rsquo;s what you&rsquo;ll need</h3>\r\n\r\n<ul>\r\n\t<li><strong>French Press</strong><strong> </strong></li>\r\n\t<li><strong>Hot water </strong>Approx. 385g of 95 degrees celcius. If you don&rsquo;t have a way to check the temperature, bring the water to a complete boil then let it rest for 1 minute.<strong> </strong></li>\r\n\t<li><strong>Freshly roasted coffee from Hook Coffee </strong>Approx. 25g of coarse grounded coffee. We can grind it for you if you&rsquo;d like!<strong> </strong></li>\r\n\t<li><strong>Mug/Cup</strong></li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-05 at 11.56.05 AM" class="alignnone size-full wp-image-708" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-05-at-11-56-05-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<h3>Brew Method</h3>\r\n\r\n<ul>\r\n\t<li>Place <strong>25g</strong> of the <strong>grounded coffee</strong>&nbsp;into the french press and slowly pour <strong>385g</strong>&nbsp;of <strong>95 degrees celsius water</strong>&nbsp;onto the coffee bed, ensuring you wet all the coffee grounds.</li>\r\n</ul>\r\n\r\n<p>[gallery ids=&quot;709,710&quot; type=&quot;rectangular&quot;]</p>\r\n\r\n<ul>\r\n\t<li>Let it steep for a total of 4 mins.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-05 at 11.56.51 AM" class="alignnone size-full wp-image-711" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-05-at-11-56-51-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>After 4 minutes, place the cap on the french press and plunge down. This pushes the coffee grounds to the bottom of the cup, leaving you with only the good stuff up top. Pour the coffee into a mug and enjoy!</li>\r\n</ul>\r\n\r\n<p>[gallery ids=&quot;712,713&quot; type=&quot;rectangular&quot;]</p>\r\n\r\n<ul>\r\n\t<li>Important tip: Make sure to pour out&nbsp;immediately or your coffee will get too bitter.</li>\r\n</ul>\r\n\r\n<h3>Searching for the perfect cup</h3>\r\n\r\n<p>Brewing coffee to your liking is an ongoing journey of experiments and tweaks. If your coffee is overtly bitter, it is likely your brew is over extracted. Try&hellip;</p>\r\n\r\n<ul>\r\n\t<li>Using a coarser grind setting</li>\r\n\t<li>Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too high.</li>\r\n</ul>\r\n\r\n<p>If your coffee tastes bland or diluted, it is likely your brew is under extracted. Try&hellip;</p>\r\n\r\n<ul>\r\n\t<li>Using a finer grind setting</li>\r\n\t<li>Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too low.</li>\r\n\t<li>Using freshly roasted and ground coffee (which won&rsquo;t be a concern if you&rsquo;re getting your coffee from us!)</li>\r\n</ul>\r\n\r\n<h3>Still not satisfied?</h3>\r\n\r\n<p>The best technique and equipment can&rsquo;t make up for low-quality coffee beans. If you&rsquo;re using beans bought from the supermarket or beans roasted months ago, maybe you should check us out <a href="http://www.hookcoffee.com.sg">here</a>. We bring in some of the best beans from around the world, roasting the beans locally at our facility right before sending it to you.</p>\r\n	2017-03-12 23:18:00.764033+00	2016-04-09 06:31:47+00	hookcoffee	./beginner_guide_to_brewing_with_the_french_press_hookblog.png	3	french-press-brew-guide-2
9	The Best of Both Worlds - the Hook Drip Bag and the How-to	\r\n\r\nLove good coffee but need it instant? Gone travelling and not sure where you'll find good coffee? Or maybe you’re new and haven’t decided if this path of specialty coffee is right for you? Fret not, our compact-sized drip bags are the perfect companion a..	<p><img alt="Drip Bag and Taster Pack bundle.jpg" class="alignnone size-full wp-image-836" src="https://hookcoffee.files.wordpress.com/2016/04/drip-bag-and-taster-pack-bundle.jpg" style="height:2553px; width:3822px" /> Love good coffee but need it instant? Gone travelling and not sure where you&#39;ll find good coffee? Or maybe you&rsquo;re new and haven&rsquo;t decided if this path of specialty coffee is right for you? Fret not, our compact-sized drip bags are the perfect companion at work and on your journeys. Here&rsquo;s how simple it is to enjoy the bare basics of the specialty coffee world. https://youtu.be/s1DCQxfTWp8</p>\r\n\r\n<h3>Before we go step-by-step, all you&rsquo;ll need is</h3>\r\n\r\n<ul>\r\n\t<li><strong>A Drip Bag</strong> (makes one cup only, no reusing/rebrewing)</li>\r\n\t<li><strong>Hot water -&nbsp;</strong>Approx. 150ml of 95 degrees celcius. If you don&rsquo;t have a way to check the temperature, bring the water to a complete boil then let it rest for 1 minute.</li>\r\n\t<li><strong>Serving cup</strong></li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-05 at 4.45.44 PM" class="alignnone size-full wp-image-784" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-05-at-4-45-44-pm.png" style="height:900px; width:1440px" /></p>\r\n\r\n<h3>Brew Method</h3>\r\n\r\n<ul>\r\n\t<li>Tear open the drip bag and place it in your cup, ensuring it is hooked onto the sides of the cup and suspended with the help of its &quot;arms&quot;</li>\r\n</ul>\r\n\r\n<p>[gallery ids=&quot;785,786&quot; type=&quot;rectangular&quot;]</p>\r\n\r\n<ul>\r\n\t<li>Pour <strong>150g</strong> of <strong>95 degrees celsius water</strong> into the drip bag.</li>\r\n</ul>\r\n\r\n<p>[gallery ids=&quot;787,788&quot; type=&quot;rectangular&quot;]</p>\r\n\r\n<ul>\r\n\t<li>Discard the bag or let it sit in the cup for a stronger cup.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-05 at 4.46.53 PM" class="alignnone size-full wp-image-789" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-05-at-4-46-53-pm.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>You&#39;re probably still in shock as to how easy this is but once you&#39;ve overcome that initial wonderment, enjoy!</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-05 at 4.47.02 PM" class="alignnone size-full wp-image-790" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-05-at-4-47-02-pm.png" style="height:900px; width:1440px" /></p>\r\n\r\n<h3>Searching for the perfect cup</h3>\r\n\r\n<p>Brewing coffee to your liking is an ongoing journey of experiments and tweaks. If your coffee is overtly bitter, it is likely your brew is over extracted. Try&hellip;</p>\r\n\r\n<ul>\r\n\t<li>Reducing the time the drip bag is left steeping.</li>\r\n\t<li>Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too high.</li>\r\n</ul>\r\n\r\n<p>If your coffee tastes bland or diluted, it is likely your brew is under extracted. Try&hellip;</p>\r\n\r\n<ul>\r\n\t<li>Increasing the time the drip bag is left steeping.</li>\r\n\t<li>Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too low.</li>\r\n</ul>\r\n\r\n<h3>Still not satisfied?</h3>\r\n\r\n<p>Our drip bags are the best of both worlds. You get both convenience and quality in a cup. Perfect for busy people like you and us, who are always on-the-go! However, you may start to get curious about home brewing or grow to crave something a tad more sophisticated. That&rsquo;s where our freshly roasted whole and pre-ground beans come in, giving you the ultimate freedom and control to make the best &amp; freshest cup of coffee you possibly can. Whenever you&#39;re ready, head over to our&nbsp;<a href="http://www.hookcoffee.com.sg">page</a>&nbsp;to learn more about our coffee options and customise your orders!</p>\r\n	2017-03-12 23:18:00.775714+00	2016-04-09 06:31:49+00	hookcoffee	./the_best_of_both_world_hookblog_.jpg	3	drip-bag-guide
10	The Beginner’s Guide to Brewing with the Aeropress, the Upside-Down Way	In 2005, president of Aerobie, Alan Adler, was unhappy with the time required to brew his coffee. With that dissatisfaction, he set out to bring to life an apparatus that would brew perfectly balanced cups of coffee with minimal work and clean-up necessary..	<p>In 2005, president of Aerobie, Alan Adler, was unhappy with the time required to brew his coffee. With that dissatisfaction, he set out to bring to life an apparatus that would brew perfectly balanced cups of coffee with minimal work and clean-up necessary, and the Aeropress was born. Years on the Aeropress has a cult-like following, swearing by its versatility, all-rounded quality, and utter convenience. The Aeropress looks like something you&#39;d find in a science lab, which is pretty appropriate for coffee geeks like us! But don&#39;t worry, unlike school science experiments, you can&#39;t go wrong with the Aeropress if you follow the steps. We do it the upside-down way, simply because it tastes better doing it the right way. We don&#39;t know why, but it&#39;s a known fact amongst the coffee lovers of the world! https://youtu.be/pzOmt5ThNto</p>\r\n\r\n<h2>Here&rsquo;s what you&rsquo;ll need</h2>\r\n\r\n<ul>\r\n\t<li><strong>Aeropress Kit</strong>\r\n\r\n\t<ul>\r\n\t\t<li>Aeropress</li>\r\n\t\t<li>Filter paper</li>\r\n\t\t<li>Stirrer</li>\r\n\t</ul>\r\n\t</li>\r\n\t<li><strong>Hot water </strong>Approx. 250ml of 95 degrees celcius. If you aren&rsquo;t able to check the temperature, bring the water to a complete boil then let it rest for 1 minute.</li>\r\n\t<li><strong>Serving cup</strong></li>\r\n\t<li><strong>Freshly roasted coffee from Hook Coffee </strong>Approx. 15g of medium-fine grounded coffee. We can grind it for you if you&rsquo;d like!</li>\r\n</ul>\r\n\r\n<h2><img alt="Screen Shot 2016-04-01 at 8.22.42 AM" class="alignnone size-full wp-image-803" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-22-42-am.png" style="height:900px; width:1440px" /></h2>\r\n\r\n<h2>Pre-Brew Preparation</h2>\r\n\r\n<p>Before we get to the actual brewing, we want to <strong>rinse the paper filter</strong> so as to remove any papery taste present.</p>\r\n\r\n<ul>\r\n\t<li>Place one filter in the basket and place that on your serving cup</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-01 at 8.23.10 AM" class="alignnone size-full wp-image-804" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-23-10-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>Pour hot water onto the filter, allowing it to pass through into your serving cup.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-01 at 8.23.20 AM-1" class="alignnone size-full wp-image-805" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-23-20-am-1.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>Discard the water when you&rsquo;re done</li>\r\n</ul>\r\n\r\n<p>Assemble the Aeropress and place it upside down, like so. <img alt="Screen Shot 2016-04-01 at 8.24.00 AM" class="alignnone size-full wp-image-806" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-24-00-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<h2>Brew Method</h2>\r\n\r\n<ul>\r\n\t<li>Place <strong>15g</strong> of <strong>grounded coffee</strong> into the Aeropress and slowly pour <strong>240g</strong> of <strong>95 degrees celsius water</strong> onto the coffee bed.</li>\r\n</ul>\r\n\r\n<p>[gallery ids=&quot;807,808&quot; type=&quot;rectangular&quot;]</p>\r\n\r\n<ul>\r\n\t<li>Let it steep for a total of 3-4 mins. In the first 30 seconds, stir the brew thoroughly, ensuring that all the coffee grounds are covered&nbsp;by water.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-01 at 8.24.51 AM" class="alignnone size-full wp-image-809" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-24-51-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>After 3-4 minutes, place your cup upside down over the Aeropress and all at once, flip it the right side up.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-01 at 8.25.06 AM" class="alignnone size-full wp-image-810" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-25-06-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>Press down on the plunger, pushing the brewed coffee through the filter into the serving cup.</li>\r\n\t<li>You&#39;re done when you hear a whizzing sound!</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-01 at 8.30.33 AM" class="alignnone size-full wp-image-811" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-30-33-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<ul>\r\n\t<li>Well, that was easy, wasn&#39;t it? Enjoy!</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-04-01 at 8.31.19 AM" class="alignnone size-full wp-image-812" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-04-01-at-8-31-19-am.png" style="height:900px; width:1440px" /></p>\r\n\r\n<h2>Searching for the Perfect Cup</h2>\r\n\r\n<p>Brewing coffee to your liking is an ongoing journey of experiments and tweaks. If your coffee is overly bitter, it is likely your brew is over extracted. Try&hellip; &bull; Using a coarser grind setting &bull; Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too high. If your coffee tastes bland or diluted, it is likely your brew is under extracted. Try&hellip; &bull; Using a finer grind setting &bull; Ensuring the water temperature is at the ideal 95 degrees celsius. The temperature may be too low. &bull; Using freshly roasted and ground coffee (which won&rsquo;t be a concern if you&rsquo;re getting your coffee from us!)</p>\r\n\r\n<h2>Still not satisfied?</h2>\r\n\r\n<p>The best technique and equipment can&rsquo;t make up for low-quality coffee beans. If you&rsquo;re using beans bought from the supermarket or beans roasted months ago, maybe you should check us out <a href="http://hookcoffee.com.sg">here</a>. We bring in some of the best beans from around the world, roasting the beans locally at our facility right before sending it to you. Happy brewing! -Intern S</p>\r\n	2017-03-12 23:18:00.781993+00	2016-04-09 06:31:50+00	hookcoffee	./beginner_guide_to_brewing_aeropress_hookblog_.png	3	aeropress-brew-guide
13	Excuse me, did I hear "ESPRESSO MARTINI”?	It's the Labour Day holiday, and we chanced upon the perfect recipe for one last cocktail before heading back to work tomorrow.\r\n\r\nOr if you've had enough for the weekend, then you're gonna want to bookmark this:\r\n\r\nIntroducing, the ESPRESSO MARTINI!\r\n\r\n[caption..	<p>It&#39;s the Labour Day&nbsp;holiday, and we chanced upon the perfect recipe for one last cocktail before heading back to work tomorrow. Or if you&#39;ve had enough for the weekend, then you&#39;re gonna want to bookmark this: Introducing, the ESPRESSO MARTINI! <img alt="unnamed-682x1024.jpg" class="alignnone size-full wp-image-887" src="https://hookcoffee.files.wordpress.com/2016/05/unnamed-682x1024.jpg" style="height:1024px; width:682px" /> Created in &lsquo;80s Soho, London, by cocktail legend Dick Bradsell, the story goes that a delightful young lady entered his bar and asked Dick to make her a drink that &ldquo;wakes me up and then [insert expletive here] me up&rdquo;. This drink is perfect for Labour Day and every other labourious day. Just a word of caution, don&#39;t expect this cocktail to keep you up all night - it doesn&#39;t work that way. To make this dark and sexy cocktail, you&#39;ll need:</p>\r\n\r\n<ul>\r\n\t<li>50ml vodka of your choice (Grey Goose recommended)</li>\r\n\t<li>35ml coffee liqueur (Kahlua preferably, or Baileys if you prefer something creamier)</li>\r\n\t<li>1 shot (25ml) of&nbsp;espresso\r\n\t<ul>\r\n\t\t<li>If you&#39;re thinking of using one of Hook&#39;s beans for this, Sweet Bundchen or Kopi Sutra will give you much more body and that decadent chocolatey oopmh. If you&#39;re more adventurous than we are, take your pick from the <a href="http://www.hookcoffee.com.sg/coffees/">full range</a>!</li>\r\n\t</ul>\r\n\t</li>\r\n\t<li>Ice</li>\r\n</ul>\r\n\r\n<p>Method: First, fill the martini glass with ice to chill. Mix all other ingredients into a cocktail shaker, then fill it with ice as well. Cap the shaker and shake the daylight out of it to create a frothy texture. Do it quick because you wouldn&#39;t want a diluted martini, would you? Once shaken, empty the ice out of the Martini glass then seive the contents of the shaker directly into the glass. <em>Voila!</em> You&#39;re now a home barista-cum-bartender ;)</p>\r\n	2017-03-12 23:18:00.797597+00	2016-05-02 11:29:38+00	hookcoffee	./espresso_martini_hookblog.jpg	4	excuse-me-did-i-hear-espresso-martini
14	Part 1/3 of The Inconvenient Truth; Drinking Responsibly	We trust you've been drinking responsibly over the weekend and you're all geared up, well-armed with freshly roasted coffees (courtesy of Hook Coffee hopefully), for the week ahead!\r\n\r\nWe've gotten a few requests to share more about Direct Trade and why we'r..	<p>We trust you&#39;ve been drinking responsibly over the weekend and you&#39;re all geared up, well-armed with freshly roasted coffees (courtesy of Hook Coffee hopefully), for the week ahead! We&#39;ve gotten a few requests to share more about Direct Trade and why we&#39;re so obsessed about trying to be 100% DT. So we&#39;ve finally gotten down to writing a three-part series - in Part 1 we&#39;ll provide a low-down on what it means and how it compares to Fair Trade, in the next we&#39;ll explain how we advocate and practice it Direct Trade, and finally in the third installment we&#39;ll give you a glimpse into one of our sourcing trips in Indonesia. Thanks to those who requested for this and keep the ideas coming in!</p>\r\n\r\n<hr />\r\n<h1><strong>Part 1</strong></h1>\r\n\r\n<p>Coffee farmers work everyday, through&nbsp;rain and shine, all to painstakingly grow the coffee beans that make their way into our daily cups of joe. In view of the expertise and hard work involved in coffee farming, we firmly believe here at Hook that our farmers should be justly rewarded - after all, coffee growing is as much as an art as coffee appreciation. Direct Trade allows us to do just that. Before you ask what&#39;s the difference between the popularised Fair Trade practice and Direct Trade, here&#39;s an infograph explaining the discrepancies aptly and succinctly. <img alt="FT_DT_Infographic_-BRCR_July_9.jpg.650x0_q70_crop-smart" class="alignnone size-full wp-image-933" src="https://hookcoffee.files.wordpress.com/2016/05/ft_dt_infographic_-brcr_july_9-650x0_q70_crop-smart.jpg" style="height:961px; width:650px" /></p>\r\n\r\n<h3><strong>What is Direct Trade?</strong></h3>\r\n\r\n<h6><span style="font-size:15px">To put it simply, Direct Trade is the process of buying beans directly from the farms and cooperatives that grow them, removing the need for brokers and organizations that control certifications (e.g. Fair Trade, Rainforest Alliance etc).</span></h6>\r\n\r\n<p>This entails a closer relationship between the buyers and growers themselves, assurance&nbsp;that the beans are in fact <a href="http://www.scaa.org/?page=resources&amp;d=green-coffee-standards">specialty-grade</a>, sustainably-grown, and ethically produced. This fosters&nbsp;a collaborative and mutually beneficial roaster-grower relationship with greater quality control and transparency, thus benefitting roasters, growers, and final consumers. Most importantly, a higher premium (10-25%&nbsp;of the final retail value) is paid for the quality beans. This&nbsp;encourages them to reinvest in the quality of their coffees, a safe and ethical working climate, and environmentally sustainable coffee production. They can enjoy better living standards, send&nbsp;their children to school and afford better health services.</p>\r\n\r\n<h3><strong>What is Fair Trade in the Coffee Industry?</strong></h3>\r\n\r\n<p>In contrast to the Direct Trade model, Fair Trade is the practice of buying coffee through an international cooperative. Fair Trade is one of many&nbsp;certification organizations worldwide that&nbsp;inspects and evaluates coffee estates and plantations according to a set criteria, before Fair Trade certification is granted. Historically, Fair Trade was established to ensure&nbsp;a minimum price and wage to sustain small farmers and&nbsp;enable them to improve their living standards. However, while the Fair Trade movement started off with great purpose, it has been corporatised and misappropriated in recent years.&nbsp;At best, Fair Trade ensures farmers get paid a very subjective &quot;fair&quot; price determined at higher levels of the supply chain (usually the certification company or international cooperative), and the money is almost never enough to be reinvested into improvement in key poverty reduction areas of&nbsp;education, health, infrastructure, and entrepreneurship. As a comparison, the Fair Trade model only pays farmers 0.5% and at the very most 5% of the final retail value of &ldquo;Fair Trade&rdquo; coffee. Additionally, the farmers have to pay thousands of dollars a year as a &ldquo;membership&rdquo; fee while agreeing to standards for pesticide and fertiliser use, which unfairly increases their cost of compliance due to lower&nbsp;productivity and diminished economies of scale. Not to be too academic about this, but a &nbsp;<a href="http://are.berkeley.edu/~esadoulet/papers/FairTrade%20July10.pdf">joint UC San Diego and UC Berkeley&nbsp;study</a>&nbsp;estimates that Fair Trade certification costs about $0.03 per pound, which is a lot for impoverished farmers, with little to no long-term benefit (there are many academic papers and articles out there confirming this). So Fair Trade isn&#39;t as great as it&#39;s been purported but we shouldn&#39;t be too quick to trample all over it and at least appreciate the international movement towards fairer supply chains across different agricultural trades. One can only imagine how much more devastating the impact is on growers that are neither involved in Direct Trade nor Fair Trade. Not to mention the unsustainable farming practices used in such instances to increase the yield and turnover rate. <strong><img alt="Add heading" class="alignnone size-full wp-image-1314" src="https://hookcoffee.files.wordpress.com/2016/05/add-heading.png" style="height:315px; width:851px" /></strong></p>\r\n\r\n<h3><strong>TL;DR</strong></h3>\r\n\r\n<p>Direct Trade is, in fact, fairer than Fair Trade, and Direct Trade has far more advantages both to growers and buyers like us, and even to you because the quality of the beans are&nbsp;as good as they can get. We hope this blog post has been useful and enlightening, and the reason <a href="http://www.hookcoffee.com.sg">Hook Coffee</a> chooses to do Direct Trade over Fair Trade is pretty obvious. So how do we practice Direct Trade and how are the benefits distributed throughout the value chain? You&#39;re gonna have to stay tuned for the next installment of this three-part series to find out. :) In the meantime, check out <a href="http://www.hookcoffee.com.sg/coffees/">our coffees</a>&nbsp;and click on &quot;more info&quot; to read about the origins, farms and growers who have made our extraordinary coffees possible.</p>\r\n	2017-03-12 23:18:00.803189+00	2016-05-30 00:00:34+00	hookcoffee	./drinking_responsibly_hookblog.jpg	3	responsible-drinking-the-low-down-on-direct-trade-in-the-coffee-industry
15	#wedontneedGeorge (Clooney): Our #ShotPods Speak For Themselves!	We actually mean it when we say we don't need George Clooney. Sure, he aged fairly well and we admit that he did pretty good in those Nespresso advertisements. Maybe we're also tempted to believe him when he acts like their pods are the best in the world. ..	<p>We actually mean it when we say we don&#39;t need George Clooney.&nbsp;Sure, he aged fairly well and we admit that he did pretty good in those Nespresso advertisements. Maybe we&#39;re also tempted to believe him when he acts like their pods are the best in the world. But we at Hook Coffee believe in letting our coffees speak for themselves more than anything else. We&#39;ve been working on our pods for quite some time now - so trust us when we say that we&#39;re just excited about this as you are. This one&#39;s for all the rushed mornings, the sluggish afternoons, and anything in between. We heard you, and we&#39;re super excited to bring you our 100% Nespresso-compatible ShotPods! <img alt="13310537_586849798145405_7167124138871597105_n.jpg" class="alignnone size-full wp-image-1464" src="https://hookcoffee.files.wordpress.com/2016/06/13310537_586849798145405_7167124138871597105_n.jpg" style="height:960px; width:960px" /> We&#39;ve kicked off our collection with 3 flavours that we hope you&#39;ll love. If you like something chocolatey and nutty, then Sweet Bundchen ShotPods (Minas Gerais, Brazil) is the one for you! Sweet Bundchen kinda reminds us of Kinder Bueno, and&nbsp;who doesn&#39;t love Kinder Bueno?! If you&#39;re a little more adventurous and you&#39;re looking for something fruity, we also have our Hakuna Matata ShotPods (Thika, Kenya) that taste like Blackcurrant Macaroons with a smooth vanilla and caramel finish. They&#39;re perfect with a little bit of milk, to balance out the fruity acidity. Our current favourite at the Hook HQ is Bird of Paradise (Purosa, Papua New Guinea) which has a dark chocolate base and hints of stone fruit. It&#39;s the darkest of the lot i.e. closest to what you&#39;re used to when you&nbsp;drink Nespresso, yet well-balanced with that subtly sweet and bright frutiness. You&#39;ll also find a light smokey oolong finish lingering, instead of that unpleasant bitter aftertaste you&#39;ve experienced with other brands before. And if you fancy the taste of coffee but caffeine isn&#39;t really your thing or you want to be able to sleep soon-ish, we also have our decaffeinated pods (organic Mount Water Decaffeinated), Decaf Amigo. It tastes like freshly baked malted pretzels and are perfect for any time of the day. We haven&#39;t launched this because we&#39;re perfecting the recipe, but they&#39;ll be available in just a matter of weeks! Use them like you would with a normal Nespresso capsule.Our pods are compatible with every Nespresso machine out there! Enjoy them straight, with milk, or even as part of a recipe - go nuts! (Quick tip: Give the shot a quick stir before drinking. You&#39;ll get a more balanced and flavourful cup that way.) If you haven&#39;t gotten your hands on these babies yet, we have only one question for you - what are you waiting for? They&#39;re available at <a href="http://hookcoffee.com.sg/coffees/shotpods">www.hookcoffee.com.sg/coffees/shotpods</a>&nbsp;and come in boxes of 20 for only $16. The weekend&#39;s almost here, and we can&#39;t think of a&nbsp;better way to celebrate than with&nbsp;our ShotPods. ;)</p>\r\n	2017-03-12 23:18:00.808648+00	2016-06-02 13:00:37+00	hookcoffee	./we_dont_need_george_hookblog_.jpg	4	wedontneedgeorge-clooney-our-pods-speak-for-themselves
11	This is the Most Mesmerising Video on Coffee You’ll Ever Watch!	We've been teasing your taste buds for awhile now, so we thought we'd do something for your eyes too...\n\nhttps://youtu.be/Vx3ue-mluXc\n\nWho knew a video of us packing our coffees could be so satisfying? :)..	We've been teasing your taste buds for awhile now, so we thought we'd do something for your eyes too...\n\nhttps://youtu.be/Vx3ue-mluXc\n\nWho knew a video of us packing our coffees could be so satisfying? :)	2017-03-12 23:18:00.786957+00	2016-04-17 11:22:27+00	hookcoffee		3	this-is-the-most-mesmerising-video-on-coffee-youll-ever-watch
12	Something exciting is happening...	\n\nSo, we haven't been very actively blogging recently, but we have a good reason for that. Can you guess what we've been up to? :)..	<img class="alignnone size-full wp-image-869" src="https://hookcoffee.files.wordpress.com/2016/05/04fd6270-6b0c-41a8-b35a-8cc740a78e0a.jpeg" alt="04fd6270-6b0c-41a8-b35a-8cc740a78e0a.jpeg" width="1024" height="700" />\n\nSo, we haven't been very actively blogging recently, but we have a good reason for that. Can you guess what we've been up to? :)	2017-03-12 23:18:00.791519+00	2016-05-02 10:50:34+00	hookcoffee		2	something-exciting-is-happening
8	Dummies Guide to Cold Brew	\r\n\r\nLike everyone else, we LOVE cold brew and wrote about our love for it here.\r\n\r\nHere are 4 reasons why we can't get enough of our cold brew coffee:\r\n\r\nPerfect for long, hot days\r\n\r\nNormally, we enjoy sipping on our hot coffees, allowing the warm waves of caffei..	<p><img alt="Screen Shot 2016-03-31 at 3.30.33 PM" class="alignnone size-full wp-image-746" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-03-31-at-3-30-33-pm.png" style="height:799px; width:1430px" /> Like everyone else, we LOVE cold brew and wrote about our love for it <a href="https://hookcoffee.com.sg/blog/everyones-goin-crazy-for-this-coffee-heres-why">here</a>. Here are 4 reasons why we can&#39;t get enough of our cold brew coffee: <strong>Perfect for long, hot days</strong> Normally, we enjoy sipping on our hot coffees, allowing the warm waves of caffeine to calm us. But on other days, especially on seriously hot ones (like the past week), a cold brew is all we need. Sipping on a cold brew on a hot day is addictively refreshing. Cold brews also contain a higher caffeine level as all other kinds of brews (up to 20x more!) so when you&#39;re feeling terribly exhausted from the unrelenting heat, you&#39;ll want to reach out for a cold brew. <strong>Delicious cups of coffee</strong> 8 in&nbsp;10 people add milk or sugar to their conventional black coffee because they don&#39;t enjoy the acidic taste of&nbsp;black coffee. With cold brew, that&#39;s just not necessary. You can instead expect a more mellow, well-rounded cup with nary a hint of acidity. Fruity and floral notes are much clearer. The muted acidity and clarity in a cup is achieved&nbsp;through the sheer amount of time the coffee interacts with the water at&nbsp;low temperatures. For these reasons, we love making&nbsp;cold&nbsp;brew with Pi&ntilde;a Loca and La Dulce Vida, but feel free to take your pick at www.hookcoffee.com.sg/coffees/! <strong>Versatility</strong> Here are some ways we&#39;ve enjoyed our cold brews:</p>\r\n\r\n<ul>\r\n\t<li>Adding a touch of vanilla syrup</li>\r\n\t<li>Adding a dash of milk</li>\r\n\t<li>Dousing it&nbsp;in frozen Baileys cubes!!!</li>\r\n</ul>\r\n\r\n<p>Heck, some cafes even offer Nitro Coffees. It looks&nbsp;suspiciously like a Guinness&nbsp;Stout,&nbsp;but definitely tastes as good or better. We even want to install a nitro tap at our office just for the fun of it. Cold brews are also versatile in the sense that you can enjoy anywhere. At home? At work? On-the-go? In the movies? At the beach? No problem! <strong>Foolproof</strong> Cold brews are so easy to prepare and require minimal effort.</p>\r\n\r\n<blockquote>Ground Coffee + Water + 12 hours (min.) = Heavenly, smooth Cold Brew</blockquote>\r\n\r\n<p>Here&#39;s a video showing how making coffee can&#39;t get any simpler than cold brews: https://youtu.be/EwkBPI-HRbw The real beauty of cold brew for specialty coffee beginners is this; cold water is much easier to work with than hot water.&nbsp;With a conventional brew, you have a few minutes to get the extraction of the coffee right. Compare this to the 12-hours cold brewing gives you. Brewing to your taste and preferences is simple&nbsp;when you can take it out of the fridge, take a sip and if it isn&#39;t saturated enough for you, throw it back in for another couple of hours. A well-made batch of cold brew can stay fresh in the fridge for a week, so it&#39;s ready whenever you are. Just remember to remove the coffee grounds after 24 hours - you wouldn&#39;t wanna overdo it, would you? Did we also mention that one bottle of cold brew&nbsp;makes 4-6 cups? If you&#39;re feeling generous, you can share your brew and if not, you can keep it for the next day! Here at Hook, simple yet effective methods&nbsp;take the cake and with specialty coffee, it doesn&#39;t get much simpler than&nbsp;cold&nbsp;brew. Kicking back on a hot day and knocking down a cold coffee sure sounds nice. Cold brews need not be something you only get at caf&eacute;s or a hot coffee you dilute with ice cubes. Here&rsquo;s how you can brew your own cold brew using the ingenious Hario Cold Brew bottle.</p>\r\n\r\n<h3>So here&rsquo;s what you&rsquo;ll need</h3>\r\n\r\n<ul>\r\n\t<li><strong>Hario Cold Brew Bottle</strong></li>\r\n\t<li><strong>Cool or room temperature water</strong></li>\r\n\t<li><strong>Freshly roasted coffee from Hook Coffee </strong>Medium-fine grounded coffee. We can grind it for you if you&rsquo;d like!</li>\r\n</ul>\r\n\r\n<h3><img alt="Screen Shot 2016-03-31 at 3.28.17 PM" class="alignnone size-full wp-image-741" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-03-31-at-3-28-17-pm.png" style="height:806px; width:1434px" /></h3>\r\n\r\n<h3>Brew Method</h3>\r\n\r\n<ul>\r\n\t<li>Pour the grounded coffee into the filter, filling it close to the brim.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-03-31 at 3.28.58 PM" class="alignnone size-full wp-image-742" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-03-31-at-3-28-58-pm.png" style="height:804px; width:1430px" /></p>\r\n\r\n<ul>\r\n\t<li>Screw the cap onto the filter.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-03-31 at 3.29.14 PM" class="alignnone size-full wp-image-743" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-03-31-at-3-29-14-pm.png" style="height:799px; width:1436px" /></p>\r\n\r\n<ul>\r\n\t<li>Pour the water into the bottle until it is approximately 3/4 full.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-03-31 at 3.29.40 PM" class="alignnone size-full wp-image-744" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-03-31-at-3-29-40-pm.png" style="height:800px; width:1435px" /></p>\r\n\r\n<ul>\r\n\t<li>Insert the filter with the coffee into the bottle of water and leave the bottle in the fridge for at least 12 hours.</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-03-31 at 3.30.15 PM" class="alignnone size-full wp-image-745" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-03-31-at-3-30-15-pm.png" style="height:803px; width:1435px" /></p>\r\n\r\n<ul>\r\n\t<li>Brew to taste. After 12 hours, take a sip from the bottle. If it is not saturated enough for your liking, keep the bottle in the fridge for another 2 hours. Repeat till satisfied.</li>\r\n\t<li>Enjoy!</li>\r\n</ul>\r\n\r\n<p><img alt="Screen Shot 2016-03-31 at 3.30.33 PM" class="alignnone size-full wp-image-746" src="https://hookcoffee.files.wordpress.com/2016/04/screen-shot-2016-03-31-at-3-30-33-pm.png" style="height:799px; width:1430px" /> The real beauty of cold brew for specialty coffee beginners is this; cold water is much easier to work with than hot water.&nbsp;With a conventional brew, you have a few minutes to get the extraction of the coffee right. Compare this to the 12-hours cold brewing gives you. Brewing to your taste and preferences is simple&nbsp;when you can take it out of the fridge, take a sip and if it isn&#39;t saturated enough for you, throw it back in for another couple of hours. A well-made batch of cold brew can stay fresh in the fridge for a week, so it&#39;s ready whenever you are. Just remember to remove the coffee grounds after 24 hours - you wouldn&#39;t wanna overdo it, would you? Did we also mention that one bottle of cold brew&nbsp;makes 4-6 cups? If you&#39;re feeling generous, you can share your brew and if not, you can keep it for the next day! Here at Hook, simple yet effective methods&nbsp;take the cake and with specialty coffee, it doesn&#39;t get much simpler than cold brew. &nbsp;</p>\r\n	2017-03-12 23:18:00.769921+00	2016-04-09 06:31:48+00	hookcoffee	./dummies_guide_to_cold_brew_hookblog_.png	3	cold-brew-guide
3	A Fresh Start	\r\n\r\nAs coffee heads, we're spoilt for choice in Singapore with many wonderful cafes - from international chains that pioneered third wave coffee to cozy indie/hipster ones. I love my cafe lattes and the art it comes with as much as the next person reading th..	<p><img alt="givebackcoffee-37" class="alignnone size-full wp-image-69" src="https://hookcoffee.files.wordpress.com/2016/03/givebackcoffee-371.jpg" style="height:735px; width:980px" /> As coffee heads, we&#39;re spoilt for choice in Singapore with many wonderful cafes - from international chains that pioneered third wave coffee to cozy indie/hipster ones. I love my cafe lattes and the art it comes with as much as the next person reading this. But every day for the past two weeks, before heading off to the office, I&rsquo;m in the kitchen grinding coffee beans as I wait for the kettle to come to a boil. A few days into this routine, my mother asks, &quot;Why go through so much hassle?&quot; I paused for awhile only to realise this 2-5 minute ritual has been more therapeutic than anything and so I replied, &ldquo;What hassle?&rdquo; Well, as I&rsquo;ve learnt from Faye &amp; Ernest (the hearts and minds behind Hook), if you aren&#39;t already, here&#39;s why you should DIY (or should we say, BIY - Brew It Yourself). Brewing your own coffee puts you in the captain&#39;s seat of your own caffeine-loaded ship. You&#39;re allowed to do as you please however you please. Make your coffee as strong or weak as you&#39;d like. Add milk, cocoa or even tea to make the coffee yours. Brewing your own coffee gives you greater freedom in a cup. It&#39;s also way more fulfilling to brew your own coffee. You&rsquo;ll take at most 5 minutes out of your hectic day to step back and focus on pleasuring yourself with the best darn cup of coffee. And you&#39;ll sit there, coffee grounds spent, holding the warm cup of liquid gold in your hands, terribly satisfied and energised. With learning to brew your own coffee you&#39;ll also learn to appreciate good coffee. The rich and heavenly aroma, nuanced flavours, juicy or bold body - it&rsquo;s like wine appreciation if you think about it!&nbsp;You won&#39;t have to rely on how the latte art poured for you by the barista at the cafe turned out or how your friends react to their cup of joe to understand if you&#39;re having a good cup of coffee. Let&rsquo;s not forget that brewing your own coffee is a lot more economical than getting your caffeine fix outside. Sure, you can spend thousands on an espresso machine, but there&rsquo;re so many other brew methods out there that are way cheaper, require way less maintenance, and taste equally good or better. But that&rsquo;s a story for another time. As a start, you might want to consider getting Hook&rsquo;s starter kit for just $18 - inclusive of a 250g bag of coffee of your choice (ground as you wish) and a Hario V60 dripper. We currently have 6 delicious coffees to choose from, all freshly sent out to you within a week of roasting. You&#39;ll be brewing the best cup of coffee you&rsquo;ve ever had straight out of the package for just $1 a cup. That&rsquo;s fresh specialty coffee, mind you! Just click <a href="http://www.hookcoffee.com.sg">here</a> to get started. There&#39;s a sea of coffee out there, behind the Instagram-perfect lattes and &ldquo;frappuccinos&rdquo;. But one need only peer over the edge and boldly take the leap. So see you around, slow dancing with your brew in hand, at the helm of your very own coffee adventure. <em>- Intern S</em></p>\r\n	2017-03-12 23:18:00.729535+00	2016-03-10 09:48:50+00	hookcoffee	./a_fresh_start_hookblog_.jpg	13	a-fresh-start
5	9 Hacks for Recycling your Coffee Grounds!	Have you ever finished brewing yet another cup of coffee, and right before you dispose of the spent coffee grounds, thought it was such a waste? If you can't make another cup of coffee and you can't bear to throw the wet grounds away, what do you do?\r\n\r\nWell..	<p>Have you ever finished brewing yet another cup of coffee, and right before you dispose of the spent coffee grounds, thought it was such a waste? If you can&#39;t make another cup of coffee and you can&#39;t bear to throw the wet grounds away, what do you do? Well, turns out coffee grounds are still pretty useful even after&nbsp;brewing a fresh cup of joe! The internet is awash with ideas on giving coffee grounds a second life so we&#39;ve gone through them and here are some of our favourites:</p>\r\n\r\n<hr />\r\n<p>&nbsp; <strong>Reduce eye bags</strong> We often struggle to stay awake by guzzling coffee, but <em>looking</em> awake is a whole different story. By putting the leftover grounds on our undereye area. Caffeine, when applied topically to the skin, constricts the blood vessels under the skin and helps de-puff eyes and diminish dark eye circles. <strong>Replace bad odour with coffee </strong> Because the scent is still present in used coffee grounds, the grounds can be used to remove bad odour around the house. Place a bed of coffee grounds in ashtrays or in satchels and leave them in musty cupboards or smelly shoes! <strong>Help your plants out</strong> Coffee serves as fantastic fertiliser. You can either place the coffee grounds directly into the soil of your plants or mix with warm water and store in a spray bottle to make a fertiliser mist. Be sure not to overdo this as the acidity of the coffee could disrupt the pH balance. <strong><img alt="91c26b34e9b23283a9a3a259a235686a.jpg" class="alignnone size-full wp-image-488" src="https://hookcoffee.files.wordpress.com/2016/03/91c26b34e9b23283a9a3a259a235686a.jpg" style="height:450px; width:360px" /></strong> <strong>Change the colour of your hydrangeas</strong> Speaking of plants and pH balance, the colour of hydrangeas are influenced by alterations in the soil&#39;s pH balance. Adding coffee grounds to the soil decreases the pH and turns pink flowers to blue! Brownie points if you&#39;re doing this for a girlfriend/wife/boyfriend/husband :) <strong>Remove tough stains and scour kitchenware</strong> Stains won&#39;t leave the tabletop or your pots and pans? Try used coffee grounds. The acidity of the coffee and the natural abrasive quality of the grounds should do the trick when mixed with a bit of water and a scrubbing cloth. <strong>Exfoliate dead skin</strong> Exfoliating ensures your pores don&#39;t get clogged with dead skin and dirt, giving you clear and smooth skin. (We aren&#39;t beauty experts but if you have sensitive skin, we recommend exfoliating not more than once a week!) But salt scrubs can be overly expensive, excessively abrasive, and totally unnecessary if you already have some used coffee ground.&nbsp;It might get a little messy but hey, you get to create your own spa experience! 2 simple and economical ways to create your own coffee scrub: <a href="http://www.savynaturalista.com/2013/11/01/coffee-salt-scrub/">here</a>&nbsp;and&nbsp;<a href="http://www.crunchybetty.com/mocha-frappucino-mask-coffee-cocoa-and-honey-facial-mask">here</a>. <strong>Cellulite treatment</strong> Got a date or getting ready for bikini season? Well, coffee grounds come&nbsp;to the rescue by helping to minimize the appearance of cellulite on your body. Just mix&nbsp;coffee grounds and warm water and apply it to the areas of concern for 10 minutes at least twice a week. We&#39;ve heard it really works! <strong>Remove product and oil build-up from your hair</strong> If you style your hair or have a naturally oily scalp, you might have a lot of build-up in your hair. Cleanse your hair and restore to its natural shine by massaging a handful of coffee grounds into your scalp before applying shampoo and rinsing it off. <strong>Use as a Natural Dye</strong> Used coffee grounds also come&nbsp;in handy for your arts &amp; crafts or DIY projects. When added to water, you can use it to dye everyday objects&nbsp;like old <a href="https://ineedcoffee.com/coffee-as-a-natural-dye/">t-shirts </a>and tote bags or home accents such as&nbsp;<a href="https://ineedcoffee.com/coffee-as-a-natural-dye/">feathers</a> and <a href="http://chemistry.about.com/od/holidayhowtos/a/eastereggdyes.htm">easter eggs</a>! You can even use coffee grounds to&nbsp;dye <a href="http://craftingagreenworld.com/2012/07/16/how-to-antique-paper-using-coffee-staining/">paper</a> to give it the old brown parchment look. <a href="https://www.google.com.sg/url?sa=i&amp;rct=j&amp;q=&amp;esrc=s&amp;source=images&amp;cd=&amp;ved=0ahUKEwi7wfnN-NvLAhXFco4KHfnKAz8QjRwIBw&amp;url=http%3A%2F%2Fblog.freepeople.com%2F2014%2F01%2Fnatural-dyeing%2F&amp;psig=AFQjCNH3aZEXmc4HFz4cYf7HOkXYZ3UWZg&amp;ust=1458998884952125"><img alt="Dyeing-with-coffee-and-tea-8.jpg" class="alignnone size-full wp-image-567" src="https://hookcoffee.files.wordpress.com/2016/03/dyeing-with-coffee-and-tea-8.jpg" style="height:387px; width:580px" /></a></p>\r\n\r\n<hr />\r\n<p>&nbsp; Choosing to use specialty coffee beans and going through the effort of brewing it yourself proves&nbsp;you&#39;re already bent on making the best coffee you possibly can, and there&#39;s no reason to not want the same from the spent grounds you&#39;d have otherwise thrown away :) If you would like to take the concept of &#39;sustainable coffee&#39; a step further, look no further - all our coffees are sustainably grown and ethically produced, and we&#39;re moving towards more sustainable packaging and business practices! (Find out more at <a href="http://find out more at www.hookcoffee.com.sg/about/">www.hookcoffee.com.sg/about/</a>)</p>\r\n	2017-03-12 23:18:00.751387+00	2016-03-25 13:36:31+00	hookcoffee	./9_hacks_for_reclcying_coffee_ground_hookblog_.jpg	3	9-hacks-for-recycling-your-coffee-grounds
18	We Got High at Singapore Coffee Fest	Yes, we got high at Singapore Coffee Fest last week.\r\n\r\nYou can't blame us - we partnered and shared a booth with Innocence Brewing, a local brewery that's pretty new to all this like us and served up the best damn coffee beer i.e. Midnight Roast at the fest..	<p>Yes, we got high at Singapore Coffee Fest last week. You can&#39;t blame us - we partnered and shared a booth with Innocence Brewing, a local brewery that&#39;s pretty new to all this like us and served up the best damn coffee beer i.e. Midnight Roast at the festival. And on top of that, we were so pumped up by the electronic dance music (albeit the same playlist on repeat over the 4 days) and the throngs of overly caffeinated people. We met so many of our lovely subscribers who dropped by to say hi, along with plenty of coffee aficionados. We made plenty of new friends and had loads of fun, all while serving up a steady stream of our delicious drip coffees. We also went around barter trading with our new friends who offer yummy snacks, chocolate, and instragramable cafe food.We had many great moments at the Festival so it was hard to narrow down to a&nbsp;few &ndash; but here are what we think were our top 5 moments from those four days: We had many great moments at the Festival so it was hard to narrow down to a&nbsp;few &ndash; but here are what we think were our top 5 moments from those four days: <strong>5) Pimpin&#39; our booth</strong> <img alt="IMG_8533" class="alignnone size-full wp-image-2203" src="https://hookcoffee.files.wordpress.com/2016/06/img_8533.jpg" style="height:473px; width:732px" /> Setting up a booth takes a lot more effort than we anticipated. From transporting our cart coffees, and equipment into a small van, to getting all our decorations up (at the very last minute) &ndash; we spent quite a bit of time pimpin&#39; our little corner! From the looks of it though, it seemed that our efforts paid off pretty well. And of course, there&rsquo;s nothing more satisfying than seeing your whole booth come together and actually getting compliments on how cute and enlivening it was! <strong>4) COFFEE (what else)</strong> From our newly released ShotPods to our drip bags, we served you nearly everything we had in our arsenal! We weren&#39;t able to keep count because the throngs of people did not stop, all we know was that we were literally serving coffees for 10 hours straight and we were all sold out on our ShotPods!!! What can we say &ndash; we love perfecting our coffees for you, and we love knowing that you love our coffees too. <strong>3) Seeing our super sporting customers&nbsp;getting their hands dirty with us</strong> <img alt="IMG_6868.JPG" class="alignnone size-full wp-image-2313" src="https://hookcoffee.files.wordpress.com/2016/06/img_6868.jpg" style="height:1080px; width:1080px" /> So what comes after you&rsquo;ve tried all our coffees? You get involved! A couple of our customers managed to beat the crowd, get behind the counter, and try their hands at brewing some coffee. We thought it turned out pretty well. (Shoutout to Sassy Sabrina and Merry Kenny - if we ever need part-timers we know who to call ;) ) <strong>2) Chilling under the fairy lights with beer, cider, and new friends at the end of the day</strong> <img alt="IMG_8532" class="alignnone size-full wp-image-2210" src="https://hookcoffee.files.wordpress.com/2016/06/img_8532.jpg" style="height:472px; width:729px" /> Like a scene straight out of Tumblr / Coachella / indie movie of your choice. After a long day on our feet, we like to kick it down a notch. One of the highlights of the festival was hanging out on the lawn with our new friends with beer in hand. (Shoutout to Jin, Jack from Jack &amp; Rai, and the amazing folks from Innocence Brewing) <strong>1) Meeting all of you wonderful people!</strong> <img alt="IMG_7106.GIF" class="alignnone wp-image-2285" src="https://hookcoffee.files.wordpress.com/2016/06/img_7106.gif" style="height:511px; width:681px" /> <img alt="Unknown.jpeg" class="alignnone size-full wp-image-2286" src="https://hookcoffee.files.wordpress.com/2016/06/unknown.jpeg" style="height:1600px; width:1600px" /> <img alt="Unknown-2.jpeg" class="alignnone size-full wp-image-2287" src="https://hookcoffee.files.wordpress.com/2016/06/unknown-2.jpeg" style="height:1600px; width:1600px" /> The smiling faces say it all! :)</p>\r\n\r\n<hr />\r\n<p>One last shoutout to the hero who forklifted our cart down from the second floor on Monday after the cargo lift had broken down! Thank you, sir! <img alt="Unknown-1.jpeg" class="alignnone size-full wp-image-2291" src="https://hookcoffee.files.wordpress.com/2016/06/unknown-1.jpeg" style="height:1200px; width:1200px" /></p>\r\n	2017-03-12 23:18:00.830713+00	2016-06-19 14:22:25+00	hookcoffee	./we_got_high_at_coffee_festival_hookblog.jpg	2	we-got-high-at-singapore-coffee-fest
22	Small Purchases To Improve Your Coffee At Home	Small Purchases To Improve Your Coffee At Home\r\n\r\n\r\n\r\nYou might have assumed, from the title of this article, that I was going to give you a list post of coffee machines you need to go out and buy to make the perfect cup. The list post would probably get us mo..	<h1 style="text-align:center">Small Purchases To Improve Your Coffee At Home</h1>\r\n\r\n<p><img alt="Hook Coffee Beans" class="aligncenter size-full wp-image-2674" src="https://hookcoffee.files.wordpress.com/2016/08/hook-coffee-image-bag-and-cup.jpg" style="height:519px; width:696px" /> You might have assumed, from the title of this article, that I was going to give you a list post of coffee machines you need to go out and buy to make the perfect cup. The list post would probably get us more views, but I would rather teach you something worth knowing; how to make the most out of what you already have, with only a few minor purchases. I guarantee that if you implement even one suggestion I made in this article you will make better coffee. <strong>Coffee has a recipe</strong> (%TDS x Brewed Coffee Weight)/Ground Coffee Weight = Extraction Percentage. To make a better coffee, you need to perfect that recipe. There are some little investments that&nbsp;are essential to doing that. I know before you got here you were aimlessly browsing Facebook, and that formula looks a little intimidating, but it really isn&rsquo;t that difficult. Read on and give me a chance to explain.</p>\r\n\r\n<h2>We Need To Start Fiddling With The Coffee Recipe And Narrowing Down Where Your Espresso Extraction Is Going Wrong.</h2>\r\n\r\n<h3><strong>Investment: Digital Scales </strong></h3>\r\n\r\n<p>Do you have digital scales? The amount of coffee grind you put in the group head will have a massive effect on <img alt="cold brew coffee in a french press" class="alignright wp-image-2649" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0327.jpg" style="height:342px; width:470px" />the&nbsp;taste of your coffee. It is one of the first things you need to address when trying to make a coffee at home. Have a look at the formula again, all three of those variables require that you know the weight of something. If you have scales, make a coffee how you normally would and weigh how much grind you put into the group head, and the weight of your coffee. <strong>My results </strong> 17 grams ground coffee weight<img alt="Tamped Coffee" class="alignright wp-image-2676" src="https://hookcoffee.files.wordpress.com/2016/08/tamped.jpg" style="height:331px; width:365px" /> 35 grams brewed coffee weight The weight of the liquid espresso is ideally somewhere around one to three times the amount of dry coffee. The most common brew ratio to start with is two times the dry coffee dose.</p>\r\n\r\n<h3><strong>Investment: A Shot Timer </strong></h3>\r\n\r\n<p>Use a shot timer with a pair of scales to get your espresso exactly how you want it. The shot time is how long it takes from starting the extraction to when you reach your target brew ratio. You want to have this time between 25 and 35 seconds. I normally aim for around 30. The perfect shot time is dependent on more factors than I could possible hope to go into, so just take my word for it and get it as close to 30 as possible. You might be wondering how you change the shot time. If you have a manual machine, and you press a button, pull a lever, or do anything really to control how much water passes through a shot, you simply watch your shot timer and press that button stopping it around thirty seconds. That is all good and well, but if you don&rsquo;t have the correct grind, stopping the extraction at thirty seconds might be too long or not long enough for your brew ratio.</p>\r\n\r\n<h3><strong>Investment: A Grinder<img alt="Coffee Grinder Empty Group Head" class="alignright wp-image-2677" src="https://hookcoffee.files.wordpress.com/2016/08/grinder-empty-group-head.jpg" style="height:612px; width:400px" /> </strong></h3>\r\n\r\n<p>The coarseness of the grind is the most important variable in extraction. Larger coffee particles will extract quicker while smaller coffee particles extract slower. If you stopped the extraction at 30 seconds, and the ratio is off, you need to adjust the grind. I personally use this grinder by Breville. Scout&#39;s honour.&nbsp;They are great machines, which in many ways outperform the more manual, commercial grinders. They retail for about $199.99 USD. I am not being paid to say this, but you should really take a look at Breville&rsquo;s grinders.<a href="http://www.breville.com.au/">&nbsp;http://www.breville.com.au/</a> That&rsquo;s right, I am not talking about a blade grinder, which cuts up coffee into randomly sized granules. You need a precision instrument made for coffee. The consistency of the grind will impact coffee extraction regardless of the method you use, and different extraction methods require different grinds. Having your own grinder allows you to set the grind. You can also buy unground beans, saving money and allowing you to be more selective.</p>\r\n\r\n<h3><strong>Investment: Tamper</strong></h3>\r\n\r\n<p><img alt="Tamping Coffee" class="alignleft size-medium wp-image-2678" src="https://hookcoffee.files.wordpress.com/2016/08/tamp.jpg?w=200" style="height:300px; width:200px" />Your tamper needs to be the same size as your group head. If it is a little bit smaller, as is often the case on cheaper home equipment, you are not compressing the grind evenly. This results in something called channeling. Water will take the path of least resistance. If you never compacted the grind around the edge of the group head, the water will all quickly flow through that channel, and the coffee won&rsquo;t extract properly. &nbsp; You tamp also needs to be consistent. You might have heard a rumour that you need to tamp with 7kg or 15kg of pressure. This is nonsense. Your grind determines your extraction time and very famous baristas have stood behind barely tamping. &nbsp; &nbsp;</p>\r\n\r\n<h3><strong>Investment: Beans</strong></h3>\r\n\r\n<p><img alt="Hook Coffee Beans" class="alignleft wp-image-2510" src="https://hookcoffee.files.wordpress.com/2016/07/920812_517604705069915_4967608315771799532_o.jpg" style="height:327px; width:491px" />I could talk about beans all day, but I will try keep this short and go over what you need to know. While there are around 20 major species within the Genis &lsquo;Coffea&rsquo; humans have only deemed two species worthy of cultivation; Coffea Arabica (known as Arabica), and Coffea Canephora (Known as Robusta) Arabica species make up 60 &ndash; 70% of the Coffee market, and it is generally considered better. Robusta is not without its qualities. It is valued for producing a thicker crema, and it is a lot easier to grow, so almost always cheaper. The freshness of the beans is another major factor influencing taste. Coffee beans have complex oils, and they definitely do not get better with age. Exposure to oxygen, humidity, and sunlight, all affect the volatile oils in coffee beans. Have you noticed the valves on supermarket coffee packets? These are put there so the beans can gas off. As soon as you roast coffee the oils evaporate when they come into contact with air. Supermarket beans were roasted months, maybe even years, ago. If they didn&rsquo;t have that valve the bag would explode. <a href="https://hookcoffee.com.sg/">Hook Coffee</a> can have sustainably grown, ethically produced, Arabica coffee beans sent to your doorstep within a week of roasting. You won&rsquo;t see any valves on our bags. The flavour hasn&rsquo;t had time to evaporate. If you are going to change one thing about how you are making coffee, try out some new beans. <a href="https://hookcoffee.com.sg/"><img alt="cropped-screen-shot-2016-03-09-at-00-27-203.png" class="alignleft size-full wp-image-41" src="https://hookcoffee.files.wordpress.com/2016/03/cropped-screen-shot-2016-03-09-at-00-27-203.png" style="height:64px; width:73px" /></a> Click <a href="https://hookcoffee.com.sg/">here</a> to learn more. &nbsp;</p>\r\n	2017-03-12 23:18:00.893922+00	2016-08-18 06:46:29+00	hookcoffee	./small_purchases_at_home_hookblog.jpg	6	small-purchases-to-improve-your-coffee-at-home
23	Stuck Without Gear? Cold Brew Coffee With a Clean Sock!	We all know that feeling. You spend hours packing up all your coffee gear, each device particularly oriented to ensure safe travels. You find yourself at your destination, tired and not interested in unpacking. The next morning rolls around and you shuffle..	<p>We all know that feeling. You spend hours packing up all your coffee gear, each device particularly oriented to ensure safe travels. You find yourself at your destination, tired and not interested in unpacking. The next morning rolls around and you shuffle through your suitcase, becoming more and more frantic. The terrible reality hits you:<strong> you left all your coffee brewing gear at home.</strong> Though inconvenient it may be, there is hope beyond the gear as long as you have coffee and water. Take note of what&rsquo;s around you. A stove and a pot? There&rsquo;s your source for hot water. A hammer and a towel? Your coffee grinder. With a little creativity and some willingness to drink less-than-ideal coffee, you won&rsquo;t have to go without your desperately needed caffeine for long.</p>\r\n\r\n<h2>For Immediate Desperation</h2>\r\n\r\n<p>If the clock is ticking until your sanity meter runs dangerously low, you need to get some water boiling. Pour that water over some crushed coffee beans and you&rsquo;ll have yourself a mug of cowboy coffee in about four minutes. That&rsquo;s simple enough, but this routine gets old and those coffee grounds aren&rsquo;t very fun to drink. Lucky for you, oh desperate coffee drinker, there&rsquo;s another way.</p>\r\n\r\n<h2>Enter The Sock</h2>\r\n\r\n<p>A clean sock makes for an effective coffee filter. The threads are woven finely enough to prevent coffee sediment from polluting your mug, and you&rsquo;ll never be farther than a skip and a hop from one, as long as you keep up with the laundry. Hot brewed and cold brew coffee are both easily attainable possibilities with a sock in your toolbox.</p>\r\n\r\n<h2>How To Make Cold Brew Coffee With A Sock</h2>\r\n\r\n<p>Begin by collecting your materials.</p>\r\n\r\n<ul>\r\n\t<li>A Vessel (a mug or small glass will work)</li>\r\n\t<li>A Filter (a clean sock)</li>\r\n\t<li>Coffee (ground using a plastic bag, towel, and hammer)</li>\r\n\t<li>Water</li>\r\n</ul>\r\n\r\n<ol>\r\n\t<li>Take about four tablespoons of coffee beans and put them in a plastic bag. Then wrap the plastic bag in a towel of some sort and use your hammer to reduce the beans to rubble. It may take a few minutes of whacking at the beans.</li>\r\n</ol>\r\n\r\n<p><img alt="DSC_0341" class="alignnone size-large wp-image-2687" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_03411.jpg?w=1000" style="height:665px; width:1000px" /></p>\r\n\r\n<ol start="2">\r\n\t<li>Nobody wants laundry detergent or cat hair flavored coffee, so give the sock a rinse before you pour the coffee into it. You may need to stretch&nbsp;the sock over your mug or glass to be able to pour the grounds in without a big mess.</li>\r\n</ol>\r\n\r\n<p><img alt="DSC_0346" class="alignnone size-large wp-image-2689" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0346.jpg?w=1000" style="height:665px; width:1000px" /></p>\r\n\r\n<ol start="3">\r\n\t<li>Pour six to eight ounces of cold water into your vessel. A standard small mug holds about eight ounces.. After five minutes, dump the sock in and out of the water (teabag style) to saturate all of the grounds evenly.</li>\r\n</ol>\r\n\r\n<p><img alt="DSC_0349" class="alignnone size-large wp-image-2690" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0349.jpg?w=1000" style="height:665px; width:1000px" /></p>\r\n\r\n<ol start="4">\r\n\t<li>After twelve hours of brewing time, lift the sock from the cold brew concentrate&nbsp;and allow the water to drain from the coffee grounds and sock threads.</li>\r\n</ol>\r\n\r\n<h2>Time To Drink</h2>\r\n\r\n<p>When the time has come, cut the cold brew concentrate with an equal part of water and add some ice. You may find that the flavors aren&rsquo;t quite as rich as you&rsquo;re used to. Don&rsquo;t be shocked - you used a hammer and a sock to brew coffee. <img alt="cold brew coffee with a sock" class="aligncenter size-large wp-image-2704" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0352.jpg?w=1000" style="height:665px; width:1000px" /></p>\r\n\r\n<h2>Lessons Learned</h2>\r\n\r\n<p>There is an obvious lesson hidden within the blog: don&rsquo;t forget your coffee gear. A second lesson deserves to be noted: Lugging around a lot of coffee gear can be tiring and burdensome. A large bag of pour over brewers, kettles and scales is effective at brewing coffee, but not for traveling light. For great cold brew coffee on the road without sacrificing portability, we at Hook Coffee suggest a couple small devices: a <a href="https://www.amazon.com/Hario-Ceramic-Skerton-Storage-Capacity/dp/B001802PIQ">small manual coffee grinder </a>and a dedicated <a href="https://www.amazon.com/Specially-Designed-Cold-brewing-Reusable-Pouches/dp/B00QG1Y18E/ref=cm_rdp_product">cold brew coffee sock</a>. With these two tools at your disposal, along with <a href="https://www.quora.com/">some high quality coffee beans</a>, you can cold brew delicious coffee anytime, anywhere.</p>\r\n	2017-03-12 23:18:00.915709+00	2016-08-21 04:19:34+00	hookcoffee	./cold_brew_coffee_with_a_clean_sock_hookblog_-2.jpg	4	stuck-without-gear-cold-brew-coffee-with-a-clean-sock
19	A Glimpse into Direct Trade Coffee in  Aceh, Indonesia	This is the third and last installation of our Direct Trade commentary and we thought we'd conclude it by sharing about our magical sourcing trip in Indonesia (fun fact: Indonesia is the fourth largest producer of coffee in the world!)\r\n\r\nAlong with our part..	<p>This is the third and last installation of our Direct Trade commentary and we thought we&#39;d conclude it by sharing about our magical sourcing trip in Indonesia (fun fact: Indonesia is the fourth largest producer of coffee in the world!) Along with our partners from the Specialty Coffee Association of Europe, our team of 19 headed to Banda Aceh last November. We used Banda Aceh as our base to move around to different farms. Just over 1000km from Singapore, Banda Aceh is located on the island of Sumatra, on the Northwestern tip of Indonesia at the mouth of the Aceh River. It is also the largest city of the province of Aceh. It&#39;s been 12 years since the 2004 Boxing Day tsunami hit the city and killed 167,000 people. Banda Aceh recovered brilliantly from the devastating disaster and showed us what resilience meant - roads, bridges, and homes have been rebuilt, trees have been replanted and grown, the millions of tons of debris that covered the shores (2km inland) have been removed. But reminders of the disaster seem to be everywhere.&nbsp;Almost everyone in Banda Aceh has a story to share. The rural coffee farms that surround the city, high up in the hills, were unscathed. The silver lining was that the coffee industry blossomed in a time of despair and provided a source of comfort and support for the rebuilding of the city. We resolved to visit the farms of Aceh and while there were too many farms and too little time, we narrowed down to 4 farms &amp;&nbsp;cooperatives that are similar in their dedication to the development of specialty coffee but unique in their production and processing methods.</p>\r\n\r\n<hr />\r\n<p><strong>Our Warm Welcome</strong> Our trip began with a long and tiring journey to Banda Aceh. We were rather exhausted when we finally reached (as with all travels), but the welcome and care taken by our hosts put all that behind us soon enough. Our first hotel was The Pade Hotel (&ldquo;Pade&rdquo; meaning rice) located on the outskirts of the city. The hotel backed onto vast stretches of rice fields making for a picturesque scene. From our hotel, we would see farmers preparing the water filled fields for their sowing during the next month. Our time with the beautiful and expansive flatlands was short-lived as we left the next day to embark on an 8-hour long drive to Gayo Mountain, located in the town of Takengon. Takengon, a town in Aceh, is in the highlands of western Sumatra and situated on the shores of Lake Laut Tawar. Takengon sits at the head of the Lake, surrounded by the coffee-growing mountains. <img alt="Pantan terong.jpg" class="alignnone size-full wp-image-2538" src="https://hookcoffee.files.wordpress.com/2016/07/pantan-terong.jpg" style="height:533px; width:1024px" /> <strong>Pantam&nbsp;Terong&nbsp;farm</strong> On Day 2, we visited a small farm in the town &ndash; much of the coffee produced in Gayo is produced organically on smallholdings, where families grow and pulp the coffees, laying the parchment to dry in front of the house. The Pantam Terong farm produces 1.5 tonnes of parchment per year. Coffee grown in this farm is all shade grown &ndash; meaning coffee is produced from coffee plants grown under a canopy of trees that provide shade. Before the parchment is fully dry (35-40% moisture), it is taken to a milling station where the parchment is removed to expose damp coffee beans. The beans are then returned to complete the drying process, where the parchment is dried to 13% moisture levels. This is called wet hulling or girling basah. This is the reason Gayo coffee, as it&rsquo;s known for, has a significant blue/green colour that differentiates it from other coffees in the world. Didn&#39;t know that, did you? Honestly, neither did we. <strong><img alt="12370697_517604475069938_7736348981843641724_o.jpg" class="alignnone size-full wp-image-2515" src="https://hookcoffee.files.wordpress.com/2016/07/12370697_517604475069938_7736348981843641724_o1.jpg" style="height:1362px; width:2048px" /></strong> <strong>KBQ Bubburrayan Cooperative</strong> Day 3 started off a little more laid back. We made a trip to the KBQ Bubburrayan Cooperative after lunch. The cooperative was started in 2002 and has 7000 members to date, each producing 700-1000kg of coffee. The system works as follows: the farmer brings in his coffee and the defective beans are measured against the good beans via cupping. Following this, the farmer then offered a price. <img alt="12365923_517604501736602_7179405425804572908_o.jpg" class="alignnone size-full wp-image-2536" src="https://hookcoffee.files.wordpress.com/2016/07/12365923_517604501736602_7179405425804572908_o.jpg" style="height:2048px; width:1362px" /> At the cooperative, we also got to see firsthand the processes involved in producing coffee after the parchment is dried. Following drying, local ladies pick out defaults from a conveyor belt and hand sort the beans before they are graded and bagged for export. Our trip round the production plant ended with a tasting session where we learnt how to identify and savour the citric and floral notes in coffee, alongside very wine-y coffee from natural processing. <img alt="10861024_517604455069940_149456631508834082_o.jpg" class="alignnone size-full wp-image-2532" src="https://hookcoffee.files.wordpress.com/2016/07/10861024_517604455069940_149456631508834082_o.jpg" style="height:1362px; width:2048px" /> The Indonesian government lays down strict rules on how coffee can be grown and processed. They limit farms to 1,800 trees per hectare, and each tree is changed every 25 years. Each tree is expected to produce 1 kg of coffee cherries (= 20g of green beans). Trees are pruned down to 2 metres, weeds are cleared with a mattock and pulp is laid between the rows as compost. Red cherries are then collected via selective picking. During our visit, we also saw small, humble research laboratories where studies of the coffees are done - the research is performed to determine the quality and characteristics of the coffees, and how the quality can be maintained or bettered sustainably. Here, we also saw jars of Kopi Luwak (Asian palm civet) parchment. We requested to see the animals, and were greeted with a satisfying reply of: &ldquo;I doubt it, as we will have to catch one first&rdquo;. This probably means that the civet cats are free-range and the Kopi Luwak is obtained naturally, instead of being reared in cages and force-fed. <strong>Kebun Percobaan Gayo Coffee Plantation</strong> Day 4 was especially eventful. We visited the coffee plantations of Kebun Percobaan Gayo. To welcome us, a lovely flute melody was performed for us before commentators gave us an introduction on the background of the farm. We got the fun opportunity to don the pickers&rsquo; traditional clothing and take part in a cherry-picking competition to see who could pick the most quality cherries in 10 minutes. Our next task was to plant a tree &ndash; a tradition for visitors like ourselves. Each tree was named and their crops to go to the local community. <img alt="12374845_517604551736597_6569361109159226326_o.jpg" class="alignnone size-full wp-image-2522" src="https://hookcoffee.files.wordpress.com/2016/07/12374845_517604551736597_6569361109159226326_o.jpg" style="height:1362px; width:2048px" /> The farmers were extremely warm and welcoming, and we even got the fun opportunity to don the pickers&rsquo; traditional clothing and take part in a cherry-picking competition to see who could pick the most quality cherries in 10 minutes. None of us from Hook won, but it gave us a better idea of the arduousness involved in the process of handpicking each and every coffee cherry is. Our next task was to plant a tree &ndash; a tradition for visitors like ourselves. Each tree was named and their crops to go to the local community. On the way back to Takengon, we saw the wide range of crops that are grown: maize, banana, sweet potato and peanuts. We stopped by a small garden that grew not only a few coffee trees, but grew chilli, ginger, cassava and oranges as well! One of our team members decided to get really into the pulping process (well actually, he was just busy snap chat-ting&nbsp;and wasn&#39;t paying attention to where he was stepping!) and fell into the wet pit of decomposing pulp! We all had a good laugh! Luckily, he was pulled out before he was completely submerged in rotten pulp. He had the fortune of being hosed down by one of the local farmers&nbsp;who also gave him some old clothing to wear on our trip back to the hotel. <img alt="12339418_517604625069923_8894631741635747590_o-2.jpg" class="alignnone size-full wp-image-2524" src="https://hookcoffee.files.wordpress.com/2016/07/12339418_517604625069923_8894631741635747590_o-2.jpg" style="height:2048px; width:1362px" /> <strong>Kebun Percontohan Coffee Farm and the Co-op</strong> On the morning of our 5th day, we set off to visit a certain&nbsp;Mr Maisir Aman Al&rsquo;s farm, Kebun Percontohan, that produces 3,500kg of coffee per year in 0 .5 hectares of Gayo 2 coffee trees. As coffee here is shade grown&nbsp;like most of the plantations in this region, Lamptora trees with orange, cinnamon and avocado formed the lush canopy - shading both us and the coffee shrubs from the harsh sun rays. The&nbsp;shade from the canopy also results in longer maturing time, and this allows the flavours and natural sweetness of the coffee cherries to be more developed. <img alt="12377761_517604591736593_3933651594894867354_o.jpg" class="alignnone size-full wp-image-2517" src="https://hookcoffee.files.wordpress.com/2016/07/12377761_517604591736593_3933651594894867354_o.jpg" style="height:1362px; width:2048px" /> We then moved on to the Co-op, Koperasi Serba Usaha &ndash; Gayo Mandiri and received a warm welcome from its officials and farmers. The Co-op has 1,300 farmers who bring their coffee for processing and certification. Following the cupping tests, the beans are then sent to Medan for final grading, sorting and bagging before being exported. We got to witness the processing of the beans and enjoyed a tasting session before lunch. <img alt="920812_517604705069915_4967608315771799532_o.jpg" class="alignnone size-full wp-image-2510" src="https://hookcoffee.files.wordpress.com/2016/07/920812_517604705069915_4967608315771799532_o.jpg" style="height:1362px; width:2048px" /> <strong>The Farewell</strong> e were inevitably sad to leave the land of endless rice fields, cows grazing on central reservations, colourful mosques and an abundance of scooters&hellip; Not to mention the culinary wonder of Aceh. (We cannot even begin to describe how much we LOVED the food.) All of this brought us so much joy and laughter, and a&nbsp;wealth of knowledge on the local customs, culture, and coffee production in Indonesia.&nbsp;Our week&#39;s stay in Aceh was blessed with unforgettable memories&nbsp;and new friendships. Farewell speeches were made as we bid our goodbyes to our new friends that we made in Aceh Tengah and Bener Meriah. The next morning, we embarked on our day-long drive back to Banda Aceh through the mountains and the paddy fields, and then made our way home to Singapore the following day.</p>\r\n\r\n<hr />\r\n<p>Banda Aceh has come a long way since the tsunami tore through the city that fateful day. But more than the rejuvenation the city has experienced since then, the Sumatran locals we met on our trip truly completed the entire experience. They were extremely warm, welcoming, and lively, never letting us feel uncomfortable at any time. For this, we are infinitely grateful and we hope to meet them again some day! <img alt="12370880_517604685069917_4489777521717637744_o-2.jpg" class="alignnone size-full wp-image-2512" src="https://hookcoffee.files.wordpress.com/2016/07/12370880_517604685069917_4489777521717637744_o-2.jpg" style="height:2048px; width:1362px" /> It is through Direct Trade that such relationships are forged, and communities are built and rebuilt. It is also through Direct Trade that we can be confident of the quality of the coffees we offer and the sustainable processes used in their production. More importantly, we find meaning in traceability and purpose in our role as storytellers for our farmers and the communities behind them. With this, we conclude our three-part series on Direct Trade and hope you&#39;ve been enlightened as much as we have been! We hope that it has been an informational and interesting read that&nbsp;gives you a better idea of what we believe in and why. &nbsp; <img alt="10320965_517606165069769_6549617816627689499_o.jpg" class="alignnone size-full wp-image-2526" src="https://hookcoffee.files.wordpress.com/2016/07/10320965_517606165069769_6549617816627689499_o.jpg" style="height:1350px; width:1800px" /> &nbsp;</p>\r\n	2017-03-12 23:18:00.837214+00	2016-07-18 14:00:00+00	hookcoffee	./a_glimpse_into_direct_trade_indonesia_hookblog.jpg	5	a-glimpse-into-direct-trade-coffee-in-aceh-indonesia
26	Stop Throwing Away Your Left Over Coffee Grounds...Do This Instead!	Stop Throwing Away Your Left Over Coffee Grind...Do This Instead\r\n\r\n\r\n\r\nIf you are like me, when your bin fills up with used coffee ground, you probably toss it all away without a second thought. I have shamelessly been throwing my used coffee away for years, ..	<h1 style="text-align:center">Stop Throwing Away Your Left Over Coffee Grind...Do This Instead</h1>\r\n\r\n<p><img alt="IMG_9424" class="aligncenter size-full wp-image-2748" src="https://hookcoffee.files.wordpress.com/2016/08/img_9424.jpg" style="height:666px; width:1000px" /> If you are like me, when your bin fills up with used coffee ground, you probably toss it all away without a second thought. I have shamelessly been throwing my used coffee away for years, and I never thought anything of it. That was until I chanced upon a store promoting all the uses for left over coffee beans. I thought this is the kind of info Hook Coffee&rsquo;s readers might be interested in, and this post came to be.</p>\r\n\r\n<h2>Exfoliate</h2>\r\n\r\n<p>This is the most exciting use of leftover coffee grounds, as coffee grounds are abrasive and effective at sloughing off dead skin. Coffee is also rich in flavonols, an antioxidant compound, that contributes to leave skin looking vibrant. &nbsp;</p>\r\n\r\n<p style="text-align:center">Hook Coffee Body Scrub</p>\r\n\r\n<ul>\r\n\t<li>1 cup leftover coffee grounds</li>\r\n</ul>\r\n\r\n<p><img alt="IMG_9426" class="aligncenter size-full wp-image-2750" src="https://hookcoffee.files.wordpress.com/2016/08/img_9426.jpg" style="height:666px; width:1000px" /></p>\r\n\r\n<ul>\r\n\t<li>3 tbsp of seasalt or sugar and 2 drops of essential oil (lavender, lemon, peppermint, geranium etc.) if you wish.</li>\r\n</ul>\r\n\r\n<p><img alt="Adding Lavander To Coffee Ground" class="aligncenter size-full wp-image-2747" src="https://hookcoffee.files.wordpress.com/2016/08/img_94231.jpg" style="height:666px; width:1000px" /></p>\r\n\r\n<ul>\r\n\t<li>&frac12; cup coconut oil</li>\r\n</ul>\r\n\r\n<p><img alt="Coffee Ground with coconut milk " class="aligncenter size-full wp-image-2751" src="https://hookcoffee.files.wordpress.com/2016/08/img_9427.jpg" style="height:666px; width:1000px" /></p>\r\n\r\n<ul>\r\n\t<li>In a bowl combine all the ingredients into a paste. Store in an airtight container in your refrigerator.</li>\r\n</ul>\r\n\r\n<p><img alt="Coffee Ground" class="aligncenter size-full wp-image-2749" src="https://hookcoffee.files.wordpress.com/2016/08/img_9425.jpg" style="height:666px; width:1000px" /> **Do not use instant coffee, the coffee will dissolve into the coconut oil.</p>\r\n\r\n<h2>Fertilizer</h2>\r\n\r\n<p>Coffee grounds are rich in nitrogen. As a rule of thumb, most fertilizers contain potassium, nitrogen, and phosphate. Coffee is not just great for composting with other organic material, you can literally take it and throw it into a garden, and your plants will love you for it. Don&rsquo;t do this every day, as too much nitrogen can throw the plant out of balance, and you might damage it. Fun fact# If you dilute your urine, it is an excellent fertilizer.</p>\r\n\r\n<h2>Deodorizer</h2>\r\n\r\n<p>Coffee is really good at absorbing smells. The only explanation I could find for why, is that it works like baking soda, and coffee is a natural deodorizer. My understanding of this is that it does more than just mask the smells. Somehow, coffee sucks the smell up. All you need to know is that if you put some used coffee ground in a Tupperware container and place it in a confined space, it will get rid of any lingering nasty smells. I wish I knew this when I moved into my apartment. The walls are all concrete and it only has one window. Needless to say it smelt like musty, wet sock for two months, until I finally burnt enough scented candles to mask the smell. Place coffee in your car or fill the bottom of an ash tray with left over coffee. Sneak a container into the bathroom. Better yet, grow a plant in the bathroom and fertilize it with coffee.</p>\r\n\r\n<h2><strong>Pest Control</strong></h2>\r\n\r\n<p>Some people swear by coffee&rsquo;s bug repelling quality. I have mixed experiences with this. Day in and day out most coffee shops battle the army of cockroaches, which descend upon them. They are attracted to the warmth of the machine, but the coffee doesn&rsquo;t exactly scare them away. I found this on an article where some guy was burning coffee grind, and you can see the bugs clearly aren&rsquo;t enjoying it. My advice to you is, try it and see what results you get. The bugs in Singapore might love or hate coffee, and I think it depends on your area. So there you have it. If you have any other uses for coffee, please leave them in the comments below. Hook Coffee can deliver single origin coffee beans to your door, a week after the beans are roasted, and their unique subscriptions make coffee affordable and easy. Take a look <a href="https://hookcoffee.com.sg/">here</a>. <a href="https://hookcoffee.com.sg/"><img alt="cropped-screen-shot-2016-03-09-at-00-27-203.png" class="aligncenter size-full wp-image-41" src="https://hookcoffee.files.wordpress.com/2016/03/cropped-screen-shot-2016-03-09-at-00-27-203.png" style="height:64px; width:73px" /></a> &nbsp;</p>\r\n	2017-03-12 23:18:00.979687+00	2016-08-28 14:00:37+00	hookcoffee	./stop_throwing_away_your_left_over_coffee_grounds_hookblog.jpg	6	stop-throwing-away-your-left-over-coffee-grind-do-this-instead
20	Know If You Are Getting A Good Coffee Before You Place An Order	Know If You Are Getting A Good Coffee Before You Place An Order\r\n\r\n[caption id="attachment_2641" align="aligncenter" width="625"] Hook Coffee[/caption]\r\n\r\nLoving coffee is as much a blessing as it is a curse. You can walk into a nice looking café and pay premi..	<h1 style="text-align:center">Know If You Are Getting A Good Coffee Before You Place An Order</h1>\r\n\r\n<p><img alt="Hook Coffee " class="size-full wp-image-2641" src="https://hookcoffee.files.wordpress.com/2016/08/hook-coffee-photo-1.jpg" style="height:416px; width:625px" /> Loving coffee is as much a blessing as it is a curse. You can walk into a nice looking caf&eacute; and pay premium for a coffee, which comes out of an impressive machine, only to take a sip and feel your face scrunch up in disgust. By now your friends have noticed, and they will start with their usual, &lsquo;the coffee is fine. What are you complaining about? You snob.&rsquo; You pity and envy them at the same time. Ignorance is, after all, bliss. I am here for you. You are not a snob, and it isn&rsquo;t your fault. The trendy new caf&eacute; you brought your friends to has artificial grass on the seats, and the light bulbs hang in glass jars. It is all very new age, and this looks like the kind of place where you come to get a good coffee. <strong>Rule #1 The Coffee Shop D&eacute;cor Means Nothing.</strong> Coffee is made by a person, with a machine, behind a counter. Assuming they started off with quality beans, the taste of your coffee is really down to the person making it. Let&rsquo;s make that rule number two <strong>Rule #2 Watch The Barista</strong> I am going to let you in on some tricks of the trade. Follow my advice, and you will know if you are going to get a good coffee before you even place an order. <strong>Step 1. Check the Hopper</strong> <img alt="BARATZA VIRTUOSO COFFEE GRINDER" class="wp-image-2636" src="https://hookcoffee.files.wordpress.com/2016/08/virtuoso-hopper_grande.png?w=300" style="height:345px; width:345px" /> The hopper holds the coffee beans in their unground form, and it is the first place coffee beans go when they leave the bag. Coffee beans have all kinds of oils/terpenes. We need these oils. They are responsible for that gorgeous espresso taste we all know and love. Check to make sure the hopper is clean. If there is any brown residue on the plastic, what you are seeing is a built up layer of oils. These oils quickly go rancid, and this makes coffee taste HORRIBLE!! In a dirty hopper, all of those beautiful fresh beans are pressed through rancid oils. <strong>Step 2. The Tamp</strong> When a barista tamps the coffee, they press it down into the group head. (The basket looking thing) This is done to evenly compact the grind. When done correctly it ensures an even extraction, and your coffee won&rsquo;t taste burnt or bitter. <img alt="Tamping Coffee" class="size-medium wp-image-2637" src="https://hookcoffee.files.wordpress.com/2016/08/coffee-tamping1.jpg?w=300" style="height:225px; width:300px" /> The group head is filled with ground coffee, tamped, and then it is locked into the machine. Water is forced through the coffee grind. All of the flavour, taste, and caffeine are extracted from the beans by this pressurised water. Think of extracting the espresso as cooking the coffee. It is a crude analogy, but it has its purpose. When you put a chicken in the oven, you will first read the packet and find out how long it has to be in there. We all know that if you leave it in too long it burns, and if you take it out to soon it is raw. Extracting espresso works the same way, but you don&rsquo;t set the oven with knobs and dials. How long the coffee takes to extract is affected by the density of the grind in the group head. The density in the group head is affected by the tamp. Most commercial coffee machines will pump water at 9 bars of atmospheric pressure through the grind. This water is very hot, so if it passes too slowly through the coffee grind it will burn. Similarly, if it passes too quickly, it won&rsquo;t extract properly. Just like our chicken. I hope you follow, but I will try make it even clearer. Imagine you have two buckets. One is filled with sand, and the other is filled with rocks. <img alt="Coffee Grind" class="size-medium wp-image-2638" src="https://hookcoffee.files.wordpress.com/2016/08/dispersion.gif?w=300" style="height:247px; width:300px" /> Now imagine we poured water through our bucket of rocks. What will happen? There is space between the rocks, and as you would expect, the water passes quickly through the bucket. What about the bucket of sand? Sand is very course. The water will take longer to flow through the bucket. The bucket filled with sand will have a longer espresso extraction time then the bucket filled with rocks. Remembering all of this you need to watch how the barista tamps the coffee. The water pressure will always be the same, so the barista&rsquo;s technique should always be the same. If you notice variations in how they are tamping, run a mile you are about to pay for a bad coffee. <strong>Step 3. The Shot Time</strong> Coffee is as much a science as it is an art. Don&rsquo;t believe me? Look at this formula. Extraction yield % = Brewed Coffee[g] x TDS[%] /Coffee Grounds[g] E.g. (espresso) 36g brewed coffee x 10% TDS / 18g ground coffee = Extraction yield of 20%. <img alt="Espresso" class="size-medium wp-image-2639" src="https://hookcoffee.files.wordpress.com/2016/08/f1xno2ohigfaxwx-medium.jpg?w=300" style="height:225px; width:300px" /> I can cover exactly what that all means in later posts, if you want to go full coffee nerd. But for now, the point I am trying to make is coffee has a recipe. Remember when I said, before you put a chicken in the oven, you read the temperature on the back of the box and set the oven. Coffee is no different. It is not hard to calculate exactly how much time a shot should take to extract. From when the barista pushes that button to when the shot stops pouring is called the extraction time, and it is arguably the single biggest contributor to the taste of the coffee. The majority of commercial coffee machines has inbuilt volumetrics. This means they measure the volume of water which passes through them, and they pump out the same amount of water every time. Do you see how all of the variables are fixed? The pressure, the amount of water. The only real variable that the barista controls is the grind and the tamp. Using the above formula, the ideal shot time is around 30 seconds. It varies a little bit depending on beans, preference, climate, altitude, the list goes on. But as rule of thumb, a good barista will time a shot to around thirty seconds. Spying on your barista, might sound a little over the top to you, but coffee is expensive. If you are about to sink money into a cup, get out your phone and time the shots being poured. Press go the second the barista presses the button. It will take around 5 seconds for the shot to start pouring, and another 25 for it to go &lsquo;click&rsquo; and finish. 5 seconds either side of 30 seconds is a good margin of error. Another thing to note is that some machines pour smaller shots for smaller coffees. Do not time a shot going into a small coffee. The machine will put out less water, and this in turn quickens the shot time. <strong>Step 4. Talk to the barista</strong> <img alt="Espresso Machine" class="size-medium wp-image-2640" src="https://hookcoffee.files.wordpress.com/2016/08/dsc8994.jpg?w=296" style="height:300px; width:296px" /> Ask them if they time their shots, and when they last adjusted the grind. There is a proportionate relationship between knowledge and the quality of the coffee in your cup. I do not subscribe to the idea that a barista can get by on talent alone. No one has the talent to magically set the grind. They have to know what they are doing, and why they are doing it. <strong>Some Final Words</strong> This knowledge and scientific method is what third wave coffee is all about. We are leaving the dark ages, and your stand against bad coffee is ushering in the renaissance. No one wants to pay for a bad coffee, and for too long we have settled on whatever was put in our cups. With your eyes and your phone, you can deduce if you are going to get good coffee in under a minute. Try it out for yourself. You don&rsquo;t need an expensive expresso machine to get serious about coffee at home. Click <a href="https://hookcoffee.com.sg/">here</a> to learn more about the most important step towards a good coffee. <a href="https://hookcoffee.com.sg/"><img alt="Hook Coffee Logo" class="alignleft wp-image-63" src="https://hookcoffee.files.wordpress.com/2016/03/cropped-screen-shot-2016-03-09-at-00-26-211.png" style="height:144px; width:187px" /></a> &nbsp; &nbsp; &nbsp; &nbsp; Share this article on social media and help us eradicate bad coffee. &nbsp;</p>\r\n	2017-03-12 23:18:00.852347+00	2016-08-13 14:22:24+00	hookcoffee	./know_if_you_are_getting_good_coffee_before_placing_an_order_hookblog_.jpg	10	know-if-you-are-getting-a-good-coffee-before-you-place-an-order
24	HOW TO READ A COFFEE PACKAGING LIKE A PRO	There’s a lot to learn about a coffee’s origin, roaster, and general quality of the packaging, and not all of it is good. We’ve all been there: you meander down an aisle or scroll down a web page to see dozens or even hundreds of coffee bags, each saying t..	<p>There&rsquo;s a lot to learn about a coffee&rsquo;s origin, roaster, and general quality of the packaging, and not all of it is good. We&rsquo;ve all been there: you meander down an aisle or scroll down a web page to see dozens or even hundreds of coffee bags, each saying they&rsquo;re gourmet and flavorful - but which ones are actually going to be good? Decades of misleading marketing and meaningless lingo have left us blind in the face of options, but the scheme is unraveling. Secrets of shady coffee sellers are coming into the light, but some companies are emerging stronger than ever. To find these honest, quality-minded coffee roasters, all you must do is read the secrets of coffee packaging.</p>\r\n\r\n<h2>The Roast Date</h2>\r\n\r\n<p>Coffee beans are an agricultural product with a limited lifespan, a reality profit-focused coffee companies have tried to undermine. To keep products on the shelves and reduce the need to closely monitor the freshness of their coffee, some businesses only print a &ldquo;Best By&rdquo; date on the bag or can, usually giving you the impression that you have months before the beans pass their point of peak freshness. <img alt="stale coffee" class="aligncenter size-large wp-image-2736" src="https://hookcoffee.files.wordpress.com/2016/08/stale-coffee-e1472675386681.jpg?w=1000" style="height:406px; width:1000px" /> In reality,&nbsp;peak freshness is reached within a week or so of being roasted, and the decay of flavors becomes obvious after two weeks. Misleading consumers to believe that coffee beans can remain fresh for months is downright&nbsp;dirty. You can clearly see in this graph that in the best conditions coffee freshness has peaked before a month. However, these ideal conditions are rarely met and the two-week rule is still the&nbsp;standard. <img alt="coffee packaging" class="aligncenter size-full wp-image-2759" src="https://hookcoffee.files.wordpress.com/2016/08/kaladi-staling.jpg" style="height:610px; width:851px" /> At all costs, avoid coffee packaging that claims a &ldquo;Best By&rdquo; date. Instead look for a &ldquo;Roasted On&rdquo; date, which indicates a coffee roaster dedicated to transparency and quality.</p>\r\n\r\n<h2>Origin and Story</h2>\r\n\r\n<p>Coffee beans are grown inside a cherry. If you take one of those beans out of the cherry and put it in the soil, under the right conditions, you&rsquo;ll eventually have a coffee plant. It takes people to plant crops and harvest them, and in many parts of the world these people are not well compensated for their work. Sadly,&nbsp;poverty among coffee producers is everywhere, and coffee buyers have been historically known to exploit farmers with manipulative deals. Though these devious deals are far less common in the modern world, there are many coffee roasters who could care less&nbsp;what conditions the coffee laborers faced when they purchase their beans. A bag without a person or farm is a bag without a story and a roaster without accountability. <a href="https://hookcoffee.com.sg/"><img alt="coffee packaging" class="alignnone size-full wp-image-2711" src="https://hookcoffee.files.wordpress.com/2016/08/coffee-packaging.png" style="height:2591px; width:4056px" /></a> Most&nbsp;coffee buyers &nbsp;desire to see the coffee laborers liberated from unethical deals and systemic poverty. Some of these&nbsp;businesses proudly announce the country, the region, the farm, and even the farmers that they form agreements with. Now the trail can be traced and the roasters are accountable to their customers who also desire to lift up the poor workers on coffee farms. Avoid coffee packaging that makes no mention of the region, farm, or farmer. Instead, look for the names of individuals and farms boldly claimed.</p>\r\n\r\n<h2>Flavor Language</h2>\r\n\r\n<p>Here&#39;s a simple rule: avoid coffee packaging that claims the contents are &quot;gourmet&quot; or &quot;premium&quot;. These buzzwords have no real meaning and only serve to mislead the customer into buying a lower-quality product.&nbsp;Without there being any standard by which these words are held, there&rsquo;s no way to know whether or not the beans actually brew a coffee drink that is &ldquo;gourmet&rdquo; or &ldquo;premium&rdquo; at all. Coffee roasters that nerd out on their craft are the ones that you want to look for. You can easily spot them by the language they use to describe their coffees. Don&#39;t be scared off by descriptions of &quot;strawberry and lime&quot; or &quot;vanilla and honey&quot;. These are proof that the roaster is so confident that they are willing to put themselves out there. It&#39;s okay to be skeptical at first, but you have to give it a try. <a href="http://www.hookcoffee.com.sg/"><img alt="hook coffee packaging" class="aligncenter size-full wp-image-2761" src="https://hookcoffee.files.wordpress.com/2016/09/hook-coffee-packaging.jpg" style="height:1501px; width:1000px" /></a> Important: we are talking strictly about unflavored, roasted coffee beans that have had nothing added for flavor. Some coffees come pre-sprayed with artificial flavor oils. Just don&rsquo;t.</p>\r\n\r\n<h2>The More The Better</h2>\r\n\r\n<p>The more open and honest a coffee roaster is about their product, the better. You may find that your favorite coffee roasters also publish the processing methods, altitudes of the farms, and plant varieties of their coffees. Though&nbsp;this extra information can be confusing and not really helpful, it is another indicator of a fine coffee roaster with fine coffee stored in fine coffee packaging.</p>\r\n\r\n<h2>Have A Look Around</h2>\r\n\r\n<p>Next time you find yourself at the store, take notice of how the coffee companies design their packaging. You may be shocked at which ones aren&rsquo;t so &ldquo;gourmet&rdquo; after all. For some examples of great coffee packaging, check out <a href="https://hookcoffee.com.sg/coffees/">Hook Coffee&rsquo;s lineup</a>.</p>\r\n	2017-03-12 23:18:00.935032+00	2016-09-01 04:23:15+00	hookcoffee	./how_to_read_a_coffee_packaging_hookblog.jpg	6	how-to-read-a-coffee-packaging-like-a-pro
27	What Does A Coffee Roaster Actually Do?	https://vimeo.com/112575328\r\n\r\nWhen you’re browsing websites and trying to decide which coffee you would like to try next, do you ever wonder what a coffee roaster actually does?\r\n\r\nSure, the title is fairly self-explanatory, but have you consider what it actu..	<p>https://vimeo.com/112575328 When you&rsquo;re browsing websites and trying to decide which coffee you would like to try next, do you ever wonder what a coffee roaster actually does? Sure, the title is fairly self-explanatory, but have you consider what it actually looks like? Have you thought about the science and how it all works? Have you considered the ways roasters get their beans? Have you ever wondered if roasters are really just shooting in the dark? Let the mysteries unravel. It&rsquo;s time to find out.</p>\r\n\r\n<h2>First Come The Beans</h2>\r\n\r\n<p>Without unroasted coffee beans, coffee roasters don&rsquo;t have jobs. Some coffee roasters get their beans from giant warehouses or online databases. They search through hundreds of crop samples to find coffees with their ideal flavor profile and price per pound. This has been the prevailing model for hundreds of years. <img alt="dsc_0130" class="aligncenter size-full wp-image-2779" src="https://hookcoffee.files.wordpress.com/2016/09/dsc_0130.jpg" style="height:598px; width:900px" /> The downside to this model was that a few importers used to control a large portion of the global coffee supply. In an age without instant global communication, the abuses towards coffee farmers committed by these international businesses were unnoticed by the developed coffee drinking world. Thankfully, the days of coffee farmer slavery and exploit are coming to a rapid end as business transparency and sustainable sourcing become values of the masses. These warehouse sourcing spots are still available for coffee buyers, but many with experience and globally-conscious minds are turning to another method.</p>\r\n\r\n<h2>The Direct Trade Model</h2>\r\n\r\n<p>Coffee roasters pursuing the direct trade model take frequent trips overseas to find the best coffees they can. They come face to face with coffee farmers, and the business relationships become&nbsp;personal ones. <img alt="12374845_517604551736597_6569361109159226326_o" class="aligncenter size-full wp-image-2522" src="https://hookcoffee.files.wordpress.com/2016/07/12374845_517604551736597_6569361109159226326_o.jpg" style="height:665px; width:1000px" /> These trips can be rigorous, often involving weeks of rugged travel, cross-cultural communication struggles, and logistical nightmares. The rewards are great, however. The middleman is passed by and a larger cut is making its way to the hands of the coffee producers. The result is a farmer who can pay better wages for his workers and a more sustainable future for coffee.</p>\r\n\r\n<h2>Campfires and Drums</h2>\r\n\r\n<p>Unroasted green coffee beans need to experience a lot of heat to be made into something that is brewable. Back before electricity, a campfire often did the trick. This was never a great way to roast coffee. The temperature was not stable and the beans were not roasted evenly. Today, coffee roasters use large rotating drums. These drums are engineered in a variety of ways, and each roaster has to get to know their machine&rsquo;s quirks and ticks over time. These complicated machines are much more suitable for controlling the hundreds of chemical reactions that turn green coffee beans into brown ones.</p>\r\n\r\n<h2>A Science, An Art</h2>\r\n\r\n<p>Roasting coffee well takes a lot of patience and practice. It is not unusual for roasters to dedicate dozens of sample batches to find the ideal balance of flavors and aromas within a coffee. No two coffee batches are the same, and roasters have to be willing to make changes in their recipes, sometimes significant ones, to make a coffee taste just right. Timers, thermometers, and graphs line the tables of coffee roasteries. No serious roaster doesn&rsquo;t monitor every environmental change that takes place within the drum. It&rsquo;s a science, a discipline. <img alt="coffee-roaster" class="aligncenter size-full wp-image-2777" src="https://hookcoffee.files.wordpress.com/2016/09/coffee-roaster.jpg" style="height:667px; width:1000px" /> The senses must always be properly tuned in to the sights and smells of coffee while it&rsquo;s roasting. When a batch of roasting coffee reaches its peak, laziness or poor attention could lose the moment and result in a dull and bitter coffee. Graphs and charts cannot do everything. It takes artistry and sensory precision to produce incredible roasted coffee. It&rsquo;s an art, an experience.</p>\r\n\r\n<h2>A Good Roaster</h2>\r\n\r\n<p>A good roaster sources quality coffee at a sustainable price and often goes the extra mile to help develop the farms they work with. A good roaster is a scientist and craftsman, always vigilant and disciplined. A good roaster honors the coffee and the people behind it, and encourages consumers to also. If you&rsquo;re on the hunt for a good coffee roaster, check out <a href="http://www.hookcoffee.com.sg">Hook Coffee&rsquo;s line up</a> of coffee beans, sourced through direct trade and roasted with precision. We leave you with a video from Hungarian roaster Laczk&oacute; G&aacute;bor that shows the beauty and rigor of skilled&nbsp;coffee roasting. https://vimeo.com/112575328 &nbsp;</p>\r\n	2017-03-12 23:18:00.993219+00	2016-09-08 11:01:40+00	hookcoffee	./what_does_a_coffee_roaster_do_hookblog.jpg	3	what-does-a-coffee-roaster-actually-do
21	How To Make Cold Brew Coffee The Easy Way: In A French Press	Tall glass towers and giant plastic buckets are often seen behind the counters of coffee shops, holding gallons of delicious, smooth cold brew concentrate at a time. These contraptions lead many to believe that brewing cold brew coffee is too difficult or ..	<p>Tall glass towers and giant plastic buckets are often seen behind the counters of coffee shops, holding gallons of delicious, smooth cold brew concentrate at a time. These contraptions lead many to believe that brewing cold brew coffee is too difficult or too complicated to attempt. This could not be further from the truth. <img alt="cold brew coffee" class="aligncenter size-full wp-image-2653" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0337.jpg" style="height:463px; width:696px" /> Cold brew coffee is one of the simplest things to make in the coffee world. There&rsquo;s no technique for pouring hot water, no particular equipment you have to go looking for, and the brewing process is so forgiving that a child could do it with great results. Part of what makes the process so simple is that you likely already have everything you need:</p>\r\n\r\n<ul>\r\n\t<li>A Vessel</li>\r\n\t<li>A Filter</li>\r\n\t<li>Coffee</li>\r\n\t<li>Water</li>\r\n</ul>\r\n\r\n<p>When you put all these together, along with some patience, you end up with a delicious, refreshing drink.</p>\r\n\r\n<h2>Equipment and Ingredients</h2>\r\n\r\n<p>While any container that doesn&rsquo;t taint the flavor of its contents will work, such as water vessel or a mason jar, the french press proves extremely effective and is not difficult to find if you don&rsquo;t already own one. <strong>French Press</strong> The glass carafe of a french press is perfect for brewing over several hours, since it doesn&rsquo;t give any flavor to the cold brew coffee. The fine metal filter makes the final step of separating the concentrate from the coffee grounds a breeze as well. <strong>Filter</strong> Any paper or cloth filter will work when it&rsquo;s time to filter the mixture when the brewing is complete. Using a french press enables you to filter out most of the grounds in a matter of seconds, so when you pour the liquid through a second filter, it takes no time at all to separate the few remaining grounds. For this guide, we&rsquo;ll use a Hario V60 cone and one of its filters to finish out the process. Any coffee filter should work, as well as a cheesecloth or clean sock - if you&rsquo;re desperate. <strong>Coffee</strong> Don&rsquo;t forget to use coffee when you want to make some cold brew. You won&rsquo;t get far without it. For this method, a coarse grind (same as you would use for a french press) is ideal, since let the brew will take place over twelve hours. You can grind the coffee yourself, or we can send coffee to you at the perfect coarseness. <strong>Water</strong> Using hard water to brew coffee often results in muddy flavors that lack sweetness. Unless you live in a lucky area that has naturally soft water without any noticeable flavors, use purified water.</p>\r\n\r\n<h2>The French Press Cold Brew Coffee Method</h2>\r\n\r\n<p>The hardest part about cold brewing coffee is the timing. Most recipes encourage ten to fifteen hours of brewing time. We&rsquo;ll just stick with twelve. Make sure that you will be available to filter the coffee twelve hours from when you begin the brewing.</p>\r\n\r\n<ol>\r\n\t<li>Weight out 70 grams of coffee using a kitchen scale, grind it coarsely, and pour it into the french press.</li>\r\n</ol>\r\n\r\n<p><img alt="cold brew coffee in a french press" class="aligncenter size-full wp-image-2649" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0327.jpg" style="height:463px; width:696px" /> 2. Pour 500 millilitres (or 500g if you still have your scale out) of water over the coffee, saturating all the grounds. <img alt="cold brew coffee in a french press" class="aligncenter size-full wp-image-2651" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0341.jpg" style="height:463px; width:696px" /> 3. After five minutes, carefully use a spoon or the french press filter to gently submerge the coffee grounds that have formed a crust at the surface of the water. This allows all the grounds to extract evenly for a balanced final cup.&nbsp;Set a timer for twelve hours. <img alt="cold brew coffee in a french press" class="aligncenter size-full wp-image-2652" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0344.jpg" style="height:463px; width:696px" /> 4. When the brewing time has elapsed, plunge the french press metal filter and pour the liquid coffee through a second filter (paper or cloth) to give you a clean cold brew concentrate. You can store the concentrate in the fridge for up to two weeks. <img alt="cold brew coffee in a french press" class="aligncenter size-full wp-image-2655" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0333.jpg" style="height:463px; width:696px" /></p>\r\n\r\n<h2>Time to Drink</h2>\r\n\r\n<p>When you&rsquo;re ready to have a refreshing glass of cold brew coffee, take some cold brew concentrate and cut it with an equal amount of water, then add ice. If the drink is too strong, add a little more water to balance it out. If it is not quite strong enough, pour in a bit more concentrate. You&rsquo;re the ultimate judge of ideal strength for you. While purchasing a glass of iced coffee at your favorite coffee shop is convenient, brewing it yourself is far more rewarding. To give brewing cold brew coffee a try, grab a bag beans from <a href="https://hookcoffee.com.sg/">Hook Coffee</a> and we&rsquo;ll send a fresh bag to your door. If you don&rsquo;t have a grinder at home, select the &ldquo;French Press&rdquo; grind size and the brewing becomes even easier. <img alt="cold brew coffee recipe" class="aligncenter size-full wp-image-2661" src="https://hookcoffee.files.wordpress.com/2016/08/cold-brew-coffee-recipe.jpg" style="height:981px; width:696px" /></p>\r\n	2017-03-12 23:18:00.874817+00	2016-08-17 04:10:39+00	hookcoffee	./how_to_make_cold_brew_coffee_hookblog.jpg	4	how-to-make-cold-brew-coffee-the-easy-way-in-a-french-press
17	5 Gifts Your Coffeeholic Dad Will Love	A son’s first hero and a daughter’s first love. How exactly do we say thank you to the most important man in our lives without reusing the same ol’ ideas like a cheesy “Best Dad Ever” mug?\r\n\r\nWe’ve done the brainstorming for you and here’s our five top picks..	<p>A son&rsquo;s first hero and a daughter&rsquo;s first love. How exactly do we say thank you&nbsp;to the most important man in our lives without reusing&nbsp;the same ol&rsquo; ideas like a cheesy &ldquo;Best Dad Ever&rdquo; mug? We&rsquo;ve done the brainstorming for you and here&rsquo;s our five top picks of gifts for Dads&nbsp;who love coffee <em>almost</em> as much as love their kids.</p>\r\n\r\n<hr />\r\n<h2>1) Handpresso Auto Espresso Maker</h2>\r\n\r\n<p><img alt="Handpresso-Auto-Espresso-Maker.jpg" class="alignnone size-full wp-image-1753" src="https://hookcoffee.files.wordpress.com/2016/06/handpresso-auto-espresso-maker.jpg" style="height:450px; width:630px" /> For all the rushed mornings that saw Dad sacrificing his sleep to&nbsp;ferry you to&nbsp;your destination, it&#39;s time you did something in return! The <a href="http://www.handpresso.com/en/">Handpresso</a> is a mobile coffee device that&nbsp;will definitely come in handy the next time Dad has to forgo his&nbsp;morning coffee. Believe it or not, we&rsquo;ve actually fortuitously met&nbsp;the Dad of one of the engineers who made the&nbsp;Handpresso&nbsp;possible. We were at an eatery in Aceh and saw this burly, grey-haired man using the Handpresso. We must have behaved like kids in a candy store, because he motioned for us to come over and offered us&nbsp;his freshly brewed coffee. Then as modestly as he could, shared that his son was one of the brilliant minds behind this gadget. With&nbsp;nothing more than a 12v cigarette lighter, the Handpresso has a&nbsp;16-bar pressure and is capable of heating up and pulling a shot of coffee in just 2 minutes.</p>\r\n\r\n<h2>2) Nespresso Machine</h2>\r\n\r\n<p><img alt="769995235.png.jpeg" class="alignnone size-full wp-image-1758" src="https://hookcoffee.files.wordpress.com/2016/06/769995235-png.jpeg" style="height:1080px; width:1440px" /> Not as novel as the above, but the Nespresso machine is another gadget we&rsquo;re becoming increasingly dependent on. The men in our lives love a decadently&nbsp;black cup, at least one every&nbsp;morning, and the&nbsp;Nespresso machine is the easiest, foolproof way to&nbsp;get there. We can&rsquo;t top you from getting the original pods along with the machine, but if you want to introduce Dad to better tasting, specialty-grade coffee (and it&rsquo;s probably about time), then why not try our <a href="http://hookcoffee.com.sg/coffees/shotpods">Nespresso-compatible ShotPods</a>? We&rsquo;ve a list of reasons to believe our ShotPods are better, and you can read about that <a href="http://thehookblog.com/2016/06/02/wedontneedgeorge-clooney-our-pods-speak-for-themselves/">here</a>. We currently have 3 different ShotPods (and are launching 2 new varieties&nbsp;at the end of the month - a&nbsp;decaf, and an extra intense one). We hope you know your dad&rsquo;s preferences well enough to use our recommendation engine.&nbsp;If you don&rsquo;t, just pretend you do and we suggest going&nbsp;for Bird of Paradise because it&rsquo;s the boldest&nbsp;of the 3.</p>\r\n\r\n<h2>3) A Good (Coffee-Related)&nbsp;Read</h2>\r\n\r\n<p>For all the Dads&nbsp;who spend their weekends&nbsp;poring over a book with&nbsp;a cup of coffee in hand, a great&nbsp;read would be the perfect&nbsp;gift. A&nbsp;recommended&nbsp;read&nbsp;is the <em><strong><a href="https://www.amazon.com/God-Cup-Obsessive-Perfect-Coffee/dp/0470173580">God in a Cup: The Obsessive Quest for the Perfect Coffee</a></strong></em>&nbsp;by&nbsp;Michaele Weissman. It&rsquo;s one of our favourites that&nbsp;we almost religiously recommend it to all our friends (at least those interested enough to ask), because it combines our passion for coffee with a sense of adventure and wanderlust, and is line with our believe that coffee specialty coffee shouldn&rsquo;t just be about better coffee but also about sustainable livelihoods and making a difference in people&rsquo;s lives and the environment. <img alt="2805445353_341efa7956_b.jpg" class="alignnone size-full wp-image-2111" src="https://hookcoffee.files.wordpress.com/2016/06/2805445353_341efa7956_b.jpg" style="height:683px; width:1024px" /></p>\r\n\r\n<h2>&nbsp;4) Hario Coffee Mill Slim Grinder</h2>\r\n\r\n<p><img alt="51LZlieTMzL._SL1000_.jpg" class="aligncenter wp-image-1770" src="https://hookcoffee.files.wordpress.com/2016/06/51lzlietmzl-_sl1000_.jpg" style="height:492px; width:492px" /> To get the most&nbsp;delicious cup of coffee, nothing beats freshly-ground beans, and it&rsquo;s never too late to <em>really</em> appreciate coffee. Hand-grinding beans can be therapeutic but we won&rsquo;t deny it gets boring and it takes&nbsp;time. But think about it, this could be the best gift for your retired Dad. It&rsquo;s a great way for him to slow down, meditate, and practise his motor skills if you ask me! The Hario Coffee Mill Slim Grinder (found at most specialty cafes and at all Isetan stores) is&nbsp;large enough to make&nbsp;two cups of coffee at a time, so he can brew a cup of joe for mum too. Dad&nbsp;can adjust the grind size to his preferred brew method too.</p>\r\n\r\n<h2>5) Hook Coffee Subscription</h2>\r\n\r\n<p><img alt="Pouring coffee" class="alignnone size-full wp-image-2189" src="https://hookcoffee.files.wordpress.com/2016/06/pouring-coffee.jpg" style="height:3744px; width:5616px" /> Last but not least,&nbsp;if you&rsquo;re looking to keep&nbsp;Dad&rsquo;s fresh coffee supply consistently replenished, just like how he always made sure you have more than enough, then look no further. You can get Dad a coffee subscription&nbsp;(even if you&rsquo;re not sure about his drinking frequency and preferences). Our <a href="http://www.hookcoffee.com.sg/coffees/send-friend">gifts feature</a>&nbsp;allows you to do just that. All you have to do is: 1. Choose a gift amount 2. Present Dad with the gift voucher 3. He chooses what he wants 4. We deliver it to him, as frequently as he needs We&#39;re pretty sure that for your (coffee)loving dad, nothing beats a&nbsp;fuss-free coffee subscription that guarantees delicious freshness, tailored to his brewing&nbsp;habits and preferences!</p>\r\n\r\n<hr />\r\n<p>We hope this list has been helpful! Good luck with finding the perfect gift and have a great family weekend together&nbsp;-&nbsp;but first, coffee!</p>\r\n	2017-03-12 23:18:00.823768+00	2016-06-17 14:15:11+00	hookcoffee	./5_gifts_your_coffeeholic_dad_will_love_hookblog.jpg	6	5-gifts-your-coffeeholic-dad-will-love
25	Coffee Grind Sizes: A Key to Better Brewing	Grocery stores are convenient places to get coffee, but there are some drawbacks. Most of these stores simply don't care about your coffee quality, and they only ever offer two options: whole bean and ground.\r\n\r\nOne powerful way to rise above the low-end cof..	<p>Grocery stores are convenient places to get coffee, but there are some drawbacks. Most of these stores simply don&#39;t care about your coffee quality, and they only ever offer two options: whole bean and ground. One powerful way to rise above the low-end coffee at grocery stores &nbsp;is to take control of the way you grind your beans.&nbsp;Being able to choose specific grind sizes enables you to reach&nbsp;new levels&nbsp;in&nbsp;your coffee journey, and the coffee only gets better. <a href="http://www.hookcoffee.com.sg/"><img alt="hario mini mill" class="aligncenter size-large wp-image-2721" src="https://hookcoffee.files.wordpress.com/2016/08/dsc_0368.jpg?w=1000" style="height:665px; width:1000px" /></a> Don&rsquo;t run away from grinding your own coffee. Grocery stores want you to think it&rsquo;s too complicated or not worth the effort - it&rsquo;s how they trap you. While a hint of extra effort is required, the reward is unquestionably worth it.</p>\r\n\r\n<h2>What Is This Reward?</h2>\r\n\r\n<p>Different coffee brewing methods work best with different size coffee grounds. For example, espresso shots are created when water is forced through tightly packed coffee grounds in a matter of seconds. If you use a coarse grind (large particle sizes), the water will run right between the grounds without producing anything you would want to drink. It takes a very fine grind size to force the water through the coffee grounds&nbsp;evenly in order to produce a balanced and flavorful shot. The french press, on the other hand, is most often used with a coarse grind size. There are two main reasons why:</p>\r\n\r\n<ol>\r\n\t<li>The fine metal mesh filter of the french press can easily become clogged by fine coffee grounds.</li>\r\n\t<li>Since the water and coffee sit together for a period of time in a french press, a coarse grind keeps the water from getting inside the coffee grounds too quickly and extracting too&nbsp;much (which would produce a bitter cup).</li>\r\n</ol>\r\n\r\n<h2>It&#39;s All About Extraction</h2>\r\n\r\n<p>When&nbsp;&nbsp;water and coffee come&nbsp;in contact, the water digs into the coffee bean grounds and pulls out the ingredients that turn clear&nbsp;water into black coffee.</p>\r\n\r\n<ul>\r\n\t<li>If the coffee bean particles are too big, water won&rsquo;t be able&nbsp;to pull out everything it needs during the time they are together. The produced liquid will be sour and acidic.</li>\r\n\t<li>If the coffee bean particles are too small, the water will extract more from the grounds than we want, producing a mug of coffee that is bitter and astringent.</li>\r\n</ul>\r\n\r\n<p>Coffee brewing is all about finding that balance of flavor and strength. The sizes of our coffee grounds are the variable we can change to find that balance.</p>\r\n\r\n<h2>Problem Solving Like A Pro</h2>\r\n\r\n<p><strong><span style="color:#6a6c6e; font-family:Lato,'Helvetica Neue',Helvetica,Arial,sans-serif; font-size:1.8rem">The Pour Over</span></strong> Let&rsquo;s say you&rsquo;re brewing a cup of coffee with a Hario V60 and you notice the water drains in less than a minute. You take a sip and realize that the coffee in your mug is thin and undeveloped in flavor. What do you do? Weak, sour, thin, and overly acidic coffee indicates that you need to <strong>extract more</strong> to produce&nbsp;a balanced cup. This can be done by <strong>reducing the coffee particle size</strong>.&nbsp; <a href="http://www.hookcoffee.com.sg/"><img alt="coffee grind sizes" class="aligncenter size-large wp-image-2719" src="https://hookcoffee.files.wordpress.com/2016/08/coffee-grind-sizes.jpg?w=1000" style="height:590px; width:1000px" /></a> <strong><span style="font-size:1.8rem">The Aeropress</span></strong> On another day you are using your handy-dandy Aeropress and find that the coffee is just not very flavorful and that it feels kind of rough on the back of your throat. The solution is simple: bitter, dull, overpowered coffee should let you know that&nbsp;you need to <strong>extract less</strong>. You can do this by <strong>grinding your coffee a little coarser</strong> next time.</p>\r\n\r\n<h2>Starting Points</h2>\r\n\r\n<p>From whole coffee beans to super fine espresso grounds, there are many options for adjusting the grind to achieve a better brew. Here are a few starting points you can use to launch you into your quest to find the ideal grind size for your brewing devices and methods.</p>\r\n\r\n<ul>\r\n\t<li>French Press - Coarse</li>\r\n\t<li>Cold Brew - Coarse</li>\r\n\t<li>Chemex - Medium to Coarse</li>\r\n\t<li>Aeropress - Medium to Fine</li>\r\n\t<li>Hario V60 - Medium to Fine</li>\r\n\t<li>Espresso - Very Fine</li>\r\n\t<li>Turkish - Nearly Invisible Fine</li>\r\n</ul>\r\n\r\n<p>Make minor adjustments, one at a time, from these starting points.</p>\r\n\r\n<h2>All It Takes Is A Grinder</h2>\r\n\r\n<p>See how empowering owning a coffee grinder can be for you home barista skills? Thankfully, it doesn&#39;t have to be very expensive either. A few hand grinders have emerged as market leaders over the years, making reliable, consistent grinding a possibility for the common man. We highly recommend the <a href="https://www.amazon.com/Hario-MSS-1B-Mini-Coffee-Grinder/dp/B001804CLY">Hario Slim Mini Mill</a> as a coffee grinder that is affordable, durable, and effective. Paired with a reliable coffee brewer and some of <a href="https://hookcoffee.com.sg/">the best coffee you can buy</a>, this grinder will take you places you could never have imagined. Tip: Find Hario Slim Mini Mill at department stores like Isetan, or if you are lucky, at a bargain on Carousell. Have fun grinding! :) &nbsp;</p>\r\n	2017-03-12 23:18:00.956513+00	2016-08-26 07:38:56+00	hookcoffee	./coffee_grind_size_hookblog_.jpg	6	coffee-grind-sizes-key-to-better-brewing
28	Traveling With Coffee: Tips For The Road	We all know that feeling of waking up in an unfamiliar bed, looking around at blank walls, and hearing the sounds of a foreign city. It’s exciting and gives us an opportunity at wild growth as people, but there are discomforts as well.\r\n\r\nYou may not speak t..	<p>We all know that feeling of waking up in an unfamiliar bed, looking around at blank walls, and hearing the sounds of a foreign city. It&rsquo;s exciting and gives us an opportunity at wild growth as people, but there are discomforts as well. You may not speak the local language. Your luggage may not arrive on time. But nothing compares to this common ultimate travel tragedy: the absence of great coffee. Taking coffee gear on your journeys may seem extravagant, but having that moment to brew and appreciate something familiar and comforting can make a major difference in your mood while you&rsquo;re on the road. <img alt="fullsizerender" class="alignnone wp-image-2798" src="https://hookcoffee.files.wordpress.com/2016/09/fullsizerender.jpg" style="height:480px; width:640px" /></p>\r\n\r\n<h2>It&rsquo;s Not As Hard As It Sounds</h2>\r\n\r\n<p>Don&rsquo;t panic - you don&rsquo;t have to lug around a giant coffee maker and pay extra airline fees for an additional bag. In reality, all you need can fit in a very small space within whatever bags you are already packing. Here are the only items you will need. <strong>Coffee Beans</strong> Obviously, you will need some great coffee beans. If you want to skip just about every other step for travel brewing and go the ultimate convenience route, check out these Drip Bags from Hook Coffee. They&rsquo;re super portable and don&rsquo;t compromise flavor quality. https://www.youtube.com/watch?v=s1DCQxfTWp8 If you like what you see, you can stop here. You don&rsquo;t need a brewer or a grinder with the Drip Bags. If you would rather take a more hands-on approach to coffee on the road, read on. <strong>A Brewer</strong> <img alt="IMG_0611.JPG" class="alignnone size-full wp-image-2802" src="https://hookcoffee.files.wordpress.com/2016/09/img_0611.jpg" style="height:1536px; width:2304px" /> The best coffee brewers for travel are ones that are small, durable, and require few or no additional materials. The Aeropress will become your best friend on the road. It&rsquo;s light, will never break, and brews a killer cup of coffee. You can add portability points with a reusable stainless steel filter to avoid paper waste and excess materials. Other options include stainless steel pour over cones that are their own filters, the Impress brewer, or the Handpresso espresso maker (for those of you who live life on the edge). For the vast majority of us, the Aeropress will do the job very well with ease. <strong>A Grinder</strong> To take those whole beans to a brewable size, you need a coffee grinder, preferably a very small one. Travel-friendly grinders require the use of some elbow grease, but the extra effort is beyond worth it. Some of our favorite manual grinders include the Hario Mini Mill and Porlex JP-30. <strong>Do You Need More?</strong> Scales, kettles and other brewing tools may not be necessary on the road. You only have so much room, so it&rsquo;s up to you to decide what sacrifices you would like to make for the sake of lighter travel. Some of these items may be available at your destination already.</p>\r\n\r\n<h2>Practical Brewing In New Places</h2>\r\n\r\n<p>Brewing a delicious, familiar mug of coffee on the road can be daunting, especially since you&rsquo;re already not following your normal routine, but it&rsquo;s not any more complicated than normal. <strong>Coffee. Water. Mix those.</strong> Here&rsquo;s a great recipe for the Aeropress while on the road:</p>\r\n\r\n<ol>\r\n\t<li>You&rsquo;ll need 16 grams of coffee (approx. 2 Aeropress scoops) and enough water to fill the Aeropress inverted style.\r\n\t<p>&nbsp;</p>\r\n\t</li>\r\n\t<li>Grind the coffee beans at a medium setting and place them into the brewing chamber.\r\n\t<p>&nbsp;</p>\r\n\t</li>\r\n\t<li>\r\n\t<p>Take water just off the boil and fill the Aeropress halfway and give the whole thing a quick swirl to saturate all the grounds. Let it sit for thirty seconds.</p>\r\n\t</li>\r\n\t<li>\r\n\t<p>Fill the Aeropress to the very top of the chamber and attach the stainless steel filter, then wait for another thirty seconds.</p>\r\n\t</li>\r\n\t<li>\r\n\t<p>Take a mug, bowl, or some other vessel and set it upside down on top of the Aeropress. Use those fine motor skills and carefully flip both the vessel and the Aeropress over.</p>\r\n\t</li>\r\n\t<li>\r\n\t<p>Press down on the plunger for thirty seconds until all the liquid has been expelled from the chamber into the vessel.</p>\r\n\t</li>\r\n</ol>\r\n\r\n<p>You may now enjoy your delicious coffee.</p>\r\n\r\n<h2>Anyone Can Do It</h2>\r\n\r\n<p>Travel brewing is just like any other type of brewing. Not only is coffee just as delicious while on the road, but it can offer a moment of peace and familiarity to those of us who need that sort of thing while traveling. The Aeropress is a powerful tool for providing travel coffee, but it won&rsquo;t be quite as convenient as the Hook Coffee Drip Bags. Choose your method according to your needs. Go out and brew.</p>\r\n	2017-03-12 23:18:01.018621+00	2016-09-13 02:31:03+00	hookcoffee	./travelling_with_coffee_tips_for_the_road_hookblog.jpg	6	traveling-with-coffee-tips-for-the-road
31	Why International Coffee Day Matters + Free Coffee Scrub	&nbsp;\r\n\r\nJust last year, in 2015, the International Coffee Organization launched the first annual International Coffee Day on October 1st. This was the first time a global awareness day was recognized and acted upon with such zeal in the coffee community.\r\n\r\n..	<p>&nbsp; Just last year, in 2015, the International Coffee Organization launched the first annual International Coffee Day on October 1st. This was the first time a global awareness day was recognized and acted upon with such zeal in the coffee community. Internationalism emphasizes just trade, sustainable practices, and respect for people that surpasses borders and nationalities. Coffee needs these things. Slavery, labor abuse, and poor living conditions are not foreign to the global coffee industry, but thanks to initiatives like this one and countless others, the landscape is changing rapidly. The power of International Coffee Day lies in awareness and action. The day is an opportunity to spread a mindset that drives coffee growers, businesses, and consumers around the world. It is a mindset that is aware of the less-than-ideal health of the global coffee industry, especially in terms of living and working conditions in coffee-producing countries, and actively works to bring about a better future. We at Hook Coffee exist in this mindset, sobering and beautiful, every day. The coffee we roast and sell was grown and cared for by real people around the world - people with families, fears, and joys. We are passionate about sourcing our coffee in ways that are <a href="https://hookcoffee.com.sg/blog/finding-purpose-in-coffee">fair and empowering towards these coffee farmers</a>. International Coffee Day is a day for ordinary people to become involved in this mindset. Buy a cup of coffee from a local shop or order a bag online. Check the coffee shop or roaster for <a href="https://hookcoffee.com.sg/blog/how-to-read-a-coffee-packaging-like-a-pro">signs </a>that they are on board with the goal of International Coffee Day: sustainability. Purchasing from low-quality sellers with dozens of middlemen isn&#39;t going to do much for our farmer friends and the long-term health of the industry. Whatever you do, remember that the day exists to create a spirit of solidarity between coffee growers, consumers, and businesspeople that reaches beyond boundaries. Check out International Coffee Organization&rsquo;s <a href="https://internationalcoffeeday.org/events/">list of events for International Coffee Day</a> to see if there&rsquo;s anything happening around you.</p>\r\n\r\n<h2>To celebrate Interantional Coffee Day, We&rsquo;re Giving Away Coffee Scrub! (Lovingly handmade by the Hook Coffee Team)</h2>\r\n\r\n<h2><img alt="IMG_0079.JPG" class="aligncenter wp-image-2834" src="https://hookcoffee.files.wordpress.com/2016/09/img_0079.jpg" style="height:492px; width:492px" /></h2>\r\n\r\n<p>We&rsquo;re committed to high quality, super fresh coffee. We never send out coffee more than seven days past its roast date, period. We are also committed to being great stewards of the coffee we buy, so we&rsquo;re putting the coffee we haven&rsquo;t sold in that timeframe towards something else incredible: coffee scrub. Sustainably sourced coffee and organic coconut oil make a great combo, and we&rsquo;re giving away scrub to the first 200 new subscribers for free! To <a href="https://hookcoffee.com.sg/">claim your coffee scrub</a>, select the coffee that&rsquo;s right for you, use the code &#39;<strong>SCRUB</strong>&#39; and we&rsquo;ll take care of the rest!&nbsp; Enjoy International Coffee Day on October 1st. Remember the struggle and wonder of the journey of the coffee bean and the people who make it happen, and know that the role you play, though maybe small, is essential for a healthy, sustainable coffee industry. Thank you for drinking coffee responsibly. Happy brewing!</p>\r\n	2017-03-12 23:18:01.053838+00	2016-10-01 02:27:21+00	hookcoffee	./international_coffee_day_coffee_scrub_hookblog.jpg	13	why-international-coffee-day-matters-free-coffee-scrub
40	Acidity: Why it's Misunderstood	Today we are going to discuss some coffee terminology. Coffee has been around since the tenth or eleventh century. Yet, regardless of coffee’s antiquity, many terms describing its taste and flavor profile are misunderstood.\r\n\r\nUntil recent decades, coffee wa..	<p>Today we are going to discuss some coffee terminology. Coffee has been around since the tenth or eleventh century. Yet, regardless of coffee&rsquo;s antiquity, many terms describing its taste and flavor profile are misunderstood. Until recent decades, coffee was a utilitarian beverage. The bitter dark drink was consumed by adults only as caffeine fuel before a long work day. Sugar was added to coffee in order to quell astringency and bad taste. Now, in specialty coffee circles, coffee is prepared in an almost culinary fashion: flavor additives aren&rsquo;t encouraged, and the best ingredients are sought out for flavor and sustainability. The&nbsp; craft of specialty coffee has not been practiced for very long, so the terminology involved becomes confusing. &nbsp; Here are few examples of misunderstood coffee terminology: -acidity -dark roast -dark coffee -bitter -strong -weak &nbsp; <strong>Today we will be focusing on acidity</strong> Acidity in coffee sounds foreign to many. When many people think of acidity, they picture chemistry sets and sourness. We at Hook like to think about acidity as something that could be positive or negative. Acidity is the juicy, sour, tart, sweet flavor and mouthfeel found in coffee. Instead of using acidity as a flavor descriptor, it&rsquo;s best to examine the <em>amount </em>of acidity (intensity) found in a cup of coffee. When a cup of coffee is sour, certain acids in the coffee are overbearing. Even when coffee is bitter, acidity is still present in the coffee. Acidity is your friend. A well-extracted cup with complex acidity is a maelstrom of sweetness, tartness, and clarity. Coffee contains <em>many </em>acids. Here&rsquo;s a list of some of them: <strong><u>Acids contained in coffee</u></strong> palmitic acid linoleic acid lactic acid acetic acid citric acid malic acid phosphoric acid quinic acid chlorogenic acids These acids effect the coffee in different ways. For instance, malic acid is a source for tartness. Quinic acid attributes to pleasant sharpness. Lactic acid promotes a mild taste and has many other effects that impact savoriness. The list goes on, and for the sake of brevity we will agree that coffee is very, very complex. &nbsp; <strong>Debunking the Dark Roast</strong> Dark roasted coffee became popular years ago before the advent of specialty, intentional coffee. Before the rise of specialty coffee, acidity was less understood. In response, roasters burnt the living daylight out of their coffee to kill the &ldquo;bad taste.&rdquo; When observing a dark roast, you&rsquo;ll notice greasy residue. You&rsquo;ll also smell something akin to burnt fish and tree bark&hellip; that&rsquo;s kind of what it tastes like. If roasters are vigilant, they roast coffee without burning it. A careful roasting process preserves the potential acidity in the bean. Having well balanced acidity in coffee brings out a variety of flavors. Some coffees inherently taste chocolatey and nutty (El Salvador), while others taste fruity and sweet (Ethiopian). All coffee contains acidity. It&rsquo;s just a matter of how you shape the potential of each bean when brewing. &nbsp; <strong>Application</strong> If you enjoy &ldquo;dark&rdquo; or &ldquo;bold&rdquo; cups of coffee, dark roasted coffee isn&rsquo;t the best option. Certain brew methods paired with particular coffees can provide you with a much richer, in depth tasting cup of coffee than a dark roasted brew. If a Colombian coffee (heavy in floral and dark chocolate notes) is brewed with an Eva Solo, an almost thick cup of coffee with a juicy mouthfeel and savory flavor will be the result. A dark roasted coffee will just taste simple, astringent, and burnt. For a &ldquo;heavier&rdquo; cup of coffee:</p>\r\n\r\n<ul>\r\n\t<li>Try brewing with immersion brew methods.</li>\r\n\t<li>Make sure that the method you are using doesn&rsquo;t employ a thick filter. This will make sure that more coffee particles (brew colloids) make it into the cup. This will make for a thicker and heavier bodied mouthfeel.</li>\r\n\t<li>Prepare the coffee in a balanced way. Don&rsquo;t over extract and mask flavor.</li>\r\n\t<li>Experiment with different coffees to manipulate flavor.</li>\r\n</ul>\r\n\r\n<p>&nbsp; Acidity in coffee is an extremely complex topic. For more information on the particular science behind particular acids in coffee, check out our coffee literature suggestions in our <a href="https://hookcoffee.com.sg/blog/the-new-year-an-intentional-review" target="_blank">previous blog.</a> As always, happy brewing! The Hook Coffee Team &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n	2017-03-12 23:18:01.223692+00	2017-01-21 07:00:53+00	hookcoffee	./acidity_why_is_it_misunderstood_hookblog.jpg	10	acidity-why-its-misunderstood
47	Define Fresh.	We're committed to connecting good coffee to good people - you all deserve nothing but the best! We will be telling you why we are obsessed about freshness at Hook and why a fresh cup is the best cup and what exactly we mean when we say we've some of the f..	<p>We&#39;re committed to connecting good coffee to good people - you all deserve nothing but the best! We will be telling you why we are obsessed about freshness at Hook and why a fresh cup is the best cup and what exactly we mean when we say we&#39;ve some of the freshest coffees in town!</p>\r\n\r\n<p>So go on, grab a fresh cup of coffee - hopefully ours - and get ready to learn something new.</p>\r\n\r\n<hr />\r\n<p>We&rsquo;ve all had cups of coffee that have instantly made our day. Rich, flavourful, and possessing an aroma to die for - these are the words that come to mind when you think about a fresh cup of coffee, right?</p>\r\n\r\n<p><img alt="yay1" class="aligncenter size-full wp-image-1486" src="https://hookcoffee.files.wordpress.com/2016/06/yay1.png" style="height:399px; width:600px" /></p>\r\n\r\n<p>The freshness of your coffee is determined the very moment it is sent to be roasted. Coffee doesn&#39;t actually start out looking like a brown bean. Instead, they start as green beans when they are brought to the roaster. The roasting profile and process&nbsp;are crucial to bringing out the&nbsp;inherent characteristics and flavours of the coffees - bold/light, floral/fruity, chocolatey/caramel-y... And as long as your coffee is FRESH, you&#39;ll be able to enjoy these delicious flavours! But the flavours and aroma weaken and wane over time. Take a look at this chart below!<img alt="staling rate of coffee.001.jpeg.001.jpeg" class="alignnone size-full wp-image-2618" src="https://hookcoffee.files.wordpress.com/2016/07/staling-rate-of-coffee-001-001.jpeg" style="height:768px; width:1024px" />You might be wondering what on earth &quot;de-gassing&quot; is! It&#39;s basically the process where the beans release carbon dioxide, the molecules rest and settle, for a richer, smoother, and more balanced cup.&nbsp;Since we send out your coffee to you within a week of roasting, by the time you receive it, your coffee is at it&rsquo;s best for consumption.</p>\r\n\r\n<p>Storage tips: Mum might have told you keeping coffees in the fridge or freezer, or any food/drink really, is the best way to preserve their freshness and extend their shelf life. Unfortunately, mum&rsquo;s wrong this time (sorry, mum!). When it comes to storing coffee, the key elements to protect it from are excessive air, moisture, heat and light. The bags we use to pack and deliver your coffees are perfect for doing all that. You can always transfer your coffees out, as long as it&rsquo;s in an airtight (ideally opaque) container and kept in a cool, dry place.</p>\r\n\r\n<p>Now that you&#39;ve been enlightened, think about the &quot;fresh&quot; coffee you&#39;ve ever bought from coffee chains and much less supermarkets. Can you imagine how stale the coffee is?</p>\r\n\r\n<div>&nbsp;</div>\r\n\r\n<p><img alt="coffee-beans-and-womans-hands_rfrtix" class="alignnone size-full wp-image-1489" src="https://hookcoffee.files.wordpress.com/2016/06/coffee-beans-and-womans-hands_rfrtix.jpg" style="height:399px; width:600px" /></p>\r\n\r\n<p>The freshness of your coffee is clearly critical but the &nbsp;segment of the coffee industry that has commoditised specialty coffee has a way of tricking you into believing your coffee is still &quot;fresh&quot;.</p>\r\n\r\n<p>Most coffee you get at the supermarket are roasted ages ago if you actually pick up a bag of coffee and look for the roasting date (which most of the time they do not reveal). And the trick to mask the staleness of a supermaket market coffee, is to roast it really dark. The result? Coffee that just taste bitter and nothing else. We wrote an article on how to read a coffee pacaking like a pro, here is the <a href="https://hookcoffee.com.sg/blog/how-to-read-a-coffee-packaging-like-a-pro">article </a>if you haven&#39;t already check it out.</p>\r\n\r\n<p>Customers, however, also often don&rsquo;t notice this because the bad taste is masked by massive amounts of sugar and syrup pumped into their cups. A Grande Mocha Frappuccino, for example, contains 61g of sugar. (According tHhis is given that within 24 to 72 hours of roasting, coffee beans slowly go stale after having been exposed to oxygen. Beans stored for too long tend to produce flat and stale tasting coffee, which is often what you get at larger chains. This applies for both the coffee drinks they sell you, and their bagged beans.</p>\r\n\r\n<p>Now, we&rsquo;re not trying to preach here or anything, but these are just a few things you should remember before buying that cup of coffee. Sure it&rsquo;s quick and convenient, but it might not be actually what&rsquo;s best for your body, or for the farmers who contributed to producing it via methods other than direct trade. If you&rsquo;re looking for a quick fix, consider using freshly ground coffee beans (maybe even ours!) or a drip bag instead. You could even <a href="https://hookcoffee.com.sg/brew-guides/v60/" target="_blank">try learning how to brew your own coffee with the V60</a> - it&rsquo;s super easy and honestly doesn&rsquo;t take that long!</p>\r\n\r\n<p>We hope this post has been insightful for you, and will be useful as you continue looking for the best coffee to drink. After all, what better way to start your Monday morning than by learning something new?</p>\r\n\r\n<p>Have a great weekend, and thanks for reading!</p>\r\n\r\n<p>Happy Brewing!</p>\r\n\r\n<p>Love,</p>\r\n\r\n<p>The Hook Team</p>\r\n\r\n<p>&nbsp;</p>\r\n	2017-03-12 23:18:01.267571+00	2017-03-07 15:15:47+00	hookcoffee	./staling-rate-of-coffee-blogpost_cover_.jpeg	10	define-fresh
44	Instant regrets?	In the words of Daft Punk, we always want things to be “better, faster and stronger” all the time. In the fast-paced world today, we always seek speed and efficiency, be it as students, young working professionals, or even just as the average joe. (As indi..	<p>In the words of Daft Punk, we always want things to be &ldquo;better, faster and stronger&rdquo; all the time. In the fast-paced world today, we always seek speed and efficiency, be it as students, young working professionals, or even just as the average joe. (As individuals who work in a startup, we also know this all too well.) But faster doesn&rsquo;t always necessarily relate to being better, especially when it comes to coffee. In this part of The Inconvenient Truth, we&rsquo;ll tell you more about instant coffee, and why it isn&rsquo;t actually the best type of coffee around. We&rsquo;ve told you about Direct Trade and Fair Trade, as well as about the freshness of your coffee in our previous posts. Now, it&rsquo;s time to add another piece of knowledge to your collection, as we journey with you, to #makecoffeebetter for you. <img alt="coffee-and-grounds.jpg" class="alignnone size-full wp-image-2340" src="https://hookcoffee.files.wordpress.com/2016/06/coffee-and-grounds.jpg" style="height:600px; width:900px" /> So you might be thinking, what exactly is so bad about instant coffee? It&rsquo;s reasonably tasty, easy to prepare when you&rsquo;re in a hurry, and does a pretty good job of waking you up. What&rsquo;s there not to like? For starters, instant coffee actually contains less caffeine than freshly brewed coffee. A cup of drip brewed coffee has about 115mg of caffeine, while an espresso shot has about 80mg of it. Instant coffee, on the other hand, contains only about 65mg of caffeine. So when you&rsquo;re trying to wake up, it&rsquo;s pretty obvious which option you should pick, isn&rsquo;t it? In this case, instant coffee really isn&rsquo;t all it&rsquo;s chalked up to be. What&rsquo;s more, people often over consume instant coffee in order to achieve that kick given how little caffeine it actually has in comparison to its counterparts. This in turn leads them to have their bodies pumped full of sugar, with the high they experience actually coming more from the sugar rather than the caffeine. Which brings us to our next point &ndash; instant coffee is also full of sugar and harmful chemicals, unlike freshly brewed coffee. We&rsquo;ve talked about the harmful effects too much sugar can bring about in previous posts (such as leaving you more vulnerable to diabetes and dehydration), and we&rsquo;re sure that as conscious consumers, you wouldn&rsquo;t want to treat your body that badly. What we haven&rsquo;t talked about though (and feel the need to) is the chemicals present in instant coffee that may be harmful for you in the long run. These chemicals inevitably get infused in instant coffee as it goes through the production process. We won&rsquo;t go into the nitty-gritty of it, but basically how instant coffee is made is by extracting coffee aroma and flavor from coffee beans, before combining it with water. This concentrated liquid is then evaporated, spray-dried or freeze-dried in order to make the granulated powder that is instant coffee. You can probably look up the entire process online if you&rsquo;re interested, but what big companies won&rsquo;t tell you about is the chemicals that get mixed into the coffee as the process carries on. The most prominent of these substances is acrylamide. This is formed in starchy foods when they are heated to and treated with high temperatures, and are found in high amounts in coffee especially. The chemical is a cumulative neurotoxin, which basically means that consuming these (accidentally) in high amounts could decrease fertility and cause damage to one&rsquo;s central nervous system. Of course, we&rsquo;re not saying you&rsquo;ll drop dead after drinking instant coffee for a few months, but in the long run, this could be a concern to think about. <img alt="61095179.jpg" class="alignnone size-full wp-image-2354" src="https://hookcoffee.files.wordpress.com/2016/06/61095179.jpg" style="height:480px; width:640px" /> To make matters worse, there&#39;s also the problem of how manufacturers often are not careful enough with the whole production process. Sometimes, dirt and other substances such as twigs and dust get mixed into the coffee as the process goes on. Obviously, this isn&#39;t the best for your health either (not to mention gross). If you&rsquo;ve read till this point, thanks for sticking with us! We know it&rsquo;s not easy to digest these long posts, but we hope they&rsquo;ve proved insightful and helpful as you try to make your coffee better for yourself. Or if you are not entirely convinced, do drop by our pop up at TANGS orchard, and have a cup of freshly brewed coffee on us. And we promise you, you will taste the difference. Stay tuned for our next instalment! We promise it&rsquo;ll be just as painless. Happy Brewing! The Hook Team</p>\r\n	2017-03-12 23:18:01.249798+00	2017-02-15 13:17:28+00	hookcoffee	./instant_regrets_hookblog.jpg	1	instant-regrets
43	Coffee Pork Ribs (Recipe)	Photo and recipe credit: MEATMEN COOKING CHANNEL\r\n\r\n[youtube https://www.youtube.com/watch?v=gVlzf6RFNH0&amp;w=560&amp;h=315]\r\n\r\nThis is definitely one of those 'you gotta try it to believe it' recipes. Perfect for a Sunday afternoon brunch with family and lov..	<p>Photo and recipe credit: MEATMEN COOKING CHANNEL [youtube https://www.youtube.com/watch?v=gVlzf6RFNH0&amp;w=560&amp;h=315] This is definitely one of those &#39;you gotta try it to believe it&#39; recipes. Perfect for a Sunday afternoon brunch with family and loved ones. Best paired with a cup of bright, tart, and nutty Prosperoo from Hook (which will be leaving our coffee menu at the end of the month!) We haven&#39;t gotten down to experimenting with every Coffee Pork Ribs recipe there is out there but we&#39;re most inclined to this one by The Meat Men simply because of how mouthwatering their video is. Check them out <a href="http://themeatmen.sg/coffee-pork-ribs/">here</a>.</p>\r\n\r\n<div>\r\n<h2>Ingredients</h2>\r\n\r\n<ul>\r\n\t<li>\r\n\t<div>500g pork ribs</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>&frac12; tsp salt</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>&frac12; tsp sugar</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>2 tbsp oyster sauce</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>1 tsp sesame oil</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>&frac12; tsp bicarbonate of soda</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>2 tbsp rice flour</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>2 tbsp potato starch</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>3 tbsp water</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>Oil for deep-frying</div>\r\n\t</li>\r\n</ul>\r\n</div>\r\n\r\n<div>\r\n<h2>Sauce</h2>\r\n\r\n<ul>\r\n\t<li>\r\n\t<div>32g of freshly roasted coffee, ground super fine (The Meat Men used instant coffee because it dissolves in water but if you&#39;d like a more aromatic and flavoursome dish and are okay with a grainier sauce, freshly roasted coffee is always better)</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>1 tbsp brown sugar</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>1 tbsp sugar</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>1 tbsp minced garlic</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>2 tbsp Worcestershire sauce</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>1 tbsp rice wine</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>1 tbsp dark soy sauce</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>3 tbsp water</div>\r\n\t</li>\r\n</ul>\r\n</div>\r\n\r\n<div>\r\n<h2>Instructions</h2>\r\n\r\n<ol>\r\n\t<li>Cut 500g pork ribs into strips</li>\r\n\t<li>Add\r\n\t<ul>\r\n\t\t<li>&frac12; tsp salt</li>\r\n\t\t<li>\r\n\t\t<div>&frac12; tsp sugar,</div>\r\n\t\t</li>\r\n\t\t<li>\r\n\t\t<div>2 tbsp oyster sauce,</div>\r\n\t\t</li>\r\n\t\t<li>\r\n\t\t<div>1 tsp sesame oil,</div>\r\n\t\t</li>\r\n\t\t<li>\r\n\t\t<div>&frac12; tsp bicarbonate of soda,</div>\r\n\t\t</li>\r\n\t\t<li>\r\n\t\t<div>2 tbsp rice flour,</div>\r\n\t\t</li>\r\n\t\t<li>\r\n\t\t<div>2 tbsp potato star</div>\r\n\t\t</li>\r\n\t\t<li>\r\n\t\t<div>3 tbsp water,</div>\r\n\t\t</li>\r\n\t\t<li>\r\n\t\t<div>1 egg (beaten)</div>\r\n\t\t</li>\r\n\t</ul>\r\n\t</li>\r\n\t<li>Mix well and let it marinate for 1 hour</li>\r\n\t<li>For coffee sauce mix in a bowl\r\n\t<ul>\r\n\t\t<li>2 packets instant coffee</li>\r\n\t\t<li>1 tbsp brown sugar</li>\r\n\t\t<li>1 tbsp sugar (adjust to taste)</li>\r\n\t\t<li>1 tbsp minced garlic</li>\r\n\t\t<li>1 tbsp rice wine (optional)</li>\r\n\t\t<li>2 tbsp Worcestershire sauce</li>\r\n\t\t<li>1 tbsp dark soy sauce</li>\r\n\t\t<li>3 tbsp water</li>\r\n\t</ul>\r\n\t</li>\r\n\t<li>\r\n\t<div>Mix well and set aside</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>Heat sufficient oil in a wok, deep-fry pork ribs till golden brown</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>Drain and set aside</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>Add coffee sauce mixture to a pan</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>Cook until it thickens</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>Add pork ribs, toss and let sauce coat evenly</div>\r\n\t</li>\r\n\t<li>\r\n\t<div>Garnish with chopped chilli padis and fresh coriander</div>\r\n\t</li>\r\n</ol>\r\nMhmmmmmm...</div>\r\n\r\n<p>&nbsp; leave your comments below on this recipe if you have tried it! Have a happy Sunday! xoxo, Team Hook</p>\r\n	2017-03-12 23:18:01.244121+00	2017-02-26 02:22:02+00	hookcoffee	./coffeeporkribs_meatmen.jpg	14	coffee-pork-ribs-recipe
33	Introducing ETERNAL SUNSHINE - Black Gold Edition #2	We are very proud at Hook Coffee to announce the launch of a second Black Gold Edition coffee, our line of rare of best of the best coffees. This new addition to the series is our highest scoring coffee yet: Eternal Sunshine.\r\n\r\n\r\n\r\nThis special offering, from..	<p>We are very proud at Hook Coffee to announce the launch of a second Black Gold Edition coffee, our line of rare of best of the best coffees. This new addition to the series is our highest scoring coffee yet: <strong>Eternal Sunshine.</strong> <img alt="img_0227" class="alignnone size-full wp-image-2872" src="https://hookcoffee.files.wordpress.com/2016/10/img_0227.jpg" style="height:1066px; width:1600px" /> This special offering, from the birthplace of coffee itself, was grown in the Torea village in Yirgacheffe, Ethiopia at about 1800 meters above sea level.&nbsp;The coffee was processed at the Aricha&nbsp;station via the natural method, which is famous for shaping coffee&rsquo;s flavor to be full and wild. This is a&nbsp;wildly exotic and deliciously fruity coffee. The satisfying sweetness&nbsp;of berries and nectarines will leave you smiling and energised like eternal sunshine.</p>\r\n\r\n<h2>Our Highest Scoring Coffee Yet</h2>\r\n\r\n<p>This Ethiopia Aricha holds an excellent score of 88. This score was determined by a licensed coffee industry Quality Grader. The Q-Grader certification is the most prestigious in the coffee world, and the professionals who hold are very skilled at grading coffees. Q-Graders use a variety of tests to determine the quality of an unroasted coffee bean. Variations in size, density, color all play a role in determining the final score. More importantly, however, is the percent of defect coffee beans and final cup quality. The more care a farm grows and processes their coffee cherries and beans, the greater the taste and higher the score. The high score of this coffee indicates that the coffee plants themselves were taken care of, that cherry pickers only selected ripe cherries, and that the processing was monitored and executed well. This is among the best of the best. According to the standards presented by the Specialty Coffee Association of America, any score between 80 and 100 falls in the &ldquo;specialty coffee&rdquo; range, and anything 85+ is considered excellent quality. Few coffees make it beyond 85 points. We are lucky to be able to offer such a prestigious option.</p>\r\n\r\n<h2>The Black Gold Edition&nbsp;Will Continue</h2>\r\n\r\n<p>We will release more top-shelf coffees as we are able to get our hands on them. Coffees this good only come around so often, but we&#39;ve got our eyes peeled! Stay tuned for more Black Gold coffees. You can buy a bag of the Eternal Sunshine for yourself on the Hook Coffee website. You&#39;ll never think of coffee the same way again. Happy Brewing, The Hook Coffee Team</p>\r\n	2017-03-12 23:18:01.108779+00	2016-10-12 04:54:39+00	hookcoffee	./introducing_eternal_sunshine_hookblog.jpg	13	ethiopia-aricha-natural
34	How To Use the Coffee Flavor Wheel	Tasting subtle flavors in our food is not something we often grow up doing. Rice is rice. Chicken tastes like chicken. That’s how most of us learn to understand flavor - on a very basic level. The idea of coffee tasting like anything other than “just coffe..	<p>Tasting subtle flavors in our food is not something we often grow up doing. Rice is rice. Chicken tastes like chicken. That&rsquo;s how most of us learn to understand flavor - on a very basic level. The idea of coffee tasting like anything other than &ldquo;just coffee&rdquo; sounds utterly ridiculous under this framework of flavor we grow into, but there&rsquo;s a way to break out of it. What if I told you that you could taste all sorts of things in your coffee? Blueberry, lime, jasmine, cashew, tomato - yes - these are all possible flavors in coffee that has been cared for from farm to roaster to cup. Nothing &nbsp;has to be added for these flavors to appear - the coffee just has to be grown and roasted with attention and discipline. Coffee beans that have been flavored with oils or additives are likely lower-quality coffee beans to begin with. As a general rule: coffee should be flavorful on its own. If it&#39;s flavored with a separate agent, it does not fit within the specialty coffee realm. To get a chance to taste these types of wild flavors for yourself, take a look at the Coffee Flavor Wheel and brew up a cup of coffee that has been sourced and roasted by a reputable specialty coffee roaster. One great coffee to do this with is our new Ethiopia Aricha Natural, which is bursting at the seams with flavor. <img alt="coffee-flavor-wheel" class="aligncenter size-large wp-image-2859" src="https://hookcoffee.files.wordpress.com/2016/10/coffee-flavor-wheel.jpg?w=724" style="height:1024px; width:724px" /></p>\r\n\r\n<h2>How To Use the Coffee Flavor Wheel</h2>\r\n\r\n<p>Take a sip of your coffee. Swirl it around all parts of your mouth for a moment and enjoy it. Ask yourself these questions:</p>\r\n\r\n<ul>\r\n\t<li>What does it remind you of?</li>\r\n\t<li>What does it taste like anything other than &ldquo;just coffee&rdquo;?</li>\r\n\t<li>Does it have any particular feeling?</li>\r\n</ul>\r\n\r\n<p>Take a look at the wheel, developed over three years with the help of over a hundred scientists. Start at the center. Is the coffee fruity at all? Nutty? Sweet? Does it taste green or vegetal? If you can get a sense of a direction that the flavor may lean&nbsp;towards, you&rsquo;re doing it correctly! Look at level two. Does that fruity taste you are experiencing remind you more of a berry or a citrus fruit? Maybe that sweetness you taste reminds you of brown sugar, sweet but dark. Move to the final circle. Is that brown sugary flavor more like honey or molasses? Is that citrus fruit an orange or a lime? For beginners, it can be quite difficult to move to the outer two levels. With time and more&nbsp;tasting comes confidence and clarity, so don&rsquo;t give up. Perform this exercise every time you try a new coffee, and you&rsquo;ll be tasting clove and peach and maple before too long.</p>\r\n\r\n<h2>Fake It Till You Make It</h2>\r\n\r\n<p>A large part of tasting is coming to realize that your palate can pick up on things more powerfully than you realize. When you fake it till you make it, you are actually learning to trust your palate. There then comes a moment when you taste something and realize that you don&rsquo;t have to guess or try to stretch the description. Learning to do this takes time, confidence, and some patience. It&rsquo;s an exercise in focus and attention, but it comes with some great rewards.</p>\r\n\r\n<h2>Be Empowered</h2>\r\n\r\n<p>The wheel is meant to empower coffee tasters of all skills to find and discern flavors within coffee. It&rsquo;s not meant to stretch reality - the flavors are based on identifiable chemicals in coffee - it&rsquo;s meant to train us how to taste and understand new levels of coffee flavor. Take this skill with you wherever you go. Soon you&rsquo;ll know the difference in flavor and mouthfeel between jasmine and arborio rice, as well as light and dark chicken meat. Happy brewing!</p>\r\n	2017-03-12 23:18:01.149852+00	2016-10-17 03:48:05+00	hookcoffee	./how_to_use_coffee_flavour_wheel_hookblog-2.jpg	10	how-to-use-the-coffee-flavor-wheel
35	5 Tools For The Coffee Nerd	Brewing coffee really only requires two things: coffee and water. Yes, it works a lot better if you use certain tools and techniques, but those two things are where it all begins. For some, the simple combination of coffee and water in a french press or a ..	<p>Brewing coffee really only requires two things: coffee and water. Yes, it works a lot better if you use certain tools and techniques, but those two things are where it all begins.&nbsp;For some, the simple combination of coffee and water in a french press or a drip pot is enough to satisfy. For others, it&rsquo;s not even close to enough. <img alt="coffee-nerd-tools" class="aligncenter size-large wp-image-2877" src="https://hookcoffee.files.wordpress.com/2016/10/coffee-nerd-tools.jpg?w=1000" style="height:665px; width:1000px" /> Here are some of the tools we coffee nerds rely on to brew our delicious, balanced coffee.</p>\r\n\r\n<h2>Gram Scale</h2>\r\n\r\n<p>Precision is the key to consistently good coffee, so it&rsquo;s no wonder that coffee shops and enthusiasts swear by using gram scales. Volume is unreliable. Coffee beans take up different amounts of room and rarely weigh the same. It can be difficult to tell how much coffee and water you&rsquo;re using when you just eyeball it. Scales take the guessing out of coffee and water ratios, making it a piece of cake to land right in that &nbsp;sweet spot of 1:15 and 1:18. Measure by volume, and there&rsquo;s no telling what ratio you&rsquo;ll land in. Measure with weight (mass), and you&#39;ll hit the bullseye ever time.</p>\r\n\r\n<h2>Thermometer</h2>\r\n\r\n<p>The generally agreed upon range of ideal water temperatures for coffee brewing is 90 to 96 degrees Celsius. This is the point where water extracts coffee at a rate that doesn&rsquo;t take hours to brew a good cup, but also not so fast that you end up with a bitter mug every time. It&rsquo;s a healthy sweet spot. Even within that range, a careful coffee brewer can achieve different results. Some like their brew heavier and more extracted and use a higher temperature. Some prefer to slow the extraction just barely with a lower temperature to achieve a smoother, brighter result. Knowing the exact temperature of your water gives you the power to make more decisions about how you brew your coffee, and enables you to get even closer to your perfect cup. There&#39;s also some fun to be had with brewing coffee at odd temperatures. The 2015 World Aeropress championships revealed that some wacky recipes can still produce amazing results. The <a href="http://sprudge.com/lukas-zahradnik-is-your-2015-world-aeropress-champion-75152.html">3rd place winner from The Philippines</a> used 79 degree Celsius water, for example. With a thermometer, you can see what all the fuss is about these odd recipes.</p>\r\n\r\n<h2>Cupping Set</h2>\r\n\r\n<p>If you&rsquo;re one to sample lots of coffees side-by-side or want to become better at tasting coffee in general, you should consider a cupping set. These small bowls and spoons are designed to enable tasters to get a strong idea of how multiple coffees taste next to each other. Coffee cupping is a practice used by professionals around the world to evaluate bean and roast quality, but the coffee nerds among us can also benefit from this style of tasting. One of the greatest benefits of this practice is the development of your palate. Learning to taste coffee can be done one cup at a time, but things get going quickly when you can assess several coffees all at once and compare them to each other. This can be done alone, but tasting with friends is another great way to accelerate the growth of your tasting ability.</p>\r\n\r\n<h2>Coffee Ground Sifter</h2>\r\n\r\n<p>The coffee grinder is the most important tool in any coffee brewing equipment arsenal. Without a strong burr grinder, you are left to the mercy of unevenly sized coffee particles, which don&rsquo;t brew at the same rate and can throw off a great cup. Even with a well-built burr grinder, there are always coffee particles that come out a different size than the rest. We call these &ldquo;fines&rdquo; (micro-particles) and &ldquo;boulders&rdquo; (extra-large). Using a sifter, you can isolate a specific particle size and remove the fines and boulders. This gives you the ability to brew a balanced cup that cannot be compromised by multiple coffee ground sizes.</p>\r\n\r\n<h2>Gooseneck Kettle</h2>\r\n\r\n<p>The gooseneck kettle is a funny looking thing, but it is an empowering tool. When you&rsquo;re brewing with a pour over cone, it&rsquo;s very important that you pour slowly and saturate all of the coffee grounds evenly. If you splash a giant flow of water into the brewer and finish pouring in two seconds, you&rsquo;ll end up with an unbalanced, underextracted cup of coffee. Gross. The slow, steady poor is what causes pour over coffee to extract evenly and sufficiently. This tool is slowly becoming less nerdy. Even coffee barely-nerds are adopting the slow, steady pouring technique that a gooseneck kettle can offer. There&rsquo;s no debate that this is a necessary tool for pour over brewing.</p>\r\n\r\n<h2>Will You Continue To Dive In?</h2>\r\n\r\n<p>The rabbit hole goes deep, and these brewing tools are what it takes to reach that next level of precision and balance. Will you explore further into the mysterious and incredible world of coffee? Have you already joined the ranks of the coffee nerds without realizing it? We&rsquo;re an excited group of folks at Hook Coffee and nerd out in every step of our coffee journey. To experience the rewards of our nerdiness, try some of our coffee. You may feel compelled to join us in the rabbit hole. Happy Brewing. The Hook Coffee Team</p>\r\n	2017-03-12 23:18:01.180528+00	2016-10-22 02:00:53+00	hookcoffee	./5_tools_for_the_coffee_nerd_hookblog.jpg	6	5-tools-for-the-coffee-nerd
37	Greetings and Merry Christmas to all!	It’s a glorious time here at Hook Coffee. A special time. A wonderful time.\r\n\r\nWhy, you ask?\r\n\r\nWell it’s Hook Coffee’s very first Christmas! Today we make merry and celebrate not only the holidays but also our fans and readers. Seriously, we couldn’t have don..	<p>It&rsquo;s a glorious time here at Hook Coffee. A special time. A wonderful time. Why, you ask? Well it&rsquo;s Hook Coffee&rsquo;s very first Christmas! Today we make merry and celebrate not only the holidays but also our fans and readers. Seriously, we couldn&rsquo;t have done it without you all. The support and encouragement over the past year has been a true joy. We at Hook also want to thank all who caved and purchased our set of tangible Christmas cheer. While we were a little unprepared for our first Christmas sale, it all worked out. Thanks for bearing with us. Christmas cheer was successfully spread to the masses. <strong>The Frustrations of Bringing Coffee Home to the Family</strong> We all know that around this time of year, coffee nerds trek across the land to family and friends for the holidays. Kettles and Aeropresses are shoved into suitcases, and coffee is sealed up in travel containers. When packing for the holidays, making room for coffee gear is one of the utmost priorities&hellip;naturally. It&rsquo;s almost exciting to think about enjoying coffee anywhere you wish. Coffee geeks pride themselves on their ability to make a pleasant cup away from home. We buy mobile coffee gear and expect to convey the beauties of coffee to everyone around. <em>However</em>, when the travel destination is reached and coffee gear is unloaded onto a family relative&rsquo;s kitchen counter, there are no cheers or smiling faces. Everyone in the room goes silent. There are befuddled looks. People wonder why Aunt Sally&rsquo;s son is cluttering up the counter space with gizmos and scales and thermometers. &ldquo;What&rsquo;s that?&rdquo; They ask. &ldquo;This is for my coffee,&rdquo; you murmur hesitantly. &ldquo;Oh,&rdquo; they say. &ldquo;Really?&rdquo; Remarks about your &ldquo;fancy coffee,&rdquo; and how &ldquo;it takes you twenty minutes to make coffee in the morning&rdquo; are then made throughout the entirety of the trip. The stabs are endless, and you realize that you should have just gone a week without drinking any coffee at all. Being passionate about the third wave coffee industry can be an exhausting endeavor. Everyone involved with the third wave coffee industry has dealt with people misunderstanding at one point or another. So what can we do when this happens <em>during Christmas</em>? We wrote up a nifty guide to get you through the holidays. Follow at your own risk. &nbsp; <strong>St. Nick&rsquo;s Coffee Survival Guide Spectacular!</strong> <em>Some options/methods for dealing with people who question your coffee methods.</em></p>\r\n\r\n<ol>\r\n\t<li>Be sleuthy. That&rsquo;s right. Sneak around. Put on your most quiet pair of socks in the morning and brew up some coffee before people start waking up. If you have an electric grinder, make sure to use it in a secluded area like outside or in the garage.</li>\r\n</ol>\r\n\r\n<ol start="2">\r\n\t<li>Show them the magic. If any of your family gives you slack for your &ldquo;excessive coffee habits,&rdquo; just make them a cup and have them try it for themselves. If they love it, you&rsquo;re home free. If not, they will most likely drench it in milk and sugar, smirking the whole time (If this happens, you&rsquo;re worse off than when you first begun).</li>\r\n</ol>\r\n\r\n<ol start="3">\r\n\t<li>Play it cool. Instead of telling them that specialty coffee is a hobby or passion, just explain that you think it&rsquo;s fun to make coffee this way. Show them how, and they will probably play with your coffee gear for the rest of trip.</li>\r\n</ol>\r\n\r\n<ol start="4">\r\n\t<li>Throw a temper tantrum. Exude rage and power. Yell and crush glass, chairs, and whatever food you can find. No one will ever question your coffee methods again.</li>\r\n</ol>\r\n\r\n<ol start="5">\r\n\t<li>Spend the entire trip making coffee. Skip meals, slurp loudly, and spill hot coffee wherever you can manage.</li>\r\n</ol>\r\n\r\n<p>&nbsp; All jokes aside, share your love of coffee with whoever you wish. If someone enjoys flavors or sugar in their coffee beverage, that&rsquo;s completely okay. Let&rsquo;s keep spreading love and cheer through coffee. Merry brewing and merry Christmas from the co-founders, Ernest and Faye. Thanks again!</p>\r\n	2017-03-12 23:18:01.20564+00	2016-12-24 05:11:50+00	hookcoffee	./greetings_and_merry_christmas_hookblog.jpg	12	greetings-and-merry-christmas-to-all
38	The New Year, An Intentional Review	A message from the co-founders: \r\n\r\nThank you for an amazing 2016. We set out to bring freshly roasted coffee to you all. Sharing our love of coffee was a simple mission, but getting to laugh and share with everyone has been an incredible experience. We are ..	<blockquote><em>A message from the co-founders:&nbsp;</em> Thank you for an amazing 2016. We set out to bring freshly roasted coffee to you all. Sharing our love of coffee was a simple mission, but getting to laugh and share with everyone has been an incredible experience. We are overwhelmed by the amount of love and support from our family, friends, investors, and our caffeinated readers. 2017 will be a truly exciting year ahead as we continue to innovate and work with amazing farmers that bring the fruits of their labor to you. Love, Ernest &amp; Faye Co-founders of Hook Coffee</blockquote>\r\n\r\n<p>With the birth of 2017 comes a blank slate. We are sad to see 2016 shift into the past, but good times are coming, and we are excited to share them with you! Whether or not you&rsquo;re ready for the new year, it&rsquo;s time to get back into the grind of things. Before we go on, we wanted to look back and further thank you all for the amazing year. Your support has been monumental! So much has been done. [gallery ids=&quot;2932,2930,2931,2933,2934&quot; type=&quot;slideshow&quot;] It is only natural that New Year&rsquo;s resolutions tag along as we celebrate 2017. Every year, many of us take out the notepad and construct massive lists on how to better ourselves. Even if you aren&rsquo;t fond of the &ldquo;New Year&rsquo;s resolution ritual,&rdquo; let&rsquo;s be honest: there are always ways to improve yourself. Looking ahead is not always fun. Improving, learning, or shaping can be a daunting task. We at Hook want to do our part and help to eliminate as many of those daunting resolutions as we can. How can we do that? Well, maybe getting better at brewing coffee is on that resolution list of yours. Loads of information can be found about the coffee realm. Roasting, brewing, grinding, farming, processing&hellip; the list goes on. Learning the coffee craft can indeed be &ldquo;daunting,&rdquo; but we want to help quell that fear. Coffee isn&rsquo;t about prestige or being a rock-star barista. Coffee is about being a part of a community that enjoys hospitality and good intentionality. &nbsp; <strong>Getting better at coffee:</strong> Understand that the coffee learning process will take some good old fashioned tears. What we mean by &ldquo;tears&rdquo; is that you won&rsquo;t just wake up one day with a kettle in your arms and an infinite knowledge of the coffee craft. It will take some work, and by work, we mean practice and being intentional. &nbsp; <strong>So how does one practice coffee?</strong> <em>Brewing coffee </em>is tactile (<em>application</em>). <em>Coffee knowledge</em> is both tactile and visual. This is vital to understand when continuing your coffee journey or beginning it. To be proficient at anything, one must perform a given task. You can&rsquo;t just read coffee theory and blogs all day if becoming better at brewing coffee is the goal. Books are good, but you&rsquo;ll end up spilling water everywhere during the brew process, adapting to changes will be entirely difficult, and efficiency will be pitiful. The same goes for brewing without knowledge: you may be able to beautifully execute a particular pour-over method, but you will have difficulty manipulating variables in the brew process without any sense of coffee theory. <em>Here are some good theory resources to amp up your coffee knowledge:</em> -The Barista Handbook (Rao) This is an all-around theory and application guide for the aspiring barista. Espresso and milk theory are addressed as well. Think of this as a barista lexicon. A wealth of information and formative application can be found here. -The World Atlas of Coffee (Hoffmann) In this book, Hoffmann takes the reader through a coffee pilgrimage. By country, this book covers key growing regions, taste profiles, and history. Roasting processes, farming processes, and brewing is also covered. This is a good pick for someone who wants to go further than just brewing. -Blue Bottle Craft of Coffee (Freeman) This book is another incredible resource that takes the reader through a thorough seed to cup process. Freeman helped the coffee industry in many ways, so this is a worthwhile read. -Everything but Espresso (Rao) Rao dissects water quality, brew colloids, agitation, temperature, and all other sorts of coffee alchemy in this book. Great for the home barista. Practicing coffee is brewing coffee, and understanding how that coffee is brewed. Intentionality should always be at the forefront. If the coffee you just brewed tastes like a rancid trash can, <em>figure out why</em> and <em>fix it</em>. &nbsp; <strong>Should you buy gear to get better?</strong> This is an interesting question. The real answer is no, but there are certain exceptions. Growing out of your gear is a real thing. For example, there comes a point when a normal kettle is too bulky and inexact. There comes a point when the current grinder being used doesn&rsquo;t provide a suitable particle size distribution. The examples can go on. Sure, gear can help us achieve our coffee goals, but more gear doesn&rsquo;t mean better coffee. Intentionality means better coffee. Think about making the upgrades you need. The one upgrade we recommend is a grinder. Many people overlook the fact that a grinder is arguably the piece of gear that affects coffee quality the most. If you want to take your coffee to the next level, obtain a grinder with better particle size distribution (PSD). PSD is the variation in size between coffee particles (usually measured in microns). If the grind is even throughout, repeatability and consistency in brewing will more likely follow. When boulders (course grind chunks) and fines (powdery coffee particles), make it into the brew bed, an unbalanced cup could be brewed. We recommend trying out the Kuissential evengrind, Knock Feldgrind, or the Baratza Encore for your coffee grinding needs! Just remember that you don&rsquo;t need to spend an arm and a leg on gear. Get what you need. &nbsp; <strong>Thanks!</strong> Thank you for embracing our achievements with us. Your support makes us happy. To express our heartfelt gratitude, here is 17% off your next order to kick start 2017. Use code: 2017 &nbsp; Happy New Year, and Happy brewing!</p>\r\n	2017-03-12 23:18:01.211263+00	2017-01-06 02:00:00+00	hookcoffee	./the_new_year_review_hookblog.jpg	13	the-new-year-an-intentional-review
39	Taking advantage of brew variables	Brewing coffee at home is a popular craft. Many wish to emulate the well balanced cups of coffee that they drink in cafes - seeking out the “perfect cup.” However, the road of coffee discovery can be long and hard. This is why we at Hook published today’s ..	<p>Brewing coffee at home is a popular craft. Many wish to emulate the well balanced cups of coffee that they drink in cafes - seeking out the &ldquo;perfect cup.&rdquo; However, the road of coffee discovery can be long and hard. This is why we at Hook published today&rsquo;s article. We hope to aid you on your coffee discovery journey!</p>\r\n\r\n<blockquote>\r\n<h4><em>Defining terms:</em></h4>\r\n\r\n<h5><strong>Overextraction</strong> &ndash; When coffee is bitter [Usually when the extraction percentage exceeds 21%. Don&rsquo;t worry about this for now, as we will be focusing more on taste in this article]</h5>\r\n\r\n<h5><strong>Underextraction</strong> &ndash; When coffee is watery or tasteless</h5>\r\n\r\n<h5>Particle Size distribution (psd) &ndash; the difference in size between the smallest coffee particle and the largest.</h5>\r\n\r\n<h5><strong>Bloom</strong> &ndash; a stage at the beginning of the brew process in which a small percentage of the total water used in the brew process is poured on the ground coffee mass. The bloom is used for coffee control and to eliminate potent volatile gases.</h5>\r\n</blockquote>\r\n\r\n<h3><strong>Before we delve into some coffee alchemy, let&rsquo;s address a few abstract variables:</strong></h3>\r\n\r\n<h3><em>Variable: practice time</em></h3>\r\n\r\n<p>For starters, <strong>the home-brewing craft will take time</strong>. There&rsquo;s a reason that the internet is cluttered with thousands of articles on &ldquo;how to make your coffee taste good.&rdquo; Like most things in life, brewing quality coffee must be practiced often. There are no shortcuts &ndash; just knowledge and application.</p>\r\n\r\n<h3><em>Variable: quality ingredients</em></h3>\r\n\r\n<p>To brew a good cup of coffee, <strong>you need high quality ingredients</strong>. This fact is not negotiable. If you cook with rancid old ingredients, the food will, well, taste rancid and old. Coffee is much the same. Using high quality coffee also acts as a compass for brewing improvement. When brewing coffee roasted by a reputable and trusted company, you can rest assured that if the coffee tastes bad, it&rsquo;s your fault. This is a good thing. Good coffee that tastes bad will show you where to go!</p>\r\n\r\n<h3><em>Variable: high performance grinder</em></h3>\r\n\r\n<p>Use <strong>a grinder with an acceptable particle size distribution</strong> to grind your coffee. A grinder is perhaps your most important tool in the brewing process. This will be addressed later in the guide as well.</p>\r\n\r\n<h4>Here are a few grinders to check out that meet a high-performance criteria:</h4>\r\n\r\n<h5>-Baratza Encore</h5>\r\n\r\n<h5>-Kuissential EvenGrind</h5>\r\n\r\n<h5>-Baratza Sette</h5>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Use your brew variables:</strong></h2>\r\n\r\n<p><strong>&nbsp;</strong>Fear not! Do not be afraid of ruining precious coffee morsels due to poor extraction. Instead, use your brew variables to pull out the bounty of aroma and flavors! Many people are afraid of brewing bitter coffee, so they compensate by brewing too quickly or with little agitation. A watery cup of coffee will be the result. We don&rsquo;t want watery coffee. We want coffee that is rich in the complex harmonies of mouthfeel and aroma and flavor.</p>\r\n\r\n<h3><em>Variable: brew time</em></h3>\r\n\r\n<p>Brew time is the amount of time that water is in contact with a ground coffee mass. The longer that coffee is submerged in water, the more extraction takes place. This variable is more pertinent in Immersion brew methods. <em>Tip</em>: Looking for a balanced cup that isn&rsquo;t intense or sharp? Try increasing time, but decreasing the intensity of other variables. For instance, increase the time brewing with a Clever dripper or Eva Solo, but coarsen the grind, lower the temp, or decrease agitation. Slower curves of extraction can yield wonderful balanced results. &nbsp;</p>\r\n\r\n<h3><em>Variable: grind [VERY IMPORTANT]</em></h3>\r\n\r\n<p>As mentioned earlier, grind quality / size is perhaps the most important brewing variable. Everything around brewing a cup of coffee is centered on the ground coffee mass. This is why grind is important. When grinding coffee, you are directly manipulating the source of all flavor and aroma. If you understand how to manipulate grind, you can effectively impact the flavor to your preference. As a rule, a coarser grind extracts less, and a finer grind extracts more. Brewing takes place when water touches coffee particles. If the water contacts or &ldquo;touches&rdquo; more coffee particles, more extraction will occur. This is why finely ground coffee extracts more thoroughly and at a faster rate. Coarsely &nbsp;ground coffee extracts slower because it takes more time for the coffee to seep into the larger particles. One must also take grinder particle size distribution (PSD) into account. PSD is essentially how similar one coffee particle is to another. Keep in mind that there are always bound to be boulders (larger grinds than desired) and fines (smaller grinds than desired) in the ground coffee mass. Having a good PSD eliminates the anomalies of boulder and fines. Good PSD gives the brewer more control over the brew process&hellip;much more control. Brewed cups can be more easily replicated, and manipulating other brew variables will yield more determinable results. <em>Tip</em>: When taking advantage of brew variables, consider changing the grind variable first. Grind is the most effective way in reaching the goal of a desired cup. Once the grind is dialed in, consider fine tuning your brew with other variables. &nbsp;</p>\r\n\r\n<h3><em>Variable: agitation / turbulence </em></h3>\r\n\r\n<p>Agitation occurs when a disturbance of the wet coffee mass takes place. Pouring turbulence, stirring, shaking, and turning are all forms of agitation. Agitating while brewing creates uniformity. Some coffee particles are extracted more than others in the brew process (this could be due to water contacting some grounds more than others or from fines existing in the coffee mass). When some coffee particles are extracted more than others, an unbalanced cup can be the result; which is a cup that tastes overextracted and underextracted at the same time (yuck!). If a stir is incorporated, forgotten grounds of coffee are incorporated into the brew mass. A stir can save your coffee and create balance! Tip: In pour overs, try stirring the bloom or stirring right after all water has been deposited into the pour over mechanism. In Immersion methods, stir once or twice in the middle or end of brewing. Stirring is an underrated tool. Use it wisely.</p>\r\n\r\n<h3>&nbsp;</h3>\r\n\r\n<h3>Variable: water temperature</h3>\r\n\r\n<p>The SCAA&rsquo;s (specialty coffee association of America) standard for brewing temperature is using water at 195 &ndash; 205F. This isn&rsquo;t a rule, but merely a suggestion. Many studies have been done on effective brewing temperatures, and this is the recommended range. As a rule, lower temperatures brew slower, and higher temperatures brew quicker. <em>Tip</em>: If you are new to brewing, stick within SCAA&rsquo;s recommended range. For the expert, experiment to your heart&rsquo;s content! &nbsp;</p>\r\n\r\n<h3>Variable: Coffee to Water Ratio</h3>\r\n\r\n<p>We recommend staying within the 1:15 &ndash; 1: 18 brew ratio. E.g. for every 1 part of coffee, there are 15 parts of water. So&hellip; 25g coffee 400ml water 400 / 25 = 16 1: 16 ratio! <em>Tip</em>: the smaller the ratio, the more chance for over extraction. Compensate by being careful with your brew variables. Even 1:13 cups can be very tasty&hellip; just be careful not to over extract! &nbsp; Be brave and confident when brewing! Complex variables don&rsquo;t have to be your enemies. Always seek out the tastiest cup, and never stop experimenting! Happy Brewing! The Hook Coffee Team. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>\r\n	2017-03-12 23:18:01.217522+00	2017-01-15 03:32:48+00	hookcoffee	./takign_advantage_of_brew_variables_hookblog_.jpg	4	taking-advantage-of-brew-variables
46	Cold Brew and Cold Coffee	Over the past decade, cold brew took the stage as a new standard for coffee refreshment.\r\n\r\nWe see it bottled, on tap, in cartons, or slowly brewing in turn-of-the-century glass mechanisms at specialty cafes. It can be enjoyed with milk, cream, or with a var..	<p>Over the past decade, cold brew took the stage as a new standard for coffee refreshment. We see it bottled, on tap, in cartons, or slowly brewing in turn-of-the-century glass mechanisms at specialty cafes. It can be enjoyed with milk, cream, or with a variety of other tasty concoctions. Cold brew can pair well with almost any cocktail base. It can even be used as a concentrate to be added in food or other signature beverages. If you are curious of the hype...well, just know that if done right, cold brew is tasty. Real tasty. Today&#39;s blog will discuss the topic of cold brew and some of its critiques. &nbsp;</p>\r\n\r\n<h2><strong>What is Cold Brew?</strong></h2>\r\n\r\n<p>For those unfamiliar, cold brew is what is sounds like. It is essentially coffee brewed cold. [Cold brew is actually brewed at room temperature most of the time, but ROOM TEMPERATURE brew doesn&#39;t sound as good, hence cold brew.] &nbsp;</p>\r\n\r\n<h2><strong>What Cold Brew is Not</strong></h2>\r\n\r\n<p>As described earlier, cold brew isn&#39;t just cold coffee. It is coffee that is brewed cold (or rather room tempetarure, it won&#39;t brew well with cold water). There are different cold coffee recipes out there. For instance, the Japanese Iced method is a brewing process that incorporates ice to slow down volatility. Japanese Iced coffee is brewed <em>normally</em> (aka hot water - using almost any brew method) into a decanter full of ice. The ice is measured in correlation to the brew ratio and final volume. The Japanese Iced method was created to make brewed coffee less volatile. Volatility is the process of gases and aroma <em>leaving</em> the coffee, and thus decreasing flavor. Something hot is more volatile than something that is cold. In other word, flavor diminishes quicker in volatile liquids. Japanese Iced coffee retains more of coffee&#39;s flavor by cooling it down immediately. As soon as the hot coffee drips onto the decanter full of ice, it becomes less volatile. It&#39;s kind of like a flavor trapping process. &nbsp;</p>\r\n\r\n<h2><strong>Cold Brew Alchemy</strong></h2>\r\n\r\n<p>Cold brew can be made using an immersion or drip method.</p>\r\n\r\n<hr />\r\n<p><em>Immersion</em>: can be done using the Toddy method. The coffee slurry is left in the toddy for 2-24 hours and then strained through a cloth or paper filter. <em>Attributes</em>: like standard immersion brew methods, immersion cold brew has a juicy, heavy mouthfeel. Brew colloids (coffee particles) are abundant in immersion methods and add more body to mouthfeel.</p>\r\n\r\n<hr />\r\n<p><em>Drip</em>: similar to a pour over, water drips onto a coffee bed - that water drips through a filter and into a decanter. Like most cold brew recipes, it takes 2-24 hours to complete a brew cycle. If you&#39;re interested, try using a Yama dripper. <em>Attributes</em>: cleaner than immersion cold brew. Clarity and depth of flavor supersedes creaminess and mouthfeel. For a quick and conveninet way, you can simply use a French press if you have one, and we we at Hook Coffee can even grind it to the right grind size for your cold brew coffee. Here is a <a href="https://hookcoffee.com.sg/blog/how-to-make-cold-brew-coffee-the-easy-way-in-a-french-press" target="_blank">post</a> we wrote previously on how to do it! &nbsp;</p>\r\n\r\n<h2><strong>Arguments against Cold Brew</strong></h2>\r\n\r\n<p>Many argue that cold brew really isn&#39;t worth the hype. If measured with a TDS meter or refractometer, many cold brew recipes seem to come out under extracted. Critics of cold brew state that the amount of coffee needed to brew properly isn&#39;t viable, that it&#39;s not sustainable, and that it&#39;s inconvenient. If you&#39;ve ever had bad cold brew, you&#39;ll maybe agree with critics&#39; sentiments. Bad cold brew tastes watery, sour, and tannic or metallic (like cough syrup to be very frank). Many shops substitute the cold brew method with the Japanese Iced process. The Japanese Iced method requires less coffee to brew, and it takes minutes, not hours, to complete a brew cycle. &nbsp;</p>\r\n\r\n<h2><strong>What we think</strong></h2>\r\n\r\n<p>We like both. Here&#39;s why: -Cold brew, and cold brew concentrate is a versatile beverage. As stated earlier, it can be added to many beverages and it tastes splendid. -When brewed at lower temperatures, coffee contains smaller amounts of sucrose, chlorogenic acid, acetic acid, and quinic acid. Because of this, cold brew is not as prone to bitter and astringent tastes. -Japanese Iced coffee doesn&#39;t take long to brew. Cold brew takes <em>hours</em> to brew. Since time isn&#39;t as much of a factor with Japanese Iced coffee, it is much easier to dial in. Cold brew can be difficult to perfect. -Japanese Iced coffee can be brewed with familiar brew methods. Nothing extra needs to be obtained or purchased. There is quite a bit of confusion surrounding the topic of cold coffee. Cold brew is just one of the ways coffee can be enjoyed cold. We at Hook enjoy it and we absolutely condone experimentation. See what you think! Try cold brew and compare it to other cold coffee methods. Explore and create! P.S. We recently did a batch of cold brew coffees at the Hook HQ using Guji Liya, and it tasted incredible. However, it got sold out really fast! If you like priority on our next brew, drop your interest <a href="https://projectbravo.typeform.com/to/kfXqco" target="_blank">here</a>! <img alt="HC-91.jpg" class="alignnone size-full wp-image-3099" src="https://hookcoffee.files.wordpress.com/2017/02/hc-91.jpg" style="height:4480px; width:6720px" /> Happy (cold) brewing! The Hook Coffee Team</p>\r\n	2017-03-12 23:18:01.261433+00	2017-02-22 02:00:13+00	hookcoffee	./HC-98.jpg	4	cold-brew-and-cold-coffee
41	Chinese New Year and Better Coffee	New Year goodness!\r\n\r\nChinese New Year is here. Red is everywhere, luck is in the air, and family reunions are abundant. We already took some time recently to discuss our year at Hook, so today we are going to focus a bit more on some practical new year reso..	<p>New Year goodness! Chinese New Year is here. Red is everywhere, luck is in the air, and family reunions are abundant. We already took some time recently to discuss our year at Hook, so today we are going to focus a bit more on some practical new year resolutions. <strong>Drinking better coffee and saving cash</strong> <em>&nbsp;</em><em>Picture this:</em> You walk into a caf&eacute; before work. The smell of coffee fills the air. The line is long. The person behind you is coughing up a storm. People are talking loudly at the table beside you. You walk up to the register and order a coffee to go. The cashier hands you your coffee and you give her five dollars or so, and then you frantically walk out of the caf&eacute; and on to work. While this scenario may not be a common one of yours, many people incorporate a similar routine into their day. Coffee and mornings go together like sun and the beach; cafes and coffee are integral to the coffee lover&rsquo;s day. Maybe you can guess what we are going to say next: something akin to &ldquo;instead of going to cafes, drink our coffee at home!&rdquo; or, &ldquo;cafes take time out of your morning.&rdquo; This isn&rsquo;t quite the case however. We <em>are</em> going to make points that the quality coffee experience can be enjoyed in a cheaper fashion, but we aren&rsquo;t bashing cafes or specific morning routines. Cafes can be great places to unwind and start your day. Many people enjoy visiting coffee shops and that&rsquo;s okay. This article simply analyzes the fiscal reality of the coffee lover. <strong>Saving money&hellip; A lot of money</strong> If one was to visit a caf&eacute; every working day of the year, spending an average of five dollars each visit, $1300 would be spent. Making this situation a bit more realistic, let&rsquo;s subtract ten weeks for holidays and such. That still leaves us with $1050 being spent a year on coffee. For some people, this cost seems reasonable&hellip; But for most, spending over $1000 on coffee seems absurd! Even the most avid of coffee bon vivants can agree that $1000 is a substantial sum of cash. Let&rsquo;s say you found a thousand bucks buried in the ground somewhere. What would you do with it? You could go on holiday! You could invest it, you could go out for a fancy dinner or two, or you could even fund your daily commute. The point is that a thousand dollars is a lot of money. But we can&rsquo;t give up coffee. As a human race, we simply cannot. The price of cutting out coffee is way too high! Coffee has become a need for the masses. So, must we give up the travel and holidays for coffee? <em>No</em>. Here&rsquo;s why. If one was to substitute their caf&eacute; coffee with Hook&rsquo;s single serve drip coffee, they would save an average of $3.60 a cup.</p>\r\n\r\n<blockquote>Hook single serve coffee bag = $1.40 average cup of coffee from a caf&eacute; = $5.00 total saved = $3.60</blockquote>\r\n\r\n<p>This means that you could save $756 dollars by drinking Hook coffee if we apply the same numbers from before. And bear in mind, this is only considering that you drink 1 cup of coffee a day, most of us drink way more than that. Hello holiday. Hello investing. Hello money. <strong>Price vs. Coffee Quality</strong> Saving over $700 by drinking our coffee sounds sketchy. I mean, that&rsquo;s a lot of money. Surely caf&eacute; coffee is tastier and more sustainable, right? Well, no. Again, we aren&rsquo;t bashing the caf&eacute; or other coffee purveyors. We love our coffee community and hope that they flourish. What we are saying is that our coffee is damn good, and sustainably sourced. We not only meticulously roast our beans, abiding by specialty coffee standards and practices, but we also abide by direct trade policies. Direct Trade means that we directly work with the farmers that grow the coffee we roast daily. In other words, we develop relationships with them. With direct trade, farmers earn 10-25% more. Because the farmers are paid well, they can support their craft &ndash; this means that the coffee tastes better, the children of the farmers can go to school, and their overall standard of living is improved. By drinking really good coffee, you can support a community that looks out for its own. We love our farmers. So by making coffee at home, you save money. You will also drink good coffee <em>every time </em>you brew a cup. A visit to the caf&eacute; can be relaxing and enjoyable, but the cost can hurt your wallet. This year, why not save money and enjoy wonderful coffees grown by wonderful farmers? Once again Happy New Year! And Happy Brewing! The Hook Coffee Team</p>\r\n	2017-03-12 23:18:01.229225+00	2017-01-28 01:00:34+00	hookcoffee	./CNY_better_coffee_hookblog.jpg	13	chinese-new-year-and-better-coffee
42	Coffee Pairing	Hello coffee people!\r\n\r\nPairing drinks with food can seem “beyond” the average food lover. Unfortunately, food pairing can even come off as pretentious. Many restaurants and eateries don’t offer specially paired suggestions of food and wine – especially not ..	<p>Hello coffee people! Pairing drinks with food can seem &ldquo;beyond&rdquo; the average food lover. Unfortunately, food pairing can even come off as pretentious. Many restaurants and eateries don&rsquo;t offer specially paired suggestions of food and wine &ndash; especially not for <em>coffee and food</em>. We watch gourmet chef&rsquo;s meticulously narrate meals, emanating flavor that permeates all senses. We watch them place axiomatic flavor choice and detail in <em>every </em>aspect of the food they serve. There are even descriptions on wine bottles that suggest certain foods to eat with the particular wine. Pairing can seem out of reach to the average joe. I mean, is it necessary to pair food and drink? Is it expensive? Well&hellip;to answer those thoughts, understand that we pair food and beverages every day. We drink wine with cheese because the tannins in the wine cut through fatty cheese proteins, creating complex flavors. We drink cola with sandwiches or pizza because carbonated sugary things cut through greasy, oily foods (and provide palate refreshment). We choose to drink hot tea with sweets as a contrasting element. The list of preferences can go on and on. Food pairing is natural. Craft coffee is something that takes time. Tasting natural flavor notes in your morning brew can be a difficult task, but once you are able to decipher flavors and aromas, you can take your coffee experience even further. Pairing coffee with food is a way to explore the hidden depths of flavor and adventure.</p>\r\n\r\n<h2>Flavor</h2>\r\n\r\n<p>Flavor can be broken up into five categories: salty, bitter, umami (think &ldquo;savory&rdquo;), sweet, and sour. Flavors within the five categories can be combined, contrasted, accentuated&hellip; the possibilities are essentially endless. Within each flavor category, millions of shades of flavors exist. Those flavors are combined with other flavors, and new flavors are made. This is why the world of food is paramount to so many us. Food is adventure. It never ends.</p>\r\n\r\n<h2>3 Types of Coffee Profiles</h2>\r\n\r\n<p>Coffee&rsquo;s flavor can be attributed to growing region, processing, roasting, and the brew process. Instead of focusing on region, or roast profile, we are going to examine flavor type. For the most part, coffee and food pairing exists within the world of desserts or barista competitions. While it isn&rsquo;t unheard of to see coffee pairing in some restaurants, it is a bit foreign. Specialty coffee is expanding into the culinary niche slowly. <strong>Fruity, acidic</strong> If bright coffees are brewed with balance in mind, the clarity and focused flavors of the cup can be mesmerizing. The bright, clear notes of blueberry or stonefruit make fruity coffees a wonderful standalone beverage as well. Ethiopian coffees lay within this category and are notorious for their tanic acidity and smoothness. <em>Pairing suggestions:</em> When pairing with bright coffees like a Sidama Ardi Ethiopian, there is a danger of masking flavors. Brighter coffees can almost be too much for a delicate tapa or meal. The balanced acidity of this type of coffee can also be masked by heavy, oily foods; like cheese or savory sauces. We recommend keeping <em>contrast </em>in mind when pairing this coffee. Bright coffees pair very well with lighter desserts. Breads are a great pairing item with brighter coffees due to their neutral flavors. A semi sweet scone with marmalade or butter will accentuate the brighter coffee notes. Affogatos usually go best with bright coffees (an affogato is ice cream and coffee &ndash; sometimes espresso), as well as ginger sweets or fruits like bananas or persimmons. <strong>Savory, Nutty</strong> Savory coffees in the specialty coffee world are the closest thing to the infamous &ldquo;dark coffee.&rdquo; Nutty and savory coffee yield notes like &ldquo;stewed tomatoes&rdquo; or &ldquo;cinnamon clove.&rdquo; Many newbies to specialty coffee prefer brighter coffees, but a lot of coffee veterans enjoy the complex simplicity of this darker profile. <em>Pairing suggestions:</em> Coffees with a darker flavor profile kind of blend in with the flavors around them. Paired right, and the coffee flavors will mutate into complex aromas and tastes with other foods. Which is why we recommend using this type of coffee to <em>accentuate and blend</em> with foods. If you are to eat breakfast with your coffee, savory coffees meld into the meal. The subtle cinnamon and nutty notes of the coffee remain constant with many savory foods. Light tapas are decent grounds for experiment as well. <strong>Floral, chocolately, light acidity</strong> This is the middle ground when it comes to coffee. Ethiopians are bright, El Salvadors are nutty and savory, and Guatemalan coffees rest within the realm of &ldquo;strawberry cream&rdquo; and &ldquo;dark chocolate.&rdquo; <em>Pairing suggestions:</em> This type of coffee has rich floral notes and a balanced flavor. However, if you wish to retain both aroma and flavor, you must be careful during the paring process. Keep pairing in the <em>neutral zone</em> with this coffee. Let the coffee shine. Greek yogurt, granola, and mild fruit (less acidity) is a good choice if you wish to keep floral and soft notes on the coffee front. Pairing with coffee is a process. Not much of it is seen in the culinary world, so feel free to experiment!</p>\r\n\r\n<h2>#gothookedwith Contest!</h2>\r\n\r\n<p>Congrats once again to our coffee pairing contest winners! Here is the winning post by Celeste Yap. &quot; Immediately got hooked after visiting during CNY when fatigue kicked in after 守岁。。 <a class="_58cn" href="https://www.facebook.com/hashtag/gothookedwith?hc_location=ufi" target="_blank">#gothookedwith</a>&quot;- Celeste Yap&nbsp; <img alt="16252179_638465513023562_5831186383616010223_o.jpg" class="alignnone wp-image-3018" src="https://hookcoffee.files.wordpress.com/2017/02/16252179_638465513023562_5831186383616010223_o.jpg?w=984" style="height:555px; width:416px" /> So once again, happy brewing! The Hook Coffee Team.</p>\r\n	2017-03-12 23:18:01.235416+00	2017-02-05 12:19:51+00	hookcoffee	./coffee_pairing_hookblog.jpg	6	coffee-pairing
48	Cupping Coffee - what does this mean?	\r\n\r\nMaybe you've heard of the term "cupping coffee."\r\n\r\nRoasters write about their flavor discoveries during the cupping process. You maybe have seen shops hosting weekly cuppings. It seems like everyone is doing it.\r\n\r\nWell, what is it?\r\n\r\nThe easiest answer is t..	<p><img alt="IMG_9838.JPG" class="alignnone size-full wp-image-3124" src="https://hookcoffee.files.wordpress.com/2017/03/img_98381.jpg" style="height:2448px; width:2448px" /> Maybe you&#39;ve heard of the term &quot;cupping coffee.&quot; Roasters write about their flavor discoveries during the cupping process. You maybe have seen shops hosting weekly cuppings. It seems like everyone is doing it. Well, what is it? The easiest answer is that it is a tool. Cupping is a process where people come together to taste coffee before it is sold. More than that, it is an <em>efficient </em>process in which tasting takes place. Notes are jotted down, discussions are ample, and decisions are made. All cupping decisions go back to the roaster. Even further than that, cupping notes can lead to roasting an entirely different coffee. &nbsp;</p>\r\n\r\n<h2><strong>Here&#39;s a brief on how cupping works.</strong></h2>\r\n\r\n<p>A table is set up with little cups and saucers around the perimeter. There is a cup of spoons in the center of the table, ready for all the participants of the cupping. <img alt="IMG_9842.JPG" class="alignnone size-full wp-image-3129" src="https://hookcoffee.files.wordpress.com/2017/03/img_9842.jpg" style="height:2448px; width:2448px" /></p>\r\n\r\n<h3><strong>First - Get the Dry Aroma</strong></h3>\r\n\r\n<p>Each of the cups is filled with ground coffee. The cupping participants then smell each of the cups and take notes. This is called the dry aroma. Many things can be determined <em>just </em>from smelling the freshly ground coffee. If one smells dried apricots and chocolate in an Ethiopian coffee, that can be a sign that the beans were roasted in the right ballpark. If instead one smells surface cleaner and toast, that can be a sign that something went wrong during the roasting period. Notes are taken for further inspection. &nbsp;</p>\r\n\r\n<h3><strong>Second - Get the Wet Aroma</strong></h3>\r\n\r\n<p>After the dry aroma is analyzed, water is poured onto the grounds. Once the grounds are brewed for a short time (details are discussed later in the article), the cupping participants break the crust of coffee that formed on the surface. This wet slurry of coffee is holding in much of the aroma. When the crust is broken by stirring with a spoon, aroma explosion happens. All the participants now smell each of the coffees and take notes. Keep in mind that the wet aroma is just as important as the dry aroma. Good coffee should stretch beyond the realm of flavor. Smell and taste go together. In this step, cuppers dissect each of the sensory imprints of a particular coffee. Instead of just brewing and tasting, cupping separates coffee into parts to be analyzed and perfected. Aroma is a <em>very important </em>part. <img alt="IMG_9847 2.JPG" class="alignnone size-full wp-image-3126" src="https://hookcoffee.files.wordpress.com/2017/03/img_9847-2.jpg" style="height:1600px; width:1600px" /></p>\r\n\r\n<h3><strong>Third - Taste and Slurp</strong></h3>\r\n\r\n<p>Once the water cools to around 71 degrees Celsius, tasting takes place. Each of the cuppers takes a spoonful of coffee and slurps it. Like, really slurps it. It can get loud in a cupping room. Slurping is done to intensify the flavor of the coffee. When almost breathing in coffee in a slurping fashion, the aroma is taken into the nose, the pores in the cheeks are saturated with coffee, and initial flavors that hit the mouth become abundantly clear. The coffee is tasted to point out unpleasant notes, and to observe palatable ones. Cuppers try to find notes like aluminum, detergent, or dirt. These bad, abstract notes can tell the roaster something that is going on, or they can point out coffee defects to green coffee buyers. As the brew cools, different notes become apparent. Once the temperature falls below 21 degrees Celsius, the observation stops. So that&#39;s the gist of cupping. We do it, and every other roaster does it. We find it educating and necessary. &nbsp;</p>\r\n\r\n<h2><strong>More in depth cupping instruction:</strong></h2>\r\n\r\n<p><em>Time between roast and cupping</em> - let the coffee rest after roast for at least 10 hours before cupping. Cup within 24 hours. <em>Ratio of water to coffee</em> - 18:1 We use 150-200 ml of water <em>Grind </em>- medium-coarse grind. Don&#39;t wait more than 15 minutes to infuse with water <em>Water</em> - Water should be poured at around 93 degrees Celsius. Brew time before wet aroma is 3-5 minutes. The coffee is measured for balance, acidity, clarity, mouthfeel, aroma, aftertaste, sweetness...and more. We try to analyze every aspect of the coffee before shipping it out to you all. &nbsp; Try cupping with your friends! While it won&#39;t be a &quot;true&quot; after roast cupping, you can learn a ton. Thanks everyone. Happy cupping! The Hook Coffee Team</p>\r\n	2017-03-12 23:18:01.273369+00	2017-03-01 04:58:16+00	hookcoffee	./Cupping_coffee_post_.jpg	10	cupping-coffee-what-does-this-mean
32	5 Reasons To Skip The Supermarket Coffee	\r\n\r\nThe infamous supermarket coffee aisle - a sight to behold, and a trap lying in wait. We all know the lure of hundreds of colorful coffee bags, but some of us are beginning to wake up to reality.\r\n\r\nSupermarket coffee is rarely coffee worth buying. You need..	<p><img alt="Supermarket_aisle_IE313-047.jpg" class="alignnone size-full wp-image-2848" src="https://hookcoffee.files.wordpress.com/2016/10/supermarket_aisle_ie313-047.jpg" style="height:399px; width:628px" /> The infamous supermarket coffee aisle - a sight to behold, and a trap lying in wait. We all know the lure of hundreds of colorful coffee bags, but some of us are beginning to wake up to reality. Supermarket coffee is rarely coffee worth buying. You need to know why.</p>\r\n\r\n<h2>1. It&rsquo;s Not Fresh or Flavorful</h2>\r\n\r\n<p>Supermarket coffee is rarely fresh and almost aways over-roasted. When green coffee beans are roasted, thousands of chemical reactions take place and the very structure of the beans change and begin to break down slowly. Carbon dioxide seeps out of the coffee cells, followed by the evaporation of aromatic oils. After two to three weeks out of the roaster, coffee beans will begin to decline very rapidly in quality. Each brew will be less satisfying than the last one, and the flavors will break down until there&rsquo;s nothing left to taste but old, stale coffee. Sadly, most supermarket coffee bags are well past the two week fresh period and have a very small fraction of the flavor they once did. To avoid the obvious decline in quality, many coffee companies roast the flavor right out of the coffee beans using a very dark roast, assuming the beans were high-quality enough to have any real flavor. This makes it seem like the flavors are still there for longer, but the reality is terribly disappointing: most of the flavors have already been roasted out, and bitterness is the primary flavor that remains. Buying fresh out of the roaster is always the&nbsp;best way to go if you want crisp, full flavors from your coffee, without any bitterness.</p>\r\n\r\n<h2>2. Most of It Is Pre-Ground</h2>\r\n\r\n<p>To make matters even worse, most supermarket coffees are pre-ground, which only reduces the amount of time it takes to become stale. While it takes two to three weeks for whole bean coffee to begin its rapid decline, it only takes about twenty minutes for ground coffee. Pre-ground coffee is a convenience that sacrifices a stunning amount of flavor, but most don&rsquo;t realize what they&rsquo;re missing out on.</p>\r\n\r\n<h2>3. Supermarket Brands Can Be Deceptive</h2>\r\n\r\n<p>Many supermarket coffee brands have some tricks to selling that are less-than-honest. Lack of origin transparency, misleading freshness labels, and empty language are among the ways you can tell that a supermarket brand is trying to artificially pump up their perceived quality without actually having a quality product. Take coffee freshness for example. Many coffee bags have a &ldquo;use by&rdquo; or &ldquo;best before&rdquo; date printed somewhere, giving shoppers the impression that coffee has a very long shelf-life. This practice is extremely common and misleading. Instead, look for coffee bags that announce the exact date that the coffee was roasted. This enables you to know whether coffee is fresh or not, though most quality-centric roasters don&rsquo;t let their coffee be sold after a week or so out of the roaster anyway. Learn to <a href="https://hookcoffee.com.sg/blog/how-to-read-a-coffee-packaging-like-a-pro">read the signs of coffee packaging</a> and never fall for these tricks again.</p>\r\n\r\n<h2>4. It&rsquo;s Not Specialty-Grade</h2>\r\n\r\n<p>Coffee beans aren&rsquo;t made in a factory. They&rsquo;re delicate seeds of cherries that grow on coffee shrubs. Some coffee cherries are picked too early, and the beans don&rsquo;t fully develop. Others are picked too late, grow with some sort of deformity, or simply don&rsquo;t have healthy soil to begin with. The quality of the coffee beans can be measured pre-roast with very little subjectivity by licensed Quality Graders. &nbsp;The best coffees in the world are labeled &ldquo;specialty grade&rdquo; for having very few defects and rounded flavors. The coffees you&rsquo;ll find in supermarkets are likely to be &ldquo;premium&rdquo; or &ldquo;exchange&rdquo; grade, meaning there were quite a few defects and the plants weren&rsquo;t well cared for. Roasters don&rsquo;t usually publish the grades of the coffee beans they source, but this is a truth around the globe: supermarkets buy mostly lower-grade coffee to avoid high coffee prices. You get what you pay for.</p>\r\n\r\n<h2>5. It&rsquo;s Not Worth The Sacrifice</h2>\r\n\r\n<p>There&rsquo;s no doubt that buying coffee while you pick up your eggs and milk can be convenient, but is it really worth the sacrifice? Are we so out of time that we&rsquo;re willing to sacrifice the quality of our daily brew? It&rsquo;s something we have every day. For some of us it&rsquo;s twice a day. That&rsquo;s a lot of coffee we&rsquo;re drinking - do you really want it to be of low quality and unsatisfying? The convenience factor can be eliminated when you consider the integration of online coffee services into daily life. For example, at <a href="https://hookcoffee.com.sg/">Hook Coffee</a>, we send freshly roasted coffee directly to your door whenever you need it. It doesn&rsquo;t get any more convenient than that. <strong>so we hope you are convinced by now... &nbsp;</strong> How about grabbing yourself a bag of freshly roasted coffee from Hook and taste the real difference? Sign up now and get your first bag for just&nbsp;<strong>$5.&nbsp;</strong> <strong>Use code: FRESH5</strong></p>\r\n	2017-03-12 23:18:01.077538+00	2016-10-05 09:30:14+00	hookcoffee	./skip_supermarket_coffee_hookblog.jpg	10	5-reasons-to-skip-the-supermarket-coffee
2	Hello	Welcome to The Hooked - the genderqueer sibling of Hook Coffee!\r\n\r\nWe're pretty sure you're here because you love and appreciate great coffee as much as we do. So we're here to feed you with the best &amp; freshest coffees, as well as the coolest (and digest..	<p>Welcome to The Hooked - the genderqueer sibling of <a href="http://www.hookcoffee.com.sg" target="_blank">Hook Coffee</a>! We&#39;re pretty sure you&#39;re here because you love and appreciate great coffee as much as we do. So we&#39;re here to feed you with the best &amp; freshest coffees, as well as the coolest (and digestible) coffee-related stories, ideas, and hacks. Not to mention sneak peeks behind-the-scenes at Hook and sweet &amp; savoury recipes for all you foodies out&nbsp;there! Follow our blog and leave comments to let us know what you&#39;d like to read about next! <img alt="12365890_517604805069905_6135640077132177630_o" class="alignnone size-full wp-image-2" src="https://hookcoffee.files.wordpress.com/2016/03/12365890_517604805069905_6135640077132177630_o.jpeg" style="height:1536px; width:2048px" /></p>\r\n	2017-03-12 23:18:00.719095+00	2016-03-07 07:26:03+00	hookcoffee	./hello_hookblog_.jpg	2	hello-2
29	Standard or Inverted: Which Aeropress Orientation Should You Use?	If you’re on the hunt for a great Aeropress recipe, you have likely already found that there are two ways you can position the Aeropress while brewing. Each orientation comes with its own strengths and weaknesses, so let’s sort it out.\r\n\r\nStandard Orientatio..	<p>If you&rsquo;re on the hunt for a great Aeropress recipe, you have likely already found that there are two ways you can position the Aeropress while brewing. Each orientation comes with its own strengths and weaknesses, so let&rsquo;s sort it out.</p>\r\n\r\n<h2>Standard Orientation</h2>\r\n\r\n<p>When the Aeropress was first released by Aerobie, the instructions on the box told us to brew our coffee with the filter attached and sitting face down on top of a mug. The plunger was to be left to the side until it was time to apply pressure at the end. This orientation is still common today, but it is no longer the most widely used. Here&rsquo;s why: coffee drips through the filter. Wierd, huh? These drops, sometimes a significant number of them, are bland and underextracted. We want them to balance out with more extraction, rather than exiting the brewing slurry. Every once in awhile there&rsquo;s an Aeropress competitor who uses the standard orientation in competition and scores very well, but the next option is the one we champion. https://vimeo.com/109778029</p>\r\n\r\n<h2>Inverted (Upside Down) Orientation</h2>\r\n\r\n<p>People all over the world started to realize very quickly that if they attached the plunger to the brew chamber and left the filter off, they could brew the coffee without any drainage. The problems were those underextracted coffee drips tainting the entire cup. The solution was to stop the dripping so that the entire brew could extract evenly. If you choose this method, you&rsquo;ll have to be a bit more careful. After you attach the filter, you have to actually flip the Aeropress over and set it on a mug so that you can use the plunger. We&rsquo;ve seen more than a few messes ourselves, but it doesn&rsquo;t take long to get the hang of it. The best way to do it is to set your mug of choice upside down on top of the inverted Aeropress, then flip both items together. You can see how we do it in our Aeropress video guide. https://www.youtube.com/watch?v=pzOmt5ThNto There&rsquo;s hope for the standard orientation, made evident by a few dozen competitors that have wowed judges with their coffee, but for most of us, the inverted method is the way to go. Ultimately, your coffee should taste the way you want it to taste. Why not try them both?</p>\r\n	2017-03-12 23:18:01.035127+00	2016-09-23 03:20:41+00	hookcoffee	./standard_or_invcerted_aeropress_hookblog.jpg	4	standard-or-inverted-which-aeropress-orientation-should-you-use
36	How to Overcome Procrastination Once and for All with Coffee.	While I do love the taste, I drink coffee because it makes me more productive. The two double espressos I just downed have my fingers flying over the keys, and I feel a little bit invincible. This confidence boost, is probably what encouraged me to start t..	<p>While I do love the taste, I drink coffee because it makes me more productive. The two double espressos I just downed have my fingers flying over the keys, and I feel a little bit invincible. This confidence boost, is probably what encouraged me to start this article with a massive fourth wall break. I am not alone. I would say there is an understanding among most people that coffee makes them more productive. Ever notice, that around office buildings there are higher concentrations of coffee shops. coincidence? I think not. The idea that coffee is something we drink, to get more done, is embodied into our culture. I bet that every day, you leave your building, and settle into a nice coffee shop for your break. And they are packed, aren&rsquo;t they? We all want our&nbsp;few hours of quick wit, flying fingers and unwavering focus, and don&#39;t mind spending the afternoon in the crash, I refer to as my normal personality, to get them. I am not trying to prove that coffee has or doesn&rsquo;t have these affects. If you believe in them, then that is good enough for me. What I want to do is run through strategies to get the most out of your coffee. <strong>Pavlovian Conditioning</strong> Pavlovian Conditioning Is a psychological phenomenon named by Ivan Pavlov. He did all kinds of wacky experiments back when psychology was still a bit edgy. He&nbsp;taught dogs to expect food when he rang a bell and found that even after he stopped feeding them, when&nbsp;he rang that bell, they still&nbsp;expected food. You need &nbsp;to condition yourself with coffee. If you consistently drink coffee after you finish a task,&nbsp;or do anything positive in your life,&nbsp;your brain will associate being productive with the caffeine hit. Saying to yourself, I will finish this and then I will make a coffee, is how you get a dog like obedience from your own mind. The real secret here is to build up a dependency to caffeine. The fear of withdrawal with further aid with your productivity. <strong>The Ritual</strong> Coffee, much like the planets and stars, must be experienced at certain times. Drinking your coffees at set times of the day, every day, will carve out a routine. You might be thinking; &ldquo;how do I have time for anything else if all I do all day is drink coffee?&rdquo; Taking breaks can actually make you more productive. The human brain wasn&rsquo;t made for long interrupted periods of focus. A short break to get your scheduled coffee will keep you sane. If you can&rsquo;t spare the time, install a coffee machine on your desk. Under the average desk, there is enough space for a small milk fridge, and you can work those very shaky hands all day long. As a serious alternative to a desk top coffee machine take a look a Hook Coffee&rsquo;s drip bags. These <a href="https://hookcoffee.com.sg/coffees/">drip coffee bags</a> are a simple, no mess solution, that you can take anywhere with you. Bring other people along on your coffee mission. Do you need to motivate a team, or are you and a co-worker stuck on a problem? Feed them coffee, even if they don&rsquo;t like it. Now you have more super charged minds, and a new environment can stimulate new ideas. <strong>Learning</strong> Be sure to bring a cup if you are learning a new skill. Studies have shown that as little as 200mg of coffee (about 2 cups) can prompt the brain to better process information, recognize words, and there is a noticeable improvement of short term memory. Coffee makes us into better versions of ourselves, and we should never do anything without it. <strong>Sleeping</strong> Do you know how productive you are if you don&rsquo;t sleep? Sleeping time is like half of all time. If you drink coffee in the moments before bed, it is just about impossible to get to sleep. You can now spend this time working on that thing you just have to finish. As the night drags on it will become harder to resist the urge to sleep. Continue drinking coffee at more regular increments, until you complete your task or die. <strong>Friends</strong> Coffee will help you make friends. Friends help you enjoy life and in turn make you more productive. Coffee inflates our confidence and sharpens our wit. If you want to come across as a fun loving, charming, character, you just drink at least four shots of coffee before interacting with anyone with a pulse. <strong>Hook Coffee</strong> If you have followed all of the steps in this guide, very soon, you will need new coffee. That is annoying isn&rsquo;t it? Needing new coffee. What if you never had to need coffee again? What if there was always just coffee? There can be. Hook Coffee offers a subscription that takes care of the problem once and for all. Tell us how many cups of coffee you drink, and we will send you the beans. We will continue to send them when you need them, so you always have free coffee. Hook Coffee beans are ethically sourced directly from farmers in the developing world, lovingly roasted in Singapore and sent to you within a week. &nbsp; <a href="https://hookcoffee.com.sg/coffees/"><img alt="cropped-screen-shot-2016-03-09-at-00-27-203.png" class="aligncenter size-full wp-image-41" src="https://hookcoffee.files.wordpress.com/2016/03/cropped-screen-shot-2016-03-09-at-00-27-203.png" style="height:64px; width:73px" /></a> &nbsp; &nbsp; &nbsp;</p>\r\n	2017-03-12 23:18:01.199577+00	2016-10-26 02:00:00+00	hookcoffee	./procaffeinating_hookblog.jpg	12	how-to-overcome-procrastination-once-and-for-all-with-coffee
30	Drip Coffee: The To The Point Extraction Method	&nbsp;\r\n\r\nhttps://www.youtube.com/watch?v=i9Nh3GUDlpo\r\n\r\nAlso commonly called drip brew, pour over coffee, and filtered coffee, drip coffee is a straight to the point extraction method. Using only the force of gravity and some coffee ground. This is how your g..	<p>&nbsp; https://www.youtube.com/watch?v=i9Nh3GUDlpo Also commonly called drip brew, pour over coffee, and filtered coffee, drip coffee is a straight to the point extraction method. Using only the force of gravity and some coffee ground. This is how your grandmother made her coffee. That is not to say that you can&rsquo;t make a damn good drip brew. Like other slow extraction methods, it is a very forgiving method, and the suggestions I make are not as concrete as an espresso recipe. You should use around 60 grams of coffee per 1 litres of water (What I would coin as the &#39;Golden ratio&#39; which can easily be applied to other brew methods like the Aeropress, Syphon and French Press). Now when we make drip coffee we use near boiling water at around 90 degrees. Boil the kettle first and set everything up once it is done and the slight drop in temperature will get you into the low 90s Again not that big a deal, water at 98 degrees isn&rsquo;t going to destroy your brew, but we are talking best practices here. You want a medium-fine grind for a drip extraction. Increased surface area will result in a better extraction, and larger coffee granules are not as likely to find their way into you cup. I am going to make a generalisation and say that the majority of people using drip extraction don&rsquo;t own a coffee grinder. Hey don&rsquo;t take it to heart. You are extracting coffee with water and paper, own your budget extraction. If at any stage you consider buying a French press or an espresso machine in search of a different extraction, I am here to tell you don&rsquo;t. That money would be better spent on a specialty coffee grinder than a fancy machine. <strong>Method</strong> The method will vary depending on your set up but most drip extractions are quite similar. Place the filter paper into your server and make sure there are no hole for the ground to wiggle its way through. Scoop your coffee on top of the filter and then begin pouring your boiling water over it. Pour just enough water to cover the grounds and wait for around 30seconds.&nbsp; Some people say this helps release the gasses the build-up during roasting. I tend to just do it because someone told me to once, and it can&rsquo;t hurt. The ideal extraction time is around 3 minutes. There are no real rules here. You just want to gradually administer the coffee, until you are out of water. Be sure to pour coffee over any coffee on the sides of the filter. Remove the filter and drink how you wish. Hook coffee offers subscriptions to your favourite beans. You tell us how many cups you drink in a week, and we will send you the bean to keep you going. Hook just wants to make sure that you always have a bag of the finest quality, fresh coffee for when you need it. Oh, if you are new to Hook Coffee and keen on brewing coffee using the V60, get it absolutely <strong>FREE</strong>&nbsp;when you sign up today. Use the voucher code: <strong>V60STARTER</strong>. Click on our logo to find out more. <a href="https://hookcoffee.com.sg/"><img alt="cropped-screen-shot-2016-03-09-at-00-27-203.png" class="aligncenter size-full wp-image-41" src="https://hookcoffee.files.wordpress.com/2016/03/cropped-screen-shot-2016-03-09-at-00-27-203.png" style="height:64px; width:73px" /></a> &nbsp;</p>\r\n	2017-03-12 23:18:01.040498+00	2016-11-13 06:24:08+00	hookcoffee	./beginner_guide_to_brewing_v60_hookblog_.png	4	drip-coffee-the-to-the-point-extraction-method
45	Crafting your own blends // Single Origin Goodness	Hello friends!\r\n\r\nToday we are going to be discussing some things that can add much needed variety to a coffee routine.\r\n\r\nWhen you walk into specialty cafes or observe the product that coffee roasters sell, you may notice that there are two types of coffee av..	<p>Hello friends! Today we are going to be discussing some things that can add much needed variety to a coffee routine. When you walk into specialty cafes or observe the product that coffee roasters sell, you may notice that there are two types of coffee available &ndash; <em>single origin</em>, and <em>blends</em>. We see these options on brewing menus. Espresso being the most notorious form of coffee that utilizes the inherent variety attributed to the blend. You will see these two coffee options everywhere. If you aren&rsquo;t familiar with the terms, you&rsquo;ve come to the right place! &nbsp;</p>\r\n\r\n<h2><strong>Single Origin</strong></h2>\r\n\r\n<p>[note: understanding single origin coffees is vital to crafting your own blend] Think of single origins as an essence of flavor from a specific coffee growing region. Single origin coffees come from one region and usually one farm. The &ldquo;Guatemala&rdquo; labeled on the bag of a single origin coffee means that the coffee is from Guatemala and ONLY from a particular region of Guatemala. As you keep growing in your coffee journey, single origin coffees can be an effective palate training tool. It <em>is</em> <em>actually</em> possible to determine the region a coffee was grown in based upon its taste. When one embarks upon the specialty coffee journey, they go through tasting phases. At first, most can only taste chocolate or &ldquo;nuttiness&rdquo; as a flavor note in their coffee. As time goes on we start tasting other flavors like apple, grape, and certain spices you are used to tasting in your cooking. Eventually you are able to taste complex flavors and determine aromas; this is when people get diagnosed with coffee obsession. If you want to taste all the colors of the rainbow, make sure to drink single origins regularly. You will learn the ins-and-outs of coffee, and you will come to appreciate the farmers that make all of this possible for us. &nbsp;</p>\r\n\r\n<h2><strong>Blends</strong></h2>\r\n\r\n<p><strong>&nbsp;</strong>A well concocted blend is simply beautiful. A blend is a mix of single origin coffees. Blending is a technique used to add stability as well as complex flavors. Roasteries and shops blend coffees to develop flavor profiles that are both user friendly (e.g. something chocolatey) or unique (e.g. bergamot, apple, and star anise notes). Many shops even adhere to the use of a daily coffee blend. For instance, our Neverneverland blend is something that is geared for the coffee greenhorn as well as coffee guru. We blended a Costa Rica and a Brazil to create a mild chocolatey cup that pairs well with snacks and other tapas. The variety blends bring to a cup are astonishing. One can combine a juicy pear and peanut like Ethiopian with a peachy Papa New Guinea to create a mild fruit explosion in a cup. Savory umami bursting coffee can be blended with a mild and dry coffee to create a wine-like shot of espresso. The possibilities are endless. Boredom is vanquished. Sure, understanding your single origin roots is important. Knowing what flavors you are mixing together helps with the coffee alchemy process. But don&rsquo;t feel intimidated if you can&rsquo;t taste everything yet. There&rsquo;s still hope. Blending your single origin coffees at home is very, very doable &ndash; even for the novice. &nbsp;</p>\r\n\r\n<h2><strong>Crafting your blend</strong></h2>\r\n\r\n<p>Alright. Dig some single origin coffees out of your stash. It&rsquo;s time to blend.</p>\r\n\r\n<blockquote>-Try a 50/50 blend for your first go (a 50/50 blend is just equal parts of two coffees). Make sure you are familiar with the individual flavor profile of each coffee. -Measure out how much coffee you need for one cup. Divide the coffee mass needed by two, and add each coffee (if 25g is needed used 12.5g of both coffees into grinder). -Prepare coffee and taste.</blockquote>\r\n\r\n<p>Once you find a blend you like, you can craft larger quantities or experiment further. [If you are crafting larger blends, make sure to mix up the beans thoroughly before grinding] If you get stuck, check out our <a href="https://hookcoffee.com.sg/coffees/">coffees page</a>. You can use this page for blend ideas and references. We list what coffees we use in the blend description. The Specu-Lose Your Mind blend features coffees from Brazil, Colombia, and Ethiopia. Combining these coffees in tandem give us flavor notes of Belgian Biscuits and Caramel. These profiles are the result of an ample amount of experimentation. As we&rsquo;ve said before, good coffee takes time. You can do it. Coffee shouldn&rsquo;t get old. It is a drink and way of life that brings us together. Crafting your own blends can spice up the coffee experience, and it helps us understand the profiles of individual coffees. &nbsp; Keep experimenting, and Happy Brewing! The Hook Coffee team &nbsp; &nbsp; &nbsp;</p>\r\n	2017-03-12 23:18:01.255704+00	2017-02-11 03:00:28+00	hookcoffee	./blends_hookblog_.jpg	1	crafting-your-own-blends-single-origin-goodness
49	A Brand Refresh 	The Hook office is bustling with excitement. We recently revamped some things - quite a few things. Our web interface and branding has been redesigned.\r\n\r\nWe have more coffees for you all to try, new shiny gear is waiting to be shipped out and tampered with, and fresh brew tips and guides are being developed as we speak.\r\n\r\nJust in case you missed out on our email which we are super excited to share with you, here is what's new! 	<p>Hello one and all!</p>\r\n\r\n<p>The Hook office is bustling with excitement. We recently revamped some things - quite a few things. Our web interface and branding has been redesigned.</p>\r\n\r\n<p>We have more coffees for you all to try, new shiny gear is waiting to be shipped out and tampered with, and fresh brew tips and guides are being developed as we speak.</p>\r\n\r\n<p>Just in case you missed out on our email which we are super excited to share with you, here is what&#39;s new!&nbsp;</p>\r\n\r\n<p><img alt="big_edm_block 5.png" src="https://hookcoffee.files.wordpress.com/2017/03/big_edm_block-51.png?w=706" style="height:331px; width:300px" /><a href="https://hookcoffee.com.sg/coffees/shop-gift-set"><img alt="big_edm_block 3.png" src="https://hookcoffee.files.wordpress.com/2017/03/big_edm_block-3.png?w=860" style="height:451px; width:300px" /></a><a href="https://hookcoffee.com.sg/gears/essentials"><img alt="big_edm_block 2.png" src="https://hookcoffee.files.wordpress.com/2017/03/big_edm_block-2.png?w=662" style="height:410px; width:300px" /></a></p>\r\n\r\n<p><strong>We really can&#39;t contain ourselves, so we&#39;re writing a post about it.</strong></p>\r\n\r\n<p>Before we go on, know that all design and branding changes are meant to simplify the process in which our community goes about discovering coffee. Hook yearns to foster an environment that condones exploration and knowledge. By implementing an interface makeover, we are hoping to bring more folks into the specialty coffee fold.</p>\r\n\r\n<p>Coffee shouldn&#39;t be pretentious and confusing. It should be a sea of exploration.</p>\r\n\r\n<p><strong>The Fresh Logo</strong></p>\r\n\r\n<p><img alt="Hook Coffee_FB.png" src="https://hookcoffee.files.wordpress.com/2017/03/hook-coffee_fb.png" style="height:44px; width:50px" /></p>\r\n\r\n<p>Our sought to align our branding with our community minded vision.</p>\r\n\r\n<p>Hook believes that connections make coffee possible. Without connections, community, and hospitality, quality coffee cannot exist. The nature of these imperative connections is what our logo conveys.</p>\r\n\r\n<p>The two rings represent the connections between farmers, suppliers, and our coffee drinking community. All of these connections bond together and form an unbreakable chain. The seed to cup process traverses through this chain, and with each step in the process, quality coffee is achieved.</p>\r\n\r\n<p><strong>Connections with Farmers</strong></p>\r\n\r\n<p>Coffee farmers are the most important conduit in the seed to cup process. Without the care and knowledge that farmers use to cultivate the coffee that we drink, good coffee couldn&#39;t happen.</p>\r\n\r\n<p>We operate in a direct trade model as much as possible. This means that we work closely with the farmers that provide us with coffee. This direct trade relationship ensures that farmers are financially compensated for their craft. Instead of abiding in a blanket price model for green coffee, we pay farmers what their coffee is worth.</p>\r\n\r\n<p>By cherishing the lives of farmers, the lives of others, we become a part of something bigger.</p>\r\n\r\n<p><strong>Connections with Suppliers</strong></p>\r\n\r\n<p>Suppliers are the next step in the seed to cup chain. Hook works with suppliers to efficiently obtain the delectable coffee that farmers grow. Coffee must be shipped to Singapore, and it&#39;s vital that the shipping methods preserve coffee freshness. Suppliers help us do this.</p>\r\n\r\n<p><strong>Connections to you!</strong></p>\r\n\r\n<p>Once the green coffee arrives at Hook HQ, we roast it and send it out to the world. Finally, the chain ends with you getting fresh bags of coffee in the mail.</p>\r\n\r\n<p>From here, we can educate on brew techniques and coffee science. As a community, we can grow and flourish!</p>\r\n\r\n<p>You see, we are all a vital part in this collective coffee chain. All steps come together to form a process. This is what the coffee community is about.</p>\r\n\r\n<p><strong>Color scheme</strong></p>\r\n\r\n<p>Hook has always sworn by quality and freshness. Our brand colors now feature a splash of aqua green as another representation of this promise. We will continue to do what we do and give you the best!</p>\r\n\r\n<p>Regardless of external forces or how big we grow, we will offer fresh products and services. Always.</p>\r\n\r\n<p><strong>Groovy Packaging</strong></p>\r\n\r\n<p>If you&#39;ve treated yourself to a bag of Hook coffee in the past, you&#39;ll notice that we changed up our coffee bags</p>\r\n\r\n<p>We did this for a couple of reasons.</p>\r\n\r\n<p><em>Firstly</em>, we now use a thicker kraft envelope that will further protect your coffee as it treks through the dangerous abyss of the postal realm. It&#39;s recyclable and durable - the perfect combo for an effective coffee container.</p>\r\n\r\n<p><em>Secondly</em>, we wanted to have some fun. Our designers went to town on the bag graphics. We think it&#39;s pretty cool</p>\r\n\r\n<p><img alt="IMG_5163.jpg" src="/media/blog/2017/03/19/hook-coffee-new-envelope003.jpeg" style="height:225px; width:300px" /></p>\r\n\r\n<p>Love our new mailing envelope? All regular subscription orders will be shipped using this envelope from today onwards!</p>\r\n\r\n<p>All in all, Hook will continue serving the coffee community. Our branding facelift is a promise that we will strive to be intentional and hospitable to all. We are thankful for the coffee lovers who choose to be a part of our vision.</p>\r\n\r\n<p>Let&#39;s make the world better and enjoy coffee whenever we can!</p>\r\n\r\n<p>Happy brewing!</p>\r\n\r\n<p>The Hook Coffee Team</p>\r\n\r\n<p><img alt="Hook Coffee_FB.png" src="https://hookcoffee.files.wordpress.com/2017/03/hook-coffee_fb.png" style="height:44px; width:50px" /></p>\r\n	2017-03-19 05:39:22.787813+00	2017-03-19 05:36:52+00	Hook Coffee	./Hook_Coffee_New_Envelope.003.jpeg	9	a-brand-refresh
50	Why We Started Hook Coffee? 	Coffee is more than a party in your mouth. It is more than caffeine. It is more than dirty water.\r\n\r\nMany of the best questions in life are the simple ones. Before we launched Hook, we asked, "why do we love coffee?"\r\n\r\nWhat was it about coffee that we loved? Many things came to mind.\r\n\r\nOnce we compiled the exorbitant list of things about coffee that make us smile, we chose to truly focus on a few: Community, quality, and enjoyment.	<p>Coffee is more than a party in your mouth. It is more than caffeine. It is more than dirty water.</p>\r\n\r\n<p>Many of the best questions in life are the simple ones. Before we launched Hook, we asked, &quot;why do we love coffee?&quot;</p>\r\n\r\n<p>What was it about coffee that we loved? Many things came to mind.</p>\r\n\r\n<p>Once we compiled the exorbitant list of things about coffee that make us smile, we chose to truly focus on a few: Community, quality, and enjoyment.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Community</strong></h2>\r\n\r\n<p>As intentional purveyors of the coffee craft, we at Hook Coffee focus on sustainability and hospitality. We believe that the best coffee isn&#39;t about just flavor and enjoyment. Coffee is one of the world&#39;s most traded commodities, and it needs to be dealt with responsibly. Sure, we publish articles on coffee quality and offer brew guides, but we also work within the coffee community to promote sustainability and well-being.</p>\r\n\r\n<p>Growing and processing specialty coffee is an art form. It takes years, and even generations to cultivate particular strands of coffee varietals that yield coffee acceptable to specialty standards.</p>\r\n\r\n<p>Hook sources coffee beans from farms all over the developing world, and we only source the finest sustainably grown Arabica coffees.</p>\r\n\r\n<p>Coffee farmers have a unique skill set and produce a luxury good. Unfortunately, many of these farmers reap very little of the profits they deserve from their craft.</p>\r\n\r\n<p>To combat unfair wages and to promote carefully grown coffee, we chose to adopt a direct trade model.</p>\r\n\r\n<p>Direct Trade means that we directly work with the farmers that grow the coffee we roast daily. In other words, we develop relationships with them. With direct trade, farmers earn 10-25% more. Because the farmers are paid well, they can support their craft &ndash; this means that the coffee tastes better, the children of the farmers can go to school, and their overall standard of living is improved. We absolutely value the farmers who devote their lives to the quality and sustainability of the coffee species.</p>\r\n\r\n<p>We also value you guys! The incredible people that support us aren&#39;t just customers... you all are our friends and teammates. Together, we can promote tasty, ethical coffee practices. Community is about different types of people coming together to do something worthwhile. We truly believe that without solid community, good coffee isn&#39;t possible.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Quality</strong></h2>\r\n\r\n<p>Part of Hook&rsquo;s mission is to educate on all things coffee related; we focus not only on sustainability / ethicality, but also on brew techniques, and the applicable science behind the brewing process. We wish to share our knowledge with you. Coffee isn&#39;t supposed to be a trade secret.</p>\r\n\r\n<p>Many of our posts concern brewing techniques and theory.</p>\r\n\r\n<p>We write these so that even the novice can enjoy and understand what is happening with their coffee. At one point or another, we all started at the beginning. At the beginning of the craft coffee journey, extraction theory and brewing technique, seemed like rocket science, and brewing a well-balanced cup seemed all but impossible.</p>\r\n\r\n<p>Starting out in craft coffee is hard.</p>\r\n\r\n<p>And Hook believes that no one should get left behind.</p>\r\n\r\n<p>Quality is not just how good something tastes. It&#39;s not about the fancy, minimalist coffee gear. It&#39;s not about the hipster coffee lifestyle. It&#39;s not even about the wacky science behind it all.</p>\r\n\r\n<p>Quality is focused and educated intentionality. It can take ten minutes to brew a cup of coffee in the morning with certain gear. Why do we do this?</p>\r\n\r\n<p>Sure, the taste is good, but really it&#39;s about care. It&#39;s about caring enough to utilize every bit of the coffee that is grown meticulously by the farmers, and roasted intentionally by roasters. Making good coffee is about respecting the potential of each coffee bean, not wasting precious resources like water, and being aware of farmers&#39; efforts.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Enjoyment</strong></h2>\r\n\r\n<p>We are about to write a post on how not to be a coffee snob. Snobbery isn&#39;t something we&#39;re fond of.</p>\r\n\r\n<p>Snobbery can be a humorous subject. People call us coffee snobs because we enjoy good coffee. Your friends may call you a snob for politely offering them a pour over.</p>\r\n\r\n<p>We would argue that promoting ethical coffee practices and valuing others isn&#39;t snobbery. We offer coffee education posts because we want everyone involved. We try our best not to exclude others and bring people in. That&#39;s what community is all about.</p>\r\n\r\n<p>Once again, we thank you coffee people out there. We couldn&#39;t do this without you!</p>\r\n\r\n<p>Before we sign off, here&#39;s a Chemex recipe we&#39;ve been digging! (we will be a doing a video and stocking chemex on our products list soon, so stay tune)</p>\r\n\r\n<blockquote>\r\n<p>Coffee mass - 25g</p>\r\n\r\n<p>Grind size - in between Medium and Coarse (23 - 26 on Baratza Virtuoso)</p>\r\n\r\n<p>Water Volume - 400 ml</p>\r\n\r\n<p>Temperature - 98.3 degrees Celsius</p>\r\n\r\n<p>Ratio - 16:1</p>\r\n\r\n<p>Brew time - apprx. 3:00 minutes</p>\r\n\r\n<p>Bloom - 50g</p>\r\n\r\n<p>Directions - After the bloom, pour from middle and loopty-loop to the outside. Keep this up for 175ml or so (conservatively, just at a nice slow pace). Then get more liberal and speed up velocity of the pour, making sure to agitate thoroughly (medium velocity, making sure to pour somewhat vigorously when rotating to the outside rim). Don&#39;t pour directly on the sides for this recipe. Pour directly in the middle for the last 30ml. Stir 5 cycles with warm spoon after 400ml.</p>\r\n</blockquote>\r\n\r\n<p>Are you ready to get Hooked yet?</p>\r\n\r\n<p>Just in case you haven&#39;t got your first bag of coffee, here is a&nbsp;<strong>$10 voucher*</strong>&nbsp;to weclome you on your amazing journey towards #makingcoffeebetter when you sign up today.&nbsp;</p>\r\n\r\n<p>Use code: <strong>TAKE10</strong></p>\r\n\r\n<p>Sign up&nbsp;<strong><a href="https://hookcoffee.com.sg/getstarted/" target="_blank">here</a></strong>!</p>\r\n\r\n<p>Happy Brewing!</p>\r\n\r\n<p>Ernest from Hook Coffee&nbsp;</p>\r\n\r\n<p>*Voucher code only applicable for your first bag of coffee on a subscription. Voucher cannot be used in conjunction with any other offers.&nbsp;</p>\r\n	2017-03-23 15:30:10.908349+00	2017-03-23 15:29:17+00	Ernest 	./IMG_5064.JPG	13	why-we-started-hook-coffee
16	Finding Purpose in Coffee	Analysing and stereotyping millennials seems to be the trend now, and many times they were unfair generalisations. But there's one thing they were right about - that we millennials seek purpose in the things we do.\r\n\r\nOur purpose is simple. To make coffee be..	<p>Analysing and stereotyping millennials seems to be the trend now, and many times they were unfair generalisations. But there&#39;s one thing they were right about - that we millennials seek purpose in the things we do. Our purpose is simple. To make coffee better (#makecoffeebetter), not only for our customers but our farmers too. This means that our customers get ethical and quality coffees, while our farmers improve production methods while enjoying&nbsp;better working conditions and more generally, better standards of living. Last week, we told you <a href="https://hookcoffee.com.sg/blog/responsible-drinking-the-low-down-on-direct-trade-in-the-coffee-industry">why we support Direct Trade</a>, but we haven&#39;t said how. Read on to find out!</p>\r\n\r\n<hr />\r\n<h1>Part 2</h1>\r\n\r\n<h3>&nbsp;</h3>\r\n\r\n<h3>Sourcing and Buying</h3>\r\n\r\n<p>Relationships are crucial to sourcing high-quality coffee. Our approach to sourcing starts with the coffee itself. We seek out the best quality beans, and we expect to pay premium prices in return.&nbsp;When we find a coffee we like, we work to build a lasting relationship with that producer in order to establish a reliable supply chain, away from the unpredictability of the commodity market. We pay premium prices, and we treat our producers as long-term business partners,&nbsp;regardless of how large or small a farm. As newcomers to the coffee industry, Hook has sought mentorship from experts from the Specialty Coffee Association of Europe (SCAE). (If you&#39;re wondering why SCAE, it&#39;s because one of our two founders, Ernest, &quot;studied&quot; at the London School of Coffee after graduating from the London School of Economics!). We&#39;ve&nbsp;also partnered a UK-based merchant that has been doing Direct Trade for over 20 years. Working closely with these organisations&nbsp;that go directly to the farms, we buy coffees from the world&#39;s best, and &nbsp;traverse seas and mountains with our partners, to visit our growers, their farms, and their communities. (We&#39;ll be sharing about our trip to Java in Part 3!).&nbsp;We even send roasted beans back to the farms, just so the growers get to see the final product of their labour. :) <em>(To read about the origins, farms and growers who have made our extraordinary coffees possible, go ahead and browse&nbsp;<a href="http://www.hookcoffee.com.sg/coffees/">our coffees</a>&nbsp;and click on &ldquo;More Info&rdquo;.)</em> <img alt="cafe.lukas.002.jpg" class="alignnone size-full wp-image-1693" src="https://hookcoffee.files.wordpress.com/2016/06/cafe-lukas-002.jpg" style="height:2832px; width:4256px" /> Another perk of Direct Trade is to cut out the unnecessary middlemen and our ability to &quot;negotiate&quot; prices. Our policy in negotiating prices is to adequately compensate our producers for the production of specialty grade coffee with prices above their cost of production and far above the internal or external commodity-grade price. Typically the farmers are paid 30-150% more than the cost of production and 10-25%&nbsp;of the final retail value - invariably higher than the Fair Trade price. (Again, refer to&nbsp;<a href="https://hookcoffee.com.sg/blog/responsible-drinking-the-low-down-on-direct-trade-in-the-coffee-industry">our last post</a>&nbsp;to understand why this is so.) The premium prices encourage farmers to reinvest in the quality of their coffees, a safe and ethical working climate, and environmentally sustainable coffee production. More importantly, a higher income means that farmers can improve their living standards, send their children to school, afford quality healthcare,&nbsp;and eventually break the chains of the poverty cycle.</p>\r\n\r\n<h3>Quality Control</h3>\r\n\r\n<p>When it comes to the perfect cuppa, our shared love for coffee means that quality is as important to us as it is to you. (What&#39;s the point of delivering the freshest coffees, when the beans aren&#39;t the best right?) And through Direct Trade, we&#39;re able to have greater quality control and ensure the best&nbsp;coffee is delivered to you. We communicate what we value in a finished cup,&nbsp;and growers can pick out batches that they think we&#39;ll like based on the particular patch of land they were grown on,&nbsp;the degree of ripeness at picking time, the amount of washing/ drying/ fermentation and so on. Our partners travel to the farms to study the production and processing of the coffees, and if weren&#39;t able to join in the fun, they present detailed reports to us with beans to sample too. <img alt="zombo-coffee-farmers" class="alignnone wp-image-1187" src="https://hookcoffee.files.wordpress.com/2016/05/zombo-coffee-farmers.jpg" style="height:454px; width:672px" /> Cupping (coffee lingo for the formal, multistep tasting process used to evaluate quality) is an important step in quality control. Cupping helps growers understand what buyers are looking for and also helps buyers like us select the cream of the <em>crop.</em>&nbsp;In fact, our partners hire certified cuppers, or what the coffee world calls &quot;Q Graders&quot;, that can verify the quality of a bean with just one slurp. We&#39;d like to think we have pretty discerning taste buds too, but Q Graders are in a league of their own. It takes years of experience and training to be a certified Q Grader, which is why we&#39;re grateful to SCAE, our partners, and our friends in the coffee industry for guiding us as we learn the ropes and pick out the best coffees for you. Other ways to&nbsp;determine the quality of a bean is its size and whether it has defects. However, the&nbsp;size of the bean also depends very much on the region, for example, beans from East Africa are much bigger than beans from South America, and is therefore not a very accurate measure of quality. Bean defects like &quot;insect bites&quot; (ew, we know...) are pretty apparent, and help in the selection process. https://www.youtube.com/watch?v=l2hyqEAYleE &nbsp; <strong><em>Sustainability</em>&nbsp;of Direct Trade</strong> Though our&nbsp;<em>purpose to make coffee better</em>&nbsp;drives our commitment to Direct Trade, a&nbsp;purely romanticised view and altruistic approach usually has a short lifespan. Ultimately, there has to be a balance of social, environmental and economic objectives. The Direct Trade model is inherently sustainable because it incentivises all parties involved to practice sustainability and focus quality, while reinforcing lasting and mutually beneficial relationships.</p>\r\n\r\n<hr />\r\n<p>Apart from Direct Trade,&nbsp;there&#39;s so much more that we can and hope to do for coffee-producing communities everywhere. If you know us, you&#39;ll know that we dream of introducing programmes and infrastructure aimed at directly helping communities to improving production and quality of life. Such programmes can come in the form of education and scholarships, or the design and building of water irrigation systems which double up as water-saving mechanisms that would bring water to an entire village. We&#39;re all about effecting permanent changes in an industry that needs it and&nbsp;if you&#39;re with us, you know <a href="http://www.hookcoffee.com.sg">where</a> and how to show your support. At home, the social injustices, though less drastic and apparent, shouldn&#39;t be overlooked too. We want to make specialty coffee accessible in every sense of the word &mdash; we want specialty coffee to be something that is inclusive,&nbsp;fun &amp; relatable, an affordable luxury for everyone to appreciate, and not let great coffee be yet another thing that reinforces the social divide between different classes of society. If you&#39;ve read till here, you&#39;re probably a real coffee lover with a warm soul and a heart of gold, and we think you&#39;ll like our upcoming post on our Origin Trip in Indonesia &mdash; so stay tuned! &nbsp; &nbsp;</p>\r\n	2017-03-12 23:18:00.815354+00	2016-06-07 14:00:27+00	hookcoffee	./finding_purpose_in_coffee_hookblog.jpg	5	finding-purpose-in-coffee
51	Tips to build your own mobile coffee set up! 	To the coffee eccentrics, nerds, geeks, and obsessives,\r\n\r\nIf you revel daily at your elegant coffee setup, or if you spend your free time looking for the next addition to your coffee arsenal, chances are you’re a coffee geek or something similar. Mind you, this isn’t a bad thing. We like coffee geeks.\r\n\r\nIf you aren’t too concerned with the realm of coffee, don’t worry. We like you too.\r\n\r\nThis blog post is for everyone; especially everyone who likes good coffee everywhere they go.	<p>To the coffee eccentrics, nerds, geeks, and obsessives,</p>\r\n\r\n<p>If you revel daily at your elegant coffee setup, or if you spend your free time looking for the next addition to your coffee arsenal, chances are you&rsquo;re a coffee geek or something similar. Mind you, this isn&rsquo;t a bad thing. We like coffee geeks.</p>\r\n\r\n<p>If you aren&rsquo;t too concerned with the realm of coffee, don&rsquo;t worry. We like you too.</p>\r\n\r\n<p>This blog post is for everyone; especially everyone who likes good coffee&nbsp;<em>everywhere&nbsp;</em>they go.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Convenience vs Quality</strong></h2>\r\n\r\n<p>For those who own a hodgepodge of brew methods and coffee trinkets, coffee is more of an experience. Coffee is meant to taste&nbsp;<em>good&nbsp;</em>regardless of time spent making it. Twenty minutes spent on the craft are twenty minutes well spent.</p>\r\n\r\n<p>For others, good coffee is great, but time is a factor. Quick decent coffee is better than a longwinded coffee experience.</p>\r\n\r\n<p>We at Hook attempt to embody the best of both worlds&hellip; yet we do lean a little toward the quality side of things. Good coffee is a process. We realize that time is valuable, so as coffee nerds, we try to optimize the quality and time variables of the coffee preparation experience.</p>\r\n\r\n<p>When optimizing a mobile coffee setup, it is important to understand how we can make the best coffee with as little as possible. One must have a set of coffee quality standards and meet those standards in a minimalist fashion. Think of it as a puzzle.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>The importance of mobile coffee</strong></h2>\r\n\r\n<p>As said earlier, the coffee nerd prefers good coffee&nbsp;<em>everywhere.&nbsp;</em>This means coffee at work, on the road, or even when you&rsquo;re on vacation.</p>\r\n\r\n<p>It&rsquo;s always useful to sift through your gear stash and figure out options.</p>\r\n\r\n<ol>\r\n\t<li><em>Keep fragility in mind</em>. This of course depends on where you will be taking your mobile coffee setup. You most likely will not want to take a siphon on the road or on vacation (think worst case scenario... exploding glass and fire seems like a nightmare). Try to incorporate as little glass as you can.</li>\r\n</ol>\r\n\r\n<ol start="2">\r\n\t<li><em>Think hard on whether or not gadgets are needed</em>. Alright, let&#39;s agree that coffee tech is cool. Thermometers, refractometers, humidifiers, etc.. All of these things are cool. Gadgets do some serious work in the kitchen at home, but in a mobile setup, they usually get in the way. Choose wisely.</li>\r\n</ol>\r\n\r\n<ol start="3">\r\n\t<li><em>Do you need a hot water kettle?&nbsp;</em>This question is of much import. Kettles are bulky and cumbersome. If for some reason you don&#39;t need to incorporate a kettle into the mobile coffee unit, don&#39;t. This applies if you will have kettle access at your destination. You&#39;ll thank us later.</li>\r\n</ol>\r\n\r\n<ol start="4">\r\n\t<li><em>Hand grinder.&nbsp;</em>Get one.</li>\r\n</ol>\r\n\r\n<ol start="5">\r\n\t<li><em>Pre-weigh your coffee.&nbsp;</em>If your trip is short and sweet, find some small tins and pre-weigh your coffee. A measuring scale takes up a heavy portion of available space. If you don&#39;t need one, don&#39;t bring one.</li>\r\n</ol>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Hook&#39;s Foolproof Drip Coffee Bags!</strong></h2>\r\n\r\n<p>Before we go any further, we understand that this can be A LOT. Not everyone can buy new things or build a coffee arsenal. This is why Hook developed a drip coffee bag!</p>\r\n\r\n<p>If you want a foolproof process that works every time,&nbsp;<a href="https://hookcoffee.com.sg/gears/essentials" target="_blank">try our drip coffee bags out!</a>&nbsp;There&#39;s no need for dialing in or practice. Just open, pour, and enjoy!</p>\r\n\r\n<p>Not everyone likes to experiment and delve into coffee science. Many just enjoy a good cup of coffee whenever they want it; our drip coffee bags are for you.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>For the coffee nerds out there, let&#39;s end with some mobile combo recommendations:</p>\r\n\r\n<blockquote>\r\n<p><strong>Setup 1 (the adventurer)</strong></p>\r\n\r\n<p>Kettle</p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/coffees/">Coffee</a></p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id16">Aeropress</a></p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id18">Hand grinder</a></p>\r\n\r\n<p>Travel mug</p>\r\n\r\n<p>Notes: You&#39;ll miss out on some coffee quality control, but you&#39;ll be able to drink coffee just about anywhere.</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<blockquote>\r\n<p><strong>Setup 2 (the guru)</strong></p>\r\n\r\n<p>Kettle</p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id17">Scale</a></p>\r\n\r\n<p>Coffee</p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id16">Aeropress</a></p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id2">Torch Dripper</a></p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id17">Hand Grinder</a></p>\r\n\r\n<p>Mug</p>\r\n\r\n<p>Notes: You have choice and proper methods to retain consistency. The Bee House mechanism is fragile, but as long as you wrap it in a towel or shirt, you should be alright.</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<blockquote>\r\n<p><strong>Setup 3 (the hopeless)</strong></p>\r\n\r\n<p>Kettle</p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id17">Scale</a></p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/coffees/">Coffee</a></p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id16">Aeropress</a></p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id27">Clever dripper&nbsp;</a></p>\r\n\r\n<p>v60</p>\r\n\r\n<p>chemex</p>\r\n\r\n<p><a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id25">Electric Grinder</a></p>\r\n\r\n<p><a href="https://www.kruveinc.com">Grind sifter</a></p>\r\n\r\n<p>TDS meter</p>\r\n\r\n<p>Flashlight</p>\r\n\r\n<p>Plush pillows</p>\r\n\r\n<p>Scissors</p>\r\n\r\n<p>Granola Bar</p>\r\n\r\n<p>Mug(s)</p>\r\n\r\n<p>Notes: I think you get the point.</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>We hope that this post gave you some ideas as to how you can optimize your mobile coffee experience. Not having coffee can be tough for some. We live in a world where coffee shops exist on every corner - yet, good coffee can be out of reach. Take control and bring good coffee with you!</p>\r\n\r\n<p>Happy Brewing!</p>\r\n\r\n<p>The Hook Coffee Team</p>\r\n	2017-03-27 14:26:22.439492+00	2017-03-27 14:24:40+00	Hook Coffee 	./IMG_5258.JPG	6	tips-to-build-your-own-mobile-coffee-set-up
52	How clever is the clever dripper?	Imagine waking up in the morning. The day barely started, and you're already fighting the onslaught of menial tasks that make up the sunrise routine. After half an hour of preparation, you realize that your coffee needs have not been quenched. There's still so much to do, and the thought of brewing up a pour over is bitter sweet. You don't have time to spend ten minutes making a coffee elixir...but then you remember that a clever dripper sits triumphantly amongst your deluge of coffee gear.\r\n	<p>Imagine waking up in the morning. The day barely started, and you&#39;re already fighting the onslaught of menial tasks that make up the sunrise routine. After half an hour of preparation, you realize that your coffee needs have not been quenched. There&#39;s still so much to do, and the thought of brewing up a pour over is bitter sweet. You don&#39;t have time to spend ten minutes making a coffee elixir...but then you remember that a clever dripper sits triumphantly amongst your deluge of coffee gear.</p>\r\n\r\n<p>Your morning can rest easy</p>\r\n\r\n<p>It comes as no surprise that the Clever Dripper is an industry favorite. The simple brew method basks in the aura of simplicity and utility.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>What is it?</strong></h3>\r\n\r\n<p>The Clever is an Immersion method.</p>\r\n\r\n<p>[<em>Immersion</em>- a method of brewing that incorporates the use of submersion. The ground coffee mass is submersed in water for a short period of time and then filtered and decanted. Immersion brew methods typically contain more brew colloids - coffee particles that are responsible for a thick mouthfeel - than pour over methods. Unlike popular belief, Immersion brew methods are not used to concoct &quot;darker brews.&quot; Immersion methods capture the body of the coffee.]</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>Tech aspects</strong></h3>\r\n\r\n<p>The Clever Dripper is an 18oz conical manual immersion device. It comes with a coaster and lid. To decant brewed coffee, simply set the Clever on a mug or carafe - this will trigger the release valve. There is a rubber stopper at the bottom of the Clever. The release valve can be engaged by something with the diameter of a coffee cup.</p>\r\n\r\n<p>Cleaning is quick and easy, and the filters used are readily available.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>The conical plastic brewing device is a favorite for a few reasons:</strong></h3>\r\n\r\n<p>1) Durability</p>\r\n\r\n<p>If you drop your Clever, it probably won&#39;t break. Don&#39;t be fooled by the &quot;plastic&quot; descriptor. The reinforced plastic is reliable, and the conical shape prevents much damage to incur if dropped.</p>\r\n\r\n<p>2) Simplicity</p>\r\n\r\n<p>As stated before, the Clever is a simple, no-games brew device. Here&#39;s what the process looks like:</p>\r\n\r\n<blockquote>\r\n<p>- Insert Melitta #4 filter. These filters are readily available at many grocery stores (depending on where you live), so if you need filters in a pinch, don&#39;t sweat it.</p>\r\n\r\n<p>- Weigh and grind coffee, heat water, and pre-wet filter.</p>\r\n\r\n<p>- Pour water over the ground coffee. Let the brew sit for the allotted period of time (according to your recipe). When time is up, set the Clever on a decanter or mug; triggering the release valve.</p>\r\n\r\n<p>- Gorgeous golden coffee shall pour forth from thine Clever and into thine cup!</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>Mobile</strong></h3>\r\n\r\n<p>Many of us embark upon travel frequently. It&#39;s a way of life that can be inconvenient, and we must compromise some of our preferences.</p>\r\n\r\n<p>Whether you&#39;re away from home because of work or leisure, you don&#39;t have to compromise good coffee - not all the time at least.</p>\r\n\r\n<p>Our favorite travel method is the Aeropress, but the Clever Dripper is our second pick. Both the Aeropress and the Clever are low maintenance, making them ideal for business trips and vacations. Your Clever Dripper will be a tad bulky in your suitcase, but if you have a little extra room you should be fine.</p>\r\n\r\n<p>All you need to brew with Clever is a grinder, hot water, and filters. Unlike pour over methods, the Clever Dripper has no need for gooseneck kettle pouring accuracy or extra decanters. If you can find a hot water source, you can brew!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>At Home / Versatility</strong></h3>\r\n\r\n<p>So you may be thinking, &quot;I don&#39;t want a piece of plastic amongst my shiny sleek coffee gear.&quot;</p>\r\n\r\n<p>Well, you&#39;d be missing out.</p>\r\n\r\n<p>The aesthetic of the Clever is simple, and it looks good. It can blend in with any coffee arsenal. Many coffee enthusiasts are Clever Dripper patrons, and for good reason.</p>\r\n\r\n<p>The device is simple, but there are many ways to manipulate the brew process. You could use a Chemex filter instead of the standard Melitta #4 to achieve a cleaner cup with less body and more clarity. You could easily brew at a 22:1 ratio, experimenting with tea-like consistencies in coffee. You could even use the Clever to filter out homemade cold brew!</p>\r\n\r\n<p>Its versatility is a tool any coffee lover&nbsp;should consider.</p>\r\n\r\n<p>Here is a video (credits to Elemental coffee) on how it works!&nbsp;<a href="https://www.youtube.com/watch?v=Ki6sNwjqwio">https://www.youtube.com/watch?v=Ki6sNwjqwio</a></p>\r\n\r\n<p>Best part is, we have they stocked under our gears section. If you are tempted to get yourself a new toy after reading this post, here is the <a href="https://hookcoffee.com.sg/gears/essentials#ess__modal-id27">direct link</a> to get your hands on it! &nbsp;</p>\r\n\r\n<p>Happy Brewing everyone!</p>\r\n\r\n<p>The Hook Coffee Team</p>\r\n\r\n<p>&nbsp;</p>\r\n	2017-04-05 13:14:56.488349+00	2017-04-05 13:11:53+00	Hook Coffee	./IMG_5455.JPG	4	how-clever-is-the-clever-dripper
53	Behind the Brew #1	Welcome to our first episode of Behind the Brew - a blog segment where we share conversations we have with people that love coffee! We want to talk to real people in our community and ask them about their home brewing and coffee experiences. That's what Behind the Brew will focus on.\r\nWithout community, coffee wouldn't be possible. Hook is excited to pick the brains of other coffee lovers out there. We are going to coffee pantries everywhere and getting your story! First up - Ernest, your co-founder.\r\n\r\n	<p>Hey everyone! Welcome to our first episode of&nbsp;<em>Behind the Brew</em>&nbsp;- a blog segment where we share conversations we have with people that love coffee!</p>\r\n\r\n<p>We want to talk to real people in our community and ask them about their home brewing and coffee experiences. That&#39;s what&nbsp;<em>Behind the Brew</em>&nbsp;will focus on.</p>\r\n\r\n<p>Without community, coffee wouldn&#39;t be possible. Hook is excited to pick the brains of other coffee lovers out there. We are going to coffee pantries everywhere and getting your story!</p>\r\n\r\n<p>Today, we are sharing an interview we had with Ernest Ting, Hook coffee&#39;s founder. Ernest thought Behind the Brew would be a good way to further involve the community with the beauty that is craft coffee, so he wanted to kick us off with the first episode.</p>\r\n\r\n<p>Let&#39;s get started!</p>\r\n\r\n<p>&nbsp;<br />\r\n<strong>So when did you first discover specialty coffee? Tell us about the experience!</strong></p>\r\n\r\n<p><em>I discovered specialty coffee in 2012. Hipster cafes began sprouting all over as craft coffee became more and more prevalent in Singapore, so I enrolled myself in a latte art course. I was fascinated by the way craft and art came together in the culinary spectrum of coffee.&nbsp;</em></p>\r\n\r\n<p><em>At that time, I was mostly interested in latte art, but I later came to realize that there is much more to coffee. This was when I began exploring further - reading and experimenting with brew methods, studying coffee origins and varietals, and familiarizing myself with taste profiles.</em></p>\r\n\r\n<p>Coffee really sunk in when I attended a three day roasting course at the London school of coffee. That was where the things that I learned came together and started making sense. This was everything from coffee sourcing to roasting and taste.&nbsp;</p>\r\n\r\n<p><strong>What do your days look like, and how do you fit good coffee into that routine?</strong></p>\r\n\r\n<p><em>Unless I have morning meetings, I like to kick start my day with a pour over. I usually use my v60 to brew up a more full bodied coffee, like Hook&#39;s &quot;Sweet Bundchen&quot; or &quot;Give me S&#39;mores.&quot; I grind my beans fresh using a Baratza precisio (which in my opinion is a superb home grinder).</em></p>\r\n\r\n<p>If my mornings are rushed, I&#39;ll just pop two capsules into the Nespresso machine and head off for work.</p>\r\n\r\n<p>When the afternoon comes along, I enjoy a flat white, and I usually take this time to taste what Hook is roasting that week. I also do some experiments with new blends!</p>\r\n\r\n<p><em>Fortunately, the Hook office is filled with coffee geeks, so there&#39;s always fresh coffee to be had -even if I&#39;m too lazy to make some myself.</em></p>\r\n\r\n<p>After dinner I usually have another cup of coffee (usually a capsule) that keeps me going through the evening.</p>\r\n\r\n<p>However, weekends are quite the opposite. The weekend provides me with more time to get the Espresso machine (Rocket V2) running, and I brew myself milk based coffee at home. And of course, I get to wind down with a brew in the afternoon.</p>\r\n\r\n<p><img alt="IMG_6065.JPG" src="https://hookcoffee.files.wordpress.com/2017/04/img_60651.jpg?w=1920" style="height:1280px; width:960px" /></p>\r\n\r\n<p><img alt="IMG_6062.JPG" src="https://hookcoffee.files.wordpress.com/2017/04/img_60622.jpg?w=1920" style="height:1280px; width:960px" /><br />\r\n<br />\r\n<strong>Walk us through your coffee brewing process!</strong></p>\r\n\r\n<p><em>To me, brewing a cup of coffee is actually quite simple. Specialty cafes these days make the brew process look like a science experiment - commanding an exorbitant price for a cup of brewed coffee. That was partially why I founded Hook Coffee, to change that.&nbsp;</em></p>\r\n\r\n<p><em>My brew process looks like this: I weigh out 15g of coffee. I then grind my beans using the Baratza precisio. Next I rinse the filter paper, dump in the ground coffee, and boil the water using an electric kettle to approximately 95 degrees. Then I brew, pouring in concentric circles. I do this until the water volume reaches 250ml. And that&rsquo;s it. It is that simple.&nbsp;</em></p>\r\n\r\n<p><strong>What&#39;s in your coffee arsenal?&nbsp;</strong></p>\r\n\r\n<p><img alt="IMG_6064.JPG" src="https://hookcoffee.files.wordpress.com/2017/04/img_6064.jpg?w=1920" style="height:1280px; width:960px" /></p>\r\n\r\n<p><em>Here&#39;s a list:</em><br />\r\n<em>-Hario weighing scale<br />\r\n-Baratza precisio<br />\r\n-Hario V60 Dripper<br />\r\n-Rocket V2<br />\r\n-Aeropress<br />\r\n-Hario Coffee Syphon<br />\r\n-Nespresso machine&nbsp;</em></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>What is your desert island gear? (Meaning, if you had to choose a few pieces of gear and be limited to that decision, what would you choose?)</strong></p>\r\n\r\n<p><em>To be completely honest, I would go for Hook&#39;s drip coffee bag. It&#39;s just so simple, and I get great coffee on the go. Essentially all I need is hot water and a cup.&nbsp;</em></p>\r\n\r\n<p><strong>What is your favorite thing about specialty coffee?</strong></p>\r\n\r\n<p><em>It&#39;s fascinating to see how coffee is something we often take for granted. Coffee is so special, so powerful, and it&#39;s constantly changing the landscapes of demographics and cultures.</em></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>And that&#39;s the end of our first adventure in Behind the Brew!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Hook is here for all of your coffee brewing needs. If you need anything, feel free to let us know.</p>\r\n\r\n<p>Happy brewing everyone!</p>\r\n\r\n<p>The Hook Coffee Team</p>\r\n	2017-04-11 13:22:11.636085+00	2017-04-11 13:20:15+00	Hook Coffee	./IMG_6063.JPG	\N	behind-the-brew-1
54	Improve your brew -v60	The complexity of coffee can be overwhelming.\r\n\r\nFirst comes the farming, then the roasting, then the brewing. Each one of these steps in the seed to cup process contains variables that should be met. Those variables are the key to intentional, tasty coffee. We have talked about farming, roasting, and brewing before. In this post, we'll target some brew variables.	<p>The complexity of coffee can be overwhelming.</p>\r\n\r\n<p>First comes the farming, then the roasting, then the brewing. Each one of these steps in the seed to cup process contains variables that should be met. Those variables are the key to intentional, tasty coffee. We have talked about farming, roasting, and brewing before. In this post, we&#39;ll target some brew variables.</p>\r\n\r\n<p>Let&#39;s troubleshoot some brew techniques. The v60 brew method will be our focus. If you don&#39;t use a v60, no worries! The techniques discussed can be used with a variety of other methods!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>The v60</strong></p>\r\n\r\n<p>The v60 is a pour over brew method. It was developed by Hario, a heat resistant glassware company in Japan. v60 provides the user with an ample amount of control during the brewing process. The &quot;fins&quot; on the side of the glass walls promote heat retention and grind distribution. The 60 degree angle promotes a neutral water flow rate, and the large hole at the bottom of the brew method lets the brewer decide how much water goes out or stays in.</p>\r\n\r\n<p>With the proper barista behind this brew method, liquid gold shall shine forth from your cup.</p>\r\n\r\n<p>The v60 is a great tool. Well, more than great actually. Many consider it a necessary pour-over method to incorporate into a routine.</p>\r\n\r\n<p>Even so, the v60 brewing process can be difficult. The large hole at the bottom and the 60 degree angle of the inner walls provide the brewer with a ton of control... but if that control isn&#39;t there, the coffee won&#39;t be liquid gold.</p>\r\n\r\n<p>It takes practice.</p>\r\n\r\n<p>So here are some tips.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Grind</strong></p>\r\n\r\n<p>This almost goes without saying, but grind is important.</p>\r\n\r\n<p>GRIND IS VERY IMPORTANT</p>\r\n\r\n<p>We can&#39;t reiterate the value of a decent grinder enough. A grinder is perhaps the most important tool in a coffee arsenal. It is the saddle on the horse, the strings on the guitar, and shampoo on the hair. Yes, it&#39;s all those things and more.</p>\r\n\r\n<p>A good grinder has a decent PSD (particle size distribution). PSD is how much the ground coffee particles differ from one another. If most of the coffee grinds look the same size, you&#39;re good to brew! If not, you&#39;ll see plenty of fines (small powdery grounds) and boulders (large chunks).</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Temperature</strong></p>\r\n\r\n<p>Temperature can be a unique tool used to dial in flavor profiles. While adjusting water temperature isn&#39;t as effective as changing grind size, it can be used to fine tune your coffee.</p>\r\n\r\n<p>The standard brewing temperatures sit at around 90.5 - 96 degrees Celsius. Staying in this range is your best bet for obtaining maximum coffee extraction.</p>\r\n\r\n<p>Lowering temperature decreases the extraction rate, and raising your temperature increases extraction.</p>\r\n\r\n<p>So if your coffee is coming out sour and thin, raise your temp. If the brew tastes burnt and toasty, lower the temp.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Maintaining the Wall</strong></p>\r\n\r\n<p>As mentioned before, the v60 has glass fins running up the inside of the glass. In order to utilize the benefits of this design, we maintain a &quot;coffee wall.&quot;</p>\r\n\r\n<p>To do this we need a goose neck kettle for precise pouring.</p>\r\n\r\n<p>By the end of the brewing process, the spent grounds should look like a burrowed hole. There should be a centimeter thick perimeter of coffee on the sides of the filter. To make sure this is the case, pour in small concentric circles while brewing. Don&#39;t let water touch the sides of the filter.</p>\r\n\r\n<p>We sometimes pour straight into the center without any agitation. The results can be surprising.</p>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<p><strong>Slow down</strong></p>\r\n\r\n<p>Many bustling specialty coffee shops utilize the quick brew nature of the v60. The v60&#39;s design allows it to brew quickly and precisely, but sometimes this shouldn&#39;t be the case.</p>\r\n\r\n<p>Different regions of coffee have different densities. The higher the altitude that the coffee was grown at, the more density it has. More density means that it takes water longer to seep into the grinds. This slows the extraction process significantly.</p>\r\n\r\n<p>If you are experiencing watery coffee, maybe slow down your pour. The lethargic flow rate may increase extraction and give you full bodied results.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Documenting Results</strong></p>\r\n\r\n<p>The best way to get better at brewing is to brew often and keep track of results. Keep a notepad on site and write down the process. Here&#39;s a template example you can use:</p>\r\n\r\n<blockquote>\r\n<p>Date:</p>\r\n\r\n<p>Coffee (Name, region):</p>\r\n\r\n<p>Water temperature:</p>\r\n\r\n<p>Grind size:</p>\r\n\r\n<p>Coffee mass:</p>\r\n\r\n<p>Water volume:</p>\r\n\r\n<p>Agitation:</p>\r\n\r\n<p>Misc:</p>\r\n\r\n<p>Taste:</p>\r\n</blockquote>\r\n\r\n<p>You&#39;ll come up with your own process, but doing this can be a start. You&#39;ll better understand how variables interact.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Consistency&nbsp;</strong></p>\r\n\r\n<p>Consistency is doing the same thing to achieve similar, if the same, results. The goal of learning the science behind the coffee brewing process is to incorporate it. We want to brew good coffee&nbsp;<em>every time</em>.</p>\r\n\r\n<p>If we come to better understand the brewing process, we will save time, enjoy ourselves more, and enjoy coffee more.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>As always,</p>\r\n\r\n<p>Happy Brewing!</p>\r\n\r\n<p>Kit</p>\r\n\r\n<p>Head of Coffee (aka bean whisperer)</p>\r\n\r\n<p>Hook Coffee&nbsp;</p>\r\n	2017-04-24 12:46:51.573748+00	2017-04-24 12:46:15+00	Kit 	./IMG_5752.JPG	4	improve-your-brew-v60
55	Tasting Notes. Using Them to Your Advantage	Flavor notes and tasting profiles are not an easy thing to understand. For instance, you may be confused when the label of the coffee you're drinking lists mango and black currant as flavor notes. This is extremely confusing to those who are new to specialty coffee. One may question if there really is mango in this coffee, or why they can't taste the notes on the bag. Today's subject matter concerns how we use our knowledge of taste to make better coffee. Enjoy the read!\r\n	<p>Flavor notes and tasting profiles are not an easy thing to understand.</p>\r\n\r\n<p>For instance, you may be confused when the label of the coffee you&#39;re drinking lists mango and black currant as flavor notes. This is extremely confusing to those who are new to specialty coffee. One may question if there really is mango in this coffee, or why they can&#39;t taste the notes on the bag.</p>\r\n\r\n<p>For most of us, coffee tastes like coffee, bread tastes like bread, and apples taste like apples...but what if we told you that apples could taste like honey and cinnamon, and coffee could taste like cardamom and sweet cream?</p>\r\n\r\n<p>Yes, it&#39;s a weird thought, but this is how culinary professionals taste the world. Undertones and notes of other flavors permeate our palates when we partake in drink or food.</p>\r\n\r\n<p>There are individuals that devote their entire lives to studying flavors through the fields of molecular gastronomy or the culinary arts. Food is made up of acids and molecular compounds...and so is coffee. It&#39;s not that far-fetched that a fruit could taste like another fruit. If foods are all made up of similar compounds, then they are bound to have some of the same characteristics!</p>\r\n\r\n<p>We in specialty coffee can learn from the culinary fields. Coffee is a complex drink, and it&#39;s our vocation to understand it to the best of our ability.</p>\r\n\r\n<p>Today&#39;s subject matter concerns how we use our knowledge of taste to make better coffee.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>What are flavor notes?</strong></h2>\r\n\r\n<p>When brewing specialty coffee, the goal is to extract as much&nbsp;<strong>relevant</strong>&nbsp;flavor as possible.</p>\r\n\r\n<p>When you read a label that provides a list of flavor notes, understand that those flavors were not added to the coffee.</p>\r\n\r\n<p>For instance, you&#39;ll read that our &quot;Give me S&#39;mores&quot; blend has hints of chocolate, marshmallows, and spice. This doesn&#39;t mean we added flavors to the coffee. A coffee&#39;s natural taste depends on the varietal and growing conditions of the bean, drying processes, and roast profile.</p>\r\n\r\n<p>Here is some of the information on the &quot;Give me S&#39;mores&quot; blend:</p>\r\n\r\n<blockquote>\r\n<p>Country: India</p>\r\n\r\n<p>Producer: Shankar Family</p>\r\n\r\n<p>Altitude: 3800-4400M</p>\r\n\r\n<p>Varietal: S-795</p>\r\n\r\n<p>Processes: Washed, sun dried on patio</p>\r\n\r\n<p>Roast profile: Medium-dark roast</p>\r\n</blockquote>\r\n\r\n<p>Because of these characteristics in the coffee, it tastes like chocolate and marshmallows. Specialty coffee pros can predict flavor based on these attributes.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>The Flavor Wheel</strong></h2>\r\n\r\n<p><img alt="SCAA_FlavorWheel.01.18.15" src="https://hookcoffee.files.wordpress.com/2017/04/scaa_flavorwheel-01-18-15.jpg?w=2720" style="height:2828px; width:2000px" /></p>\r\n\r\n<p>We did a post about the<a href="https://hookcoffee.com.sg/blog/how-to-use-the-coffee-flavor-wheel"> flavor wheel</a> a while back. We discussed how to read and understand it.</p>\r\n\r\n<p>What we didn&#39;t discuss was how to use it to your advantage.</p>\r\n\r\n<p>Like we said earlier, when brewing, the goal is to extract as much&nbsp;<strong>relevant</strong>&nbsp;flavor as possible. When we say&nbsp;<strong>relevant</strong>, we mean notes that make sense for the coffee at hand. All coffees taste different, and all coffees have flavor notes that should and shouldn&#39;t be there.</p>\r\n\r\n<p>But how do we know what those notes are, you ask? Through observing under and over extraction.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Under Extraction</strong></h2>\r\n\r\n<p>Under extraction occurs when coffee isn&#39;t extracted enough. This means that there is still more flavor to &quot;pull&quot; out of the coffee.</p>\r\n\r\n<p>Under extracted coffee comes off as sour and watery. It can also come off as green/vegetative.</p>\r\n\r\n<p>Let&#39;s observe the flavor wheel. Point yourself toward the &quot;sour/fermented&quot; section. As you can see, a lot of acids are listed. Most of us do not know what these acids taste like, so we encourage you to do some research. After performing a quick internet search, we found that acetic acid is akin to vinegar and pungency.</p>\r\n\r\n<p>If this is the &quot;sour taste&quot; in your coffee, it&#39;s a good indicator that your coffee is under extracted.</p>\r\n\r\n<p>Also observe the green/vegetative section. If you are tasting grassy and peapod tasting coffee, that&#39;s a very good sign that your coffee is under extracted.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Over Extraction</strong></h2>\r\n\r\n<p>Just think the opposite of under extraction. Over extraction occurs when you &quot;pull&quot; too much flavor out of the coffee. This results in a burned tasting coffee.</p>\r\n\r\n<p>Navigate to the &quot;other&quot; section on the flavor wheel. We see descriptors such as cardboard and bitter. If you taste any of the notes in this section, it&#39;s a good indicator that your coffee is over extracted...or that something weird is going on.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Conclusions</strong></h2>\r\n\r\n<p>Tasting over extracted coffee is easy. If the coffee is burnt or bitter tasting, it&#39;s probably over extracted.</p>\r\n\r\n<p>Under extracted coffee is a little more difficult to taste. Many believe that if coffee isn&#39;t bitter, it&#39;s good. Specialty shops around the globe serve under extracted coffee. This is a mistake.</p>\r\n\r\n<p>Under extracted coffee is not only bad tasting, it&#39;s a waste of coffee resources. Pulling the&nbsp;<strong>relevant</strong>&nbsp;flavor out of a coffee bean is a great accomplishment. Enjoy coffee to its fullest!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h2><strong>Fixing your coffee</strong></h2>\r\n\r\n<p>If your coffee is&nbsp;<em>under extracted,</em>&nbsp;you can do one or more of the following:</p>\r\n\r\n<blockquote>\r\n<p>-Fine the grind</p>\r\n\r\n<p>-Expand brew time</p>\r\n\r\n<p>-Raise water temp</p>\r\n</blockquote>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>If your coffee is&nbsp;<em>over extracted</em>:</p>\r\n\r\n<blockquote>\r\n<p>-Coarsen grind</p>\r\n\r\n<p>-Lessen brew time</p>\r\n\r\n<p>-Lower temp</p>\r\n</blockquote>\r\n\r\n<p>Do this and happiness shall follow you.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Happy brewing everyone!</p>\r\n\r\n<p>Kit&nbsp;</p>\r\n\r\n<p>Head of Coffee (aka bean whisperer)&nbsp;</p>\r\n\r\n<p>Hook Coffee</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Photo credits: SCAA</p>\r\n\r\n<p>&nbsp;</p>\r\n	2017-04-30 03:30:44.669569+00	2017-04-30 03:29:56+00	Kit 	./SCAA_FlavorWheel_Poster.01.18.15_Page_2.png	10	tasting-notes-using-them-to-your-advantage
56	Too fresh to drink?	We live by the mantra that coffee has to be brewed FRESH. But can coffee be too fresh to drink? Is there an optimal time in which to brew coffee? For this week’s post, we look to dive into the commonly asked about topic - freshness and the age of roasted coffee.\r\n	<h2><strong>Freshly roasted coffee.</strong></h2>\r\n\r\n<p>That&rsquo;s one of the promises that we here, at Hook Coffee make &ndash; getting freshly roasted coffee out to our subscribers. But what makes it so important? Why go through all the trouble of procuring delicious coffee and roasting them every week, ensuring that each of our subscribers get their coffees within a week of roasting? Because some of the simplest yet most delicious things come from sourcing incredibly fresh produce.</p>\r\n\r\n<p>But can coffee be too fresh to drink? Is there an optimal time in which to brew coffee? For this week&rsquo;s post, we look to dive into the commonly asked about topic - freshness and the age of roasted coffee.</p>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<h3><strong>REST</strong></h3>\r\n\r\n<p>It is a common practice for espresso bars to &ldquo;rest&rdquo; their coffee before putting them in the hopper and pulling shots. If they don&rsquo;t, there&rsquo;s often complaints of sourness or too much gas as it is still &ldquo;fresh&rdquo;, thus affecting the extraction process. It is an often discussed about matter, yet for the common drinker it is a subject that is commonly pushed aside without knowing what goes on in the resting process.</p>\r\n\r\n<p>Resting coffee refers to the process where a bag of coffee is allowed to sit and naturally de-gas. When coffee is roasted, a by-product of the process is that CO2 is developed and built up within the cell walls of the coffee bean. So, within the first 3-5 days after roasting, the coffee bean experiences a substantial amount of Carbon Dioxide gas (CO2) being released from its internal structure.</p>\r\n\r\n<p>If you were to brew the coffee with an espresso machine within the first few days, you&rsquo;ll notice a significant amount of crema in your cup and often, you will also notice that the espresso coming out of your portafilter pales or blondes earlier. Given that there is still a significant amount of CO2 gas within the cell structures, it often affects the brewing process in this way.</p>\r\n\r\n<p>Resting allows the coffee to stabilise, with any excess gasses being released and for more subtle flavours to develop, it is a process which many baristas and specialty caf&eacute;s do not overlook.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3><strong>So, what does this mean? Do we have to rest coffees for filter brews? What does this translate to the home brewer?</strong></h3>\r\n\r\n<p>While freshness is vital to the enjoyment of coffee, more often than not, we will find that tasting any coffee that was just roasted within a few hours to a day ago can be quite different to tasting that same coffee after it has been given a few days of resting.</p>\r\n\r\n<p>As a guideline and based on our experience, we have found that the flavours of most of our coffee peaks from&nbsp;<strong>4-6&nbsp;day onwards for filter brews</strong>&nbsp;(such as a pour over) and&nbsp;<strong>7-10 days onwards for espresso</strong>&nbsp;brews. This allows the volatile aromatics to settle in and for the CO2 to be released.</p>\r\n\r\n<p>Given proper storage conditions, a coffee can last up to a month and sometimes even two months! But remember - once you tear open that seal and each time you open the bag, you are introducing air to your coffees and over time, oxidation will take its effect and your coffees will eventually become stale (We will talk more about storage condition in our next post!).</p>\r\n\r\n<p>It is surprising and exciting to find that the flavours in coffee continuously change and subtle flavours begin to show over time. Very much like having a cup of filter coffee to cool down &ndash; you might be pleased to find that some nuanced flavour show up as the drink gradually transitions from hot to warm in temperature. That said, nothing really beats&nbsp;<em>freshly brewed coffee.</em>&nbsp;It is never nice to drink a cup of coffee that was left to sit for an hour.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Look out for our next post, we&rsquo;ll talk more about ideal storage conditions for your new bag of coffee!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Happy Brewing, Friends!</p>\r\n\r\n<p>Kit&nbsp;</p>\r\n\r\n<p>Head of Coffee</p>\r\n\r\n<p>Hook Coffee&nbsp;</p>\r\n	2017-05-08 14:24:16.299127+00	2017-05-08 14:23:15+00	Kit	./DSC_0023.JPG	10	when-is-the-best-time-to-brew-your-coffee
57	What is the optimal brewing time?	This is the second segment of a two part series on time. If you didn't take a look at the last one, we highly recommend that you check it out! In the second segment, we want to talk about one of the imperative brew variables: optimal brewing time. Brew time is the amount of time that water is in contact with a ground coffee mass. The longer that coffee is submerged in water, the more extraction takes place.\r\n	<p>This is the second segment of a two part series on time. If you didn&#39;t take a look at the last one, we highly recommend that you check it out!</p>\r\n\r\n<p>Time is one of the variables that effects the taste and composition of a coffee. Whether it be in the coffee farming process or when you&#39;re brewing up a cup of joe, time is there. Time is always watching.</p>\r\n\r\n<p>The first segment of this series discussed coffee aging.</p>\r\n\r\n<p>We went through some of the common misconceptions of coffee&#39;s aging process, and we also examined some of the science behind the coffee aging phenomenon.</p>\r\n\r\n<p>In the second segment, we want to talk about one of the imperative brew variables: optimal brewing time.</p>\r\n\r\n<p>Brew time is the amount of time that water is in contact with a ground coffee mass. The longer that coffee is submerged in water, the more extraction takes place.</p>\r\n\r\n<p>This variable is more pertinent in Immersion brew methods, but as you read from the last post, time is always affecting the world around it.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>What is Optimal?</strong></p>\r\n\r\n<p>Many people entering in to the world of specialty coffee are boggled by the question, &quot;what is optimal?&quot;</p>\r\n\r\n<p>It&#39;s hard for many newcomers to understand that there is no simple answer to this question.</p>\r\n\r\n<p>As seen in the first segment, coffee changes. Every day, every hour, coffee is changing. It&#39;s an organic material that interacts with the environment around it.</p>\r\n\r\n<p>So what really is optimal? What is the&nbsp;<em>best&nbsp;</em>way to brew coffee? How can we always brew, without fail, a delectable cup?</p>\r\n\r\n<p>Well, the &quot;optimal&quot; brewing time is one that pulls as many flavors from the coffee as possible.</p>\r\n\r\n<p>When hot water touches coffee, it removes the flavoring solubles in the coffee. According to Fedele&#39;s VST Universal Brewing Control Chart, the optimal extraction is one that removes only 18 - 22% of solubles from the coffee.</p>\r\n\r\n<p>If we are to achieve &quot;optimal,&quot; we need to be as careful with time as we are with our other variables.</p>\r\n\r\n<p>Here&#39;s a quick refresher of the brewing variable list:</p>\r\n\r\n<blockquote>\r\n<p>- Slurry temperature (the slurry is the mix of coffee grounds and water)</p>\r\n\r\n<p>- Brew time</p>\r\n\r\n<p>- Grind size</p>\r\n\r\n<p>- Agitation</p>\r\n\r\n<p>- Ratio of coffee to water</p>\r\n\r\n<p>- Roast date of coffee</p>\r\n</blockquote>\r\n\r\n<p>These are all things that affect the extraction rate.</p>\r\n\r\n<p>This means that &quot;good brewing time&quot; will not achieve good coffee.&nbsp;<em>Brewing time is a tool.</em></p>\r\n\r\n<p>Brewing time is just one most variable that we must take into account. Grind size, agitation, brewing ratio, contact time.... these are all things that extract coffee. Using time as a tool to interact with other variables is your best bet when attempting to achieve &quot;optimal.&quot;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>Tips for achieving the optimal brew time</strong></p>\r\n\r\n<p>We&#39;ve said this before, and we will say it again: your grind size is one of the most important variables. In fact, it&#39;s so important that other brewing variables must follow in its wake.</p>\r\n\r\n<p>Here&#39;s what Ted R. Lingle says about brewing time in SCAA&#39;s Coffee Brewing Handbook:</p>\r\n\r\n<p>&quot;The brewing process starts the moment hot water touches the coffee grounds and stops when the water and coffee grounds are separated. The period during which the water remains in direct contact with the coffee is known as the brewing time. the most desirable beverage results when the brewing process is completed with the time period prescribed for the coffee&#39;s grind.&quot;</p>\r\n\r\n<p>This is vitally important to understand!</p>\r\n\r\n<p>Once again, many variables must be taken into account when brewing. Coffee is complex. There is quite a bit going on.</p>\r\n\r\n<p>So try this...</p>\r\n\r\n<p>Start with grind size. Always start with grind size. What do you wish to brew? A V60? A Clever? A Chemex?</p>\r\n\r\n<p>After you decide, think about the interaction between variables. We already &nbsp;know that a finer grind will yield a higher extraction percentage. If this is true, we must be careful to not brew for too long, else over extraction will occur. You need to find a happy medium of time that interacts nicely with the variables around it.</p>\r\n\r\n<p>This is just one example. We could list many, many more.</p>\r\n\r\n<p>Here&#39;s a quick cheat sheet for extraction time.</p>\r\n\r\n<blockquote>\r\n<p>For fine grind, less time</p>\r\n\r\n<p>For medium grind, medium time</p>\r\n\r\n<p>For coarse grind, long time.</p>\r\n</blockquote>\r\n\r\n<p>In terms of brewing with a clever...</p>\r\n\r\n<blockquote>\r\n<p><em>For fine grind, less time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</em><strong>1:30min</strong></p>\r\n\r\n<p><em>For medium grind, medium time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</em><strong>2:45min</strong></p>\r\n\r\n<p><em>For coarse grind, long time.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</em><strong>3:30min</strong></p>\r\n</blockquote>\r\n\r\n<p>Try this out and see what you come up with!</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>As always, Happy Brewing!</p>\r\n\r\n<p>The Hook Coffee Team</p>\r\n	2017-05-15 15:01:30.144867+00	2017-05-15 15:01:30+00	Hook Coffee	./IMG_6970_NJxPceb.JPG	10	what-is-the-optimal-brewing-time
\.


--
-- Name: blog_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('blog_post_id_seq', 57, true);


--
-- Data for Name: blog_post_tags; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY blog_post_tags (id, post_id, tag_id) FROM stdin;
224	55	32
225	55	1
226	55	2
227	55	37
228	55	33
229	55	34
129	33	3
130	33	26
131	33	27
132	33	28
133	33	29
134	33	30
135	34	32
136	34	33
137	34	34
138	34	3
139	34	31
140	35	3
141	35	35
142	35	36
143	35	37
144	35	38
234	56	2
235	56	3
236	56	37
237	56	22
151	49	6
155	50	1
156	50	2
157	50	6
158	51	2
159	51	3
160	51	36
161	51	37
162	51	38
163	51	16
164	51	17
165	51	18
166	51	35
241	57	8
242	57	2
243	57	37
170	24	3
171	24	9
172	24	11
173	24	6
174	31	19
175	31	20
176	31	21
177	32	24
178	32	25
179	32	3
180	32	22
181	32	23
90	3	1
91	3	2
92	20	3
93	20	4
94	20	5
95	20	6
96	21	8
97	21	6
98	21	7
99	22	9
100	22	3
101	22	4
102	22	5
103	23	10
104	23	3
105	23	7
106	25	1
107	25	3
108	25	12
113	27	9
114	27	13
115	27	14
116	27	15
117	28	16
118	28	17
119	28	18
120	28	3
187	52	3
188	52	2
189	52	35
190	52	36
191	52	38
199	53	2
200	53	35
201	53	36
202	53	5
203	53	6
204	53	17
205	53	37
209	54	2
210	54	37
211	54	38
\.


--
-- Name: blog_post_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('blog_post_tags_id_seq', 243, true);


--
-- Data for Name: blog_tag; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY blog_tag (id, name, slug) FROM stdin;
1	Back to Basics	back-to-basics
2	BIY (Brew it Yourself)	biy-brew-it-yourself
3	Coffee	coffee
4	coffee grind	coffee-grind
5	espresso	espresso
6	hook coffee	hook-coffee
7	cold brew coffee	cold-brew-coffee
8	french press	french-press
9	coffee beans	coffee-beans
10	sock	sock
11	coffee packaging	coffee-packaging
12	grinding	grinding
13	coffee roaster	coffee-roaster
14	roasting	roasting
15	sourcing	sourcing
16	aeropress	aeropress
17	drip bags	drip-bags
18	travel	travel
19	coffee scrub	coffee-scrub
20	international coffee day	international-coffee-day
21	sustainability	sustainability
22	fresh	fresh
23	quality	quality
24	specialty	specialty
25	supermarket	supermarket
26	black gold edition	black-gold-edition
27	eternal sunshine	eternal-sunshine
28	ethiopia aricha natural	ethiopia-aricha-natural
29	grading	grading
30	specialty coffee	specialty-coffee
31	ethiopia	ethiopia
32	flavor wheel	flavor-wheel
33	scaa	scaa
34	tasting	tasting
35	equipment	equipment
36	gear	gear
37	nerd	nerd
38	tools	tools
39	interview 	interview
\.


--
-- Name: blog_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('blog_tag_id_seq', 39, true);


--
-- Data for Name: coffees_brewmethod; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_brewmethod (id, name, img, name_en, name_zh_hans, slug) FROM stdin;
1	Espresso	./espresso.png	Espresso	浓缩咖啡	
2	Drip	./drip.png	Drip	滤杯	
3	Aeropress	./aeropress.png	Aeropress	爱乐压	
4	French press	./french_press.png	French press	法式滤压壶	
5	Stove top	./stove_top.png	Stove top	摩卡壶	
7	None	./none.png	None	无	
6	Nespresso	./SHOTPODS-NESPRESSO_COMPATIBLE_.png	Nespresso	Nespresso	
8	Cold Brew	./coldbrewicon_-_purple-01-01.png	Cold Brew		
\.


--
-- Name: coffees_brewmethod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_brewmethod_id_seq', 8, true);


--
-- Data for Name: coffees_coffeegear; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_coffeegear (id, name, essentials, model, description, link, price, description_en, description_zh_hans, in_stock, link_en, link_zh_hans, model_en, model_zh_hans, more_info, more_info_en, more_info_zh_hans, name_en, name_zh_hans, special, allow_choice_package, weight, available, recommend, the_order) FROM stdin;
7	Set D	t	Whole Beans and Drip Coffee	1 x Christmas Blend\r\n(200g Whole coffee beans)\r\n\r\nAssortment of 5 individually\r\nwrapped drip coffee bags	#	25.00	1 x Christmas Blend\r\n(200g Whole coffee beans)\r\n\r\nAssortment of 5 individually\r\nwrapped drip coffee bags		f	#	#	Whole Beans and Drip Coffee		Balancing the inner coffee geek and convenience, This gift set is perfect for that coffee geek friend you know that secretly enjoys hand grinding his own beans in the morning, yet still enjoys the convenience of a great drip coffee on the go.\r\n\r\nWhat this set contains:\r\n1 x 200g Hook’s Christmas Blend\r\n(whole coffee beans)\r\nAssortment of 5 individually wrapped\r\ndrip coffee bags\r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\n\r\nFor special request, drop us an email at hola@hookcoffee.com.sg!	Balancing the inner coffee geek and convenience, This gift set is perfect for that coffee geek friend you know that secretly enjoys hand grinding his own beans in the morning, yet still enjoys the convenience of a great drip coffee on the go.\r\n\r\nWhat this set contains:\r\n1 x 200g Hook’s Christmas Blend\r\n(whole coffee beans)\r\nAssortment of 5 individually wrapped\r\ndrip coffee bags\r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\n\r\nFor special request, drop us an email at hola@hookcoffee.com.sg!		Set D		set	t	700	f	f	0
8	Set E	t	Shotpods Set	30 Shotpods in\r\n3 Delicious flavours	#	21.00	30 Shotpods in\r\n3 Delicious flavours		t	#	#	Shotpods Set		You know that coffee lover friend who indulges in the coffee capsules like a daily ritual. This Christmas, how about surprising him with Hook’s very own Nespresso compatible pods - Shotpods. These coffees contains some of the finest coffees directly sourced from the world’s best farms, perfectly roasted and filled into a pod just for that additional convenience.\r\n\r\nWhat this set contains:\r\n1 Box of Sweet Bundchen Shotpods\r\n1 Box of Birds of Paradise Shotpods\r\n1 Box of The Godfather Shotpods\r\n\r\n*Each Box consist of 10 Nespresso compatible \r\ncapsules\r\n** Nespresso machine not included\r\n\r\nFor special enquiries, drop us an email at hola@hookcoffee.com.sg!	You know that coffee lover friend who indulges in the coffee capsules like a daily ritual. This Christmas, how about surprising him with Hook’s very own Nespresso compatible pods - Shotpods. These coffees contains some of the finest coffees directly sourced from the world’s best farms, perfectly roasted and filled into a pod just for that additional convenience.\r\n\r\nWhat this set contains:\r\n1 Box of Sweet Bundchen Shotpods\r\n1 Box of Birds of Paradise Shotpods\r\n1 Box of The Godfather Shotpods\r\n\r\n*Each Box consist of 10 Nespresso compatible \r\ncapsules\r\n** Nespresso machine not included\r\n\r\nFor special enquiries, drop us an email at hola@hookcoffee.com.sg!		Set E		set	f	500	f	f	0
9	Set F	t	Ultimate Hook's Experience	1 x Christmas Blend\r\n10 Shotpods\r\nAssortment of 5 individually\r\nwrapped drip coffee bags	#	35.00	1 x Christmas Blend\r\n10 Shotpods\r\nAssortment of 5 individually\r\nwrapped drip coffee bags		f	#	#	Ultimate Hook's Experience		Can’t decide which is best for the coffee loving friend this Christmas? How about a gift set that contains it all. Bring the Ultimate Hook Experience to your coffee loving friend this Christmas!\r\n\r\nWhat this set contains:\r\n1 x 200g Hook Christmas blend\r\n1 Box of The Godfather Shotpods (10 Shotpods)\r\nAssortment of 5 Individually wrapped \r\ndrip coffee bags\r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor special request, drop us an email at hola@hookcoffee.com.sg!	Can’t decide which is best for the coffee loving friend this Christmas? How about a gift set that contains it all. Bring the Ultimate Hook Experience to your coffee loving friend this Christmas!\r\n\r\nWhat this set contains:\r\n1 x 200g Hook Christmas blend\r\n1 Box of The Godfather Shotpods (10 Shotpods)\r\nAssortment of 5 Individually wrapped \r\ndrip coffee bags\r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor special request, drop us an email at hola@hookcoffee.com.sg!		Set F		set	t	500	f	f	0
2	Donut Coffee Dripper 	t	-	-	#	68.00	-		f	#	#	-		Developed for simplicity and precision, this coffee dripper features a tall brewing chamber and a terraced inner design that forces water and coffee to interact the entire duration of the brew, resulting in a heavy, creamy body. The ceramic dripper and natural wood base exhibit the artistry of the craftsmen who made them.	Developed for simplicity and precision, this coffee dripper features a tall brewing chamber and a terraced inner design that forces water and coffee to interact the entire duration of the brew, resulting in a heavy, creamy body. The ceramic dripper and natural wood base exhibit the artistry of the craftsmen who made them.		Donut Coffee Dripper 			f	700	f	f	0
3	House Measuring Scoop 	t	-		#	36.00			f	#	#	-		This 10g coffee scoop will empower you to brew excellent coffee by eliminating guessing from coffee bean measuring. It is made from natural wood and shaped like a house, for coffee and homes both provide comfort and sanctuary. A fitting and charming design for a coffee scoop.	This 10g coffee scoop will empower you to brew excellent coffee by eliminating guessing from coffee bean measuring. It is made from natural wood and shaped like a house, for coffee and homes both provide comfort and sanctuary. A fitting and charming design for a coffee scoop.		House Measuring Scoop 			f	700	f	f	0
1	Marina Coffee Dripper	t	-		#	38.00			f	#	#	-		Inspired by sailing amidst the fresh sea breeze, this coffee dripper and filter holder make for a functional and elegant coffee brewing set. Designed with heat-resistant, durable elastomer, the set will last a lifetime - or two - and will be a vessel for great coffee brewing for years to come.	Inspired by sailing amidst the fresh sea breeze, this coffee dripper and filter holder make for a functional and elegant coffee brewing set. Designed with heat-resistant, durable elastomer, the set will last a lifetime - or two - and will be a vessel for great coffee brewing for years to come.		Marina Coffee Dripper			f	500	f	f	0
5	Set B	t	Drip Coffee Bags Gift Set	Assortment of 20 individually packed drip coffee bags	#	36.00	Assortment of 20 individually packed drip coffee bags		f	#	#	Drip Coffee Bags Gift Set		This exclusive gift set consist of an assortment of 20 individually sealed drip coffee bags. A perfect gift for any coffee lovers. Ideal for the little christmas gathering with your friends and family too.\r\n\r\nWhat this set contains: \r\n4 x Hook’s Christmas Blend \r\n2 x Kopi Sutra \r\n2 x A Midsummers’ Night Dream \r\n2 x Guji Liya \r\n2 x Sweet Bundchen \r\n2 x Honey I Shrunk the Kids \r\n2 x Neverneverland \r\n2 x Speculose Your Mind \r\n2 x Eternal Sunshine \r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\n\r\nFor special request, drop us an email at hola@hookcoffee.com.sg 	This exclusive gift set consist of an assortment of 20 individually sealed drip coffee bags. A perfect gift for any coffee lovers. Ideal for the little christmas gathering with your friends and family too.\r\n\r\nWhat this set contains: \r\n4 x Hook’s Christmas Blend \r\n2 x Kopi Sutra \r\n2 x A Midsummers’ Night Dream \r\n2 x Guji Liya \r\n2 x Sweet Bundchen \r\n2 x Honey I Shrunk the Kids \r\n2 x Neverneverland \r\n2 x Speculose Your Mind \r\n2 x Eternal Sunshine \r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\n\r\nFor special request, drop us an email at hola@hookcoffee.com.sg 		Set B		set	f	800	f	f	0
6	Set C	t	Whole Beans Gift Set	1 x  Christmas Blend\r\n(80g Whole Beans)\r\nHook’s 2016 Top 3\r\n(3 x 80g Whole Beans)	#	30.00	1 x  Christmas Blend\r\n(80g Whole Beans)\r\nHook’s 2016 Top 3\r\n(3 x 80g Whole Beans)		t	#	#	Whole Beans Gift Set		Specially curated for that coffee enthusiast friend you have in mind, this gift set bundles Hook’s 2016 top 3 best seller, which includes the limited edition Hook’s Christmas blend. All in whole coffee beans, just so that he could express his inner coffee geek by freshly hand grinding and brewing that perfect pot of joe.\r\n\r\nWhat this set contains:\r\n1 x 80g Hook’s Christmas Blend\r\n(whole coffee beans) \r\n3 x 80g Hook’s 2016 Top 3\r\n(whole coffee beans)\r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor custom enquiries, drop us an email at hola@hookcoffee.com.sg	Specially curated for that coffee enthusiast friend you have in mind, this gift set bundles Hook’s 2016 top 3 best seller, which includes the limited edition Hook’s Christmas blend. All in whole coffee beans, just so that he could express his inner coffee geek by freshly hand grinding and brewing that perfect pot of joe.\r\n\r\nWhat this set contains:\r\n1 x 80g Hook’s Christmas Blend\r\n(whole coffee beans) \r\n3 x 80g Hook’s 2016 Top 3\r\n(whole coffee beans)\r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor custom enquiries, drop us an email at hola@hookcoffee.com.sg		Set C		set	t	700	f	f	0
10	SET G	t	Hook X Amazin' Graze	Assortment of 10 Individually packed drip coffee bags \r\n1 X Cinnamon Spiced Nuts from Amazin’ Graze (120g)	#	25.00	Assortment of 10 Individually packed drip coffee bags \r\n1 X Cinnamon Spiced Nuts from Amazin’ Graze (120g)		f	#	#	Hook X Amazin' Graze		What makes a cup of coffee even more exciting? We collaborated with the good guys at Amazin Graze, and found this truly amazing Cinnamon Spiced Nuts that goes perfectly with a cup of Hook’s Drip Coffee. Exclusively available for this Christmas only. \r\n\r\nWhat this set contains: \r\n2 x Hook’s Christmas Blend \r\n2 x Kopi Sutra \r\n2 x A Midsummers’ Night Dream \r\n2 x Guji Liya \r\n2 x Sweet Bundchen\r\n\r\n1x 120g Cinnamon Spice Nuts from Amazin' Graze (120g) \r\n\r\nFind out more about Amazin' Gra(https://www.amazingraze.co) \r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment.\r\n\r\nFor special request drop us an email at hola@hookcoffee.com.sg\r\n\r\n	What makes a cup of coffee even more exciting? We collaborated with the good guys at Amazin Graze, and found this truly amazing Cinnamon Spiced Nuts that goes perfectly with a cup of Hook’s Drip Coffee. Exclusively available for this Christmas only. \r\n\r\nWhat this set contains: \r\n2 x Hook’s Christmas Blend \r\n2 x Kopi Sutra \r\n2 x A Midsummers’ Night Dream \r\n2 x Guji Liya \r\n2 x Sweet Bundchen\r\n\r\n1x 120g Cinnamon Spice Nuts from Amazin' Graze (120g) \r\n\r\nFind out more about Amazin' Gra(https://www.amazingraze.co) \r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment.\r\n\r\nFor special request drop us an email at hola@hookcoffee.com.sg\r\n\r\n		SET G		set	f	500	f	f	0
11	SET H	t	Marina Coffee Dripper Gift Set	1 X Marina Coffee Dripper \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jam-azing (80g choose whole/grounded) \r\n	#	53.00	1 X Marina Coffee Dripper \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jam-azing (80g choose whole/grounded) \r\n		t	#	#	Marina Coffee Dripper Gift Set		An exclusive collaboration with Atomi Singapore. \r\n\r\nhttp://atomi-jp.com\r\n\r\nWhat this set contains:\r\n\r\n1 X Marina Coffee Dripper \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jam-azing (80g choose whole/grounded) \r\n\r\n*Complimentary filter papers will be included. \r\n\r\nChoice of colour for Marina Coffee Dripper subject to stock availability. \r\n\r\nFor custom enquiries, drop us an email at hola@hookcoffee.com.sg	An exclusive collaboration with Atomi Singapore. \r\n\r\nhttp://atomi-jp.com\r\n\r\nWhat this set contains:\r\n\r\n1 X Marina Coffee Dripper \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jam-azing (80g choose whole/grounded) \r\n\r\n*Complimentary filter papers will be included. \r\n\r\nChoice of colour for Marina Coffee Dripper subject to stock availability. \r\n\r\nFor custom enquiries, drop us an email at hola@hookcoffee.com.sg		SET H		set	f	500	f	f	0
12	SET I 	t	Donus Dripper Gift Set 	1 X Donut Coffee Dripper \r\n1 X House Measuring Scoop \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jama-zing (80g choose whole/grounded) \r\n1 X Give me S’mores (80g choose whole/grounded) \r\n	#	125.00	1 X Donut Coffee Dripper \r\n1 X House Measuring Scoop \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jama-zing (80g choose whole/grounded) \r\n1 X Give me S’mores (80g choose whole/grounded) \r\n		t	#	#	Donus Dripper Gift Set 		What this set contains:\r\n\r\n1 X Donut Coffee Dripper \r\n1 X House Measuring Scoop \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jama-zing (80g choose whole/grounded) \r\n1 X Give me S’mores (80g choose whole/grounded) \r\n\r\n* Complimentary filter paper will be included. \r\n\r\n** Colour of donut dripper subject to stock availability. \r\n\r\n*** Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor custom enquiries, drop us an email at hola@hookcoffee.com.sg	What this set contains:\r\n\r\n1 X Donut Coffee Dripper \r\n1 X House Measuring Scoop \r\n1 X Christmas Blend (80g choose whole/grounded) \r\n1 X Jama-zing (80g choose whole/grounded) \r\n1 X Give me S’mores (80g choose whole/grounded) \r\n\r\n* Complimentary filter paper will be included. \r\n\r\n** Colour of donut dripper subject to stock availability. \r\n\r\n*** Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor custom enquiries, drop us an email at hola@hookcoffee.com.sg		SET I 		set	f	1000	f	f	0
4	Set A	t	Drip Coffee Bags Gift Set	Assortment of 10 individually \r\npacked drip coffee bags 	#	18.00	Assortment of 10 individually \r\npacked drip coffee bags 		f	#	#	Drip Coffee Bags Gift Set		This exclusive gift set consist of an assortment of 10 individually packed drip coffee bags. A perfect gift for any coffee lovers, or just to keep as an emergency stash for yourself this Christmas. :) \r\n\r\nWhat this set contains: \r\n2 x Hook’s Christmas Blend \r\n2 x Kopi Sutra \r\n2 x A Midsummers’ Night Dream \r\n2 x Guji Liya \r\n2 x Sweet Bundchen \r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor special request drop us an email at hola@hookcoffee.com.sg 	This exclusive gift set consist of an assortment of 10 individually packed drip coffee bags. A perfect gift for any coffee lovers, or just to keep as an emergency stash for yourself this Christmas. :) \r\n\r\nWhat this set contains: \r\n2 x Hook’s Christmas Blend \r\n2 x Kopi Sutra \r\n2 x A Midsummers’ Night Dream \r\n2 x Guji Liya \r\n2 x Sweet Bundchen \r\n\r\n*Coffee variants are indicative only and subjected to change depending on availability at the time of fulfilment. \r\n\r\nFor special request drop us an email at hola@hookcoffee.com.sg 		Set A		set	f	500	f	f	0
16	Aeropress Maker Kit	t	Aeropress Maker Kit		#	65.00			t	#	#	Aeropress Maker Kit		This kit includes almost everything you need to successfully brew coffee goodness with an aeropress. Included is a formidable plastic scoop, multipurpose funnel, stirring paddle, 350 filters with filter holder, and the Aeropress plunger and chamber. An aeropress will aid you at home or on the trail, and it is perhaps the most versatile of all brewing methods. The self-plunging decanting process allows the user to make anything from concentrated espresso-like coffee to a light bodied cup. The simple plastic design makes for a durable solution to your coffee brewing needs. Simply brew, plunge, rinse, and repeat!	This kit includes almost everything you need to successfully brew coffee goodness with an aeropress. Included is a formidable plastic scoop, multipurpose funnel, stirring paddle, 350 filters with filter holder, and the Aeropress plunger and chamber. An aeropress will aid you at home or on the trail, and it is perhaps the most versatile of all brewing methods. The self-plunging decanting process allows the user to make anything from concentrated espresso-like coffee to a light bodied cup. The simple plastic design makes for a durable solution to your coffee brewing needs. Simply brew, plunge, rinse, and repeat!		Aeropress Maker Kit			f	500	t	f	0
17	Hario Drip Coffee Scale	t	Hario Drip Coffee Scale		#	77.00			t	#	#	Hario Drip Coffee Scale		Hario's coffee scale will instantly become one of the most valued tools in your coffee gear collection. Its sleek design and ergonomic utility lets you breathe - helping you focus less on the scale and more on making your coffee taste great. Its built-in timer utility condenses your coffee setup, and its acute measuring accuracy will promote overall consistency in your brew. The Drip Scale's measuring platform allows comfortable room for most brewing methods. This scale makes espresso and brewing preparation a breeze.	Hario's coffee scale will instantly become one of the most valued tools in your coffee gear collection. Its sleek design and ergonomic utility lets you breathe - helping you focus less on the scale and more on making your coffee taste great. Its built-in timer utility condenses your coffee setup, and its acute measuring accuracy will promote overall consistency in your brew. The Drip Scale's measuring platform allows comfortable room for most brewing methods. This scale makes espresso and brewing preparation a breeze.		Hario Drip Coffee Scale			f	500	t	f	0
15	Longevity 	t	Drip Coffee Brew Kit 	1 x 200g Whole/Ground Prosperoo \r\n1 x Hario V60 Dripper (Red) \r\n8 x Prosperoo Drip Coffee Bags 	#	38.00	1 x 200g Whole/Ground Prosperoo \r\n1 x Hario V60 Dripper (Red) \r\n8 x Prosperoo Drip Coffee Bags 		f	#	#	Drip Coffee Brew Kit 		The longevity gift sets consist of a 200g bag of our limited edition CNY coffee (choose whole or ground), a red Hario V60 coffee dripper and 8 10 individually packed drip coffee bags (in an auspicious ’Ang Bao’ wrapping. A perfect starter kit for any coffee loving friends this CNY. \r\n\r\nWhat this set contains: \r\n\r\n1 x 200g Whole/Ground Prosperoo \r\n\r\n8 x Prosperoo Drip Coffee Bags \r\n\r\n1 x Hario V60 Dripper (Red) 	The longevity gift sets consist of a 200g bag of our limited edition CNY coffee (choose whole or ground), a red Hario V60 coffee dripper and 8 10 individually packed drip coffee bags (in an auspicious ’Ang Bao’ wrapping. A perfect starter kit for any coffee loving friends this CNY. \r\n\r\nWhat this set contains: \r\n\r\n1 x 200g Whole/Ground Prosperoo \r\n\r\n8 x Prosperoo Drip Coffee Bags \r\n\r\n1 x Hario V60 Dripper (Red) 		Longevity 		set	t	1000	f	f	0
14	Happiness 	t	Assorted Drip Coffee Bags Set 	Assortment of 10 Drip Coffee Bags	#	18.00	Assortment of 10 Drip Coffee Bags		t	#	#	Assorted Drip Coffee Bags Set 		Back by popular demand, the Happiness gift set consists of 10 individually packed drip coffee bags in auspicious "Ang Baos". Indulge in an assortment of Hook Coffee’s classics, including our limited edition Chinese New Year coffee, Prosperoo, that at one whiff and sip, would immediately remind you of delicious pineapple tarts!\r\n\r\nWhat this set contains:\r\n\r\n2 x Prosperoo \r\n\r\n2 x Honey I Shrunk the Kids \r\n\r\n2 x Kopi Sutra \r\n\r\n2 x Sweet Bundchen \r\n\r\n2 X Guji Liya \r\n\r\n\r\n(Coffee variants will be subject to stock availability at the time of fullfillment) 	Back by popular demand, the Happiness gift set consists of 10 individually packed drip coffee bags in auspicious "Ang Baos". Indulge in an assortment of Hook Coffee’s classics, including our limited edition Chinese New Year coffee, Prosperoo, that at one whiff and sip, would immediately remind you of delicious pineapple tarts!\r\n\r\nWhat this set contains:\r\n\r\n2 x Prosperoo \r\n\r\n2 x Honey I Shrunk the Kids \r\n\r\n2 x Kopi Sutra \r\n\r\n2 x Sweet Bundchen \r\n\r\n2 X Guji Liya \r\n\r\n\r\n(Coffee variants will be subject to stock availability at the time of fullfillment) 		Happiness 		set	f	500	f	f	0
18	Hario Hand Grinder	t	Hario Hand Grinder		#	45.00			t	#	#	Hario Hand Grinder		Don't let the simplicity fool you. This grinder is a wonderful addition to any coffee setup. The Mini Mill is not just a fiscally viable grinding option, but it is an effective way to grind your beans. The conical ceramic burrs and easily adjustable setting notch make this grinder a powerful tool at home or on the go. Its ceramic burrs will stay sharp and provide you with a suitable grind. The topmost receptacle holds up to 24 grams, allowing you to grind one or two cups at a time.	Don't let the simplicity fool you. This grinder is a wonderful addition to any coffee setup. The Mini Mill is not just a fiscally viable grinding option, but it is an effective way to grind your beans. The conical ceramic burrs and easily adjustable setting notch make this grinder a powerful tool at home or on the go. Its ceramic burrs will stay sharp and provide you with a suitable grind. The topmost receptacle holds up to 24 grams, allowing you to grind one or two cups at a time.		Hario Hand Grinder			f	500	t	f	0
20	Aeropress Filter Papers 	t	Aeropress Filter Papers 		#	8.00			t	#	#	Aeropress Filter Papers 		These bleached microfilters are an essential tool in aeropress brewing. Each filter has one use. Simply add into the aeropress filter cap to start brewing! Pre-wet for best results.	These bleached microfilters are an essential tool in aeropress brewing. Each filter has one use. Simply add into the aeropress filter cap to start brewing! Pre-wet for best results.		Aeropress Filter Papers 			f	500	t	f	0
21	Hario V60 Filter Papers (100)	t	Hario V60 Filter Papers (100)		#	8.00			t	#	#	Hario V60 Filter Papers (100)		These filters will accompany you on your pour-over journey. They fit a size 01 v60 and are easily disposable (1-3 cups at a time).	These filters will accompany you on your pour-over journey. They fit a size 01 v60 and are easily disposable (1-3 cups at a time).		Hario V60 Filter Papers (100)			f	500	t	f	0
22	Breville Dual Boiler	f	Breville Dual Boiler		#	2088.00			t	#	#	Breville Dual Boiler		No longer must you rely on machines that cost as much as a car. Consistent espresso is more than just possible with this machine. The Breville Dual Boiler gives the user an espresso experience like no other. Instead of constantly tampering with settings, buttons, and levers, the Breville allows you to customize just about everything from pre-infusion to shot volume and clean cycle. The dual boiler design keeps hot water at the ready. Easily adjust brew parameters and sit back. Your liquid gold in cup has arrived.\r\n\r\nFeatures: \r\n\r\n* Achieves the 4 elements of the Gold Standard\r\n* The first domestic machine to meet the Gold Standard\r\n\r\n- Simultaneous extration & texturing\r\n- PID control maintains extraction temp to +/-1°C\r\n- Low pressure pre-infusion\r\n- Stainless steel Dual Boilers\r\n- Includes razor dosing tool\r\n- Over Pressure Valve (OPV) limits maximum extraction pressure to 9 bars\r\n- Heated Group Head keeps temp stable from tank to cup\r\n- 15 bar Italian made pump\r\n- Integrated magnetic tamper\r\n- Backlit LCD interface	No longer must you rely on machines that cost as much as a car. Consistent espresso is more than just possible with this machine. The Breville Dual Boiler gives the user an espresso experience like no other. Instead of constantly tampering with settings, buttons, and levers, the Breville allows you to customize just about everything from pre-infusion to shot volume and clean cycle. The dual boiler design keeps hot water at the ready. Easily adjust brew parameters and sit back. Your liquid gold in cup has arrived.\r\n\r\nFeatures: \r\n\r\n* Achieves the 4 elements of the Gold Standard\r\n* The first domestic machine to meet the Gold Standard\r\n\r\n- Simultaneous extration & texturing\r\n- PID control maintains extraction temp to +/-1°C\r\n- Low pressure pre-infusion\r\n- Stainless steel Dual Boilers\r\n- Includes razor dosing tool\r\n- Over Pressure Valve (OPV) limits maximum extraction pressure to 9 bars\r\n- Heated Group Head keeps temp stable from tank to cup\r\n- 15 bar Italian made pump\r\n- Integrated magnetic tamper\r\n- Backlit LCD interface		Breville Dual Boiler			f	1500	t	f	0
39	Everything Chocolate 	t	Limited Edition Easter Gift Box 	A Celebration of Hook' most chocolatey coffees in one Eggcelent box\r\n\r\n\r\n	#	20.00	A Celebration of Hook' most chocolatey coffees in one Eggcelent box\r\n\r\n\r\n		t	#	#	Limited Edition Easter Gift Box 		A Celebration of Hook' most chocolatey coffees in one Eggcelent box. \r\n\r\n10 Individually wrapped drip coffee bags \r\n\r\n2 X Give Me S'mores\r\n2 X Sweet Bundchen \r\n2 X A Midsummers Night Dream\r\n2 X Shake Your Bun Bun \r\n2 X Speculose your Mind \r\n	A Celebration of Hook' most chocolatey coffees in one Eggcelent box. \r\n\r\n10 Individually wrapped drip coffee bags \r\n\r\n2 X Give Me S'mores\r\n2 X Sweet Bundchen \r\n2 X A Midsummers Night Dream\r\n2 X Shake Your Bun Bun \r\n2 X Speculose your Mind \r\n		Everything Chocolate 		set	f	500	t	f	0
19	Hario V60 Dripper	t	Hario V60 Dripper		#	8.00			t	#	#	Hario V60 Dripper		The v60 is one of the most reliable brew methods around. The ridged walls are angled at 60 degrees, maintaining a water flow that promotes a balanced and consistent cup of coffee. With this method, one can easily manipulate brew variables. The simple design allows the user to increase flow rate and agitation at will. The v60 method is used in homes and at coffee shops around the world.	The v60 is one of the most reliable brew methods around. The ridged walls are angled at 60 degrees, maintaining a water flow that promotes a balanced and consistent cup of coffee. With this method, one can easily manipulate brew variables. The simple design allows the user to increase flow rate and agitation at will. The v60 method is used in homes and at coffee shops around the world.		Hario V60 Dripper			f	500	t	f	0
23	Breville Oracle	f	Breville Oracle		#	3598.00			t	#	#	Breville Oracle		Breville's Oracle espresso machine is an automated wonder. The Oracle offers hands free dosing, tamping, and even milk texturing. With allocated engineering like the dedicated steam boilers and patented heat system, the Oracle will never run out of juice. With a competent and a powerful automated setup like this, espresso can be a part of the daily routine.\r\n\r\nFeatures:\r\n\r\nAuto & Mess Free - The integrated conical burr grinder automatically grinds, doses and tamps22 grams for a double shot, similar to the commercial machine in your favorite café.\r\n\r\nPrecise Espresso Extraction - Dual stainless steel boilers and heated group head, both regulated by our digital temperature control (PID) automatically delivers the water at precisely the right temperature, extracting maximum flavor potential. The Oracle™ also features an Over Pressure Valve (OPV). This commercial feature limits the maximum pressure throughout the extraction, helping prevent bitter flavors in the shot. It also has true low pressure pre-infusion, which gradually increases the pressure to gently expand the grinds for an even extraction.\r\n\r\nMicro-foam Milk - The automatic steam wand textures milk to your preferred taste and temperature, from silky smooth latte (less texture) to creamy cappuccino (more texture). Powered by a dedicated boiler, the auto steam wand delivers barista quality micro-foam that enhances the flavor of the coffee and is essential for creating latte art.\r\n\r\nOne Touch Americano - the innovative One Touch Americano feature delivers a double espresso, and then separately through a dedicated spout, fills the cup with hot water, the same way as any good commercial machine.	Breville's Oracle espresso machine is an automated wonder. The Oracle offers hands free dosing, tamping, and even milk texturing. With allocated engineering like the dedicated steam boilers and patented heat system, the Oracle will never run out of juice. With a competent and a powerful automated setup like this, espresso can be a part of the daily routine.\r\n\r\nFeatures:\r\n\r\nAuto & Mess Free - The integrated conical burr grinder automatically grinds, doses and tamps22 grams for a double shot, similar to the commercial machine in your favorite café.\r\n\r\nPrecise Espresso Extraction - Dual stainless steel boilers and heated group head, both regulated by our digital temperature control (PID) automatically delivers the water at precisely the right temperature, extracting maximum flavor potential. The Oracle™ also features an Over Pressure Valve (OPV). This commercial feature limits the maximum pressure throughout the extraction, helping prevent bitter flavors in the shot. It also has true low pressure pre-infusion, which gradually increases the pressure to gently expand the grinds for an even extraction.\r\n\r\nMicro-foam Milk - The automatic steam wand textures milk to your preferred taste and temperature, from silky smooth latte (less texture) to creamy cappuccino (more texture). Powered by a dedicated boiler, the auto steam wand delivers barista quality micro-foam that enhances the flavor of the coffee and is essential for creating latte art.\r\n\r\nOne Touch Americano - the innovative One Touch Americano feature delivers a double espresso, and then separately through a dedicated spout, fills the cup with hot water, the same way as any good commercial machine.		Breville Oracle			f	2000	t	f	0
25	Breville Smart Grinder Pro	f	Breville Smart Grinder Pro		#	398.00			t	#	#	Breville Smart Grinder Pro		You no longer must be smarter than your grinder. Breville's smart grinder thinks for you. The precision digital timer gives you the option of changing grind size on the fly, letting you choose from 60 different programmable grind settings as you please. The conical burrs grind the coffee evenly, allowing for an extremely impressive particle size distribution of coffee grounds. The Smartgrinder lets you take the reins to adapt to any situation quickly. Dialing in your brew should no longer be a problem.\r\n\r\n\r\nFeatures: \r\n\r\n* Dosing IQ™ delivers the precise amount every time\r\n* Precision Digital Timer allows users to adjust and program grind time in 0.2sec increments\r\n- Auto dosing system with manual adjustment option\r\n- Stainless steel conical burr griner\r\n- 25 grind settings\r\n- Hands free grinding\r\n- 450g bean hopper with locking system for bean transfer\r\n- Backlit LCD interface\r\n- Removable grind tray\r\n- Two portafilter cradles (50/54mm & 58mm)\r\n- 1650W	You no longer must be smarter than your grinder. Breville's smart grinder thinks for you. The precision digital timer gives you the option of changing grind size on the fly, letting you choose from 60 different programmable grind settings as you please. The conical burrs grind the coffee evenly, allowing for an extremely impressive particle size distribution of coffee grounds. The Smartgrinder lets you take the reins to adapt to any situation quickly. Dialing in your brew should no longer be a problem.\r\n\r\n\r\nFeatures: \r\n\r\n* Dosing IQ™ delivers the precise amount every time\r\n* Precision Digital Timer allows users to adjust and program grind time in 0.2sec increments\r\n- Auto dosing system with manual adjustment option\r\n- Stainless steel conical burr griner\r\n- 25 grind settings\r\n- Hands free grinding\r\n- 450g bean hopper with locking system for bean transfer\r\n- Backlit LCD interface\r\n- Removable grind tray\r\n- Two portafilter cradles (50/54mm & 58mm)\r\n- 1650W		Breville Smart Grinder Pro			f	800	t	f	0
24	Breville Infuser	f	Breville Infuser		#	998.00			t	#	#	Breville Infuser		The Infuser is a machine that will provide quality espresso without hurting your wallet. This machine features a pre-infusion function that seamlessly extracts the espresso to full bodied perfection. The Infuser automatically adjusts temperature after steaming, and it gives the user enough brew options to craft excellent espresso.\r\n\r\n\r\nFeatures:\r\n\r\n- PID temperature control\r\n- Low pressure pre-infusion\r\n- Pressure gauge to assist with optimum coffee extraction\r\n- Thermocoil system\r\n- 15 bar Italian made pump\r\n- Integrated magnetic tamper\r\n- Dedicated hot water wand\r\n- 54mm stainless steel portafilter\r\n- 1 hole flat steam tip	The Infuser is a machine that will provide quality espresso without hurting your wallet. This machine features a pre-infusion function that seamlessly extracts the espresso to full bodied perfection. The Infuser automatically adjusts temperature after steaming, and it gives the user enough brew options to craft excellent espresso.\r\n\r\n\r\nFeatures:\r\n\r\n- PID temperature control\r\n- Low pressure pre-infusion\r\n- Pressure gauge to assist with optimum coffee extraction\r\n- Thermocoil system\r\n- 15 bar Italian made pump\r\n- Integrated magnetic tamper\r\n- Dedicated hot water wand\r\n- 54mm stainless steel portafilter\r\n- 1 hole flat steam tip		Breville Infuser			f	1000	t	f	0
13	Prosperity 	t	Prosperoo Drip Coffee Bag Set	10 X Prosperoo Drip Coffee Bags 	#	18.00	10 X Prosperoo Drip Coffee Bags 		t	#	#	Prosperoo Drip Coffee Bag Set		The Prosperity gift set consists of 10 individually packed drip coffee bags in red auspicious "Ang Baos", featuring our limited edition Chinese New Year coffee, Prosperoo, that smells and tastes similar to delicious pineapple tarts. A perfect compliment to your favourite new year goodies! \r\n\r\nWhat this set contains:\r\n\r\n10 x Prosperoo	The Prosperity gift set consists of 10 individually packed drip coffee bags in red auspicious "Ang Baos", featuring our limited edition Chinese New Year coffee, Prosperoo, that smells and tastes similar to delicious pineapple tarts. A perfect compliment to your favourite new year goodies! \r\n\r\nWhat this set contains:\r\n\r\n10 x Prosperoo		Prosperity 		set	f	500	f	f	0
26	Bialetti Stovetop Moka Express (3cups) 	t	3 Cups		#	65.00			t	#	#	3 Cups		The moka pot is one of the most cherished and respected brew methods around the world. The brewing device is made up of an eight-sided aluminum body, allowing heat to distribute evenly and effectively. Once put on the stove, steam and pressure builds from the bottom chamber into the middle chamber holding the coffee. Eventually, the pressure pushes through to the final chamber. The resulting creamy espresso-like brew is something to behold. If you enjoy a heavy, full bodied brew, the Bialtti Moka pot is your friend.	The moka pot is one of the most cherished and respected brew methods around the world. The brewing device is made up of an eight-sided aluminum body, allowing heat to distribute evenly and effectively. Once put on the stove, steam and pressure builds from the bottom chamber into the middle chamber holding the coffee. Eventually, the pressure pushes through to the final chamber. The resulting creamy espresso-like brew is something to behold. If you enjoy a heavy, full bodied brew, the Bialtti Moka pot is your friend.		Bialetti Stovetop Moka Express (3cups) 			f	1000	t	f	0
38	Bodum Java French Press (White)	t	White (3cups)		#	40.00			t	#	#	White (3cups)		The French press has infiltrated kitchen counters around the globe. It's a classic immersion method that has been around for almost a century. Brewing with the French press is an easy ritual. After letting the grounds steep in the elegant glass chamber, just plunge the fine mesh filter through the coffee slurry. The result is a balanced cup with a heavy mouthfeel. 	The French press has infiltrated kitchen counters around the globe. It's a classic immersion method that has been around for almost a century. Brewing with the French press is an easy ritual. After letting the grounds steep in the elegant glass chamber, just plunge the fine mesh filter through the coffee slurry. The result is a balanced cup with a heavy mouthfeel. 		Bodum Java French Press (White)			f	500	t	f	0
27	Clever Dripper	t	Clever Dripper		#	30.00			t	#	#	Clever Dripper		The Clever Dripper by Abid, is a simple and powerful way to brew your morning cup. This mechanism features a solid plastic design: conical ridged body (holds 18 oz), handle, and an easy release valve. Also included is a lid and coaster. To brew, use Melitta Filters, pour water onto coffee grounds, and wait until the desired time to then place the Clever onto the rim of a decanter. Upon pressure, the mechanism will decant the delicious brew. Regardless of the simplicity, the Clever Dripper yields balanced and complex cups. Your specialty coffee experience need not look any further.	The Clever Dripper by Abid, is a simple and powerful way to brew your morning cup. This mechanism features a solid plastic design: conical ridged body (holds 18 oz), handle, and an easy release valve. Also included is a lid and coaster. To brew, use Melitta Filters, pour water onto coffee grounds, and wait until the desired time to then place the Clever onto the rim of a decanter. Upon pressure, the mechanism will decant the delicious brew. Regardless of the simplicity, the Clever Dripper yields balanced and complex cups. Your specialty coffee experience need not look any further.		Clever Dripper			f	500	t	f	0
40	Hario Cold Coffee Brewer 	t	-		#	48.00			t	#	#	-		The fuss free way to brew a perfect cold brew coffee. \r\n\r\nHook’s recommendation: Guji Liya (request to be ground for cold brew), steep in room temperature water for 15hrs, chill it overnight, and you are in for a real treat. \r\n\r\nHook’s tip: do not steep the coffee grounds in the bottle when you store it in the fridge after brewing, it will cause over extraction making the coffee overly-bitter! \r\n\r\nMyth: Cold brew coffee is brewed cold - it is not! It is brewed best with room tempt water	The fuss free way to brew a perfect cold brew coffee. \r\n\r\nHook’s recommendation: Guji Liya (request to be ground for cold brew), steep in room temperature water for 15hrs, chill it overnight, and you are in for a real treat. \r\n\r\nHook’s tip: do not steep the coffee grounds in the bottle when you store it in the fridge after brewing, it will cause over extraction making the coffee overly-bitter! \r\n\r\nMyth: Cold brew coffee is brewed cold - it is not! It is brewed best with room tempt water		Hario Cold Coffee Brewer 			f	1000	t	t	0
30	Kopi Sutra Drip Coffee Gift Set	t	10 x Drip Coffee Bags 		#	20.00			t	#	#	10 x Drip Coffee Bags 		10 Individually packed Kopi Sutra drip coffee bags in a beautiful giftable box\r\n	10 Individually packed Kopi Sutra drip coffee bags in a beautiful giftable box\r\n		Kopi Sutra Drip Coffee Gift Set		set	f	500	t	f	0
28	Sweet Bundchen Drip Coffee Gift Set 	t	10 X Drip Coffee Bags		#	20.00			t	#	#	10 X Drip Coffee Bags		10 Individually packed Sweet Bundchen drip coffee bags in a beautiful giftable box	10 Individually packed Sweet Bundchen drip coffee bags in a beautiful giftable box		Sweet Bundchen Drip Coffee Gift Set 		set	f	500	t	f	0
31	A Midsummer Night Dream Drip Coffee Set 	t	10 X Drip Coffee Bags 		#	20.00			t	#	#	10 X Drip Coffee Bags 		10 Individually packed A Midsummer Night Dream drip coffee bags in a beautiful giftable box\r\n	10 Individually packed A Midsummer Night Dream drip coffee bags in a beautiful giftable box\r\n		A Midsummer Night Dream Drip Coffee Set 		set	f	500	t	f	0
32	Guji Liya Drip Coffee Gift Set 	t	10 x Drip Coffee Bags 		#	20.00			t	#	#	10 x Drip Coffee Bags 		10 Individually packed Guji Liya drip coffee bags in a beautiful giftable box\r\n	10 Individually packed Guji Liya drip coffee bags in a beautiful giftable box\r\n		Guji Liya Drip Coffee Gift Set 		set	f	500	t	f	0
33	Ciao Bella Drip Coffee Gift Set	t	10 x Drip Coffee Bags 		#	20.00			t	#	#	10 x Drip Coffee Bags 		10 Individually packed Ciao Bella drip coffee bags in a beautiful giftable box	10 Individually packed Ciao Bella drip coffee bags in a beautiful giftable box		Ciao Bella Drip Coffee Gift Set		set	f	500	t	f	0
34	Honey I Shrunk the Kids II Drip Coffee Gift Set	t	10 x Drip Coffee Bags 		#	20.00			t	#	#	10 x Drip Coffee Bags 		10 Individually packed Honey I Shrunk the Kid II drip coffee bags in a beautiful giftable box\r\n	10 Individually packed Honey I Shrunk the Kid II drip coffee bags in a beautiful giftable box\r\n		Honey I Shrunk the Kids II Drip Coffee Gift Set		set	f	500	t	f	0
35	Speculose your mind Drip Coffee Gift Sets	t	10 X Drip Coffee Bags 		#	20.00			t	#	#	10 X Drip Coffee Bags 		10 Individually packed Speculose Your Mind drip coffee bags in a beautiful giftable box\r\n	10 Individually packed Speculose Your Mind drip coffee bags in a beautiful giftable box\r\n		Speculose your mind Drip Coffee Gift Sets		set	f	500	t	f	0
36	Drip Coffee Variety Pack	t	10 x Drip Coffee Bag		#	20.00			t	#	#	10 x Drip Coffee Bag		Our most popular gift set, the variety pack is a curation of Hook Coffee's top sellers in one awesome box! \r\n\r\nFor customised gift sets, drop us a note at hola@hookcoffee.com.sg! 	Our most popular gift set, the variety pack is a curation of Hook Coffee's top sellers in one awesome box! \r\n\r\nFor customised gift sets, drop us a note at hola@hookcoffee.com.sg! 		Drip Coffee Variety Pack		set	f	500	t	f	0
29	Jamazing Drip Coffee Gift Set	t	10 x Drip Coffee Bags 		#	20.00			f	#	#	10 x Drip Coffee Bags 		10 Individually packed Jamazing drip coffee bags in a beautiful giftable box\r\n	10 Individually packed Jamazing drip coffee bags in a beautiful giftable box\r\n		Jamazing Drip Coffee Gift Set		set	f	500	f	f	0
37	Bodum Java French Press (Black)	t	Black (3cups)		#	40.00			t	#	#	Black (3cups)		The French press has infiltrated kitchen counters around the globe. It's a classic immersion method that has been around for almost a century. Brewing with the French press is an easy ritual. After letting the grounds steep in the elegant glass chamber, just plunge the fine mesh filter through the coffee slurry. The result is a balanced cup with a heavy mouthfeel. 	The French press has infiltrated kitchen counters around the globe. It's a classic immersion method that has been around for almost a century. Brewing with the French press is an easy ritual. After letting the grounds steep in the elegant glass chamber, just plunge the fine mesh filter through the coffee slurry. The result is a balanced cup with a heavy mouthfeel. 		Bodum Java French Press (Black)			f	500	t	f	0
\.


--
-- Data for Name: coffees_coffeegear_brew_methods; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_coffeegear_brew_methods (id, coffeegear_id, brewmethod_id) FROM stdin;
1	16	3
2	17	2
3	18	7
6	20	3
7	21	2
12	22	7
14	23	7
16	25	7
17	24	7
18	13	1
19	13	7
20	15	1
21	15	7
22	14	1
23	14	7
32	30	2
33	28	2
35	31	2
36	32	2
37	33	2
38	34	2
39	35	2
47	29	2
48	26	5
49	37	4
50	38	4
51	1	2
52	2	2
53	3	7
54	27	2
63	36	2
65	19	2
70	40	8
71	39	2
\.


--
-- Name: coffees_coffeegear_brew_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_coffeegear_brew_methods_id_seq', 71, true);


--
-- Name: coffees_coffeegear_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_coffeegear_id_seq', 40, true);


--
-- Data for Name: coffees_coffeegearcolor; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_coffeegearcolor (id, name) FROM stdin;
1	Beech 
2	White 
3	Blue 
4	Red
5	Black 
6	Walnut 
7	Beige 
\.


--
-- Name: coffees_coffeegearcolor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_coffeegearcolor_id_seq', 7, true);


--
-- Data for Name: coffees_coffeegearimage; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_coffeegearimage (id, image, coffee_gear_id, color_id) FROM stdin;
26	./set_a_opimized.png	4	\N
27	./set_b_opimized.png	5	\N
28	./set_c_opimized.png	6	\N
29	./set_d_opimized.png	7	\N
30	./set_e_opimized.png	8	\N
31	./set_f_opimized.png	9	\N
32	./set_g_optimized.png	10	\N
33	./set_h_otimized.png	11	\N
34	./set_i_otimized.png	12	\N
35	./Prosperity_.png	13	\N
36	./Happiness_.png	14	\N
37	./Longeivity.png	15	\N
38	./E1_-_Aeropress.jpg	16	\N
39	./E2_-_Hario_Drip_Coffee_Scale.jpg	17	\N
40	./Drip_Coffee_Scale_no.2.jpg	17	\N
41	./E3-_Hario_Hand_Grinder.jpg	18	\N
43	./E5-_Aeropress_filter_Papers_350.jpg	20	\N
44	./E6_-_Harip_V60_01_Filter_Papers_Unbleached.jpg	21	\N
16	./atomi_marina_02_Nt1EH3D_AMUzLPG.jpg	1	\N
18	./marina_coffee_BE.jpg	1	7
19	./marina_coffee_NV.jpg	1	3
20	./marina_coffee_RD.jpg	1	4
21	./marina_coffee_WH.jpg	1	2
22	./atomi_donut_coffee_dripper.jpg	2	\N
23	./atomi_donut_coffee_dripper_02_EjfG7WG_ZedDtZB.jpg	2	2
24	./donut_coffee_dripper.jpg	2	5
25	./TORCH.jpg	2	2
13	./HOUSE_MEASURE_BEECH.jpg	3	1
12	./atomi_house_measure_01_QKbTdyB.jpg	3	\N
45	./M1_-_Breville_Dual_Boiler.jpg	22	\N
46	./M2_-_Breville_Oracle.jpg	23	\N
47	./M3_-_Infuser.jpg	24	\N
48	./M4-_Breville_Smart_Grinder.jpg	25	\N
49	./12726544_1041794012523224_779908986_n.jpg	26	\N
50	./clever-coffee-dripper-new-model.jpg	27	\N
51	./Sweet_Bundchen_Gift_Set_U1VgyPA.jpg	28	\N
52	./Jamazing_Giftset.jpg	29	\N
53	./Kopi_Sutra_Gift_Set.jpg	30	\N
54	./A_Midsummer_Night_Dream_Gift_Set.jpg	31	\N
55	./Guji_Liya_Gift_Set.jpg	32	\N
56	./Ciao_Bella_Gift_Sets.jpg	33	\N
57	./Honey_I_Shrunk_the_Kids_Gift_Set.jpg	34	\N
58	./Speculose_your_mind_gift_sets.jpg	35	\N
63	./IMG_4212_xPJW9wz.jpg	36	\N
42	./VD-01T_530X600.jpg	19	\N
64	./bodum-java-black-3-cup.jpg	37	\N
65	./bodum-java-white-3-cup.jpg	38	\N
66	./Everything_chocolate_box___.png	39	\N
67	./FIC-70-MC_530x600.jpg	40	\N
68	./FIC_-_3_530x600.jpg	40	\N
\.


--
-- Name: coffees_coffeegearimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_coffeegearimage_id_seq', 68, true);


--
-- Data for Name: coffees_coffeesticker; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_coffeesticker (id, name, description, caption, hashtag, sticker, coffee_id) FROM stdin;
3	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/sweet_bundchen_1024.png	13
2	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/peara_peara_1024.png	19
9	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/birds_of_paradise_shotpods_1024.png	23
10	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/hakuna_matata_shotpods_1024.png	22
11	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/godfather_shotpods_1024.png	27
1	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/kopi_sutra_1024.png	11
8	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/sweet_bundchen_shotpods_1024.png	21
7	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/specu_lose_1024.png	20
6	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/guji_liya_1024.png	14
5	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/ciao_bella_1024.png	16
4	Hook Coffee Singapore	We deliver specialty coffee, sourced from the world's best farms and hand-roasted locally in Singapore. Your fresh and delicious coffee is sent out to you within a week of roasting, just the way you want it, and straight to your mailbox! #IAMHOOKED	HOOKCOFFEE.COM.SG	#HOOKCOFFEESG	stickers/honey_i_shunk_the_kids_1024.png	26
\.


--
-- Name: coffees_coffeesticker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_coffeesticker_id_seq', 11, true);


--
-- Data for Name: coffees_coffeetype; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_coffeetype (id, name, maker, region, country, taste, more_taste, body, roasted_on, shipping_till, amount, profile, img, description, altitude, varietal, process, mode, special, label, label_drip, label_position, amount_one_off, intensity, decaf, altitude_en, altitude_zh_hans, description_en, description_zh_hans, maker_en, maker_zh_hans, more_taste_en, more_taste_zh_hans, process_en, process_zh_hans, region_en, region_zh_hans, taste_en, taste_zh_hans, varietal_en, varietal_zh_hans, weight, acidity, blend, discovery, unavailable, img_moreinfo) FROM stdin;
2	Piña Loca	Carlos Alberto Ulchur	Inzá, Cauca	CO	Nutty and Tropical	Imagine that delicate balance of juicy sweetness and tartness of caramelised roasted nuts! That's exactly what you’ll tastes in this coffee! It also happens to be our favourite to brew with using a Dripper, Aeropress, or French Press!	2	2016-04-04	2016-04-11	14.00	"1"=>"3", "2"=>"3", "3"=>"4", "4"=>"1", "5"=>"1", "6"=>"4"	./Piña_Loca.jpg	Aside from the rich nutty flavour, the taste of tropical fruits like pineapples is so distinct in this coffee that we couldn't resist naming it Piña Loca, which translates to "crazy pineapple". \r\n\r\nPiña Loca was produced and processed by Carlos Alberto Ulchur in his microlot (an area of only 3 hectares!) located in the municipality of Inzá, Department of Cauca. Carlos's microlot is perched on Macizo Colombiano (the Colombian Plateau), surrounding the high peaks of Tolima and Huila, and overlooks the Pacific Ocean. The area is an important source of water and wildlife, and we hear the minerals carried by the sea breeze contributes to the flavours in the coffees.\r\n\r\nCarlos is a member of ASORCAFE (Asociación de Productores de Café del Oriente Caucano) which represents some 450 producers across Cauca. His microlot stands out because his beans demonstrate exceptional and distinct qualities. Piña Loca is a showcase of what a small microlot from this remote and often overlooked region of Colombia has to offer.\r\n\r\n	1900m	Caturra & Colombia	Fully Washed	f	f	labels/2.pdf	labels/2d.pdf	1	18.00	6	f	1900m	1900 米	Aside from the rich nutty flavour, the taste of tropical fruits like pineapples is so distinct in this coffee that we couldn't resist naming it Piña Loca, which translates to "crazy pineapple". \r\n\r\nPiña Loca was produced and processed by Carlos Alberto Ulchur in his microlot (an area of only 3 hectares!) located in the municipality of Inzá, Department of Cauca. Carlos's microlot is perched on Macizo Colombiano (the Colombian Plateau), surrounding the high peaks of Tolima and Huila, and overlooks the Pacific Ocean. The area is an important source of water and wildlife, and we hear the minerals carried by the sea breeze contributes to the flavours in the coffees.\r\n\r\nCarlos is a member of ASORCAFE (Asociación de Productores de Café del Oriente Caucano) which represents some 450 producers across Cauca. His microlot stands out because his beans demonstrate exceptional and distinct qualities. Piña Loca is a showcase of what a small microlot from this remote and often overlooked region of Colombia has to offer.	Aside from the rich nutty flavour, the taste of tropical fruits like pineapples is so distinct in this coffee that we couldn't resist naming it Piña Loca, which translates to "crazy pineapple". \r\n\r\nPiña Loca was produced and processed by Carlos Alberto Ulchur in his microlot (an area of only 3 hectares!) located in the municipality of Inzá, Department of Cauca. Carlos's microlot is perched on Macizo Colombiano (the Colombian Plateau), surrounding the high peaks of Tolima and Huila, and overlooks the Pacific Ocean. The area is an important source of water and wildlife, and we hear the minerals carried by the sea breeze contributes to the flavours in the coffees.\r\n\r\nCarlos is a member of ASORCAFE (Asociación de Productores de Café del Oriente Caucano) which represents some 450 producers across Cauca. His microlot stands out because his beans demonstrate exceptional and distinct qualities. Piña Loca is a showcase of what a small microlot from this remote and often overlooked region of Colombia has to offer.	Carlos Alberto Ulchur	Carlos Alberto Ulchur	Imagine that delicate balance of juicy sweetness and tartness of caramelised roasted nuts! That's exactly what you’ll tastes in this coffee! It also happens to be our favourite to brew with using a Dripper, Aeropress, or French Press!	Imagine that delicate balance of juicy sweetness and tartness of caramelised roasted nuts! That's exactly what you’ll tastes in this coffee! It also happens to be our favourite to brew with using a Dripper, Aeropress, or French Press!	Fully Washed	水洗处理法	Inzá, Cauca	Inzá, Cauca	Nutty and Tropical	Nutty and Tropical	Caturra & Colombia	Caturra & Colombia	200	Medium	f	f	f	\N
3	Nevernever	Hook's Espresso Blend 	Brazil 	CR	Chocolatey, balanced and never grows old	A classic blend with a buttery nuttiness and dark chocolate. This is perfect for an Espresso based drink. 	4	2016-09-18	2016-09-25	14.00	"1"=>"1", "2"=>"5", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./Neverneverland.jpg	Just like Peter Pan, this ultimate classic espresso blend is one that never grows old. Naturally we named it Neverneverland. Never mind the irony that Hook’s the protagonist here!\r\n\r\nNeverneverland is a perfect marriage of Hook’s two favourite coffee - Sweet Bundchen and Honey I Shrunk the kids. The result? A perfectly balanced cup - bold, smooth, and chocolatey - exactly what you're looking for in a your everyday espresso. \r\n\r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nHoney I Shrunk the kids was grown in Los Santos and processed at Beneficio del Rio Tarrazú. Located on the Tarrazú River, Beneficio del Rio Tarrazú coffee mill uses clean, hydroelectric power generated on the farm, and has been awarded the Bandera Ecologica and proclaimed a “protector of the environment” by the government of Costa Rica for its progressive design and operation. No honey is actually involved but the "honey process" is a method particular to the best mills in Costa Rica, where ‘honey’ relates to the ‘mucilage’ (sticky substance) on the coffee bean.	Different Altitudes	Mixed Varietals	Honey Processed and Natural	f	f	labels/Neverneverland__Jbt3p3b.pdf	labels/Neverneverland_DB__5AWv8tF.pdf	2	18.00	6	f	Different Altitudes	Different Altitudes	Just like Peter Pan, this ultimate classic espresso blend is one that never grows old. Naturally we named it Neverneverland. Never mind the irony that Hook’s the protagonist here!\r\n\r\nNeverneverland is a perfect marriage of Hook’s two favourite coffee - Sweet Bundchen and Honey I Shrunk the kids. The result? A perfectly balanced cup - bold, smooth, and chocolatey - exactly what you're looking for in a your everyday espresso. \r\n\r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nHoney I Shrunk the kids was grown in Los Santos and processed at Beneficio del Rio Tarrazú. Located on the Tarrazú River, Beneficio del Rio Tarrazú coffee mill uses clean, hydroelectric power generated on the farm, and has been awarded the Bandera Ecologica and proclaimed a “protector of the environment” by the government of Costa Rica for its progressive design and operation. No honey is actually involved but the "honey process" is a method particular to the best mills in Costa Rica, where ‘honey’ relates to the ‘mucilage’ (sticky substance) on the coffee bean.	Just like Peter Pan, this ultimate classic espresso blend is one that never grows old. Naturally we named it Neverneverland. Never mind the irony that Hook’s the protagonist here!\r\n\r\nNeverneverland is a perfect marriage of Hook’s two favourite coffee - Sweet Bundchen and Honey I Shrunk the kids. The result? A perfectly balanced cup - bold, smooth, and chocolatey - exactly what you're looking for in a your everyday espresso. \r\n\r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nHoney I Shrunk the kids was grown in Los Santos and processed at Beneficio del Rio Tarrazú. Located on the Tarrazú River, Beneficio del Rio Tarrazú coffee mill uses clean, hydroelectric power generated on the farm, and has been awarded the Bandera Ecologica and proclaimed a “protector of the environment” by the government of Costa Rica for its progressive design and operation. No honey is actually involved but the "honey process" is a method particular to the best mills in Costa Rica, where ‘honey’ relates to the ‘mucilage’ (sticky substance) on the coffee bean.	Hook's Espresso Blend 	Hook's Espresso Blend 	A classic blend with a buttery nuttiness and dark chocolate. This is perfect for an Espresso based drink. 	A classic blend with a buttery nuttiness and dark chocolate. This is perfect for an Espresso based drink. 	Honey Processed and Natural	Honey Processed and Natural	Brazil	Brazil	Chocolatey, balanced and never grows old	Chocolatey, balanced and never grows old	Mixed Varietals	Mixed Varietals	200	Medium	f	f	f	\N
29	Decaf Amigo	GRAPOS Co-operative 	Chiapas	MX	Freshly Baked Malted Pretzels	Sometimes it’s ok to slow down and enjoy a caffeine-free experience. Indulge in this delicious and comforting decaf coffee that tastes like freshly baked malted pretzels when hot, and like refreshing coffee beer when iced! Best enjoyed black, without milk.	1	2016-08-28	2016-12-25	14.00	"1"=>"2", "2"=>"2", "3"=>"2", "4"=>"2", "5"=>"2", "6"=>"2"	./decafamigo.jpg	This coffee was grown on micro-lot farms belonging to the Grupo de Asesores de Producción Orgánica y Sustentable (GRAPOS) in Chiapas, Mexico. There are currently about 2,600 of these micro lot farms under the GRAPOS cooperative, where support is given to these farmers in coffee rush mitigation and prevention as well as supporting crop diversification.\r\n\r\nThis coffee has been decaffeinated using the Mexican Mountain Water Process, an all natural process where the beans are soaked in hot water to remove caffeine and oils, leaving the coffee 99% caffeine free. Oils are then being returned to the coffee bean, preserving the original characteristics, aroma and flavour of the green coffee.\r\n\r\nThe beans are also 100% organic.	1,200 - 1,600m	Caturra, Carillo, Bourbon	Fully Washed	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	t	1,200 - 1,600m	1,200 - 1,600 米	This coffee was grown on micro-lot farms belonging to the Grupo de Asesores de Producción Orgánica y Sustentable (GRAPOS) in Chiapas, Mexico. There are currently about 2,600 of these micro lot farms under the GRAPOS cooperative, where support is given to these farmers in coffee rush mitigation and prevention as well as supporting crop diversification.\r\n\r\nThis coffee has been decaffeinated using the Mexican Mountain Water Process, an all natural process where the beans are soaked in hot water to remove caffeine and oils, leaving the coffee 99% caffeine free. Oils are then being returned to the coffee bean, preserving the original characteristics, aroma and flavour of the green coffee.\r\n\r\nThe beans are also 100% organic.	This coffee was grown on micro-lot farms belonging to the Grupo de Asesores de Producción Orgánica y Sustentable (GRAPOS) in Chiapas, Mexico. There are currently about 2,600 of these micro lot farms under the GRAPOS cooperative, where support is given to these farmers in coffee rush mitigation and prevention as well as supporting crop diversification.\r\n\r\nThis coffee has been decaffeinated using the Mexican Mountain Water Process, an all natural process where the beans are soaked in hot water to remove caffeine and oils, leaving the coffee 99% caffeine free. Oils are then being returned to the coffee bean, preserving the original characteristics, aroma and flavour of the green coffee.\r\n\r\nThe beans are also 100% organic.	GRAPOS Co-operative 	GRAPOS 合作社	Sometimes it’s ok to slow down and enjoy a caffeine-free experience. Indulge in this delicious and comforting decaf coffee that tastes like freshly baked malted pretzels when hot, and like refreshing coffee beer when iced! Best enjoyed black, without milk.	Sometimes it’s ok to slow down and enjoy a caffeine-free experience. Indulge in this delicious and comforting decaf coffee that tastes like freshly baked malted pretzels when hot, and like refreshing coffee beer when iced! Best enjoyed black, without milk.	Fully Washed	水洗处理法	Chiapas	恰帕斯	Freshly Baked Malted Pretzels	新鲜出炉的麦芽椒盐卷饼	Caturra, Carillo, Bourbon	Caturra, Carillo, Bourbon	200	Medium	f	f	f	\N
15	Hakuna Matata (Kenya AA)	Asali Co-op	Thika	KE	Blackcurrant Macarons with a vanilla and caramel finish	Imagine juicy sweet blackcurrants bursting in your mouth, a subtle almond nuttiness, and an elegant vanilla & caramel finish. 	3	2016-05-30	2016-06-06	22.00	"1"=>"5", "2"=>"4", "3"=>"3", "4"=>"2", "5"=>"4", "6"=>"3"	./Hakuna_Matata.jpg	If you’re familiar with Disney’s Lion King, you’ll know that we named this coffee after the theme song, Hakuna Matata, which means “No Worries” (in Swahili language). And if you just had one sip of this coffee, you would understand why — it tastes and smells like a miracle, and would chase all your blues away.\r\n \r\nKenya’s red-orange acidic soils coupled with the region’s moderate climate and equatorial sunlight allow Kenya to be perhaps the world’s most consistent producer of world-class specialty coffees. To add to that, Hakuna Matata was grown in the foothills of Aberdare Ranges, a UNESCO World Heritage Site. The local custom of long (multi-day) wet fermentation is believed to contribute significantly to enhancing the natural fruit derived flavours and clean cup profile in the coffee. \r\n \r\nAs some of the world’s finest gourmet and organic coffees, these beans were carefully graded after harvest. The beans are first sorted and rated by bean size as well as shape, color, and density. A general rule with Kenyan coffee beans is that the bigger the beans, the more essential oils there are and this enhances the tastes and aromas. Kenya AA is the highest-graded and are about a quarter inch in diameter. \r\n \r\nKenya has one of the most transparent and rigid buying systems in the world due to strict laws in place protecting the coffee industry. Farmers are organised by cooperative structures (each farmer has 0.5-3 acres), such as the Asali co-op that produced these beans. A co-op usually serves a number of processing stations - each station servicing surrounding smallholder farmers. ‘Market agents’ act as representatives to the farmers throughout the chain. These agents are a very important step in connecting the farmer to the market. The agents and farmers work together to set the reserve price at auction. The prices are typically high, especially for the Kenya AA beans, and these earnings return to the co-ops and go toward finance, education, and providing inputs and support for the local coffee farmers.	1,675 to 1,750 m	SL28 and SL34	Fully Washed	f	t	labels/hakuna.pdf	labels/hakuna_drip.pdf	2	18.00	6	f	1,675 to 1,750 m	1,675 - 1,750 米	If you’re familiar with Disney’s Lion King, you’ll know that we named this coffee after the theme song, Hakuna Matata, which means “No Worries” (in Swahili language). And if you just had one sip of this coffee, you would understand why — it tastes and smells like a miracle, and would chase all your blues away.\r\n \r\nKenya’s red-orange acidic soils coupled with the region’s moderate climate and equatorial sunlight allow Kenya to be perhaps the world’s most consistent producer of world-class specialty coffees. To add to that, Hakuna Matata was grown in the foothills of Aberdare Ranges, a UNESCO World Heritage Site. The local custom of long (multi-day) wet fermentation is believed to contribute significantly to enhancing the natural fruit derived flavours and clean cup profile in the coffee. \r\n \r\nAs some of the world’s finest gourmet and organic coffees, these beans were carefully graded after harvest. The beans are first sorted and rated by bean size as well as shape, color, and density. A general rule with Kenyan coffee beans is that the bigger the beans, the more essential oils there are and this enhances the tastes and aromas. Kenya AA is the highest-graded and are about a quarter inch in diameter. \r\n \r\nKenya has one of the most transparent and rigid buying systems in the world due to strict laws in place protecting the coffee industry. Farmers are organised by cooperative structures (each farmer has 0.5-3 acres), such as the Asali co-op that produced these beans. A co-op usually serves a number of processing stations - each station servicing surrounding smallholder farmers. ‘Market agents’ act as representatives to the farmers throughout the chain. These agents are a very important step in connecting the farmer to the market. The agents and farmers work together to set the reserve price at auction. The prices are typically high, especially for the Kenya AA beans, and these earnings return to the co-ops and go toward finance, education, and providing inputs and support for the local coffee farmers.	If you’re familiar with Disney’s Lion King, you’ll know that we named this coffee after the theme song, Hakuna Matata, which means “No Worries” (in Swahili language). And if you just had one sip of this coffee, you would understand why — it tastes and smells like a miracle, and would chase all your blues away.\r\n \r\nKenya’s red-orange acidic soils coupled with the region’s moderate climate and equatorial sunlight allow Kenya to be perhaps the world’s most consistent producer of world-class specialty coffees. To add to that, Hakuna Matata was grown in the foothills of Aberdare Ranges, a UNESCO World Heritage Site. The local custom of long (multi-day) wet fermentation is believed to contribute significantly to enhancing the natural fruit derived flavours and clean cup profile in the coffee. \r\n \r\nAs some of the world’s finest gourmet and organic coffees, these beans were carefully graded after harvest. The beans are first sorted and rated by bean size as well as shape, color, and density. A general rule with Kenyan coffee beans is that the bigger the beans, the more essential oils there are and this enhances the tastes and aromas. Kenya AA is the highest-graded and are about a quarter inch in diameter. \r\n \r\nKenya has one of the most transparent and rigid buying systems in the world due to strict laws in place protecting the coffee industry. Farmers are organised by cooperative structures (each farmer has 0.5-3 acres), such as the Asali co-op that produced these beans. A co-op usually serves a number of processing stations - each station servicing surrounding smallholder farmers. ‘Market agents’ act as representatives to the farmers throughout the chain. These agents are a very important step in connecting the farmer to the market. The agents and farmers work together to set the reserve price at auction. The prices are typically high, especially for the Kenya AA beans, and these earnings return to the co-ops and go toward finance, education, and providing inputs and support for the local coffee farmers.	Asali Co-op	Asali 合作社	Imagine juicy sweet blackcurrants bursting in your mouth, a subtle almond nuttiness, and an elegant vanilla & caramel finish. 	Imagine juicy sweet blackcurrants bursting in your mouth, a subtle almond nuttiness, and an elegant vanilla & caramel finish. 	Fully Washed	水洗处理法	Thika	锡卡	Blackcurrant Macarons with a vanilla and caramel finish	黑加仑马卡龙，香草和焦糖口味	SL28 and SL34	SL28 and SL34	200	Medium	f	f	f	\N
17	Taster 3x80g	Taster 3x80g	Taster 3x80g	AF	Taster 3x80g	Taster 3x80g	3	2016-04-21	2016-04-21	18.00	"0"=>"0"	./taster3x80g.jpg	Taster 3x80g	1256m	Arabica	Natural	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	1256m	1256 米	Taster 3x80g	Taster 3x80g	Taster 3x80g	Taster 3x80g	Taster 3x80g	Taster 3x80g	Natural	Natural	Taster 3x80g	Taster 3x80g	Taster 3x80g	Taster 3x80g	Arabica	Arabica	200	Medium	f	f	f	\N
7	Lunar Gift Set	Hook Coffee Team	Hook Coffee	SG	...	...	4	2016-01-31	2016-02-01	28.00	"0"=>"0"	./IMG_3140.JPG	A limited edition Lunar New Year blend that tastes like pineapple tarts & nuts, perfectly paired with an exclusive red Hario V60 dripper	...	...	...	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	...	...	A limited edition Lunar New Year blend that tastes like pineapple tarts & nuts, perfectly paired with an exclusive red Hario V60 dripper	A limited edition Lunar New Year blend that tastes like pineapple tarts & nuts, perfectly paired with an exclusive red Hario V60 dripper	Hook Coffee Team	Hook Coffee Team	...	...	...	...	Hook Coffee	Hook Coffee	...	...	...	...	200	Medium	f	f	f	\N
6	Taster pack	Hook Coffee	Mix	SG	Mix	Mix	3	2016-02-01	2016-02-08	7.00	"0"=>"0"	./Drip_Bag_Taster_Pack_2.jpg	Mix	Mix	Mix	Mix	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	Mix	Mix	Mix	Mix	Hook Coffee	Hook Coffee	Mix	Mix	Mix	Mix	Mix	Mix	Mix	Mix	Mix	Mix	200	Medium	f	f	f	\N
4	La Dulce Vida	The Alvarez Family	Santa Ana Volcano	SV	Ripened Cherry & Peach Compote	A delicate balance of sweetness and tartness of cherries & peaches with a juicy mouthfeel. It’s no wonder this coffee won the Cup of Excellence (the most prestigious award for specialty coffees worldwide)! Best brewed using a Dripper or the Aeropress.	3	2016-04-04	2016-04-11	14.00	"1"=>"4", "2"=>"1", "3"=>"2", "4"=>"1", "5"=>"1", "6"=>"4"	./La_Dulce_Vida.jpg	La Dulce Vida, meaning The Sweet Life, is representative of the delicate natural sweetness of this coffee, and reminiscent of its light and whimsical character.\r\n\r\nThe Alvarez family has been growing coffee in the lush green hills of Santa Ana for over 100 years and across 4 generations. Their award-winning farms are in the west of the country, around the Santa Ana volcano. It's the rich volcanic soils and mild climate that provide the ideal conditions for growing these delicious coffees. La Dulce Vida comes from two small neighbouring farms (51 hectares in total). The beans are carefully hand-picked and collected in traditional hand-woven baskets from December until March by pickers who have been specially trained to select only the best and fully-mature coffee cherries - the more mature, the sweeter.\r\n\r\nThe El Borbollon mill, where La Dulce Vida is processed, is managed by Eduardo Alvarez who proudly claims that "coffee runs in his blood". Under Eduardo's direction, the mill has had much success in accessing specialty coffee markets. In fact, Eduardo's hard work and advocacy have enabled many farms in the area to win several Cup of Excellence competitions, including the farm where La Dulce Vida come from.\r\n\r\nThe Alvareza family farms and mill offer social support to local communities and have recently been working with local NGO Fundación Salvadoreña para la Salud y el Desarrollo Humano (FUSAL) to help tackle child malnutrition. The family is also committed to developing sustainable practices in order to protect and preserve the environment, particularly the trees that provide habitation for the region's native birds.	1500m	Red Bourbon	Fully Washed	f	f	labels/La_Dulce_Vida_.pdf	labels/La_Dulce_Vida_DB.pdf	2	18.00	6	f	1500m	1500 米	La Dulce Vida, meaning The Sweet Life, is representative of the delicate natural sweetness of this coffee, and reminiscent of its light and whimsical character.\r\n\r\nThe Alvarez family has been growing coffee in the lush green hills of Santa Ana for over 100 years and across 4 generations. Their award-winning farms are in the west of the country, around the Santa Ana volcano. It's the rich volcanic soils and mild climate that provide the ideal conditions for growing these delicious coffees. La Dulce Vida comes from two small neighbouring farms (51 hectares in total). The beans are carefully hand-picked and collected in traditional hand-woven baskets from December until March by pickers who have been specially trained to select only the best and fully-mature coffee cherries - the more mature, the sweeter.\r\n\r\nThe El Borbollon mill, where La Dulce Vida is processed, is managed by Eduardo Alvarez who proudly claims that "coffee runs in his blood". Under Eduardo's direction, the mill has had much success in accessing specialty coffee markets. In fact, Eduardo's hard work and advocacy have enabled many farms in the area to win several Cup of Excellence competitions, including the farm where La Dulce Vida come from.\r\n\r\nThe Alvareza family farms and mill offer social support to local communities and have recently been working with local NGO Fundación Salvadoreña para la Salud y el Desarrollo Humano (FUSAL) to help tackle child malnutrition. The family is also committed to developing sustainable practices in order to protect and preserve the environment, particularly the trees that provide habitation for the region's native birds.	La Dulce Vida, meaning The Sweet Life, is representative of the delicate natural sweetness of this coffee, and reminiscent of its light and whimsical character.\r\n\r\nThe Alvarez family has been growing coffee in the lush green hills of Santa Ana for over 100 years and across 4 generations. Their award-winning farms are in the west of the country, around the Santa Ana volcano. It's the rich volcanic soils and mild climate that provide the ideal conditions for growing these delicious coffees. La Dulce Vida comes from two small neighbouring farms (51 hectares in total). The beans are carefully hand-picked and collected in traditional hand-woven baskets from December until March by pickers who have been specially trained to select only the best and fully-mature coffee cherries - the more mature, the sweeter.\r\n\r\nThe El Borbollon mill, where La Dulce Vida is processed, is managed by Eduardo Alvarez who proudly claims that "coffee runs in his blood". Under Eduardo's direction, the mill has had much success in accessing specialty coffee markets. In fact, Eduardo's hard work and advocacy have enabled many farms in the area to win several Cup of Excellence competitions, including the farm where La Dulce Vida come from.\r\n\r\nThe Alvareza family farms and mill offer social support to local communities and have recently been working with local NGO Fundación Salvadoreña para la Salud y el Desarrollo Humano (FUSAL) to help tackle child malnutrition. The family is also committed to developing sustainable practices in order to protect and preserve the environment, particularly the trees that provide habitation for the region's native birds.	The Alvarez Family	The Alvarez Family	A delicate balance of sweetness and tartness of cherries & peaches with a juicy mouthfeel. It’s no wonder this coffee won the Cup of Excellence (the most prestigious award for specialty coffees worldwide)! Best brewed using a Dripper or the Aeropress.	A delicate balance of sweetness and tartness of cherries & peaches with a juicy mouthfeel. It’s no wonder this coffee won the Cup of Excellence (the most prestigious award for specialty coffees worldwide)! Best brewed using a Dripper or the Aeropress.	Fully Washed	水洗处理法	Santa Ana Volcano	Santa Ana Volcano	Ripened Cherry & Peach Compote	Ripened Cherry & Peach Compote	Red Bourbon	Red Bourbon	200	Medium	f	f	f	\N
12	Birds & Bees	An Accidental Creation by the Founders 	West Java, Indonesia and Santa Ana	SV	Honey Herbal Jelly	This limited edition blend of beans from 2 diverse regions is an unusual but beautiful matrimony. The result? Honeyed hints of herbal jelly! This balanced and soothing concoction also has a clean juicy mouthfeel, and is great on almost any brew method!	4	2016-04-04	2016-04-11	14.00	"1"=>"2", "2"=>"4", "3"=>"5", "4"=>"3", "5"=>"4", "6"=>"3"	./Birds__Bees.jpg	Opposites do attract. This blend is a marriage between earthy and herbal Sumatra beans and juicy, sweet El Salvadoran greens. It was an accidental creation by the Founders, and this is how we’d explain the Birds and Bees to curious, inquisitive kids! \r\n\r\n\r\nThe Sumatran varietals were produced by the Mount Halu Co-op, which consists of almost 100 farmers with 1-2 hectares of farmland each, on the ancient land of the Hindu Sunda Kingdom in West Java Raja Sunda. The El Salvadoran beans on the other hand were grown on 2 small lots in the Santa Ana region of El Salvador. A very different climate — milder, drier, but equally ideal for top quality specialty coffee. Coincidentally enough, both these coffees were grown on volcanoes that have nutrient-rich soils! 	Different Altitudes	Mixed Varietals	Wet-hulled and Fully Washed	f	f	labels/Birds_and_Bees__UlKKM88.pdf	labels/Birds_and_Bees_DB.pdf	2	18.00	6	f	Different Altitudes	Different Altitudes	Opposites do attract. This blend is a marriage between earthy and herbal Sumatra beans and juicy, sweet El Salvadoran greens. It was an accidental creation by the Founders, and this is how we’d explain the Birds and Bees to curious, inquisitive kids! \r\n\r\n\r\nThe Sumatran varietals were produced by the Mount Halu Co-op, which consists of almost 100 farmers with 1-2 hectares of farmland each, on the ancient land of the Hindu Sunda Kingdom in West Java Raja Sunda. The El Salvadoran beans on the other hand were grown on 2 small lots in the Santa Ana region of El Salvador. A very different climate — milder, drier, but equally ideal for top quality specialty coffee. Coincidentally enough, both these coffees were grown on volcanoes that have nutrient-rich soils! 	Opposites do attract. This blend is a marriage between earthy and herbal Sumatra beans and juicy, sweet El Salvadoran greens. It was an accidental creation by the Founders, and this is how we’d explain the Birds and Bees to curious, inquisitive kids! \r\n\r\n\r\nThe Sumatran varietals were produced by the Mount Halu Co-op, which consists of almost 100 farmers with 1-2 hectares of farmland each, on the ancient land of the Hindu Sunda Kingdom in West Java Raja Sunda. The El Salvadoran beans on the other hand were grown on 2 small lots in the Santa Ana region of El Salvador. A very different climate — milder, drier, but equally ideal for top quality specialty coffee. Coincidentally enough, both these coffees were grown on volcanoes that have nutrient-rich soils! 	An Accidental Creation by the Founders 	An Accidental Creation by the Founders 	This limited edition blend of beans from 2 diverse regions is an unusual but beautiful matrimony. The result? Honeyed hints of herbal jelly! This balanced and soothing concoction also has a clean juicy mouthfeel, and is great on almost any brew method!	This limited edition blend of beans from 2 diverse regions is an unusual but beautiful matrimony. The result? Honeyed hints of herbal jelly! This balanced and soothing concoction also has a clean juicy mouthfeel, and is great on almost any brew method!	Wet-hulled and Fully Washed	Wet-hulled and Fully Washed	West Java, Indonesia and Santa Ana	West Java, Indonesia and Santa Ana	Honey Herbal Jelly	Honey Herbal Jelly	Mixed Varietals	Mixed Varietals	200	Medium	f	f	f	\N
18	Taster 5x	Taster 5x	Taster 5x	AF	Taster 5x	Taster 5x	3	2016-04-21	2016-04-21	7.00	"0"=>"0"	./taster5x.jpg	Taster 5x	1256m	Arabica	Natural	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	1256m	1256 米	Taster 5x	Taster 5x	Taster 5x	Taster 5x	Taster 5x	Taster 5x	Natural	Natural	Taster 5x	Taster 5x	Taster 5x	Taster 5x	Arabica	Arabica	200	Medium	f	f	f	\N
19	Peara Peara	Echavarria Family	Antioquia	CO	Poached Pears and Dark Chocolate Sauce	Unleash your inner snob with this dream coffee. You’ll first notice the succulent mouthfeel before revelling in the aftertaste of poached pears and bittersweet dark chocolate. Perfect for all brew methods, even for a bold Espresso or for a delicate Drip.	3	2016-09-11	2016-09-18	14.00	"1"=>"3", "2"=>"4", "3"=>"5", "4"=>"1", "5"=>"3", "6"=>"5"	./coffees.001_eUGsGdU.jpeg	Perched on the high Andes mountain range in Antioquia, Colombia and extending toward the Caribbean Sea — that is where you’ll find Santa Bárbara Estate. With diverse microclimates, singular volcanic soils, high altitudes, and a tradition of excellence in coffee production, Santa Bárbara Estate produces some of Colombia’s very best coffees — every lot is made up of 100% native Colombia variety with scores of more than 86 points (out of 100) on a Cup of Excellence score sheet. Amongst the 60 microlots that make up the estate, Peara Peara helms from “the jewel of the estate” aka the La Joyeria microlot (‘joyeria’ literally means ‘jewel’ in Spanish).\r\n \r\nThe beans are handpicked upon ripening over 2 days, then fermented over 48 hours. Each lot is composed of two days worth of picking; the coffee picked on the second day is added to the first after 24 hours fermentation, then left to ferment for a further 24 hours. The inspiration for the process was taken from farmers throughout Antioquia and Huila, who often have 2-3 day fermentation as their farms are so small that one day’s picking is often not sufficient for the ideal fermentation process.\r\n \r\nThe Echavarria Family runs the Santa Bárbara Estate and have been in the business of coffee production since the 1980s. They have since made a name for themselves for producing the highest quality coffees possible in Colombia.\r\n \r\nSanta Bárbara Estate employs 60 people all year round, who on average earn 30% above the minimum wage. At least half of them also receive free housing within the farm for themselves and their families. A further 1,200 pickers are hired during the main harvest, comprised mainly of farmers from around the region, to supplement their income. \r\n \r\nThe Santa Bárbara Estate also runs an extensive scholarship and financial aid program for worker’s children as well as helping long-term employees to acquire their own plots of land upon retirement.	1,700 - 2,000m	Arabica	Natural	f	f	labels/Peara_Peara_8xUX9At.pdf	labels/l_peara_peara_drip_bags.pdf	1	18.00	6	f	1,700 - 2,000m	1,700 - 2,000 米	Perched on the high Andes mountain range in Antioquia, Colombia and extending toward the Caribbean Sea — that is where you’ll find Santa Bárbara Estate. With diverse microclimates, singular volcanic soils, high altitudes, and a tradition of excellence in coffee production, Santa Bárbara Estate produces some of Colombia’s very best coffees — every lot is made up of 100% native Colombia variety with scores of more than 86 points (out of 100) on a Cup of Excellence score sheet. Amongst the 60 microlots that make up the estate, Peara Peara helms from “the jewel of the estate” aka the La Joyeria microlot (‘joyeria’ literally means ‘jewel’ in Spanish).\r\n \r\nThe beans are handpicked upon ripening over 2 days, then fermented over 48 hours. Each lot is composed of two days worth of picking; the coffee picked on the second day is added to the first after 24 hours fermentation, then left to ferment for a further 24 hours. The inspiration for the process was taken from farmers throughout Antioquia and Huila, who often have 2-3 day fermentation as their farms are so small that one day’s picking is often not sufficient for the ideal fermentation process.\r\n \r\nThe Echavarria Family runs the Santa Bárbara Estate and have been in the business of coffee production since the 1980s. They have since made a name for themselves for producing the highest quality coffees possible in Colombia.\r\n \r\nSanta Bárbara Estate employs 60 people all year round, who on average earn 30% above the minimum wage. At least half of them also receive free housing within the farm for themselves and their families. A further 1,200 pickers are hired during the main harvest, comprised mainly of farmers from around the region, to supplement their income. \r\n \r\nThe Santa Bárbara Estate also runs an extensive scholarship and financial aid program for worker’s children as well as helping long-term employees to acquire their own plots of land upon retirement.	位于哥伦比亚安蒂奥基亚省高高的安第斯山脉，一直延伸到加勒比海 - 在那里你可以找到圣巴巴拉房产。有各种不同的小气候，奇异的火山土壤，高海拔，以及咖啡生产的优良传统，圣巴巴拉房产生产哥伦比亚最好的一些咖啡 - 每一块土地都是由100%的哥伦比亚本土咖啡构成的，在卓越咖啡记分表上的得分超过86分（总分100）。在房产中的60块土地中，Peara Peara产自其中最棒的一块地“房产的珍宝”，又名为La Joyeria小土地（“joyeria”在西班牙语中的意思是“珠宝”）。\r\n\r\n咖啡豆都是精心挑选出来的，需要超过两天的时间来成熟，然后发酵超过48小时。每块地都需要两天的时间来采摘咖啡；第二天挑选出来的咖啡会被添加到第一天采摘的咖啡，这些咖啡豆已经发酵了24小时，然后进一步发酵24小时。这个过程的灵感来自于安蒂奥基亚省和乌伊拉的农民，他们通常会让咖啡豆发酵2到3天，因为他们的农场太小，一天的采摘对于理想的发酵过程而言是不够的。\r\n\r\n埃查瓦里亚家族经营圣巴巴拉房产，并且自从20世纪80年代开始就经营咖啡生产的业务。他们还因为生产出哥伦比亚最高质量的咖啡而声名鹊起。\r\n\r\n圣巴巴拉房产全年雇佣60人，他们的平均收入比最低收入高30%。至少一半的人及其家人在农场内有免费住房。在主要收获时期，另有1200名采摘者被雇佣，这些主要都是周边区域的农民，来打工补充他们的收入。\r\n\r\n圣巴巴拉房产还经营一个广泛的奖学金和财政援助计划，用来帮助工人的孩子以及长期员工在退休后获得自己的土地。	Echavarria Family	埃查瓦里亚家族	Unleash your inner snob with this dream coffee. You’ll first notice the succulent mouthfeel before revelling in the aftertaste of poached pears and bittersweet dark chocolate. Perfect for all brew methods, even for a bold Espresso or for a delicate Drip.	有了这款梦幻咖啡，你就可以释放内心的势利。你会首先注意到汁多味美的口感，然后陶醉在蜜汁梨和又苦又甜的黑巧克力的回味中。适合所有烹煮咖啡的方法，甚至是超浓的意式浓缩咖啡或者是较轻柔的滤杯咖啡也可以。	Natural	日晒法	Antioquia	安蒂奥基亚省	Poached Pears and Dark Chocolate Sauce	蜜汁梨和黑巧克力酱	Arabica	阿拉比卡	200	Medium	f	f	f	\N
24	Shotpods Taster Pack	Hook Coffee	Mix	SG	Mix	Mix	3	\N	\N	5.00	"0"=>"0"	./SHOTPODS_POPUP.002.png.002.png	Mix	Mix	Mix	Mix	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	Mix	Mix	Mix	Mix	Hook Coffee	Hook Coffee	Mix	Mix	Mix	Mix	Mix	Mix	Mix	Mix	Mix	Mix	200	Medium	f	f	f	\N
34	Christmas Blend	Antonio Jose Alfaro and Shankar Family	India	SV	Christmas Spiced Chocolate Pie	This chocolatey blend with hints of Christmas dessert spices epitomises all things festive — love, joy & that warm fuzzy feeling. This cup is sure to delight your loved ones and lead Santa right down your chimney, regardless of your brew method.	4	2017-02-25	2017-03-04	14.00	"1"=>"3", "2"=>"5", "3"=>"5", "4"=>"3", "5"=>"3", "6"=>"3"	./christmas_blend_square-01.png	 	3800M & Above 	Red Bourbon & S-795	Mixed processes 	f	f	labels/old_christmas_blend_HhCiyW5_JmWNeCp.pdf	labels/old_christmas_blend_DB_G11B2mP.pdf	2	18.00	6	f	3800M & Above 	1256m	 	This coffee is good	Antonio Jose Alfaro and Shankar Family		This chocolatey blend with hints of Christmas dessert spices epitomises all things festive — love, joy & that warm fuzzy feeling. This cup is sure to delight your loved ones and lead Santa right down your chimney, regardless of your brew method.		Mixed processes 	Natural	India		Christmas Spiced Chocolate Pie		Red Bourbon & S-795	Arabica	250	Medium	f	f	f	\N
22	Hakuna Matata Shotpods	Asali Co-op	Thika	KE	Blackcurrant Macarons with a vanilla and caramel finish	If you love adventure and finding gems before they become hip, you have to try this. Juicy sweet blackcurrants bursting in your mouth, a subtle almond nuttiness, and an elegant vanilla & caramel finish. Best enjoyed with some milk (Milk: Coffee = 1:4).	3	\N	\N	14.00	"1"=>"5", "2"=>"4", "3"=>"3", "4"=>"2", "5"=>"4", "6"=>"3"	./coffees.011.jpeg	Every Disney and Lion King fan will know that we named this coffee after the theme song, Hakuna Matata, which means “No Worries” (in Swahili language). And if you just had one sip of this coffee, you would understand why Hakuna Matata is the King of the Coffee Kingdom and "our problem-free philosophy".\r\n \r\nKenya’s red-orange acidic soils coupled with the region’s moderate climate and equatorial sunlight allow Kenya to be perhaps the world’s most consistent producer of world-class specialty coffees. To add to that, Hakuna Matata was grown in the foothills of Aberdare Ranges, a UNESCO World Heritage Site. The local custom of long (multi-day) wet fermentation is believed to contribute significantly to enhancing the natural fruit derived flavours and clean cup profile in the coffee. \r\n \r\nAs some of the world’s finest gourmet and organic coffees, these beans were carefully graded after harvest. The beans are first sorted and rated by bean size as well as shape, color, and density. A general rule with Kenyan coffee beans is that the bigger the beans, the more essential oils there are and this enhances the tastes and aromas. Kenya AA is the highest-graded and are about a quarter inch in diameter. \r\n \r\nKenya has one of the most transparent and rigid buying systems in the world due to strict laws in place protecting the coffee industry. Farmers are organised by cooperative structures (each farmer has 0.5-3 acres), such as the Asali co-op that produced these beans. A co-op usually serves a number of processing stations - each station servicing surrounding smallholder farmers. ‘Market agents’ act as representatives to the farmers throughout the chain. These agents are a very important step in connecting the farmer to the market. The agents and farmers work together to set the reserve price at auction. The prices are typically high, especially for the Kenya AA beans, and these earnings return to the co-ops and go toward finance, education, and providing inputs and support for the local coffee farmers.	1,675 to 1,750 m	SL28 and SL34	Fully Washed	f	f			1	18.00	6	f	1,675 to 1,750 m	1,675 - 1,750 米	Every Disney and Lion King fan will know that we named this coffee after the theme song, Hakuna Matata, which means “No Worries” (in Swahili language). And if you just had one sip of this coffee, you would understand why Hakuna Matata is the King of the Coffee Kingdom and "our problem-free philosophy".\r\n \r\nKenya’s red-orange acidic soils coupled with the region’s moderate climate and equatorial sunlight allow Kenya to be perhaps the world’s most consistent producer of world-class specialty coffees. To add to that, Hakuna Matata was grown in the foothills of Aberdare Ranges, a UNESCO World Heritage Site. The local custom of long (multi-day) wet fermentation is believed to contribute significantly to enhancing the natural fruit derived flavours and clean cup profile in the coffee. \r\n \r\nAs some of the world’s finest gourmet and organic coffees, these beans were carefully graded after harvest. The beans are first sorted and rated by bean size as well as shape, color, and density. A general rule with Kenyan coffee beans is that the bigger the beans, the more essential oils there are and this enhances the tastes and aromas. Kenya AA is the highest-graded and are about a quarter inch in diameter. \r\n \r\nKenya has one of the most transparent and rigid buying systems in the world due to strict laws in place protecting the coffee industry. Farmers are organised by cooperative structures (each farmer has 0.5-3 acres), such as the Asali co-op that produced these beans. A co-op usually serves a number of processing stations - each station servicing surrounding smallholder farmers. ‘Market agents’ act as representatives to the farmers throughout the chain. These agents are a very important step in connecting the farmer to the market. The agents and farmers work together to set the reserve price at auction. The prices are typically high, especially for the Kenya AA beans, and these earnings return to the co-ops and go toward finance, education, and providing inputs and support for the local coffee farmers.	Every Disney and Lion King fan will know that we named this coffee after the theme song, Hakuna Matata, which means “No Worries” (in Swahili language). And if you just had one sip of this coffee, you would understand why Hakuna Matata is the King of the Coffee Kingdom and "our problem-free philosophy".\r\n \r\nKenya’s red-orange acidic soils coupled with the region’s moderate climate and equatorial sunlight allow Kenya to be perhaps the world’s most consistent producer of world-class specialty coffees. To add to that, Hakuna Matata was grown in the foothills of Aberdare Ranges, a UNESCO World Heritage Site. The local custom of long (multi-day) wet fermentation is believed to contribute significantly to enhancing the natural fruit derived flavours and clean cup profile in the coffee. \r\n \r\nAs some of the world’s finest gourmet and organic coffees, these beans were carefully graded after harvest. The beans are first sorted and rated by bean size as well as shape, color, and density. A general rule with Kenyan coffee beans is that the bigger the beans, the more essential oils there are and this enhances the tastes and aromas. Kenya AA is the highest-graded and are about a quarter inch in diameter. \r\n \r\nKenya has one of the most transparent and rigid buying systems in the world due to strict laws in place protecting the coffee industry. Farmers are organised by cooperative structures (each farmer has 0.5-3 acres), such as the Asali co-op that produced these beans. A co-op usually serves a number of processing stations - each station servicing surrounding smallholder farmers. ‘Market agents’ act as representatives to the farmers throughout the chain. These agents are a very important step in connecting the farmer to the market. The agents and farmers work together to set the reserve price at auction. The prices are typically high, especially for the Kenya AA beans, and these earnings return to the co-ops and go toward finance, education, and providing inputs and support for the local coffee farmers.	Asali Co-op	Asali 合作社	If you love adventure and finding gems before they become hip, you have to try this. Juicy sweet blackcurrants bursting in your mouth, a subtle almond nuttiness, and an elegant vanilla & caramel finish. Best enjoyed with some milk (Milk: Coffee = 1:4).	If you love adventure and finding gems before they become hip, you have to try this. Juicy sweet blackcurrants bursting in your mouth, a subtle almond nuttiness, and an elegant vanilla & caramel finish. Best enjoyed with some milk (Milk: Coffee = 1:4).	Fully Washed	水洗处理法	Thika	锡卡	Blackcurrant Macarons with a vanilla and caramel finish	黑加仑马卡龙，香草和焦糖口味	SL28 and SL34	SL28 and SL34	200	Medium	f	f	f	\N
30	Neverneverland	Hook's Espresso Blend 	Costa Rica	BR	Chocolatey, balanced and never grows old	A classic blend with a buttery nuttiness and dark chocolate. This is perfect for an Espresso based drink. 	4	2017-03-13	2017-03-20	14.00	"1"=>"1", "2"=>"5", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./neverneverland-02.jpg	Just like Peter Pan, this ultimate classic espresso blend is one that never grows old. Naturally we named it Neverneverland. Never mind the irony that Hook’s the protagonist here!\r\n\r\nNeverneverland is a perfect marriage of Hook’s two favourite coffee - Sweet Bundchen and Honey I Shrunk the kids. The result? A perfectly balanced cup - bold, smooth, and chocolatey - exactly what you're looking for in a your everyday espresso. \r\n\r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nHoney I Shrunk the kids was grown in Los Santos and processed at Beneficio del Rio Tarrazú. Located on the Tarrazú River, Beneficio del Rio Tarrazú coffee mill uses clean, hydroelectric power generated on the farm, and has been awarded the Bandera Ecologica and proclaimed a “protector of the environment” by the government of Costa Rica for its progressive design and operation. No honey is actually involved but the "honey process" is a method particular to the best mills in Costa Rica, where ‘honey’ relates to the ‘mucilage’ (sticky substance) on the coffee bean. The honey colour is governed by the level of mucilage that’s left on the coffee bean prior to drying\r\n	Different Altitudes	Mixed Varietals	Honey Processed and Natural	f	f	labels/NNL__SDdYCOj.pdf	labels/NNL_DB_48RNUCE.pdf	2	18.00	6	f	Different Altitudes	Different Altitudes	Just like Peter Pan, this ultimate classic espresso blend is one that never grows old. Naturally we named it Neverneverland. Never mind the irony that Hook’s the protagonist here!\r\n\r\nNeverneverland is a perfect marriage of Hook’s two favourite coffee - Sweet Bundchen and Honey I Shrunk the kids. The result? A perfectly balanced cup - bold, smooth, and chocolatey - exactly what you're looking for in a your everyday espresso. \r\n\r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nHoney I Shrunk the kids was grown in Los Santos and processed at Beneficio del Rio Tarrazú. Located on the Tarrazú River, Beneficio del Rio Tarrazú coffee mill uses clean, hydroelectric power generated on the farm, and has been awarded the Bandera Ecologica and proclaimed a “protector of the environment” by the government of Costa Rica for its progressive design and operation. No honey is actually involved but the "honey process" is a method particular to the best mills in Costa Rica, where ‘honey’ relates to the ‘mucilage’ (sticky substance) on the coffee bean. The honey colour is governed by the level of mucilage that’s left on the coffee bean prior to drying\r\n	Just like Peter Pan, this ultimate classic espresso blend is one that never grows old. Naturally we named it Neverneverland. Never mind the irony that Hook’s the protagonist here!\r\n\r\nNeverneverland is a perfect marriage of Hook’s two favourite coffee - Sweet Bundchen and Honey I Shrunk the kids. The result? A perfectly balanced cup - bold, smooth, and chocolatey - exactly what you're looking for in a your everyday espresso. \r\n\r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nHoney I Shrunk the kids was grown in Los Santos and processed at Beneficio del Rio Tarrazú. Located on the Tarrazú River, Beneficio del Rio Tarrazú coffee mill uses clean, hydroelectric power generated on the farm, and has been awarded the Bandera Ecologica and proclaimed a “protector of the environment” by the government of Costa Rica for its progressive design and operation. No honey is actually involved but the "honey process" is a method particular to the best mills in Costa Rica, where ‘honey’ relates to the ‘mucilage’ (sticky substance) on the coffee bean. The honey colour is governed by the level of mucilage that’s left on the coffee bean prior to drying\r\n	Hook's Espresso Blend 	Hook's Espresso Blend 	A classic blend with a buttery nuttiness and dark chocolate. This is perfect for an Espresso based drink. 	A classic blend with a buttery nuttiness and dark chocolate. This is perfect for an Espresso based drink. 	Honey Processed and Natural	Honey Processed and Natural	Costa Rica	Costa Rica	Chocolatey, balanced and never grows old	Chocolatey, balanced and never grows old	Mixed Varietals	Mixed Varietals	200	Medium	f	f	f	\N
8	Once Upon A Golden Moon	Hook Coffee (Limited edition Blend)	Colombia	BR	Pineapple Tarts & Good Fortune	A limited edition blend of beans from Colombia and Brazil - a harmonious balance with nutty, floral and fruity notes. And we’re not just saying this because it’s Lunar New Year, but we’re pretty sure we tasted pineapple tarts in there! 	3	2016-02-29	2016-03-01	14.00	"1"=>"3", "2"=>"3", "3"=>"3", "4"=>"3", "5"=>"3", "6"=>"3"	./CNY_coffee_photo_.001.jpeg	The Brazilian beans were produced on a young coffee farm, perched in the mountainous Chapada Diamantina region of Bahia, northern Brazil. Apart from the dark cocoa and nutty notes characteristic of Brazilian coffees, these beans are also very fruity. The Colombian beans on the other hand were grown on a very different landscape — the fertile soils of Macizo Colombiano (the Colombian Plateau) surrounding the high peaks of Tolima and Huila, and the salts and minerals from the Pacific Ocean, contribute to the unique nutty, floral and fruity notes of this coffee.\r\n\r\nA blend of these two beans creates a harmonious balance and we’ve roasted it carefully to bring out that familiar buttery, mildly sweet, pineappley fruitiness of freshly baked pineapple tarts. A touch of nuttiness seals the deal!\r\n\r\nThis coffee would be a perfect accompaniment to your assorted New Year goodies, without adding any extra calories!	Different Altitudes	Mixed Varietals	Fully Washed and Pulped Natural	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	Different Altitudes	Different Altitudes	The Brazilian beans were produced on a young coffee farm, perched in the mountainous Chapada Diamantina region of Bahia, northern Brazil. Apart from the dark cocoa and nutty notes characteristic of Brazilian coffees, these beans are also very fruity. The Colombian beans on the other hand were grown on a very different landscape — the fertile soils of Macizo Colombiano (the Colombian Plateau) surrounding the high peaks of Tolima and Huila, and the salts and minerals from the Pacific Ocean, contribute to the unique nutty, floral and fruity notes of this coffee.\r\n\r\nA blend of these two beans creates a harmonious balance and we’ve roasted it carefully to bring out that familiar buttery, mildly sweet, pineappley fruitiness of freshly baked pineapple tarts. A touch of nuttiness seals the deal!\r\n\r\nThis coffee would be a perfect accompaniment to your assorted New Year goodies, without adding any extra calories!	The Brazilian beans were produced on a young coffee farm, perched in the mountainous Chapada Diamantina region of Bahia, northern Brazil. Apart from the dark cocoa and nutty notes characteristic of Brazilian coffees, these beans are also very fruity. The Colombian beans on the other hand were grown on a very different landscape — the fertile soils of Macizo Colombiano (the Colombian Plateau) surrounding the high peaks of Tolima and Huila, and the salts and minerals from the Pacific Ocean, contribute to the unique nutty, floral and fruity notes of this coffee.\r\n\r\nA blend of these two beans creates a harmonious balance and we’ve roasted it carefully to bring out that familiar buttery, mildly sweet, pineappley fruitiness of freshly baked pineapple tarts. A touch of nuttiness seals the deal!\r\n\r\nThis coffee would be a perfect accompaniment to your assorted New Year goodies, without adding any extra calories!	Hook Coffee (Limited edition Blend)	Hook Coffee (Limited edition Blend)	A limited edition blend of beans from Colombia and Brazil - a harmonious balance with nutty, floral and fruity notes. And we’re not just saying this because it’s Lunar New Year, but we’re pretty sure we tasted pineapple tarts in there! 	A limited edition blend of beans from Colombia and Brazil - a harmonious balance with nutty, floral and fruity notes. And we’re not just saying this because it’s Lunar New Year, but we’re pretty sure we tasted pineapple tarts in there! 	Fully Washed and Pulped Natural	Fully Washed and Pulped Natural	Colombia	Colombia	Pineapple Tarts & Good Fortune	Pineapple Tarts & Good Fortune	Mixed Varietals	Mixed Varietals	200	Medium	f	f	f	\N
1	Ole Ola	Pedro Hugh Barré & Fabiano Barré	Chapada Diamantina, Bahia	BR	Dark Chocolate Fruit & Nut Bar	This coffee is atypical of most Brazilian beans. It reminds us of creamy dark chocolate fruit & nut bars - bold yet juicy. Although its chocolatey notes dominate, the slight fruity acidity makes for a balanced cup. Delicious regardless of your brew method.	4	2016-02-22	2016-02-29	14.00	"1"=>"3", "2"=>"4", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"3"	./Ole_Ola.jpg	Brazil is known for coffee, beautiful women, and football among many other things. So we named this coffee after one of the 2014 FIFA World Cup theme songs. Let's try to forget their heartbreaking defeat during the semis and celebrate everything else Brazil has to offer - including this delicious coffee!\r\n\r\nOle Ola was grown by Pedro Hugh Barré & Fabiano Barré in Fazenda Progresso - a relatively young coffee farm that lies in the mountainous Chapada Diamantina region of Bahia, northern Brazil. The farm started life in 1984 as a vegetable farm and the Barrés relatively recently diversified into coffee. 1,000 out of 22,000 hectares has been dedicated to coffee. \r\n\r\nBecause of the popularity of Barrés' coffees, the farm has expanded rapidly - nevertheless sustainably - and currently employs some 200 workers, which swells to between 400 and 500 during harvest. 	1,150 to 1,200 m	Catuaí, Catucai & Yellow Topazio	Pulped natural	f	f	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	1,150 to 1,200 m	1,150 - 1,200 米	Brazil is known for coffee, beautiful women, and football among many other things. So we named this coffee after one of the 2014 FIFA World Cup theme songs. Let's try to forget their heartbreaking defeat during the semis and celebrate everything else Brazil has to offer - including this delicious coffee!\r\n\r\nOle Ola was grown by Pedro Hugh Barré & Fabiano Barré in Fazenda Progresso - a relatively young coffee farm that lies in the mountainous Chapada Diamantina region of Bahia, northern Brazil. The farm started life in 1984 as a vegetable farm and the Barrés relatively recently diversified into coffee. 1,000 out of 22,000 hectares has been dedicated to coffee. \r\n\r\nBecause of the popularity of Barrés' coffees, the farm has expanded rapidly - nevertheless sustainably - and currently employs some 200 workers, which swells to between 400 and 500 during harvest. 	Brazil is known for coffee, beautiful women, and football among many other things. So we named this coffee after one of the 2014 FIFA World Cup theme songs. Let's try to forget their heartbreaking defeat during the semis and celebrate everything else Brazil has to offer - including this delicious coffee!\r\n\r\nOle Ola was grown by Pedro Hugh Barré & Fabiano Barré in Fazenda Progresso - a relatively young coffee farm that lies in the mountainous Chapada Diamantina region of Bahia, northern Brazil. The farm started life in 1984 as a vegetable farm and the Barrés relatively recently diversified into coffee. 1,000 out of 22,000 hectares has been dedicated to coffee. \r\n\r\nBecause of the popularity of Barrés' coffees, the farm has expanded rapidly - nevertheless sustainably - and currently employs some 200 workers, which swells to between 400 and 500 during harvest. 	Pedro Hugh Barré & Fabiano Barré	Pedro Hugh Barré & Fabiano Barré	This coffee is atypical of most Brazilian beans. It reminds us of creamy dark chocolate fruit & nut bars - bold yet juicy. Although its chocolatey notes dominate, the slight fruity acidity makes for a balanced cup. Delicious regardless of your brew method.	This coffee is atypical of most Brazilian beans. It reminds us of creamy dark chocolate fruit & nut bars - bold yet juicy. Although its chocolatey notes dominate, the slight fruity acidity makes for a balanced cup. Delicious regardless of your brew method.	Pulped natural	Pulped natural	Chapada Diamantina, Bahia	巴伊亚州吉曼提那高地	Dark Chocolate Fruit & Nut Bar	Dark Chocolate Fruit & Nut Bar	Catuaí, Catucai & Yellow Topazio	Catuaí, Catucai & Yellow Topazio	200	Medium	f	f	f	\N
23	Bird of Paradise Shotpods	Purosa Co-op	Purosa, Eastern Highlands	PG	Dark Chocolate and Stone Fruits	If you’ve ever wondered what it feels like to be a bird in paradise, indulge in this coffee's dark chocolate base, brightened by hints of tropical stone fruit flavours. It finishes like a smooth landing, leaving a lingering & smokey oolong aftertaste.	5	2017-05-08	2017-05-15	14.00	"1"=>"1", "2"=>"1", "3"=>"5", "4"=>"4", "5"=>"3", "6"=>"3"	./birds_of_paradise_thumbnail.png	The Bird of Paradise is a species of birds endemic to New Guinea, distinguished by its striking colors and bright plumage of yellow, blue, scarlet, green - and this coffee is as beautiful and exotic as its name suggests. \r\n \r\nBird of Paradise was shade-grown and cultivated on the rich volcanic soils of Purosa Valley in the Eastern Highlands of Papua New guinea, where rain is abounding and native wildlife flourishes. Purosa is the nucleus for a range of coffee and community activities and is located 93 kilometers South-West of Goroka township, the capital of the Eastern Highlands Province. \r\n \r\nAs the area is isolated and difficult to access it was decided some years ago to follow an organic coffee stream so as to add value to the coffee and to compensate for the difficult access and the historically low prices persisting at that time. \r\n \r\nThe coffees are the labour of love of Purosa Co-operative’s smallholder farmers who come from various indigenous groups. Despite a history of tribal conflict especially between the North Fore and South Fore groups, they have come together to produce this inspiringly harmonious coffee.\r\n \r\nThe objectives of the co-operative include pooled-effort and investments for the improvement of roads and infrastructure, to enhance resources for community schools in the district, to support four health centres and aid posts through the provision of beds and medicines, and to provide employment particularly women's groups.	1,800m	Typica and Bourbon	Wet Processed	t	f			1	18.00	8	f	1,800m	1,800 米	The Bird of Paradise is a species of birds endemic to New Guinea, distinguished by its striking colors and bright plumage of yellow, blue, scarlet, green - and this coffee is as beautiful and exotic as its name suggests. \r\n \r\nBird of Paradise was shade-grown and cultivated on the rich volcanic soils of Purosa Valley in the Eastern Highlands of Papua New guinea, where rain is abounding and native wildlife flourishes. Purosa is the nucleus for a range of coffee and community activities and is located 93 kilometers South-West of Goroka township, the capital of the Eastern Highlands Province. \r\n \r\nAs the area is isolated and difficult to access it was decided some years ago to follow an organic coffee stream so as to add value to the coffee and to compensate for the difficult access and the historically low prices persisting at that time. \r\n \r\nThe coffees are the labour of love of Purosa Co-operative’s smallholder farmers who come from various indigenous groups. Despite a history of tribal conflict especially between the North Fore and South Fore groups, they have come together to produce this inspiringly harmonious coffee.\r\n \r\nThe objectives of the co-operative include pooled-effort and investments for the improvement of roads and infrastructure, to enhance resources for community schools in the district, to support four health centres and aid posts through the provision of beds and medicines, and to provide employment particularly women's groups.	The Bird of Paradise is a species of birds endemic to New Guinea, distinguished by its striking colors and bright plumage of yellow, blue, scarlet, green - and this coffee is as beautiful and exotic as its name suggests. \r\n \r\nBird of Paradise was shade-grown and cultivated on the rich volcanic soils of Purosa Valley in the Eastern Highlands of Papua New guinea, where rain is abounding and native wildlife flourishes. Purosa is the nucleus for a range of coffee and community activities and is located 93 kilometers South-West of Goroka township, the capital of the Eastern Highlands Province. \r\n \r\nAs the area is isolated and difficult to access it was decided some years ago to follow an organic coffee stream so as to add value to the coffee and to compensate for the difficult access and the historically low prices persisting at that time. \r\n \r\nThe coffees are the labour of love of Purosa Co-operative’s smallholder farmers who come from various indigenous groups. Despite a history of tribal conflict especially between the North Fore and South Fore groups, they have come together to produce this inspiringly harmonious coffee.\r\n \r\nThe objectives of the co-operative include pooled-effort and investments for the improvement of roads and infrastructure, to enhance resources for community schools in the district, to support four health centres and aid posts through the provision of beds and medicines, and to provide employment particularly women's groups.	Purosa Co-op	Purosa 合作社	If you’ve ever wondered what it feels like to be a bird in paradise, indulge in this coffee's dark chocolate base, brightened by hints of tropical stone fruit flavours. It finishes like a smooth landing, leaving a lingering & smokey oolong aftertaste.	If you’ve ever wondered what it feels like to be a bird in paradise, indulge in this coffee's dark chocolate base, brightened by hints of tropical stone fruit flavours. It finishes like a smooth landing, leaving a lingering & smokey oolong aftertaste.	Wet Processed	Wet Processed	Purosa, Eastern Highlands	东部高地	Dark Chocolate and Stone Fruits	黑巧克力和核果	Typica and Bourbon	Typica and Bourbon	200	Medium	f	f	f	\N
35	Prosperoo 	Carlos Alberto Ulchur	Cauca	CO	Pineapple Tarts 	W-huat a better way to spring into this Chinese New Year with a coffee that reminds us of everyone's favourite pineapple tarts. Celebrate with the sweet taste of happiness and fruits of prosperity. A coffee not to be missed this CNY. 	4	2017-03-13	2017-03-20	14.00	"1"=>"4", "2"=>"5", "3"=>"5", "4"=>"3", "5"=>"1", "6"=>"3"	./CNY_coffee_photo_.001.jpeg	This microlot was produced and processed by Carlos Alberto Ulchur, a smallholder member of the ASORCAFE - Inzá, Cauca producer group. Produced at 1,900 metres above sea level, this very special lot was selected out from the rest of the organization’s producers as being of exceptional quality. This coffee had us wowed and is a great showcase for what this remote and often overlooked region of Colombia has to offer.\r\n\r\nThe municipality of Inzá is located in the corner of the Department of Cauca, bordering with Tolima and Huila and looking out to the west over the Pacific Ocean. Situated on the “Macizo Colombiano” (the Colombian Plateau), which surrounds the high peaks of Tolima and Huila, the region is an important source of water and wildlife, in addition to being prime coffee growing land.\r\n\r\nASORCAFE (Asociación de Productores de Café del Oriente Caucano) represents, in total, some 450 producers from across the Department. This specific lot, however, has been selected only from Sr. Ulchur’s production this year. Every single producer delivering to the group has their lot cupped by the Association’s cupping lab in Pedregal. Lots scoring 85 points or more are reserved for the Inzá, Cauca microlot offered by Mercanta. However, encouraged by our partners in Colombia, Santa Barbara Estates, the group has also begun to reserve those lots that cup even higher than 85 points or that demonstrate exceptional or unique qualities. These stringent standards result in identifying very small, very special microlots, such as this one, being made available for export.\r\nThe association of coffee growers, ASORCAFE, was founded in 2004 by 10 coffee growers with an entrepreneurial spirit who were tired of private parchment buyers who were paying them below national prices. 	1900m	Arabica	Fully Washed 	f	f	labels/CNY_LABEL.pdf	labels/CNY_NEW_DB.pdf	2	18.00	6	f	1900m	1256m	This microlot was produced and processed by Carlos Alberto Ulchur, a smallholder member of the ASORCAFE - Inzá, Cauca producer group. Produced at 1,900 metres above sea level, this very special lot was selected out from the rest of the organization’s producers as being of exceptional quality. This coffee had us wowed and is a great showcase for what this remote and often overlooked region of Colombia has to offer.\r\n\r\nThe municipality of Inzá is located in the corner of the Department of Cauca, bordering with Tolima and Huila and looking out to the west over the Pacific Ocean. Situated on the “Macizo Colombiano” (the Colombian Plateau), which surrounds the high peaks of Tolima and Huila, the region is an important source of water and wildlife, in addition to being prime coffee growing land.\r\n\r\nASORCAFE (Asociación de Productores de Café del Oriente Caucano) represents, in total, some 450 producers from across the Department. This specific lot, however, has been selected only from Sr. Ulchur’s production this year. Every single producer delivering to the group has their lot cupped by the Association’s cupping lab in Pedregal. Lots scoring 85 points or more are reserved for the Inzá, Cauca microlot offered by Mercanta. However, encouraged by our partners in Colombia, Santa Barbara Estates, the group has also begun to reserve those lots that cup even higher than 85 points or that demonstrate exceptional or unique qualities. These stringent standards result in identifying very small, very special microlots, such as this one, being made available for export.\r\nThe association of coffee growers, ASORCAFE, was founded in 2004 by 10 coffee growers with an entrepreneurial spirit who were tired of private parchment buyers who were paying them below national prices. 	This coffee is good	Carlos Alberto Ulchur		W-huat a better way to spring into this Chinese New Year with a coffee that reminds us of everyone's favourite pineapple tarts. Celebrate with the sweet taste of happiness and fruits of prosperity. A coffee not to be missed this CNY. 		Fully Washed 	Natural	Cauca		Pineapple Tarts 		Arabica	Arabica	200	Medium	f	f	f	\N
25	A Little Bit of...	Hook Coffee	Brazil, Kenya	PG	A Variety of 3 x 10 ShotPods (not for Subscriptions)	Who remembers the song "Mambo No. 5" by Lou Bega which was a hit in 1999? We were in primary school then but we sure remember it like it was yesterday! This Variety Pack is perfect for all those who, like Bega, desire "a little bit of” everything gooooood.	4	\N	\N	24.00	"1"=>"5"	./Variety_Pack_Pods.001_e4sZ2HH.jpeg	Experience coffees from different farms in beautiful parts of the world, from the green and hilly South of Minas Gerais in Brazil, the Aberdares Ranges of the Thika region in Kenya, to the lush volcanoes of Purosa in Papua New Guinea. All at the push of a button. And don't worry about expiry - our ShotPods have a shelf life of 3 years.\r\n \r\nRead 'more info' on the 3 coffees in this variety pack to learn more about the farms and their communities, and why we're so proud of the quality and stories behind our ShotPods.	1,000m - 1,800m	Mixed Varietals	Natural / Washed / Wet	f	t	labels/blank.pdf	labels/blank.pdf	1	18.00	6	f	1,000m - 1,800m	1,000 - 1,800 米	Experience coffees from different farms in beautiful parts of the world, from the green and hilly South of Minas Gerais in Brazil, the Aberdares Ranges of the Thika region in Kenya, to the lush volcanoes of Purosa in Papua New Guinea. All at the push of a button. And don't worry about expiry - our ShotPods have a shelf life of 3 years.\r\n \r\nRead 'more info' on the 3 coffees in this variety pack to learn more about the farms and their communities, and why we're so proud of the quality and stories behind our ShotPods.	Experience coffees from different farms in beautiful parts of the world, from the green and hilly South of Minas Gerais in Brazil, the Aberdares Ranges of the Thika region in Kenya, to the lush volcanoes of Purosa in Papua New Guinea. All at the push of a button. And don't worry about expiry - our ShotPods have a shelf life of 3 years.\r\n \r\nRead 'more info' on the 3 coffees in this variety pack to learn more about the farms and their communities, and why we're so proud of the quality and stories behind our ShotPods.	Hook Coffee	Hook Coffee	Who remembers the song "Mambo No. 5" by Lou Bega which was a hit in 1999? We were in primary school then but we sure remember it like it was yesterday! This Variety Pack is perfect for all those who, like Bega, desire "a little bit of” everything gooooood.	Who remembers the song "Mambo No. 5" by Lou Bega which was a hit in 1999? We were in primary school then but we sure remember it like it was yesterday! This Variety Pack is perfect for all those who, like Bega, desire "a little bit of” everything gooooood.	Natural / Washed / Wet	Natural / Washed / Wet	Brazil, Kenya	Brazil, Kenya	A Variety of 3 x 10 ShotPods (not for Subscriptions)	A Variety of 3 x 10 ShotPods (not for Subscriptions)	Mixed Varietals	Mixed Varietals	200	Medium	f	f	f	\N
31	Eternal Sunshine	Village of Torea	Yirgacheffe	ET	Berries and Nectarines	Soak up the sunshine with this wildly exotic and deliciously fruity coffee. The sweet, satisfying hints of berries and nectarines will leave you smiling and energised like eternal sunshine.	3	2017-03-13	2017-03-20	18.00	"1"=>"5", "2"=>"1", "3"=>"1", "4"=>"3", "5"=>"4", "6"=>"5"	./Eternal_sunshine_.jpg	This Aricha, from the region of Yirgacheffe, is located on the eastern slope of the lush green mountains of the Rift Valley at an altitude of 1,950 metres above sea level. Yirgacheffe famous for a very good reason, producing consistently clean stone fruit coffees as seen here. Farmers deliver their ripe cherries to the kebel aricha mill. Once sorted the beans are put on the drying beds and turned for four to six weeks in an effort to minimise ferment. The dried cherry is then taken to their mill 5 hours away in Addis Abba where they are hulled and bagged.\r\n\r\nTry it to believe it! 	1850 - 1880m	Arabica, Heirloom	Natural	f	t			2	22.00	3	f	1850 - 1880m	1850 - 1880 米	This Aricha, from the region of Yirgacheffe, is located on the eastern slope of the lush green mountains of the Rift Valley at an altitude of 1,950 metres above sea level. Yirgacheffe famous for a very good reason, producing consistently clean stone fruit coffees as seen here. Farmers deliver their ripe cherries to the kebel aricha mill. Once sorted the beans are put on the drying beds and turned for four to six weeks in an effort to minimise ferment. The dried cherry is then taken to their mill 5 hours away in Addis Abba where they are hulled and bagged.\r\n\r\nTry it to believe it! 	This Aricha, from the region of Yirgacheffe, is located on the eastern slope of the lush green mountains of the Rift Valley at an altitude of 1,950 metres above sea level. Yirgacheffe famous for a very good reason, producing consistently clean stone fruit coffees as seen here. Farmers deliver their ripe cherries to the kebel aricha mill. Once sorted the beans are put on the drying beds and turned for four to six weeks in an effort to minimise ferment. The dried cherry is then taken to their mill 5 hours away in Addis Abba where they are hulled and bagged.\r\n\r\nTry it to believe it! 	Village of Torea	Village of Torea	Soak up the sunshine with this wildly exotic and deliciously fruity coffee. The sweet, satisfying hints of berries and nectarines will leave you smiling and energised like eternal sunshine.	Soak up the sunshine with this wildly exotic and deliciously fruity coffee. The sweet, satisfying hints of berries and nectarines will leave you smiling and energised like eternal sunshine.	Natural	Natural	Yirgacheffe	Yirgacheffe	Berries and Nectarines	Berries and Nectarines	Arabica, Heirloom	Arabica, Heirloom	250	Medium	f	f	f	\N
33	Jam-Mazing	Fernando Alfaro & family	Apaneca-Ilamatepec, Ahuachapán	SV	Jam Tarts 	Beautiful shortbread cookies topped with a jam-mazing sweet berry mouthful — think Arnott’s Tartlets or Jammie Dodgers. If this fun and fruity coffee doesn’t get you excited like a kid, we don’t know what will! Drip or Aeropress for the best flavours.	3	2017-03-20	2017-03-27	14.00	"1"=>"4", "2"=>"3", "3"=>"5", "4"=>"2", "5"=>"1", "6"=>"4"	./jamazing_thumbnail.png	El Carmen Estate is located at 1,300m above sea level in El Salvador’s Apaneca-Ilamatepec mountain range, one of Central America’s prime specialty coffee producing areas. The estate has been farmed by the Alfaro family for over a century. \r\n \r\nEl Carmen lies in the heart of El Salvador’s main ‘protected highway’ of forest, a part of the Mesoamerican Biological Corridor System that stretches all the way from Mexico down to Panama. In El Salvador, where more than 80% of the country’s coffee is produced under shade, this eco-system is based mainly in the coffee forest. For this reason, coffee farms such as El Carmen play a vital role as a sanctuary for hundreds of the migratory and native bird species found in this part of the world. \r\n \r\nThe estate was founded in the middle of the 19th century when Antonio José Alfaro acquired a plot of land near the village of Ataco – meaning ‘Site of Elevated Springs’ in the indigenous Nahuatl language – where he started to produce coffee. His son, Agustin Alfaro, founder of the Salvadoran National Coffee Company, followed in his father’s footsteps and established El Carmen as one of El Salvador’s leading exporters. His efforts were continued by Antonio Alfaro, head of the third generation of this coffee family and are carried through today by Fernando Alfaro, the fourth generation of his family to farm coffee. \r\n \r\nDuring the harvest, the Bourbon and Pacas cherries are hand-picked only when perfectly ripe and floated to remove any debris or underweight cherries. After this, they are delivered to dry on African Beds for 21 days, where they are regularly raked to ensure even drying. They spend an additional three to four days on clay patios, for a total drying time of 24-25 days. Finally, the beans are prepared and all defects removed and screened to uniform size. 	1300m & Above 	100% Red Bourbon	Fully Washed	f	f	labels/Jamazing_normal_.pdf	labels/Jamazing_DB_.pdf	1	18.00	6	f	1300m & Above 	1256m	El Carmen Estate is located at 1,300m above sea level in El Salvador’s Apaneca-Ilamatepec mountain range, one of Central America’s prime specialty coffee producing areas. The estate has been farmed by the Alfaro family for over a century. \r\n \r\nEl Carmen lies in the heart of El Salvador’s main ‘protected highway’ of forest, a part of the Mesoamerican Biological Corridor System that stretches all the way from Mexico down to Panama. In El Salvador, where more than 80% of the country’s coffee is produced under shade, this eco-system is based mainly in the coffee forest. For this reason, coffee farms such as El Carmen play a vital role as a sanctuary for hundreds of the migratory and native bird species found in this part of the world. \r\n \r\nThe estate was founded in the middle of the 19th century when Antonio José Alfaro acquired a plot of land near the village of Ataco – meaning ‘Site of Elevated Springs’ in the indigenous Nahuatl language – where he started to produce coffee. His son, Agustin Alfaro, founder of the Salvadoran National Coffee Company, followed in his father’s footsteps and established El Carmen as one of El Salvador’s leading exporters. His efforts were continued by Antonio Alfaro, head of the third generation of this coffee family and are carried through today by Fernando Alfaro, the fourth generation of his family to farm coffee. \r\n \r\nDuring the harvest, the Bourbon and Pacas cherries are hand-picked only when perfectly ripe and floated to remove any debris or underweight cherries. After this, they are delivered to dry on African Beds for 21 days, where they are regularly raked to ensure even drying. They spend an additional three to four days on clay patios, for a total drying time of 24-25 days. Finally, the beans are prepared and all defects removed and screened to uniform size. 	This coffee is good	Fernando Alfaro & family		Beautiful shortbread cookies topped with a jam-mazing sweet berry mouthful — think Arnott’s Tartlets or Jammie Dodgers. If this fun and fruity coffee doesn’t get you excited like a kid, we don’t know what will! Drip or Aeropress for the best flavours.		Fully Washed	Natural	Apaneca-Ilamatepec, Ahuachapán		Jam Tarts 		100% Red Bourbon	Arabica	250	Low	f	f	f	\N
36	Give Me S’mores Shotpods	Shankar Family	Karnataka, India	IN	Hot Chocolate, Marshmallows, and Spice	Velvety hot chocolate topped with marshmallows and spice — what could be more comforting? Well, a coffee that tastes just like that! This cup will literally get you screaming “Give me S’more”! For the richest experience, brew with Espresso or Stove Top.	5	2017-04-24	2017-04-30	14.00	"1"=>"1", "2"=>"5", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./give_me_smores_thumbnail.png	This is a classic example of an outstanding Indian coffee with a cupping score of 87.5. This coffee was grown by the Shankar family in the Western Ghat mountains and the farm dates back to 1865 first established by the British, only changing hands in 1950s. The Shankar family’s complex approach to poly-culture farming included providing dense shades of fig, silver oak and jack fruit, with pepper vines, cardaom and vanilla accompanying in the understory.\r\n \r\nThis beautiful orchard is also home to a wide range of flora and fauna and wildlife such as deers, foxes, Jungle Pigeons and wild boards. The Kalledevarapura has been shade grown in a polyculture forest farm environment and has been cultivated without the use of pesticides, herbicides or synthetic fertilizers.	3800-4400M	S-795	Washed, sun dried on patio	t	f			2	18.00	11	f	3800-4400M	1256m	This is a classic example of an outstanding Indian coffee with a cupping score of 87.5. This coffee was grown by the Shankar family in the Western Ghat mountains and the farm dates back to 1865 first established by the British, only changing hands in 1950s. The Shankar family’s complex approach to poly-culture farming included providing dense shades of fig, silver oak and jack fruit, with pepper vines, cardaom and vanilla accompanying in the understory.\r\n \r\nThis beautiful orchard is also home to a wide range of flora and fauna and wildlife such as deers, foxes, Jungle Pigeons and wild boards. The Kalledevarapura has been shade grown in a polyculture forest farm environment and has been cultivated without the use of pesticides, herbicides or synthetic fertilizers.	This coffee is good	Shankar Family		Velvety hot chocolate topped with marshmallows and spice — what could be more comforting? Well, a coffee that tastes just like that! This cup will literally get you screaming “Give me S’more”! For the richest experience, brew with Espresso or Stove Top.		Washed, sun dried on patio	Natural	Karnataka, India		Hot Chocolate, Marshmallows, and Spice		S-795	Arabica	250	Low 	f	f	f	\N
20	Specu-Lose Your Mind	Hook (3-Region Blend)	Brazil, Colombia	ET	Speculoos! (Caramelised & Spiced Belgian Biscuits)	Can you hear those jingle bells? Caramelised, spiced, and biscuity - this Speculoos-tasting coffee is basically that warm & fuzzy Christmas feeling in a cup and all year round. The perfect blend for all moods and all brew methods. 	4	2017-05-28	2017-06-04	14.00	"1"=>"3", "2"=>"5", "3"=>"5", "4"=>"1", "5"=>"3", "6"=>"3"	./speculoose_thumbnail.png	Specu-Lose Your Mind is what happens when you put 3 different coffees from 3 contrasting regions together. Part Brazilian, part Colombian and part Ethiopian, this coffee exhibits the flavour quirks of the different farms and microclimates in which they were grown.\r\n \r\nThe beans from Brazil were produced by the passionate Oliveira Bueno Alves who is a 4th generation coffee farmer who now runs the Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais. Her deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop).\r\n \r\nThe Colombian beans on the other hand were cultivated within the Santa Bárbara Estate, perched on the high Andes mountain range in Antioquia, Colombia. The Echavarria Family runs the Santa Bárbara Estate and have made a name for themselves for producing the highest quality coffees possible in Colombia. Santa Bárbara Estate employs 60 people all year round, who on average earn 30% above the minimum wage. At least half of them also receive free housing within the farm for themselves and their families. \r\n \r\nThe smallholders of Guji, a remote district found in the lush mountainous region of East Sidamo, Ethiopia, have just 1-2 hectares of coffee growing in their back garden and process the coffees using traditional, time-honoured methods, under shade trees alongside other agricultural produce and without the use of chemicals.\r\n  \r\nFun Facts: Speculoos are traditional Belgian shortcrust biscuits that are baked during the winter festive season. Sit down at any café in Belgium, and the cookie served alongside your coffee will probably be a speculoos biscuit, or some other cookie that tastes just like it. 	1,000m - 2,150m	Mixed Varietals	Natural / Washed	t	f	labels/Speculose_your_mind.pdf	labels/speculose_your_mind_db.pdf	1	18.00	6	f	1,000m - 2,150m	1,000 - 2,150 米	Specu-Lose Your Mind is what happens when you put 3 different coffees from 3 contrasting regions together. Part Brazilian, part Colombian and part Ethiopian, this coffee exhibits the flavour quirks of the different farms and microclimates in which they were grown.\r\n \r\nThe beans from Brazil were produced by the passionate Oliveira Bueno Alves who is a 4th generation coffee farmer who now runs the Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais. Her deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop).\r\n \r\nThe Colombian beans on the other hand were cultivated within the Santa Bárbara Estate, perched on the high Andes mountain range in Antioquia, Colombia. The Echavarria Family runs the Santa Bárbara Estate and have made a name for themselves for producing the highest quality coffees possible in Colombia. Santa Bárbara Estate employs 60 people all year round, who on average earn 30% above the minimum wage. At least half of them also receive free housing within the farm for themselves and their families. \r\n \r\nThe smallholders of Guji, a remote district found in the lush mountainous region of East Sidamo, Ethiopia, have just 1-2 hectares of coffee growing in their back garden and process the coffees using traditional, time-honoured methods, under shade trees alongside other agricultural produce and without the use of chemicals.\r\n  \r\nFun Facts: Speculoos are traditional Belgian shortcrust biscuits that are baked during the winter festive season. Sit down at any café in Belgium, and the cookie served alongside your coffee will probably be a speculoos biscuit, or some other cookie that tastes just like it. 	当你把来自三个对比鲜明的地区的三种不同的咖啡放在一起时，你就会有Specu-Lose Your Mind这种感觉，一部分的巴西咖啡，一部分的哥伦比亚咖啡和埃塞俄比亚咖啡，这展示了不同农场的口味的区别和它们所种植区域的小气候。\r\n\r\n来自巴西的咖啡豆是由热情的奥利维拉·布埃诺·阿尔维斯生产的，她是第四代咖啡种植户，现在管理着米纳斯吉拉斯绿色，多丘陵的南部的Sitio Morro Agudo农场。她对咖啡根深蒂固的爱与了解驱使着她努力改善栽培技术和可持续性的努力（比如，多关注Sitio Morro Agudo的土壤护理和管理，来保持最理想的土壤肥力和作物的再生）。\r\n\r\n另一方面，哥伦比亚咖啡豆是在哥伦比亚安蒂奥基亚省的高安第斯山脉的圣巴巴拉房产种植的。埃查瓦里亚家族管理着圣巴巴拉房产并且因为他们在哥伦比亚生产出最高质量的咖啡而名声大噪。圣巴巴拉房产全年雇佣60人，他们的平均收入比最低工资高30%。他们中至少一半的人及其家人在农场内有免费住房。\r\n\r\n埃塞俄比亚东西达摩省的茂密山区的一个偏远地区Guji的小农，只有1 - 2公顷的咖啡生长在他们的后院，并且使用传统的，由来已久的方法处理咖啡，在与其他农产品靠在一起的树荫下，不使用任何化学品。\r\n\r\n趣闻：肉桂焦糖饼干是传统的比利时酥皮糕点饼干，是在冬季节日期间烘焙的。坐在比利时的任何一家咖啡馆，和你的咖啡一起上的饼干很有可能就是肉桂焦糖饼干，或者尝起来像肉桂焦糖饼干的其他饼干。	Hook (3-Region Blend)	Hook（3区融合）	Can you hear those jingle bells? Caramelised, spiced, and biscuity - this Speculoos-tasting coffee is basically that warm & fuzzy Christmas feeling in a cup and all year round. The perfect blend for all moods and all brew methods. 	你能听到那些门铃声吗？焦糖化，肉桂味，饼干味 -  这款肉桂焦糖饼干口味的咖啡基本上就是全年都可以让你喝着这咖啡享受到让人快乐的圣诞节的感觉。是所有情绪和烹煮方法的完美融合。	Natural / Washed	日晒法/水洗处理法	Brazil, Colombia	巴西，哥伦比亚	Speculoos! (Caramelised & Spiced Belgian Biscuits)	肉桂焦糖饼干！（焦糖和肉桂饼干）	Mixed Varietals	混合品种	250	Medium	t	f	f	\N
16	Ciao Bella	Hook (Classic Blend)	East Sidamo, Ethiopia and West Java	ID	Chocolate Ganache Fruit Tarts	A chic blend for the sophisticated trendsetter, this coffee is full-bodied yet elegant, balancing chocolatey notes with lively fruitiness. Don’t be shy to brew her with whatever brew method — she’s beautiful no matter what.	3	2017-05-28	2017-06-04	14.00	"1"=>"3", "2"=>"5", "3"=>"4", "4"=>"3", "5"=>"4", "6"=>"4"	./ciao_bella_thumbnail.png	Inspired by Californian Blue Bottle's Bella Donovan — Ciao Bella (which means “Hello Beautiful” in Italian) is bold and nuanced while preserving a mysterious elegance, and it’s hard not to fall in love at first sip.\r\n \r\nThe love child of two coffees — one from Ethiopia and the other from Indonesia — Ciao Bella is a combination of their best characteristics. The coffees from Guji, a  remote district found in the lush mountainous East Sidamo, Ethiopia, is bright and fruity, even a little floral, while the beans from the ancient Hindu Sunda Kingdom in West Java Raja Sunda, Indonesia has dark and earthy cocoa notes. \r\n \r\nBoth coffees were grown by smallholder farmers, organised by cooperatives. The Javanese co-op of Mount Halu comprises 100 farmers with 1-2 hectares of farmland each. The coffees are traceable to individual microlots so the growers are rewarded accordingly for their individual hard work. Furthermore, regular checks are performed at the co-op level to help maintain strict quality controls and all coffee is cupped by external coffee professionals.\r\n \r\nSimilarly, the smallholders of Guji have just 1-2 hectares of coffee growing in their back garden and process the coffees using traditional, time-honoured methods, under shade trees alongside other agricultural produce and without the use of chemicals.\r\n \r\nThe rich traditions and stories of these coffees are ingrained in each bean, and shines through every cup.	Different Altitudes	Mixed Varietals	Washed / Natural / Well-Hulled	f	f	labels/NLBLANK.9.pdf	labels/NL.9.pdf	1	18.00	6	f	Different Altitudes	不同海拔	Inspired by Californian Blue Bottle's Bella Donovan — Ciao Bella (which means “Hello Beautiful” in Italian) is bold and nuanced while preserving a mysterious elegance, and it’s hard not to fall in love at first sip.\r\n \r\nThe love child of two coffees — one from Ethiopia and the other from Indonesia — Ciao Bella is a combination of their best characteristics. The coffees from Guji, a  remote district found in the lush mountainous East Sidamo, Ethiopia, is bright and fruity, even a little floral, while the beans from the ancient Hindu Sunda Kingdom in West Java Raja Sunda, Indonesia has dark and earthy cocoa notes. \r\n \r\nBoth coffees were grown by smallholder farmers, organised by cooperatives. The Javanese co-op of Mount Halu comprises 100 farmers with 1-2 hectares of farmland each. The coffees are traceable to individual microlots so the growers are rewarded accordingly for their individual hard work. Furthermore, regular checks are performed at the co-op level to help maintain strict quality controls and all coffee is cupped by external coffee professionals.\r\n \r\nSimilarly, the smallholders of Guji have just 1-2 hectares of coffee growing in their back garden and process the coffees using traditional, time-honoured methods, under shade trees alongside other agricultural produce and without the use of chemicals.\r\n \r\nThe rich traditions and stories of these coffees are ingrained in each bean, and shines through every cup.	受到加州蓝瓶的Bella Donovan的启发 - Ciao Bella（意大利语，意思是“你好，美丽的”）的口感很浓但又细致入微，保持着一种神秘的优雅，而且很难在尝了第一口后还不爱上这咖啡。\r\n\r\n两种咖啡的爱的结晶 - 一种来自埃塞俄比亚，另一种来自印度尼西亚 - Ciao Bella是两者最好的特点的集合体。这种咖啡来自Guji，埃塞俄比亚东西达摩省的茂密山区的一个偏远地区，不是很浓，有果香，甚至还有花香，来自印度尼西亚West Java Raja Sunda的古老的Hindu Sunda Kingdom的咖啡豆有着浓浓的，充满大自然的气息的可可味。\r\n\r\n两种咖啡都是由小农种植，合作社组织的。Halu山的爪哇合作社有100位农民，每人有1-2公顷的农田。这些咖啡是可追踪的，可以追踪到个人的土地，所以种植者会因为个人的辛勤劳作而获得相应的奖励。此外，合作社会定期执行检察来帮助维持严格的质量控制，并且所有的咖啡都是由外部的咖啡专业人员包装的。\r\n\r\n同样地，Guji的小农在他们的后院有1-2公顷的咖啡种植地，并且使用传统的，由来已久的方法处理咖啡，在与其他农产品靠在一起的树荫下，不使用任何化学品。\r\n\r\n这些咖啡中丰富的传统和故事都根深蒂固地存在于每一粒咖啡豆中，并且照耀着每一杯咖啡。	Hook (Classic Blend)	Hook（经典融合）	A chic blend for the sophisticated trendsetter, this coffee is full-bodied yet elegant, balancing chocolatey notes with lively fruitiness. Don’t be shy to brew her with whatever brew method — she’s beautiful no matter what.	一款适合老练的潮人的精致融合，这咖啡浓郁而优雅，巧克力味和水果味完美融合。不要害羞，不论你用何种方法烹煮她 - 她都依旧美丽。	Washed / Natural / Well-Hulled	水洗处理法/日晒法/湿剥除法	East Sidamo, Ethiopia and West Java	东西达摩，埃塞俄比亚和西爪哇	Chocolate Ganache Fruit Tarts	巧克力甘纳许水果蛋挞	Mixed Varietals	混合品种	250	Medium	t	f	f	\N
27	The Godfather ShotPods	Rufino Dominguez López	La Paz	HN	Dark Caramel Sticky Date Pudding	Strong and powerful like The Godfather of the mafia, this coffee offers an explosion in your mouth with an aromatic dark Italian roast and hints of burnt caramel and sweet dates for a sinful mouthful and a satisfyingly bittersweet finish	5	2017-05-08	2017-05-15	14.00	"1"=>"1", "2"=>"5", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./the_godfather_thumbnail.png	Strong, Dark, Bold, Powerful. These are the similarities between this coffee and the famed mob drama, The Godfather. \r\n\r\nThis coffee was grown and produced on a small farm, Finca La Florida. Nestled in the highlands of charming Marcala, a municipality in the Honduran department of La Paz, Finca La Florida lies in a region internationally renowned for its exceptional and widely enjoyed coffee. To this day, coffee crops have become one of Marcala’s most precious patrimonies. To recognise the region’s commitment to high quality and sustainable standards, the DOP (Protected Origin Denomination) was awarded to Marcala in 2005, which was the first awarded to Central American country.\r\n \r\nProud of their coffee heritage and the region’s indigenous Lencan culture (one where the Lenca have a mutual relationship with their land, agriculture and interaction with the ecosystem), the farmers work hard to protect the quality and reputation of their coffee and this region remains one of the most beautiful and unspoiled areas of Honduras.\r\n \r\nRufino Dominguez López is one such farmer who exudes great passion when sharing his knowledge about the production of coffee at Finca La Florida. With perseverance and handwork, he purchased a small plot of of uncultivated land (just under a hectare), and transformed it into his pride and joy — in turn bringing joy to those who drink his coffees.	1,600m	Catuai	Washed	t	f			1	18.00	11	f	1,600m	1,600 米	Strong, Dark, Bold, Powerful. These are the similarities between this coffee and the famed mob drama, The Godfather. \r\n\r\nThis coffee was grown and produced on a small farm, Finca La Florida. Nestled in the highlands of charming Marcala, a municipality in the Honduran department of La Paz, Finca La Florida lies in a region internationally renowned for its exceptional and widely enjoyed coffee. To this day, coffee crops have become one of Marcala’s most precious patrimonies. To recognise the region’s commitment to high quality and sustainable standards, the DOP (Protected Origin Denomination) was awarded to Marcala in 2005, which was the first awarded to Central American country.\r\n \r\nProud of their coffee heritage and the region’s indigenous Lencan culture (one where the Lenca have a mutual relationship with their land, agriculture and interaction with the ecosystem), the farmers work hard to protect the quality and reputation of their coffee and this region remains one of the most beautiful and unspoiled areas of Honduras.\r\n \r\nRufino Dominguez López is one such farmer who exudes great passion when sharing his knowledge about the production of coffee at Finca La Florida. With perseverance and handwork, he purchased a small plot of of uncultivated land (just under a hectare), and transformed it into his pride and joy — in turn bringing joy to those who drink his coffees.	Strong, Dark, Bold, Powerful. These are the similarities between this coffee and the famed mob drama, The Godfather. \r\n\r\nThis coffee was grown and produced on a small farm, Finca La Florida. Nestled in the highlands of charming Marcala, a municipality in the Honduran department of La Paz, Finca La Florida lies in a region internationally renowned for its exceptional and widely enjoyed coffee. To this day, coffee crops have become one of Marcala’s most precious patrimonies. To recognise the region’s commitment to high quality and sustainable standards, the DOP (Protected Origin Denomination) was awarded to Marcala in 2005, which was the first awarded to Central American country.\r\n \r\nProud of their coffee heritage and the region’s indigenous Lencan culture (one where the Lenca have a mutual relationship with their land, agriculture and interaction with the ecosystem), the farmers work hard to protect the quality and reputation of their coffee and this region remains one of the most beautiful and unspoiled areas of Honduras.\r\n \r\nRufino Dominguez López is one such farmer who exudes great passion when sharing his knowledge about the production of coffee at Finca La Florida. With perseverance and handwork, he purchased a small plot of of uncultivated land (just under a hectare), and transformed it into his pride and joy — in turn bringing joy to those who drink his coffees.	Rufino Dominguez López	Rufino Dominguez López	Strong and powerful like The Godfather of the mafia, this coffee offers an explosion in your mouth with an aromatic dark Italian roast and hints of burnt caramel and sweet dates for a sinful mouthful and a satisfyingly bittersweet finish	Strong and powerful like The Godfather of the mafia, this coffee offers an explosion in your mouth with an aromatic dark Italian roast and hints of burnt caramel and sweet dates for a sinful mouthful and a satisfyingly bittersweet finish	Washed	水洗处理法	La Paz	拉巴斯	Dark Caramel Sticky Date Pudding	黑焦糖枣蓉布甸	Catuai	Catuai	200	Low	f	f	f	\N
28	A Midsummers Night’s Dream	San Miguel Escobar	Antigua	GT	Forest Berries Chocolate Roulade	In a world of magic, fairies, gods and goddesses, exists this enchanting coffee (or love potion) that tastes of rich dark chocolate and romantic forest berries. Regardless of your brew method, it’ll taste like a dream.	4	2017-05-28	2017-06-04	14.00	"1"=>"5", "2"=>"5", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./a_midsummer_nights_dream_thumbnail.png	The story behind this coffee is as romantic and whimsical as Shakespeare’s popular play, A Midsummer Night’s Dream.\r\n\r\nProduced in San Miguel Escobar, a beautiful small town situated at the base of Volcán Agua, approximately 4 miles from Antigua, Guatemala, these coffees display extraordinarily complex and delicious flavours.\r\n\r\nIn the 16th century, San Miguel was the second colonial capital of Guatemala until it was destroyed by a catastrophic mudflow from the volcano in 1541. In present times, it is a typical Guatemalan town and home to many coffee farmers. Plots of coffee stretch up the slopes of the volcano, providing the perfect location for shade-grown, high altitude coffee.\r\n\r\nThere are 30 members in the San Miguel Escobar Cooperative. The farmers are generally small-holders, owning an average of approximately 3 acres of land each. Long term sustainability and sustainable livelihoods is an imminent concern for the cooperative. The farmers and their families harvest the lands and process the coffees with extreme passion and care. \r\n\r\nThis valley is enclosed by three volcanoes: Agua, Fuego and Acatenango. Its climate is temperate year-round with steady moisture that makes this a suitable and perfect place for coffee to be slowly nurtured. Cool nights work in favour of the stabilisation process, allowing for no extreme climate variations between the dry and wet seasons of Guatemala.	1,500 - 1,600m	Bourbon and Typica	Fully Washed	t	f	labels/A_midsummer_night_dream.pdf	labels/a_midsummer_db.pdf	1	18.00	6	f	1,500 - 1,600m	1,500 - 1,600 米	The story behind this coffee is as romantic and whimsical as Shakespeare’s popular play, A Midsummer Night’s Dream.\r\n\r\nProduced in San Miguel Escobar, a beautiful small town situated at the base of Volcán Agua, approximately 4 miles from Antigua, Guatemala, these coffees display extraordinarily complex and delicious flavours.\r\n\r\nIn the 16th century, San Miguel was the second colonial capital of Guatemala until it was destroyed by a catastrophic mudflow from the volcano in 1541. In present times, it is a typical Guatemalan town and home to many coffee farmers. Plots of coffee stretch up the slopes of the volcano, providing the perfect location for shade-grown, high altitude coffee.\r\n\r\nThere are 30 members in the San Miguel Escobar Cooperative. The farmers are generally small-holders, owning an average of approximately 3 acres of land each. Long term sustainability and sustainable livelihoods is an imminent concern for the cooperative. The farmers and their families harvest the lands and process the coffees with extreme passion and care. \r\n\r\nThis valley is enclosed by three volcanoes: Agua, Fuego and Acatenango. Its climate is temperate year-round with steady moisture that makes this a suitable and perfect place for coffee to be slowly nurtured. Cool nights work in favour of the stabilisation process, allowing for no extreme climate variations between the dry and wet seasons of Guatemala.	这款咖啡背后的故事就像莎士比亚笔下流行的剧本，仲夏夜之梦一样浪漫而怪诞。\r\n\r\n产于圣米格尔埃斯科瓦尔，一座位于Volcán Agua底部的美丽小镇，距离危地马拉，安提瓜岛大约4英里（6.43千米），这些咖啡展示出极其复杂可口的味道。\r\n\r\n在16世纪，直到圣米格尔在1541年被一个灾难性的火山泥流摧毁前，圣米格尔一直都是危地马拉的第二殖民首都。在当今时代，圣米格尔是一个典型的危地马拉城镇，同时也是很多咖啡种植户的家。咖啡在火山斜坡上种植开来，为高海拔，蔽光生长的咖啡提供了完美的位置。\r\n\r\n在圣米格尔埃斯科瓦尔合作社，有30名成员。这些农民通常都是小自耕农，每人拥有平均约3英亩（1.2公顷）的土地。长期的可持续性和可持续的生计是合作社迫在眉睫的问题。咖啡种植户和他们的家人怀着极大的热情和关怀收割这片土地，处理咖啡。\r\n\r\n这个山谷被三座火山包围：阿瓜火山，富埃戈火山和阿卡特南戈火山。气候全年温和，降水稳定，这就使其成为缓慢培育咖啡的合适又完美的场所。凉爽的夜晚有助于稳定的过程，在危地马拉的干季和湿季就不会有极端的气候变化。\r\n	San Miguel Escobar	圣米格尔埃斯科瓦尔	In a world of magic, fairies, gods and goddesses, exists this enchanting coffee (or love potion) that tastes of rich dark chocolate and romantic forest berries. Regardless of your brew method, it’ll taste like a dream.	在一个充满魔术，精灵，神和女神的世界，存在着这种尝起来像口味更浓的黑巧克力和浪漫的森林浆果的迷人咖啡（或者说爱情魔药）。不管你煮咖啡的方式如何，这尝起来都像是一个梦。	Fully Washed	水洗处理法	Antigua	安提瓜岛	Forest Berries Chocolate Roulade	森林果巧克力卷	Bourbon and Typica	波邦和铁皮卡	250	Medium	f	f	f	\N
13	Sweet Bundchen	Oliveira Bueno Alves	Minas Gerais	BR	Kinder Bueno	On and off the runway, Sweet Bundchen is sexy, creamy, and confidently bold - tasting of rich milk chocolates & delicately nutty hazelnuts. Kinda like our favourite childhood chocolate, Kinder Bueno! Absolutely delicious regardless of your brew method.	4	2017-05-28	2017-06-04	14.00	"1"=>"1", "2"=>"4", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./sweet_bundchen_thumbnail.png	The name of this coffee was inspired by the much-loved Brazilian supermodel Gisele Bundchen — for very obvious reasons! Let’s not forget that Bundchen is also the Goodwill Ambassador for the United Nations Environment Programme. \r\n \r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nThe farm’s current challenge is the cost of production given Oliviera’s commitment to sustainable and quality coffees. Practices such as direct-trade that justly reward the farms for their coffees give producers like Oliviera better opportunities to invest in more efficient yet sustainable agricultural and harvesting processes.	1000m	Catuaí & Mundo Novo	Natural	t	f	labels/Sweet_Bundchen.pdf	labels/sweet_bundchen_db.pdf	1	18.00	6	f	1000m	1000 米	The name of this coffee was inspired by the much-loved Brazilian supermodel Gisele Bundchen — for very obvious reasons! Let’s not forget that Bundchen is also the Goodwill Ambassador for the United Nations Environment Programme. \r\n \r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nThe farm’s current challenge is the cost of production given Oliviera’s commitment to sustainable and quality coffees. Practices such as direct-trade that justly reward the farms for their coffees give producers like Oliviera better opportunities to invest in more efficient yet sustainable agricultural and harvesting processes.	这款咖啡名字的灵感来源于受人爱戴的巴西超模，吉赛尔·邦辰 - 原因很明显！不要忘记邦辰还是联合国环境规划署的亲善大使。\r\n\r\n从2001年开始，甜美邦辰产于米纳斯吉拉斯绿色，多丘陵的南部的Sitio Morro Agudo农场。由热情的奥利维拉·布埃诺·阿尔维斯管理。咖啡种植的历史与奥利维拉的家族史深深纠缠在一起，要一直追溯到19世纪晚期，她的曾祖父，Mario Marques Bueno，在巴西米纳斯吉拉斯地区开始种植咖啡。她对咖啡根深蒂固的爱与了解驱使着她努力改善栽培技术和可持续性的努力（比如，多关注Sitio Morro Agudo的土壤护理和管理，来保持最理想的土壤肥力和作物的再生），并且这带来了一些在这个区域最顶级的咖啡。奥利维拉又添置了一块7公顷的土地，专用于本土树种和荒野。\r\n\r\n因为奥利维拉致力于可持续和咖啡质量，农场当前的挑战是生产成本。公正地根据他们的咖啡奖励农民这样的直接贸易行为给奥利维拉投资更高效的可持续农业和收获过程提供了更好的机会。	Oliveira Bueno Alves	奥利维拉·布埃诺·阿尔维斯	On and off the runway, Sweet Bundchen is sexy, creamy, and confidently bold - tasting of rich milk chocolates & delicately nutty hazelnuts. Kinda like our favourite childhood chocolate, Kinder Bueno! Absolutely delicious regardless of your brew method.	台上台下，甜美邦辰都很性感，滑腻，浓浓的，尝起来像浓浓的牛奶巧克力和精致的坚果榛子。有点像我们童年最喜欢的巧克力，健达缤纷乐巧克力！不管你的烹煮方法如何都绝对美味。	Natural	日晒法	Minas Gerais	巴西	Kinder Bueno	健达缤纷乐巧克力	Catuaí & Mundo Novo	卡杜艾和蒙多诺渥	250	Low 	f	f	f	\N
11	Kopi Sutra	Mount Halu Co-operative	West Java	ID	Black Forest Cake	Everything you’d want in a Black Forest Cake — the depth and earthiness of cocoa, the juiciness and sweetness of black cherries, and a bold weighty body. An Everyday kinda coffee perfect for any brew method or occassion.	5	2017-05-28	2017-06-04	14.00	"1"=>"3", "2"=>"5", "3"=>"5", "4"=>"2", "5"=>"2", "6"=>"2"	./kopi_sutra_thumbnail.png	A coffee that evokes love and desire deserves a name like Kopi Sutra (derived from Kama Sutra), so we named it as such. \r\n \r\nThe Hindu Sunda Kingdom in West Java reigned from 669 till 1579. The descendants of the ancient kingdom, including the producers of this coffee, have remained upon the West Java Raja Sunda land for generations, humbly cultivating the same Sundanese soil.  \r\n \r\nPak Asep, the leader of the Mount Halu Co-op, manages about 100 farmers with 1-2 hectares of farmland each. Originally a vegetable farmer, he was inspired to move into coffee when he realised the power of the specialty coffee market to transform lives. Although blessed with rich volcanic soil, high altitudes and the ideal climate for producing top-quality Arabica coffee, these farmers did not achieve quality premiums in the past. Their coffees were controlled by big trading corporations and so were their incomes. By providing education, Pak has helped them to be more productive, profitable, and sustainable. \r\n \r\nThe coffees are traceable to individual microlots so  the growers are rewarded accordingly for their individual hard work. Furthermore, regular checks are performed at the co-op level to help maintain strict quality controls and all coffee is cupped by external coffee professionals. 	1,200 to 1,800 m	Lini S-795, Sigarar Utang, Typica, and Ateng (Catimor)	Wet-Hulled Method	t	f	labels/NLBLANK.13.pdf	labels/NL.13.pdf	1	18.00	6	f	1,200 to 1,800 m	1,200 - 1,800 米	A coffee that evokes love and desire deserves a name like Kopi Sutra (derived from Kama Sutra), so we named it as such. \r\n \r\nThe Hindu Sunda Kingdom in West Java reigned from 669 till 1579. The descendants of the ancient kingdom, including the producers of this coffee, have remained upon the West Java Raja Sunda land for generations, humbly cultivating the same Sundanese soil.  \r\n \r\nPak Asep, the leader of the Mount Halu Co-op, manages about 100 farmers with 1-2 hectares of farmland each. Originally a vegetable farmer, he was inspired to move into coffee when he realised the power of the specialty coffee market to transform lives. Although blessed with rich volcanic soil, high altitudes and the ideal climate for producing top-quality Arabica coffee, these farmers did not achieve quality premiums in the past. Their coffees were controlled by big trading corporations and so were their incomes. By providing education, Pak has helped them to be more productive, profitable, and sustainable. \r\n \r\nThe coffees are traceable to individual microlots so  the growers are rewarded accordingly for their individual hard work. Furthermore, regular checks are performed at the co-op level to help maintain strict quality controls and all coffee is cupped by external coffee professionals. 	能唤起爱和欲望的咖啡担得起Kopi Sutra（来源于卡马经）这个名字，所以我们如此命名。\r\n\r\n西爪哇的Hindu Sunda Kingdom在669年到1579年都处于统治地位。古王国的后裔，包括这款咖啡的生产商，一直生活在West Java Raja Sunda这片土地上，谦虚地培养着相同的巽他土壤。\r\n\r\nPak Asep，Hula山合作社的领导人，管理着大约100位农民，每个农民都有1-2公顷农田。起初，一个蔬菜农民，当他意识到精品咖啡市场的力量可以改变生活时，他被激发转种咖啡。尽管有丰富的生产最优质的阿拉比卡咖啡的火山土壤，高海拔和理想的气候，但是这些农民并没有在过去实现质量溢价。他们的咖啡都是受到大型贸易公司控制的，他们的收入也是。通过提供教育，Pak帮助他们变得更高效、更有利可图和更可持续。\r\n\r\n这些咖啡是可追踪的，可以追踪到个人的土地，所以种植者会因为个人的辛勤劳动而获得相应的奖励。此外，合作社会定期执行检察来帮助维持严格的质量控制，并且所有的咖啡都是由外部的咖啡专业人员包装的。	Mount Halu Co-operative	Halu 山合作社	Everything you’d want in a Black Forest Cake — the depth and earthiness of cocoa, the juiciness and sweetness of black cherries, and a bold weighty body. An Everyday kinda coffee perfect for any brew method or occassion.	所有你在黑森林蛋糕里想要的东西 - 可可的深度和质朴，黑樱桃的多汁性和甜度，以及浓烈的味道和厚厚的质感。这是适合日常喝的咖啡，适合所有烹煮方式和场合。	Wet-Hulled Method	湿剥除法	West Java	西爪哇	Black Forest Cake	黑森林蛋糕	Lini S-795, Sigarar Utang, Typica, and Ateng (Catimor)	Lini S-795，Sigarar Utang，铁皮卡，和Ateng （卡帝莫）	250	Medium	f	f	f	\N
41	Discovery Programme	Variety 	Brazil, Ethiopia, Java, Guatemala 	IN	Variety 	Ready to discover a whole new world of coffee? Start with this special curation of three uniquely irresistible coffees. 	4	2017-05-28	2017-06-04	18.00	"1"=>"5", "2"=>"5", "3"=>"5", "4"=>"5", "5"=>"5", "6"=>"5"	./website_thumbnails.png	Give Me S’mores from Karnataka, India is a velvety coffee reminiscent of dark hot chocolate, marshmallows and subtle spices. Guji Liya, from East Sidamo, Ethiopia is quite the opposite — delicate, floral, and bursting with bright citrus notes. Last but not least, Shake your Bun Bun! In this best selling blend of coffees from 5 countries across 3 regions, you’ll find a balanced cup with an indulgent taste of freshly baked cinnamon buns.\r\n\r\nHow the discovery pack works?\r\n\r\nStart off with these 3 coffees, tell us how you enjoyed them by rating these coffees in your account so we know what to sent you next and what not to. Continue receiving 3 x 80g bags of beans each time at your desired frequnecy or opt for a full 200g bag if you found what you love! 	Mix 	Mix 	Mix	t	t			1	22.00	6	f	Mix 	1256m	Give Me S’mores from Karnataka, India is a velvety coffee reminiscent of dark hot chocolate, marshmallows and subtle spices. Guji Liya, from East Sidamo, Ethiopia is quite the opposite — delicate, floral, and bursting with bright citrus notes. Last but not least, Shake your Bun Bun! In this best selling blend of coffees from 5 countries across 3 regions, you’ll find a balanced cup with an indulgent taste of freshly baked cinnamon buns.\r\n\r\nHow the discovery pack works?\r\n\r\nStart off with these 3 coffees, tell us how you enjoyed them by rating these coffees in your account so we know what to sent you next and what not to. Continue receiving 3 x 80g bags of beans each time at your desired frequnecy or opt for a full 200g bag if you found what you love! 	This coffee is good	Variety 		Ready to discover a whole new world of coffee? Start with this special curation of three uniquely irresistible coffees. 		Mix	Natural	Brazil, Ethiopia, Java, Guatemala 		Variety 		Mix 	Arabica	300	Mix	f	t	f	\N
26	Honey, I Shrunk The Kids II	Santa Teresa 	Santa Clara, Chiriquí Province	PA	Honeycomb and Wild Flower Honey	Expect to be graced by a delicate honeycomb sweetness balanced by divine dark chocolate. This honey washed coffee emanates a juicy mouthfeel that compliments the rich honeycomb and cocoa flavors. 	4	2017-05-21	2017-05-28	14.00	"1"=>"2", "2"=>"4", "3"=>"4", "4"=>"1", "5"=>"4", "6"=>"2"	./honey_i_shrunk_the_kids_II_thumbnail.png	Honey, I Shrunk The Kids was a movie we all watched as kids and remember vividly. We're pretty sure that this coffee will be one you'll remember for a long time too, particularly it's natural light floral wildflower honey sweetness - so throw out your sugar and sweeteners right now!\r\n \r\n\r\nFinca Santa Teresa is a boutique, high altitude coffee farm located in Panama, Santa Clara, Chiriquí Province, an area renowned for its unique and exceptional coffees. The Farm is located at latitude 1.08991, longitude 2.77899, and is close to the township of Volcan. The country’s “second city” of David is about an hour away.\r\n\r\nFinca Santa Teresa was established by the local Berard family in 1997. In 2012, it was acquired by Toby Smith and Andre Wierzbicki who have expanded the operations and scale. This has included the construction of new raised drying beds, additional planting of coffee, improvements to the staff housing, the construction of an owners’ cabin and the development of a new school on the farm. In 2015 Campbell and Grant Fleming joined Toby and Andre and made an investment into the Farm. This new investor group brings together a broad and complimentary set of skills that will augur a new era for the continued success of FST. The sales strategy of FST has also been developed under its new ownership. Historically, the coffee had been almost entirely sold into the US market to a single buyer. Sales are now global with customers from Russia to Switzerland to Taiwan to Australia to China. Toby Smith was the founder of Toby’s Estate Coffee, the largest specialty coffee roaster in Australia and now has a presence in the US (New York) and SE Asia. The Farm is a multi-award winner in the Best of Panama competition and its coffees are used by some of the finest baristas in competitions globally. In 2014 the Farm became UTZ Certified, a European standard that ensures best practice in all aspects of Farm practice. FST is the only Farm in Panama with this certification.	1,400 to 1,800 m	Caturra and Catuaí	Honey Processed	f	f	labels/honey_i_shrunk_the_kids_normal_.pdf	labels/Honey_I_shrunk_the_kids_DB_II_.pdf	1	18.00	6	f	1,400 to 1,800 m	1,200 - 1,700 米	Honey, I Shrunk The Kids was a movie we all watched as kids and remember vividly. We're pretty sure that this coffee will be one you'll remember for a long time too, particularly it's natural light floral wildflower honey sweetness - so throw out your sugar and sweeteners right now!\r\n \r\n\r\nFinca Santa Teresa is a boutique, high altitude coffee farm located in Panama, Santa Clara, Chiriquí Province, an area renowned for its unique and exceptional coffees. The Farm is located at latitude 1.08991, longitude 2.77899, and is close to the township of Volcan. The country’s “second city” of David is about an hour away.\r\n\r\nFinca Santa Teresa was established by the local Berard family in 1997. In 2012, it was acquired by Toby Smith and Andre Wierzbicki who have expanded the operations and scale. This has included the construction of new raised drying beds, additional planting of coffee, improvements to the staff housing, the construction of an owners’ cabin and the development of a new school on the farm. In 2015 Campbell and Grant Fleming joined Toby and Andre and made an investment into the Farm. This new investor group brings together a broad and complimentary set of skills that will augur a new era for the continued success of FST. The sales strategy of FST has also been developed under its new ownership. Historically, the coffee had been almost entirely sold into the US market to a single buyer. Sales are now global with customers from Russia to Switzerland to Taiwan to Australia to China. Toby Smith was the founder of Toby’s Estate Coffee, the largest specialty coffee roaster in Australia and now has a presence in the US (New York) and SE Asia. The Farm is a multi-award winner in the Best of Panama competition and its coffees are used by some of the finest baristas in competitions globally. In 2014 the Farm became UTZ Certified, a European standard that ensures best practice in all aspects of Farm practice. FST is the only Farm in Panama with this certification.	亲爱的，我把孩子缩小了是我们在小时候看的一部电影，而且现在还记忆犹新。我们确信这咖啡也会让你记住它很长一段时间，尤其是那自然轻柔的花蜜的甜味 - 所以现在就扔掉你的糖和甜味剂吧！\r\n\r\n这款咖啡是在Los Santos种植，在Beneficio del Rio Tarrazú处理的。位于Tarrazú River（塔拉珠河），Beneficio del Rio Tarrazú磨咖啡机使用的是在农场生成的清洁的水力发电，并且多次因其先进的设计和操作被哥斯达黎加政府评为Bandera Ecologica和“环境保护者”。\r\n\r\n实际上没有蜂蜜真的参与到“蜜处理法”中，而是哥斯达黎加最好的工厂特定使用的方法，“蜜”与咖啡豆上的“粘膜”（胶状物质）有关。蜜的颜色由干燥前仍留在咖啡豆上的粘膜水平决定。粘膜水平是咖啡甜度和味道的决定因素；传统上来说，越多的粘膜或者说“蜜”留在咖啡豆上，那么咖啡的甜度和味道就更棒。在粘膜干燥过程中也会发酵，这会减弱咖啡的酸度并让甜果味更加明显。\r\n\r\n塔拉珠地区丰富的沉积土壤使得那里有不同的树荫和丰富的生物多样性。这地方也是野生美洲豹的家，由于大规模的砍伐森林，变林为耕，野生美洲豹正濒临灭绝。喝着这咖啡，你就是在直接支持哥斯达黎加的Beneficio del Rio Tarrazú的可持续农业和美洲豹保育计划（JCP）。\r\n	Santa Teresa 	San Diego Mill	Expect to be graced by a delicate honeycomb sweetness balanced by divine dark chocolate. This honey washed coffee emanates a juicy mouthfeel that compliments the rich honeycomb and cocoa flavors. 	这咖啡的味道又淘气又美味，经过蜜处理的咖啡有淡淡的花香似的甜味，掺杂着较苦的黑巧克力的味道，最后有让人惊讶的水果的味道。无论你的烹煮方式是怎样的，这都是个真正经典的可爱之作。	Honey Processed	蜜处理法	Santa Clara, Chiriquí Province	塔拉珠	Honeycomb and Wild Flower Honey	蜂窝和黑巧克力块	Caturra and Catuaí	卡杜拉和卡杜艾	250	Low 	f	f	f	\N
37	Shake Your Bun Bun!	A Medley of Hook's 5 Favourites! 	India, West Java, Ethiopia, Guatemala 	BR	Toasted Cinnamon Buns	 Shake Your Bun Bun is a glorious fusion of all our best sellers. We combined a medley of coffees from Brazil, West Java, India, Guatemala, and Ethiopia into this blend. The resulting brew is an indulgent taste of toasty cinnamon buns.	4	2017-05-28	2017-06-04	14.00	"1"=>"4", "2"=>"4", "3"=>"4", "4"=>"4", "5"=>"4", "6"=>"4"	./Shake_your_Bun_Bun__Thumbnail.jpg	The blend appeals to even the craftiest of coffee drinkers. No one will blame you if you can’t help shakin’ your bun bun. \r\n\r\n	Mix Altitude 	Mix Varietal 	Mix Processes 	t	f	labels/shake_your_bun_bun.pdf	labels/shake_your_bun_bun_db.pdf	1	18.00	6	f	Mix Altitude 	1256m	The blend appeals to even the craftiest of coffee drinkers. No one will blame you if you can’t help shakin’ your bun bun. \r\n\r\n	This coffee is good	A Medley of Hook's 5 Favourites! 		 Shake Your Bun Bun is a glorious fusion of all our best sellers. We combined a medley of coffees from Brazil, West Java, India, Guatemala, and Ethiopia into this blend. The resulting brew is an indulgent taste of toasty cinnamon buns.		Mix Processes 	Natural	India, West Java, Ethiopia, Guatemala 		Toasted Cinnamon Buns		Mix Varietal 	Arabica	200	Low	t	f	f	\N
32	Give me S'mores	Shankar Family	Karnataka, India	IN	Hot Chocolate, Marshmallows, and Spice	Velvety hot chocolate topped with marshmallows and spice — what could be more comforting? Well, a coffee that tastes just like that! This cup will literally get you screaming “Give me S’more”! For the richest experience, brew with Espresso or Stove Top.	4	2017-05-28	2017-06-04	14.00	"1"=>"1", "2"=>"5", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./give_me_smores_thumbnail.png	This is a classic example of an outstanding Indian coffee with a cupping score of 87.5. This coffee was grown by the Shankar family in the Western Ghat mountains and the farm dates back to 1865 first established by the British, only changing hands in 1950s. The Shankar family’s complex approach to poly-culture farming included providing dense shades of fig, silver oak and jack fruit, with pepper vines, cardaom and vanilla accompanying in the understory.\r\n \r\nThis beautiful orchard is also home to a wide range of flora and fauna and wildlife such as deers, foxes, Jungle Pigeons and wild boards. The Kalledevarapura has been shade grown in a polyculture forest farm environment and has been cultivated without the use of pesticides, herbicides or synthetic fertilizers.\r\n	3800-4400M	S-795	Washed, sun dried on patio	t	f	labels/Give_me_smores.pdf	labels/give_me_smores_db.pdf	1	18.00	6	f	3800-4400M	1256m	This is a classic example of an outstanding Indian coffee with a cupping score of 87.5. This coffee was grown by the Shankar family in the Western Ghat mountains and the farm dates back to 1865 first established by the British, only changing hands in 1950s. The Shankar family’s complex approach to poly-culture farming included providing dense shades of fig, silver oak and jack fruit, with pepper vines, cardaom and vanilla accompanying in the understory.\r\n \r\nThis beautiful orchard is also home to a wide range of flora and fauna and wildlife such as deers, foxes, Jungle Pigeons and wild boards. The Kalledevarapura has been shade grown in a polyculture forest farm environment and has been cultivated without the use of pesticides, herbicides or synthetic fertilizers.\r\n	This coffee is good	Shankar Family		Velvety hot chocolate topped with marshmallows and spice — what could be more comforting? Well, a coffee that tastes just like that! This cup will literally get you screaming “Give me S’more”! For the richest experience, brew with Espresso or Stove Top.		Washed, sun dried on patio	Natural	Karnataka, India		Hot Chocolate, Marshmallows, and Spice		S-795	Arabica	250	Low 	f	f	f	\N
14	Guji Liya	Smallholders of Guji	East Sidamo	ET	Meyer Lemon Meringue Pie	Guji Liya will take you on a quintessential journey to the birthplace of coffee with its floral notes, hints of citrus, and a subtly sweet caramel finish (think: heavenly lemon meringue pies). Do her justice by brewing as a Drip or with an Aeropress.	3	2017-05-28	2017-06-04	14.00	"1"=>"4", "2"=>"2", "3"=>"2", "4"=>"5", "5"=>"5", "6"=>"5"	./guji_liya_thumbnail.png	Did you know that Ethiopia (more specifically the town of Bongia) is the birthplace of coffee and the beginnings of this sacred caffeine culture can be traced back to the 10th century?\r\n \r\nGuji is a remote district found in the lush mountainous East Sidamo, Ethiopia, and was named after one of the tribes that have resided in the region for centuries. More than any other country, Ethiopia has a broad genetic diversity among its coffee varieties, with each type having distinctive taste, shape and colour. Guji’s coffees are eminent for their complex floral aroma and citrus notes.\r\n \r\nThe coffees of Guji are organically grown by dedicated smallholders who often just have 1-2 hectares of coffee growing in their back garden and processed using traditional, time-honoured methods, under shade trees alongside other agricultural produce and without the use of chemicals. The farmers themselves have named their coffees ‘Liya’, a feminine and  Amharic form for the name Leah, meaning “weary”.\r\n \r\nWorking in partnership with Addis Exporter, a business with more than 100 years’ experience in exporting high quality coffee from Ethiopia, we have been able to select a complex washed coffee, that has been given the name ‘Liya’. The smallholder farmers that have hand-picked each and every coffee cherry sells them to a local trader who oversees the processing and sorting before trading the beans to the Ethiopia Commodity Exchange (ECX) that grades the beans according to Specialty Coffee Association of America (SCAA) standards. The best of the best are chosen by Addis Exporter and end up here with us and a premium is paid to the smallholder farmers as a reward for their impeccable work and beans.	2,000 to 2,150 m	Heirloom	Washed and Natural	t	f	labels/Guji_Liya.pdf	labels/Guji_Liya_db.pdf	1	18.00	6	f	2,000 to 2,150 m	2,000 - 2,150 米	Did you know that Ethiopia (more specifically the town of Bongia) is the birthplace of coffee and the beginnings of this sacred caffeine culture can be traced back to the 10th century?\r\n \r\nGuji is a remote district found in the lush mountainous East Sidamo, Ethiopia, and was named after one of the tribes that have resided in the region for centuries. More than any other country, Ethiopia has a broad genetic diversity among its coffee varieties, with each type having distinctive taste, shape and colour. Guji’s coffees are eminent for their complex floral aroma and citrus notes.\r\n \r\nThe coffees of Guji are organically grown by dedicated smallholders who often just have 1-2 hectares of coffee growing in their back garden and processed using traditional, time-honoured methods, under shade trees alongside other agricultural produce and without the use of chemicals. The farmers themselves have named their coffees ‘Liya’, a feminine and  Amharic form for the name Leah, meaning “weary”.\r\n \r\nWorking in partnership with Addis Exporter, a business with more than 100 years’ experience in exporting high quality coffee from Ethiopia, we have been able to select a complex washed coffee, that has been given the name ‘Liya’. The smallholder farmers that have hand-picked each and every coffee cherry sells them to a local trader who oversees the processing and sorting before trading the beans to the Ethiopia Commodity Exchange (ECX) that grades the beans according to Specialty Coffee Association of America (SCAA) standards. The best of the best are chosen by Addis Exporter and end up here with us and a premium is paid to the smallholder farmers as a reward for their impeccable work and beans.	你知道埃塞俄比亚（更具体地说，Bongia小镇）是咖啡的发源地，这个神圣文化的开端可以被追溯到10世纪吗？\r\n\r\nGuji 是埃塞俄比亚东西达摩省的茂密山区的一个偏远地区，并且以几个世纪以来一直居住在该区域的一个部落命名的。埃塞俄比亚在其咖啡品种方面，有广泛的遗传多样性，比其他国家都多，每种咖啡都有独特的味道，形状和颜色。Guji的咖啡以复杂的花香味和柑橘调著称。\r\n\r\nGuji的咖啡是由专用小农有机种植的，这些小农通常只有1 - 2公顷的咖啡生长在他们的后院，并且使用传统的，由来已久的方法处理咖啡，在与其他农产品靠在一起的树荫下，不使用任何化学品。农户自己将咖啡命名为“Liya”，是Leah这个名字的阿姆哈拉语形式，也是女性化的名字，意思是“疲倦的”。\r\n\r\n和Addis Exporter合作，Addis Exporter在从埃塞俄比亚出口高品质的咖啡方面有100多年的经验，我们能够选择复杂的水洗咖啡，这已经被命名为“Liya”，精心挑选每一个咖啡果的小农户将它们卖给本地的商人，他们负责在将咖啡豆卖给埃塞俄比亚商品交易所（ECXA）之前的处理和分拣工作。埃塞俄比亚商品交易所会根据美国精品咖啡协会（SCAA）的标准给咖啡豆划分等级。Addis Exporter会选择精品咖啡中的精品，然后咖啡就到了我们手中，小农户会获得一笔奖金作为对于他们的完美的工作和咖啡豆的奖励。\r\n	Smallholders of Guji	Guji 的小农	Guji Liya will take you on a quintessential journey to the birthplace of coffee with its floral notes, hints of citrus, and a subtly sweet caramel finish (think: heavenly lemon meringue pies). Do her justice by brewing as a Drip or with an Aeropress.	Guji Liya会带你开始一段完美的旅程，去往咖啡的发源地，那里的咖啡有花香的味道，柑橘属的味道以及最后是淡淡的甜焦糖味（想想：超好吃的柠檬酥皮派）。使用滤杯或爱乐压来烹煮她，会让你品尝到咖啡的美味。	Washed and Natural	水洗处理法和日晒法	East Sidamo	东西达摩	Meyer Lemon Meringue Pie	Meyer柠檬酥皮派	Heirloom	Heirloom	250	Medium	f	f	f	\N
5	Jai Ho Shotpods	The Araluguppe Family 	Chickmagalur, Bababudaangiri	IN	Velvety Dark Chocolate	Intense and velvety dark chocolate enlivened by subtle hints of dessert spices. This coffee is low on acidity, straight-up, and comforting. Superbly creamy and makes an excellent cappuccino. 	5	2016-08-26	2016-03-31	14.00	"1"=>"3", "2"=>"4", "3"=>"5", "4"=>"2", "5"=>"2", "6"=>"3"	./jaiho_.jpg	We named this coffee Jai Ho because we love Slumdog Millionaire, the Pussycat Dolls, and the fact that this coffee makes us want to dance all the time!\r\n\r\nCradled in the highlands of southwest Karnataka, Chikmagalur is cultivating a reputation for its cool climate, verdant mountain scenery, and growing range of lodgings. But the main perk of any visit is the coffee.\r\n\r\nJai Ho was grown by the Araluguppe family at the famous Thippanahalli Estate, in the district of Bababudaangiri and perched on the slopes of the highest peak in Karnataka, Mullayanagiri.  The Araluguppe family has been in the business of growing coffee for the past 7 generations. Yes, 7! It's no wonder the coffees from their farm are extremely sought after. Despite the high demand, the Araluguppe family continues to practice only sustainable methods of production and prides themselves for the quality of their coffees.	1280m	S.795	Wet processed	f	f			1	18.00	12	f	1280m	1280 米	We named this coffee Jai Ho because we love Slumdog Millionaire, the Pussycat Dolls, and the fact that this coffee makes us want to dance all the time!\r\n\r\nCradled in the highlands of southwest Karnataka, Chikmagalur is cultivating a reputation for its cool climate, verdant mountain scenery, and growing range of lodgings. But the main perk of any visit is the coffee.\r\n\r\nJai Ho was grown by the Araluguppe family at the famous Thippanahalli Estate, in the district of Bababudaangiri and perched on the slopes of the highest peak in Karnataka, Mullayanagiri.  The Araluguppe family has been in the business of growing coffee for the past 7 generations. Yes, 7! It's no wonder the coffees from their farm are extremely sought after. Despite the high demand, the Araluguppe family continues to practice only sustainable methods of production and prides themselves for the quality of their coffees.	We named this coffee Jai Ho because we love Slumdog Millionaire, the Pussycat Dolls, and the fact that this coffee makes us want to dance all the time!\r\n\r\nCradled in the highlands of southwest Karnataka, Chikmagalur is cultivating a reputation for its cool climate, verdant mountain scenery, and growing range of lodgings. But the main perk of any visit is the coffee.\r\n\r\nJai Ho was grown by the Araluguppe family at the famous Thippanahalli Estate, in the district of Bababudaangiri and perched on the slopes of the highest peak in Karnataka, Mullayanagiri.  The Araluguppe family has been in the business of growing coffee for the past 7 generations. Yes, 7! It's no wonder the coffees from their farm are extremely sought after. Despite the high demand, the Araluguppe family continues to practice only sustainable methods of production and prides themselves for the quality of their coffees.	The Araluguppe Family 	Araluguppe 家族	Intense and velvety dark chocolate enlivened by subtle hints of dessert spices. This coffee is low on acidity, straight-up, and comforting. Superbly creamy and makes an excellent cappuccino. 	Intense and velvety dark chocolate enlivened by subtle hints of dessert spices. This coffee is low on acidity, straight-up, and comforting. Superbly creamy and makes an excellent cappuccino. 	Wet processed	Wet processed	Chickmagalur, Bababudaangiri	Chickmagalur, Bababudaangiri	Velvety Dark Chocolate	醇和黑巧克力	S.795	S.795	200	Medium	f	f	f	\N
40	Appley Ever After 	Orlando Carbajal	La Paz 	HN	Caramelised apples 	Smooth and sweet like caramel toffees yet juicy and crisp like braeburn apples	4	2017-05-28	2017-06-04	14.00	"1"=>"2", "2"=>"5", "3"=>"4", "4"=>"3", "5"=>"2", "6"=>"2"	./appely_ever_after_thumbnail.jpg	Orlando Carbajal started his career as a coffee producer in August 1995 and this coffee is a fine example of the fruits of his labour.\r\n\r\nThe name of his farm is "Plantanares", meaning Banana Plantation as he grows his coffee under the shades of his banana trees. One fun fact is that the lot from which this coffee is harvested from is named after the previous owner of the farm, Don Juan.\r\n\r\nIn 2012, Senor Carbajal's farm was hit by the devastating La Roya (also known as coffee rust), which destroyed all of his crop. Fortunately, he did not give up and he replanted his crops and we are very happy to see that his hard work and determination has paid off.\r\n\r\nWe are lucky to be able to offer this coffee to our family and friends!	1450-1700m	Caturra, typica, HICAFE 90, lempira	Wet washed	t	f	labels/appley_ever_after.pdf	labels/appley_ever_after_db.pdf	1	18.00	4	f	1450-1700m	1256m	Orlando Carbajal started his career as a coffee producer in August 1995 and this coffee is a fine example of the fruits of his labour.\r\n\r\nThe name of his farm is "Plantanares", meaning Banana Plantation as he grows his coffee under the shades of his banana trees. One fun fact is that the lot from which this coffee is harvested from is named after the previous owner of the farm, Don Juan.\r\n\r\nIn 2012, Senor Carbajal's farm was hit by the devastating La Roya (also known as coffee rust), which destroyed all of his crop. Fortunately, he did not give up and he replanted his crops and we are very happy to see that his hard work and determination has paid off.\r\n\r\nWe are lucky to be able to offer this coffee to our family and friends!	This coffee is good	Orlando Carbajal		Smooth and sweet like caramel toffees yet juicy and crisp like braeburn apples		Wet washed	Natural	La Paz 		Caramelised apples 		Caturra, typica, HICAFE 90, lempira	Arabica	200	Medium	f	f	f	\N
39	The Grape Gatsby	Gakundu Farmers	Manyatta – Embu County	KE	Kyoho grapes	Fancy the luscious taste and sweet juiciness of Kyoho grapes in your coffee? This special edition coffee is indulgent enough for even Great Gatsby's most extravagant of parties, and no one would even be asking for wine. 	3	2017-05-28	2017-06-04	18.00	"1"=>"5", "2"=>"1", "3"=>"3", "4"=>"3", "5"=>"4", "6"=>"3"	./The_Grape_Gatsby.jpg	Gichugu Wet Mill is located in Embu County and has been operating since the early 1970s. Along with three other mills, they form the Gakundu Farmers Cooperative Society that consists of nearly 85% smallholder farms. About 980 farmers work at Gichugu, while the Gakundu Cooperative has over 3,600 registered members. Farmers take ripe cherries to be processed in the centralised wet mill, where they are pulped, fermented overnight, washed and sun dried in elevated tables. Gichugu produces about 40,000 kgs of green coffee each year.	1680m	Arabica, SL28	Washed, Sun Dried	t	t	labels/NLBLANK.11.pdf	labels/NL.11.pdf	1	22.00	6	f	1680m	1256m	Gichugu Wet Mill is located in Embu County and has been operating since the early 1970s. Along with three other mills, they form the Gakundu Farmers Cooperative Society that consists of nearly 85% smallholder farms. About 980 farmers work at Gichugu, while the Gakundu Cooperative has over 3,600 registered members. Farmers take ripe cherries to be processed in the centralised wet mill, where they are pulped, fermented overnight, washed and sun dried in elevated tables. Gichugu produces about 40,000 kgs of green coffee each year.	This coffee is good	Gakundu Farmers		Fancy the luscious taste and sweet juiciness of Kyoho grapes in your coffee? This special edition coffee is indulgent enough for even Great Gatsby's most extravagant of parties, and no one would even be asking for wine. 		Washed, Sun Dried	Natural	Manyatta – Embu County		Kyoho grapes		Arabica, SL28	Arabica	200	Medium	f	f	f	\N
21	Sweet Bundchen Shotpods	Oliveira Bueno Alves 	Minas Gerais	BR	Kinder Bueno	On and off the runway, Sweet Bundchen is sexy, creamy, and confidently bold - tasting of rich milk chocolates & delicately nutty hazelnuts. Add a little milk and be reminded of your favourite childhood chocolate bar, Kinder Bueno.	4	2017-04-24	2017-04-30	14.00	"1"=>"1", "2"=>"4", "3"=>"5", "4"=>"1", "5"=>"1", "6"=>"1"	./sweet_bundchen_thumbnail.png	The name of this coffee was inspired by the much-loved Brazilian supermodel Gisele Bundchen — for very obvious reasons! Let’s not forget that Bundchen is also the Goodwill Ambassador for the United Nations Environment Programme. \r\n \r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nThe farm’s current challenge is the cost of production given Oliviera’s commitment to sustainable and quality coffees. Practices such as direct-trade that justly reward the farms for their coffees give producers like Oliviera better opportunities to invest in more efficient yet sustainable agricultural and harvesting processes.	1000m	Catuaí & Mundo Novo	Natural	f	f			1	18.00	6	f	1000m	1000 米	The name of this coffee was inspired by the much-loved Brazilian supermodel Gisele Bundchen — for very obvious reasons! Let’s not forget that Bundchen is also the Goodwill Ambassador for the United Nations Environment Programme. \r\n \r\nSweet Bundchen was produced in Sitio Morro Agudo farm, in the green and hilly South of Minas Gerais, run by the passionate Oliveira Bueno Alves since 2001. The history of coffee farming is deeply entwined with Oliviera’s family history, going all the way back to the late 1800s when her great-grandfather, Mr. Mario Marques Bueno, began cultivating coffee in Brazil’s Minas Gerais region. The deep-seated knowledge and love for coffee has driven Oliveira to strive to improve cultivation techniques and sustainability efforts (for example, much attention is paid to soil care and management in Sitio Morro Agudo to maintain optimal soil fertility and regeneration of crop), and this has resulted in some of the highest quality coffees in the region. Oliviera has set aside another 7 hectares of land, conserved and dedicated to indigenous tree species and wilderness.\r\n \r\nThe farm’s current challenge is the cost of production given Oliviera’s commitment to sustainable and quality coffees. Practices such as direct-trade that justly reward the farms for their coffees give producers like Oliviera better opportunities to invest in more efficient yet sustainable agricultural and harvesting processes.	这款咖啡名字的灵感来源于受人爱戴的巴西超模，吉赛尔·邦辰 - 原因很明显！不要忘记邦辰还是联合国环境规划署的亲善大使。\r\n\r\n从2001年开始，甜美邦辰产于米纳斯吉拉斯绿色，多丘陵的南部的Sitio Morro Agudo农场。由热情的奥利维拉·布埃诺·阿尔维斯管理。咖啡种植的历史与奥利维拉的家族史深深纠缠在一起，要一直追溯到19世纪晚期，她的曾祖父，Mario Marques Bueno，在巴西米纳斯吉拉斯地区开始种植咖啡。她对咖啡根深蒂固的爱与了解驱使着她努力改善栽培技术和可持续性的努力（比如，多关注Sitio Morro Agudo的土壤护理和管理，来保持最理想的土壤肥力和作物的再生），并且这带来了一些在这个区域最顶级的咖啡。奥利维拉又添置了一块7公顷的土地，专用于本土树种和荒野。\r\n\r\n因为奥利维拉致力于可持续和咖啡质量，农场当前的挑战是生产成本。公正地根据他们的咖啡奖励农民这样的直接贸易行为给奥利维拉投资更高效的可持续农业和收获过程提供了更好的机会。	Oliveira Bueno Alves 	奥利维拉·布埃诺·阿尔维斯	On and off the runway, Sweet Bundchen is sexy, creamy, and confidently bold - tasting of rich milk chocolates & delicately nutty hazelnuts. Add a little milk and be reminded of your favourite childhood chocolate bar, Kinder Bueno.	On and off the runway, Sweet Bundchen is sexy, creamy, and confidently bold - tasting of rich milk chocolates & delicately nutty hazelnuts. Add a little milk and be reminded of your favourite childhood chocolate bar, Kinder Bueno.	Natural	日晒法	Minas Gerais	巴西	Kinder Bueno	健达缤纷乐巧克力	Catuaí & Mundo Novo	卡杜艾和蒙多诺渥	200	Low	f	f	f	\N
38	Hands off my Nuts! Shotpods	Carlos Alberto Ulchur	Cauca	CO	Honey Coated Nuts	This fully washed Columbian coffee resonates with luscious nuttiness and subtle sweetness. Hazelnut and almond notes are accompanied by beautiful wild flower honey	4	2017-04-24	2017-04-30	14.00	"1"=>"2", "2"=>"4", "3"=>"4", "4"=>"2", "5"=>"2", "6"=>"2"	./hands_off_my_nuts_thumbnail.png	Expect to enjoy this coffee at any time of the day and don’t worry, no one’s gonna judge you for going nuts over this.\r\n\r\nThis microlot was produced and processed by Carlos Alberto Ulchur, a smallholder member of the ASORCAFE - Inzá, Cauca producer group. Produced at 1,900 metres above sea level, this very special lot was selected out from the rest of the organization’s producers as being of exceptional quality. This coffee had us wowed and is a great showcase for what this remote and often overlooked region of Colombia has to offer.	1900m	Arabica	Fully Washed	t	f			1	18.00	9	f	1900m	1256m	Expect to enjoy this coffee at any time of the day and don’t worry, no one’s gonna judge you for going nuts over this.\r\n\r\nThis microlot was produced and processed by Carlos Alberto Ulchur, a smallholder member of the ASORCAFE - Inzá, Cauca producer group. Produced at 1,900 metres above sea level, this very special lot was selected out from the rest of the organization’s producers as being of exceptional quality. This coffee had us wowed and is a great showcase for what this remote and often overlooked region of Colombia has to offer.	This coffee is good	Carlos Alberto Ulchur		This fully washed Columbian coffee resonates with luscious nuttiness and subtle sweetness. Hazelnut and almond notes are accompanied by beautiful wild flower honey		Fully Washed	Natural	Cauca		Honey Coated Nuts		Arabica	Arabica	200	Medium	f	f	f	\N
42	Peach, Please! Cold Brew	Shakiso Woreda	Sidama, Guji	ET	Juicy Sweet Peach	Our summer favourite is now available as a bottled cold brew! Enjoy it's sweet peachy and rosy floral notes with each sip, and we promise you, our cold brew will cool you down and pep you up! Perfect for those seeking more caffeine, less acidity, and of course, delicious chilled coffee.	3	2017-07-09	2017-07-16	35.00	"1"=>"5", "2"=>"2", "3"=>"2", "4"=>"2", "5"=>"2", "6"=>"5"	peach_thumbnail-01_1.png	This coffee grows in the Oromia region, one of Ethiopia’s largest regions. The farm is located in the Guji zone, the southern part of Oromia that borders on the Sidama and Gedeo zones. The enterprise has 640 hectares with its own nursery sites to grow coffee seedlings. During harvest, there are more than 300 coffee pickers harvesting coffee. About 150 of them supply coffee individually to the wet mill.	1700m	Heirloom	Fully washed	t	f			1	39.00	6	f	1700m	1256m	This coffee grows in the Oromia region, one of Ethiopia’s largest regions. The farm is located in the Guji zone, the southern part of Oromia that borders on the Sidama and Gedeo zones. The enterprise has 640 hectares with its own nursery sites to grow coffee seedlings. During harvest, there are more than 300 coffee pickers harvesting coffee. About 150 of them supply coffee individually to the wet mill.	This coffee is good	Shakiso Woreda		Our summer favourite is now available as a bottled cold brew! Enjoy it's sweet peachy and rosy floral notes with each sip, and we promise you, our cold brew will cool you down and pep you up! Perfect for those seeking more caffeine, less acidity, and of course, delicious chilled coffee.		Fully washed	Natural	Sidama, Guji		Juicy Sweet Peach		Heirloom	Arabica	2000	Low - Medium	f	f	f	Peach-Please.jpg
\.


--
-- Data for Name: coffees_coffeetype_brew_method; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_coffeetype_brew_method (id, coffeetype_id, brewmethod_id) FROM stdin;
5004	16	2
3595	25	6
5005	16	3
3820	34	1
5006	16	7
3821	34	3
5007	14	8
5008	14	2
3822	34	4
3823	34	5
5009	14	3
5010	14	7
5011	13	1
5012	13	4
5013	13	5
5014	13	7
3602	18	1
3603	18	2
3604	18	3
3605	18	4
3606	18	5
5015	11	1
5016	11	3
5017	11	4
4673	6	7
2300	3	1
2301	3	5
4674	24	7
3607	18	6
3608	18	7
5018	11	5
5019	11	7
5020	21	6
4927	26	1
4928	26	2
3609	17	1
2008	12	2
2009	12	3
2010	12	4
2011	12	7
3610	17	2
3611	17	3
4929	26	3
4930	26	4
4931	26	5
4008	35	2
4009	35	3
3612	17	4
4932	26	7
3613	17	5
2018	4	2
2019	4	3
2020	4	4
4014	30	1
3614	17	6
2023	2	2
2024	2	3
2025	2	4
4635	36	6
3615	17	7
2502	19	2
2503	19	5
2504	19	7
3616	8	2
2506	15	1
2507	15	2
2508	15	3
2509	15	4
2510	15	5
2511	15	7
3617	8	3
3618	7	7
4190	31	8
4191	31	1
4192	31	2
4193	31	3
3593	29	6
3621	1	7
4967	5	6
4969	22	6
4970	23	6
4971	27	6
4972	41	1
4973	41	2
4974	41	3
4975	41	4
4976	41	5
4246	33	2
4247	33	3
4977	41	7
4978	41	8
4979	40	2
4980	40	3
4981	40	4
4982	40	5
4983	39	8
4984	39	2
4985	39	3
4986	37	1
4987	37	2
4988	37	3
4989	37	4
4990	37	5
4991	32	1
4992	32	5
4993	28	1
4994	28	2
4995	28	3
4996	28	4
4997	28	5
4998	20	1
4999	20	2
5000	20	3
5001	20	4
5002	20	5
5003	20	7
5022	38	6
5023	42	8
\.


--
-- Name: coffees_coffeetype_brew_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_coffeetype_brew_method_id_seq', 5023, true);


--
-- Name: coffees_coffeetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_coffeetype_id_seq', 42, true);


--
-- Data for Name: coffees_farmphotos; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_farmphotos (id, photo1, photo2, photo3, photo4, photo5, coffee_id) FROM stdin;
\.


--
-- Name: coffees_farmphotos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_farmphotos_id_seq', 1, false);


--
-- Data for Name: coffees_flavor; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_flavor (id, name, img, name_en, name_zh_hans) FROM stdin;
1	Berries	./berries.jpg	Berries	\N
2	Caramel	./caramel.jpg	Caramel	\N
3	Chocolate	./chocolate.jpg	Chocolate	\N
4	Citrus Lemons	./citrus-lemons.jpg	Citrus Lemons	\N
5	Edible Flowers	./edible-flower.jpg	Edible Flowers	\N
6	Stone Fruits	./stone-fruits.jpg	Stone Fruits	\N
7	None	./no-preference.jpg	None	无
\.


--
-- Name: coffees_flavor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_flavor_id_seq', 7, true);


--
-- Data for Name: coffees_rawbean; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_rawbean (id, name, stock, status, created_date) FROM stdin;
6	West Java Papadayan 	120.00	t	2016-11-06 06:43:27.950914+00
3	Brazil Dutra	148.00	t	2016-11-06 06:40:01.578083+00
1	Ethiopia Aricha 	104.00	t	2016-10-11 11:50:45.719246+00
2	Guatemala Antigua	90.00	t	2016-11-06 06:39:41.643799+00
7	Costa Rica Honey	0.00	f	2016-11-06 06:46:09.369012+00
4	Colombia La Joyeria	0.00	f	2016-11-06 06:41:08.496538+00
5	Ethiopia Guji Liya	155.00	t	2016-11-06 06:42:35.827637+00
\.


--
-- Name: coffees_rawbean_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_rawbean_id_seq', 10, true);


--
-- Data for Name: coffees_sharedcoffeesticker; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY coffees_sharedcoffeesticker (id, "user", post, hashtag, created, customer_id) FROM stdin;
\.


--
-- Name: coffees_sharedcoffeesticker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('coffees_sharedcoffeesticker_id_seq', 1, false);


--
-- Data for Name: content_brewguide; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_brewguide (id, name, name_en, name_zh_hans, description, description_en, description_zh_hans, video, required_list, required_list_en, required_list_zh_hans, brew_time, brew_time_en, brew_time_zh_hans, img, banner, slug, banner_img_bcolor, banner_txt_bcolor, subtitle, subtitle_en, subtitle_zh_hans) FROM stdin;
1	Espresso	Espresso		We are going to walk you through, the step by step of, pulling a shot of espresso. The purpose here is really to leave you with enough of an understanding that you can diagnose what is wrong with your own coffee and improve on it. We are using a Breville dual boiler for the purpose of this guide. It is an amazing machine that blurs the line between home and a commercial espresso machine. We are not being paid by Breville, we just thougt that it is a really great piece of equipment. 	We are going to walk you through, the step by step of, pulling a shot of espresso. The purpose here is really to leave you with enough of an understanding that you can diagnose what is wrong with your own coffee and improve on it. We are using a Breville dual boiler for the purpose of this guide. It is an amazing machine that blurs the line between home and a commercial espresso machine. We are not being paid by Breville, we just thougt that it is a really great piece of equipment. 		hqVJ3Z-TZ1c	Coffee\r\nEspresso machine\r\nDouble basket \r\nportafilter\r\nGrinder\r\nScale\r\nTamper\r\nTimer	Coffee\r\nEspresso machine\r\nDouble basket \r\nportafilter\r\nGrinder\r\nScale\r\nTamper\r\nTimer		30 seconds	30 seconds	30 seconds	./Espresso.png	./brew_guide_espresso-1.png	espresso	#774f43	#3e2b25			
2	V60	V60		Commonly called drip brew, pour over coffee, and filtered coffee, drip coffee is a straight to the point extraction method. Using only the force of gravity and some coffee ground, this is how your grandmother made her coffee. That is not to say that you can’t make a good drip brew. Like other slow extraction methods, it is a very forgiving method. We personally love this method of brewing coffees, as the clean brew that comes out of it just brings out the wonderful elements you can expect from each coffee!	Commonly called drip brew, pour over coffee, and filtered coffee, drip coffee is a straight to the point extraction method. Using only the force of gravity and some coffee ground, this is how your grandmother made her coffee. That is not to say that you can’t make a good drip brew. Like other slow extraction methods, it is a very forgiving method. We personally love this method of brewing coffees, as the clean brew that comes out of it just brings out the wonderful elements you can expect from each coffee!		i9Nh3GUDlpo	A V60 Dripper \r\n(Get it free if you are new to Hook Coffee) \r\n\r\nA V60 Filter papers\r\n\r\nA Bag of Fresh Coffee\r\n\r\nMug \r\n\r\nScoop \r\n\r\nKettle\r\n\r\nScale (Optional but good to have) 	A V60 Dripper \r\n(Get it free if you are new to Hook Coffee) \r\n\r\nA V60 Filter papers\r\n\r\nA Bag of Fresh Coffee\r\n\r\nMug \r\n\r\nScoop \r\n\r\nKettle\r\n\r\nScale (Optional but good to have) 		90 seconds	90 seconds	30 seconds	./drip.png	./brew_guide_v60-1.png	v60	#ce9630	#846121	aka Pourover	aka Pourover	
3	Stovetop	Stovetop		A real classic as far as extraction methods go. The stove top coffee maker is a simple, timeless, method to extract coffee. These machines can be tucked away, out of site, when not in use, and a good one will last forever. \r\nThe most common stove top coffee machine is the Moka pot. The Italian machine has become synonymous with stove top extraction.	A real classic as far as extraction methods go. The stove top coffee maker is a simple, timeless, method to extract coffee. These machines can be tucked away, out of site, when not in use, and a good one will last forever. \r\nThe most common stove top coffee machine is the Moka pot. The Italian machine has become synonymous with stove top extraction.		TBaNhmemifc	Stovetop or Moka Pot\r\n\r\nFresh Coffee\r\n\r\nStove	Stovetop or Moka Pot\r\n\r\nFresh Coffee\r\n\r\nStove		90 seconds	90 seconds	30 seconds	./stove_top.png	./brew_guide_stove_top-1.png	stovetop	#294249	#1c2c31			
4	French Press	French Press		The French press goes by many names all over the world. You might know it as the coffee press or the coffee plunger. It is a slow extraction method that works by sitting coffee ground in a container and adding water just shy of boiling. The plunger is then pressed down to force the ground to the bottom of the beaker. After extraction the water is then poured into a cup.	The French press goes by many names all over the world. You might know it as the coffee press or the coffee plunger. It is a slow extraction method that works by sitting coffee ground in a container and adding water just shy of boiling. The plunger is then pressed down to force the ground to the bottom of the beaker. After extraction the water is then poured into a cup.		lPA_teaMKaE	A French Press aka Plunger\r\n\r\nFresh Coffee\r\n\r\nHot Water	A French Press aka Plunger\r\n\r\nFresh Coffee\r\n\r\nHot Water		240 seconds	240 seconds	30 seconds	./french_press.png	./brew_guide_french_press_3-1.png	french-press	#562622	#3c1918	aka Coffee Plunger	aka Coffee Plunger	
5	Aeropress	Aeropress		In 2005, president of Aerobie, Alan Adler, was unhappy with the time required to brew his coffee. With that dissatisfaction, he set out to bring to life an apparatus that would brew perfectly balanced cups of coffee with minimal work and clean-up necessary, and the Aeropress was born.\r\n\r\nYears on the Aeropress has a cult-like following, swearing by its versatility, all-rounded quality, and utter convenience. The Aeropress looks like something you’d find in a science lab, which is pretty appropriate for coffee geeks like us! But don’t worry, unlike school science experiments, you can’t go wrong with the Aeropress if you follow the steps.	In 2005, president of Aerobie, Alan Adler, was unhappy with the time required to brew his coffee. With that dissatisfaction, he set out to bring to life an apparatus that would brew perfectly balanced cups of coffee with minimal work and clean-up necessary, and the Aeropress was born.\r\n\r\nYears on the Aeropress has a cult-like following, swearing by its versatility, all-rounded quality, and utter convenience. The Aeropress looks like something you’d find in a science lab, which is pretty appropriate for coffee geeks like us! But don’t worry, unlike school science experiments, you can’t go wrong with the Aeropress if you follow the steps.		tKsQ0aDlqIU	Aeropress Kit comprising:\r\n1 x Aeropress\r\n1 x Aeropress Filters\r\n1 X Aerpresss Paddle\r\n1 X Aeropress Scoop\r\n\r\nFresh Coffee\r\n\r\nA Mug\r\n\r\nWeighing Scale (Optional but good to have!)	Aeropress Kit comprising:\r\n1 x Aeropress\r\n1 x Aeropress Filters\r\n1 X Aerpresss Paddle\r\n1 X Aeropress Scoop\r\n\r\nFresh Coffee\r\n\r\nA Mug\r\n\r\nWeighing Scale (Optional but good to have!)		90 seconds	90 seconds	30 seconds	./aeropress.png	./brew_guide_aeropress-1.png	aeropress	#4c2432	#3a1B27			
\.


--
-- Name: content_brewguide_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_brewguide_id_seq', 5, true);


--
-- Data for Name: content_brewguidestep; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_brewguidestep (id, img, description, description_en, description_zh_hans, brew_guide_id) FROM stdin;
1		The first thing we do is fill the basket with ground coffee. This is called dosing. You want the coffee ground to crown over the top of the basket. It can feel like a bit of a waste of beans, but we are talking about a couple of cents worth of beans sacrificed in pursuit of a perfect coffee.	The first thing we do is fill the basket with ground coffee. This is called dosing. You want the coffee ground to crown over the top of the basket. It can feel like a bit of a waste of beans, but we are talking about a couple of cents worth of beans sacrificed in pursuit of a perfect coffee.		1
2		Next, take the group head and tap it twice on a bench or the grinder. Great!! The tap pushes the coffee around, and this helps distribute any clumps in the basket. We usually dose once more into the basket. This is to fill up any of the space uncovered. We find that the extra tap gets us closer to the ideal brew ratio by increasing the weight of dried ground. There should be around 18-20g of grounds in a double shot filter basket.	Next, take the group head and tap it twice on a bench or the grinder. Great!! The tap pushes the coffee around, and this helps distribute any clumps in the basket. We usually dose once more into the basket. This is to fill up any of the space uncovered. We find that the extra tap gets us closer to the ideal brew ratio by increasing the weight of dried ground. There should be around 18-20g of grounds in a double shot filter basket.		1
3		Then use your finger and run it over the top of the basket. Flicking the coffee, crowning out the top of the basket, into a bin or down a sink. You can use any flat surface. We have seen people use razor blades, and even the flat edge of the tamper. If you do use your finger, find a flat edge.	Then use your finger and run it over the top of the basket. Flicking the coffee, crowning out the top of the basket, into a bin or down a sink. You can use any flat surface. We have seen people use razor blades, and even the flat edge of the tamper. If you do use your finger, find a flat edge.		1
4		Are you happy with your tamp? If so, purge some water out of the espresso machine just to wash out any old grounds left there previously, lock the basket into the espresso machine and start the extraction. Depending on your machine, you might need to start the extraction within a certain time of placing the group head in the machine. There is a lot of heat and pressure just waiting to spoil you shot, so if you lock the group head in, and then you walk away, you might not some back to a very nice coffee. It is recommended to press the button within 5 seconds!	Are you happy with your tamp? If so, purge some water out of the espresso machine just to wash out any old grounds left there previously, lock the basket into the espresso machine and start the extraction. Depending on your machine, you might need to start the extraction within a certain time of placing the group head in the machine. There is a lot of heat and pressure just waiting to spoil you shot, so if you lock the group head in, and then you walk away, you might not some back to a very nice coffee. It is recommended to press the button within 5 seconds!		1
5		We aim for an extraction time of between 25 to 35 seconds. There is so much misinformation and misconception surrounding why, but my understanding is that at 9 bars of pressure, which is what most coffee machines are set to, it takes about this long to extract the average amount of coffee in a basket. A fancy espresso machine doesn’t mean a thing without a quality grinder.We use and recommend the Breville Smart Pro Grinder. It is a phenomenal machine, and you have to give credit where it is due. Remember when I said the ideal espresso extraction time was between 25 to 30 seconds. If your time is over or under this, the culprit is almost always the grind. When I was learning to make coffee I was given this analogy, and it helped me to properly understand how setting the grind works. There is this other method that has proven to be rather handy - if your shot is gushing out during the first 5 seconds - adjust the grind size down (i.e. you need a finer grind size), vice versa. If the first 5 seconds is perfect, but the shot starts gushing after, there issnt enough grounds in the basket, so dose more. Try this technique and you will be plesantly surprised!	We aim for an extraction time of between 25 to 35 seconds. There is so much misinformation and misconception surrounding why, but my understanding is that at 9 bars of pressure, which is what most coffee machines are set to, it takes about this long to extract the average amount of coffee in a basket. A fancy espresso machine doesn’t mean a thing without a quality grinder.We use and recommend the Breville Smart Pro Grinder. It is a phenomenal machine, and you have to give credit where it is due. Remember when I said the ideal espresso extraction time was between 25 to 30 seconds. If your time is over or under this, the culprit is almost always the grind. When I was learning to make coffee I was given this analogy, and it helped me to properly understand how setting the grind works. There is this other method that has proven to be rather handy - if your shot is gushing out during the first 5 seconds - adjust the grind size down (i.e. you need a finer grind size), vice versa. If the first 5 seconds is perfect, but the shot starts gushing after, there issnt enough grounds in the basket, so dose more. Try this technique and you will be plesantly surprised!		1
6		So when do you know when to stop the extraction? Do not rely too much on blonding. Blonding is the practice of stopping an espresso shot when the colours start to mix and the crema changes to a blond colour. Blonding can be very subjective and often not the best measure. Ideally, we would recommend you to use a weighing scale to measure the weight of the shot. You should be aiming to achieve a 1:1 ratio (a Ristretto) - so 20g of grounds to 20g of coffee. There are other ratios as well which you can experiment with - Normale 1:2 and Lungo 1:3. If you find the shot too acidic, try pulling a longer shot like a Normale to achieve a rounder shot.	So when do you know when to stop the extraction? Do not rely too much on blonding. Blonding is the practice of stopping an espresso shot when the colours start to mix and the crema changes to a blond colour. Blonding can be very subjective and often not the best measure. Ideally, we would recommend you to use a weighing scale to measure the weight of the shot. You should be aiming to achieve a 1:1 ratio (a Ristretto) - so 20g of grounds to 20g of coffee. There are other ratios as well which you can experiment with - Normale 1:2 and Lungo 1:3. If you find the shot too acidic, try pulling a longer shot like a Normale to achieve a rounder shot.		1
7		There you go! If you want to get a little more geeky and delve into greater details on perfecting your Espresso shot, downloda our Hook Coffee master brew guide here! Have fun!	There you go! If you want to get a little more geeky and delve into greater details on perfecting your Espresso shot, downloda our Hook Coffee master brew guide here! Have fun!		1
8		Place filter paper into the V60 dripper and make sure there are hole for the grounds to wiggle its way through.	Place filter paper into the V60 dripper and make sure there are hole for the grounds to wiggle its way through.		2
9		Give the filter paper a rinse with your hot water to remove the papery taste. Your water should be around 90 degrees celsius to brew a good pour over!	Give the filter paper a rinse with your hot water to remove the papery taste. Your water should be around 90 degrees celsius to brew a good pour over!		2
10		Scoop 12g of grounds on top of the filter (remember the golden ratio here is 60g of coffee to 1litre of water). If you have a Hario V60, then you can simply use the scoop provided to measure out approximately 12 grams of coffee.	Scoop 12g of grounds on top of the filter (remember the golden ratio here is 60g of coffee to 1litre of water). If you have a Hario V60, then you can simply use the scoop provided to measure out approximately 12 grams of coffee.		2
11		Pour just enough water to cover the grounds and wait for about 30 seconds - this helps to release the gasses that builds up during roasting to ensure a better brew.	Pour just enough water to cover the grounds and wait for about 30 seconds - this helps to release the gasses that builds up during roasting to ensure a better brew.		2
12		Then keep pouring in a circular motion, and be sure that you pour over any coffee on the sides of the filter until the desired water amount which in this case is 200ml of water.	Then keep pouring in a circular motion, and be sure that you pour over any coffee on the sides of the filter until the desired water amount which in this case is 200ml of water.		2
13		Once the water has filter through, discard the paper filter and enjoy!	Once the water has filter through, discard the paper filter and enjoy!		2
14		Pre-boil a kettle of water. You don’t have to do this if you don’t want to, but this can speed up your brewing time!	Pre-boil a kettle of water. You don’t have to do this if you don’t want to, but this can speed up your brewing time!		3
15		Pour the boiled water into the base of the stove-top, up to the pressure valve and no higher. I repeat, DO NOT FILL ABOVE THIS SAFETY VALVE!	Pour the boiled water into the base of the stove-top, up to the pressure valve and no higher. I repeat, DO NOT FILL ABOVE THIS SAFETY VALVE!		3
16		Fill up the coffee basket with coffee. You don’t need to tamp the ground into the basket. There is not enough pressure created for the water to extract through a compressed bed of coffee. You just fill until it is level with the top of the basket and then scrape off the excess with your finger.	Fill up the coffee basket with coffee. You don’t need to tamp the ground into the basket. There is not enough pressure created for the water to extract through a compressed bed of coffee. You just fill until it is level with the top of the basket and then scrape off the excess with your finger.		3
17		Screw the pot onto the base. Be careful to hold it with something to insulate the heat.	Screw the pot onto the base. Be careful to hold it with something to insulate the heat.		3
18		Place the Moka pot on the stove and heat it at a medium heat. You need to get it to a boil, so the evaporating water will pass through the bed of coffee and into the top of the pot.	Place the Moka pot on the stove and heat it at a medium heat. You need to get it to a boil, so the evaporating water will pass through the bed of coffee and into the top of the pot.		3
19		Turn off the stove a few seconds after the first bubble appear at the top of the spout. Listen out for a percolation sound. You will come to know this sound in time, but it is quite distinctive.	Turn off the stove a few seconds after the first bubble appear at the top of the spout. Listen out for a percolation sound. You will come to know this sound in time, but it is quite distinctive.		3
20		Wait until the coffee stops bubbling out the spout. Pour and enjoy!	Wait until the coffee stops bubbling out the spout. Pour and enjoy!		3
21		Add a scoop of coffee into your french press.	Add a scoop of coffee into your french press.		4
22		Pour the water just shy of boiling into the grounds. (I would like to use the same golden ratio as a V60 here - 12g of coffee to 200ml of water).	Pour the water just shy of boiling into the grounds. (I would like to use the same golden ratio as a V60 here - 12g of coffee to 200ml of water).		4
23		Let it steep for 4mins. You can just use your phone timer here.	Let it steep for 4mins. You can just use your phone timer here.		4
24		Push plunger down slowly, 	Push plunger down slowly, 		4
25		serve and enjoy!	serve and enjoy!		4
26		Rinse Aeropress filter on the cap, and discard water.	Rinse Aeropress filter on the cap, and discard water.		5
27		Fix Aeropress parts together and fill Aeropress with 12g of coffee.	Fix Aeropress parts together and fill Aeropress with 12g of coffee.		5
28		Fill Aeropress with 200ml of water, give it a nice slow stir 5 times with the Aeropress paddle provided in the kit.	Fill Aeropress with 200ml of water, give it a nice slow stir 5 times with the Aeropress paddle provided in the kit.		5
29		Let it steep for 1 minute, and screw cap on.	Let it steep for 1 minute, and screw cap on.		5
30		Place mug upside-down on the top of the Aeropress and flip the whole thing over.	Place mug upside-down on the top of the Aeropress and flip the whole thing over.		5
31		Plunge down steadily immediately. Plunge down until you hear a hissing sound then stop!	Plunge down steadily immediately. Plunge down until you hear a hissing sound then stop!		5
32		Wala! You are done, remove the Aeropress and enjoy this amazing cuppa.	Wala! You are done, remove the Aeropress and enjoy this amazing cuppa.		5
\.


--
-- Name: content_brewguidestep_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_brewguidestep_id_seq', 32, true);


--
-- Data for Name: content_career; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_career (id, title, description, active, img, description_en, description_zh_hans, title_en, title_zh_hans) FROM stdin;
4	HOOK POP-UP TEAM	Mad about pulling hundreds of espresso shot and brewing the perfect pourover? Be part of the team to be on the ground bringing happiness to thousands of coffee lovers, and spread the word about our fantastic coffees!	t	./yToekabqc.png	Mad about pulling hundreds of espresso shot and brewing the perfect pourover? Be part of the team to be on the ground bringing happiness to thousands of coffee lovers, and spread the word about our fantastic coffees!	狂热地喜欢烹煮浓缩咖啡和烹煮完美的手冲咖啡？加入我们的团队，亲自将幸福带给成千上万的咖啡爱好者，将我们奇妙的咖啡告知全世界！	HOOK POP-UP TEAM	Hook 广告团队
3	CONTENT CREATOR INTERN	Fancy writing and creating beautiful content to inspire people to drink better coffee? We’re looking for an intern to regularly create awe-inspiring content for our marketing campaigns, social media platforms and other brand touch points. 	t	./world-512.jpg	Fancy writing and creating beautiful content to inspire people to drink better coffee? We’re looking for an intern to regularly create awe-inspiring content for our marketing campaigns, social media platforms and other brand touch points. 	喜欢写作，创作美丽的内容来激励人们喝更好的咖啡？我们在寻找一个实习生来为我们的营销活动，社交媒体平台和其他品牌接触点创作令人惊叹的内容。	CONTENT CREATOR INTERN	内容创建者实习生
2	DESIGN GURU	Can your creativity and design skills get people hooked on us and our coffees? We’re looking for a creative designer to help build our brand and champion fun & innovative marketing campaigns! 	t	./quote.png	Can your creativity and design skills get people hooked on us and our coffees? We’re looking for a creative designer to help build our brand and champion fun & innovative marketing campaigns! 	你的创造力和设计技能能够让大家迷上我们和我们的咖啡吗？我们在寻找一个富有创造力的设计师来帮助我们建立我们的品牌和推动有趣又创新的营销活动。	DESIGN GURU	设计大师
1	DIGITAL MARKETING INTERN	Are you tech savvy and know the formulae to digital marketing? Experienced in SEO and SEM? Competent in digital marketing data and analytics? Take on this exciting role and yours the skills to the table!	t	./lightbulb-icon-LightBulbOn-300x300.png	Are you tech savvy and know the formulae to digital marketing? Experienced in SEO and SEM? Competent in digital marketing data and analytics? Take on this exciting role and yours the skills to the table!	你精通科技，知道数字营销的规则吗？在SEO和SEM方面很有经验？能胜任数字营销数据和分析？成为这个激动人心的角色，然后将你的技能带入我们的团队！	DIGITAL MARKETING INTERN	数字营销实习生
\.


--
-- Name: content_career_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_career_id_seq', 4, true);


--
-- Data for Name: content_greeting; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_greeting (id, time_of_day, line1, line1_en, line1_zh_hans, line2, line2_en, line2_zh_hans, line3, line3_en, line3_zh_hans) FROM stdin;
3	morning	COFFEE IS ESSENTIAL,	COFFEE IS ESSENTIAL,		Fresh coffee is a choice.	Fresh coffee is a choice.		We deliver freshly roasted coffee right to your doorstep. Choose whole beans, ground coffee, drip coffee bags, or Nespresso<sup>&reg;</sup> compatible pods.	We deliver freshly roasted coffee right to your doorstep. Choose whole beans, ground coffee, drip coffee bags, or Nespresso<sup>&reg;</sup> compatible pods.	
2	noon	Coffee is essential,	Coffee is essential,		Fresh coffee is a choice.	Fresh coffee is a choice.		We deliver freshly roasted coffee right to your doorstep. Choose whole beans, ground coffee, drip coffee bags, or Nespresso<sup>&reg;</sup> compatible pods.	We deliver freshly roasted coffee right to your doorstep. Choose whole beans, ground coffee, drip coffee bags, or Nespresso<sup>&reg;</sup> compatible pods.	
1	evening	Coffee is essential,	Coffee is essential,		Fresh coffee is a choice.	Fresh coffee is a choice.		We deliver freshly roasted coffee right to your doorstep. Choose whole beans, ground coffee, drip coffee bags, or Nespresso<sup>&reg;</sup> compatible pods.	We deliver freshly roasted coffee right to your doorstep. Choose whole beans, ground coffee, drip coffee bags, or Nespresso<sup>&reg;</sup> compatible pods.	
\.


--
-- Name: content_greeting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_greeting_id_seq', 3, true);


--
-- Data for Name: content_instagrampost; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_instagrampost (id, url, data) FROM stdin;
9	https://www.instagram.com/p/BURLkLTltba/?tagged=hookcoffee&hl=en	"text"=>"\\"My afternoon #nespresso fix. Getting hooked on @hook_coffee \\\\ud83c\\\\uddf8\\\\ud83c\\\\uddec #supportlocal\\"", "image_url"=>"\\"https://scontent-lhr3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/18513710_1862697473985165_1860768789713387520_n.jpg\\"", "author_url"=>"\\"https://www.instagram.com/thehuangergames\\"", "author_name"=>"\\"thehuangergames\\"", "created_time"=>"\\"2017-05-19T09:12:17+00:00\\"", "author_avatar"=>"\\"https://scontent-lhr3-1.cdninstagram.com/t51.2885-19/s150x150/15338326_1347299111981652_8661516698798522368_a.jpg\\""
10	https://www.instagram.com/p/BUTAZ18lJid/?tagged=hookcoffee&hl=en	"text"=>"\\"#blackberrypriv\\\\n#hookcoffee\\"", "image_url"=>"\\"https://scontent-lhr3-1.cdninstagram.com/t51.2885-15/sh0.08/e35/p640x640/18513658_633577396848780_6988482342637535232_n.jpg\\"", "author_url"=>"\\"https://www.instagram.com/juxcyme\\"", "author_name"=>"\\"juxcyme\\"", "created_time"=>"\\"2017-05-20T02:13:14+00:00\\"", "author_avatar"=>"\\"https://scontent-lhr3-1.cdninstagram.com/t51.2885-19/s150x150/14714638_1821416278115863_4384942888006451200_a.jpg\\""
11	https://www.instagram.com/p/BTz8xzwhGoC/?tagged=hookcoffee&hl=en	"text"=>"\\"Rise and shine .... coz it's a bloody new week \\\\ud83d\\\\ude12\\"", "image_url"=>"\\"https://scontent-lhr3-1.cdninstagram.com/t51.2885-15/s640x640/sh0.08/e35/18252533_297800583993845_9031231181605044224_n.jpg\\"", "author_url"=>"\\"https://www.instagram.com/immwmmi\\"", "author_name"=>"\\"immwmmi\\"", "created_time"=>"\\"2017-05-08T00:45:05+00:00\\"", "author_avatar"=>"\\"https://scontent-lhr3-1.cdninstagram.com/t51.2885-19/s150x150/13721118_539912879547497_1599356851_a.jpg\\""
\.


--
-- Name: content_instagrampost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_instagrampost_id_seq', 11, true);


--
-- Data for Name: content_post; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_post (id, title, message, section_id, message_en, message_zh_hans, title_en, title_zh_hans) FROM stdin;
24	How will my orders be delivered and when will I receive my coffee?	All new orders will be shipped out on the next working day, and subsequently, your delivery frequency will be based on what you've indicated under your 'Preferences' (with the help of Hook's Coffee Calculator). We ship all orders using SingPost normal mail. We’ve chosen to use the normal mail service because you don’t have to wait at home to receive your coffee or be afraid to miss the delivery – we’ve thoughtfully designed the packaging to fit standard mailboxes where your coffee will be dropped off, so no more post-office runs necessary!\r\n\r\nYou really have little to worry about especially if you've subscribed for regular delivery! After your first bag, you will notice that your coffees will magically appear in your mailbox without even doing a thing! And it'll always be fresh.\r\n\r\nWe find our local mail officers extremely reliable and efficient – this is Singapore after all! We’re confident SingPost will get the coffees to you within 2-4 working days. However, if your coffee somehow doesn’t reach you after the fourth day, drop us an email and we’ll send you another bag immediately the next day. 	4	All new orders will be shipped out on the next working day, and subsequently, your delivery frequency will be based on what you've indicated under your 'Preferences' (with the help of Hook's Coffee Calculator). We ship all orders using SingPost normal mail. We’ve chosen to use the normal mail service because you don’t have to wait at home to receive your coffee or be afraid to miss the delivery – we’ve thoughtfully designed the packaging to fit standard mailboxes where your coffee will be dropped off, so no more post-office runs necessary!\r\n\r\nYou really have little to worry about especially if you've subscribed for regular delivery! After your first bag, you will notice that your coffees will magically appear in your mailbox without even doing a thing! And it'll always be fresh.\r\n\r\nWe find our local mail officers extremely reliable and efficient – this is Singapore after all! We’re confident SingPost will get the coffees to you within 2-4 working days. However, if your coffee somehow doesn’t reach you after the fourth day, drop us an email and we’ll send you another bag immediately the next day. 	所有的新订单都会在下一个工作日寄出，并且随后，你的送货频率会基于你在“偏好”中显示的内容而定（当然是在Hook的咖啡计算器的帮助下）。我们使用新加坡邮政普通邮寄来运送所有订单。我们选择使用普通邮寄服务是因为你不需要在家等待收货或者是害怕会错误收货 - 我们很贴心地考虑到了这些，所以我们将包裹设计为便于放进邮箱的大小，这样你的咖啡就可以直接抵达你的邮箱，你再也不用跑到邮局去取货了！\r\n\r\n你真的无须担心，尤其是如果你已经订阅了定期配送！在你的第一个包裹之后，你会注意到你的咖啡会奇迹般地出现在你的邮箱里，即使你什么都没有做！是的，并且永远是新鲜的。\r\n\r\n我们发现我们当地的邮局工作人员非常可靠高效 - 毕竟这是新加坡！我们确信新加坡邮政会在2-4个工作日内将咖啡送到你手中。但是，如果你在四天后还没有收到咖啡，那么请给我们发送电子邮件，我们会立刻在第二天为你再发一个包裹。\r\n	How will my orders be delivered and when will I receive my coffee?	我的订单会如何被送达，并且我在什么时候会收到我的咖啡？
59	Can I have 2 ongoing subscriptions for coffees and ShotPods?	Absolutely! You can manage your subscriptions for both your coffees and ShotPods on your account page under the respective tabs. You'll be able to manage your choice of coffee and ideal delivery frequency separately.	7	Absolutely! You can manage your subscriptions for both your coffees and ShotPods on your account page under the respective tabs. You'll be able to manage your choice of coffee and ideal delivery frequency separately.	绝对的！你可以在咖啡和咖啡胶囊各自的选项卡下，你的账户页面上管理你的订阅。你可以分别管理你选择的咖啡和理想的配送频率。	Can I have 2 ongoing subscriptions for coffees and ShotPods?	我能针对咖啡和咖啡胶囊有两个使用中的订阅吗？
56	How are Hook’s Shot Pods different from Nespresso®’s?	Great question! Well, for one, as like almost all of our coffees, the coffees that make it into our pods are direct-traded*. Direct-traded coffees are either bought directly from farmers or a co-operative of farmers and we’ve adopted this model to give you traceability of our coffees and ethical choices. Our farmers receive a bigger share of the final retail value (10-25% more than Fairtrade) and this is just one of the ways we show our appreciation for their skills and hard work as growing and processing specialty coffee is a real art. \r\n\r\nOur coffees are also specialty-grade Arabica beans with a score of 80+ from the Specialty Coffee Association of America (SCAA) (which basically means they’re top quality stuff), sustainably grown and ethically produced, and as much as possible direct-traded. \r\n\r\nTo do our farmers and beans justice, the beans are roasted with love and care to achieve the perfect balance, body, and aroma in every espresso shot, and to bring out their natural qualities and flavor-quirks. They’re freshly roasted and packed immediately, then shipped right to your door.\r\n\r\nAnd you know what? Because we don’t engage celebrity ambassadors to market our pods (#wedontneedGeorge), we can pass on the savings to you for an even greater experience overall, and let our pods speak for themselves.\r\n\r\nIf you think of any other ways we can be better than Nespresso®, drop us an email at hola@hookcoffee.com.sg! 	10	Great question! Well, for one, as like almost all of our coffees, the coffees that make it into our pods are direct-traded*. Direct-traded coffees are either bought directly from farmers or a co-operative of farmers and we’ve adopted this model to give you traceability of our coffees and ethical choices. Our farmers receive a bigger share of the final retail value (10-25% more than Fairtrade) and this is just one of the ways we show our appreciation for their skills and hard work as growing and processing specialty coffee is a real art. \r\n\r\nOur coffees are also specialty-grade Arabica beans with a score of 80+ from the Specialty Coffee Association of America (SCAA) (which basically means they’re top quality stuff), sustainably grown and ethically produced, and as much as possible direct-traded. \r\n\r\nTo do our farmers and beans justice, the beans are roasted with love and care to achieve the perfect balance, body, and aroma in every espresso shot, and to bring out their natural qualities and flavor-quirks. They’re freshly roasted and packed immediately, then shipped right to your door.\r\n\r\nAnd you know what? Because we don’t engage celebrity ambassadors to market our pods (#wedontneedGeorge), we can pass on the savings to you for an even greater experience overall, and let our pods speak for themselves.\r\n\r\nIf you think of any other ways we can be better than Nespresso®, drop us an email at hola@hookcoffee.com.sg! 	问得好！举例来说，就像我们几乎所有的咖啡，在我们的咖啡胶囊中的咖啡都是通过直接贸易*购买的。通过直接贸易购买的咖啡要么是直接从咖啡种植户购买的，要么是从与咖啡种植户的合作社购买的，我们采取直接贸易模式，便于你追踪我们的咖啡和道德选择。我们的咖啡种植户会收到最终零售价的较大份额（比互惠贸易多10-25%），而且这只是我们感谢他们的技术和辛勤工作的方式之一，因为种植和处理精品咖啡是一门真正的艺术。\r\n\r\n我们的咖啡还是精品级的阿拉比卡咖啡豆，并且在美国精品咖啡协会（SCAA）的得分超过80（这基本意味着我们的咖啡是顶级的），可持续种植，生产时遵守企业道德概念并且尽可能的进行直接贸易。\r\n\r\n为了公平对待我们的咖啡种植户和咖啡豆，咖啡豆都是在充满爱与关怀的环境中烘焙的，以此来让浓缩咖啡达到完美平衡，让咖啡拥有完美的味道和香味，带出其自然品质和独特风味。这些咖啡都是新鲜烘焙的，然后立刻包装，随后就会送到你门口。\r\n\r\n你知道吗？因为我们不请名人来我们宣传咖啡胶囊（#wedontneedGeorge），我们可以让剩下的这部分钱给你带来更好的咖啡体验，让我们的咖啡胶囊为自己代言。\r\n\r\n如果你认为我们在其他方面也能比Nespresso®好，请给我们发送电子邮件：hola@hookcoffee.com.sg！	How are Hook’s Shot Pods different from Nespresso®’s?	Hook 的咖啡胶囊和Nespresso®的胶囊有什么区别？
22	How flexible is Hook’s subscription service then?	Although technically we offer a subscription service, we hate calling ourselves a subscription-based coffee company because subscriptions are usually inflexible and we know commitment can be a scary thing. We won’t tie you to any contract – you can edit, pause or cancel your subscription at any time, with zero commitment. You can even customise your delivery frequency using our Coffee Calculator - you'll never have to worry you'll get more than you need, or worse, run out mid-week! Learn how you can edit, pause or cancel your subscription by reading the “Managing Your Account” section.	4	Although technically we offer a subscription service, we hate calling ourselves a subscription-based coffee company because subscriptions are usually inflexible and we know commitment can be a scary thing. We won’t tie you to any contract – you can edit, pause or cancel your subscription at any time, with zero commitment. You can even customise your delivery frequency using our Coffee Calculator - you'll never have to worry you'll get more than you need, or worse, run out mid-week! Learn how you can edit, pause or cancel your subscription by reading the “Managing Your Account” section.	尽管从技术上来说，我们提供订阅服务，可是我们讨厌将自己称为订阅式咖啡公司，因为订阅通常比较刻板，而我们知道承诺可能是件可怕的事情。我们不会用任何合同来捆绑你 - 你可以随时编辑，暂停或取消你的订阅，无需任何承诺。你甚至还可以使用我们的咖啡计算器自定义你的送货频率 - 你永远也不用担心你收到的咖啡会超过你所需要的量，或者更糟糕，在一星期的中间咖啡就喝完了！通过阅读“管理你的账户”这一章节来学习一下如何能够编辑，暂停或取消你的订阅。	How flexible is Hook’s subscription service then?	Hook 的订阅服务有多么的灵活？
21	Why does Hook use a subscription model?	We know that coffee is like a daily ritual to many. Not having a good cup of coffee to kick-start your day is probably the worst thing that could happen, not to forget that much needed perk-me-up in the afternoon. That aroma of freshly roasted coffee is an additional bonus to look forward to. So at Hook, we strive to ensure you won't ever have to run out of the coffee you love. We also believe in always having a supply of freshly roasted coffee so we’d rather send you your beans frequently than let you stock up and accumulate stale coffee in your pantry! This is why we've built our Coffee Calculator to help you determine your delivery frequency based on your coffee consumption. You'll never have to worry you'll get more than you need, or worse, run out mid-week! \r\n\r\nWe promise to send out your coffee to you within a week of roasting – there’s no compromising on that. You only pay when your coffee is sent out to you and we cover all shipping costs. We currently do weekly or fortnightly subscriptions, but are working towards customising your subscription based on your personal rate of coffee consumption! It’s certainly not an easy task to do, but it’s our mission to ensure you drink only the best and freshest coffees.\r\n\r\nLikewise, you won't need to stock up on Nespresso capsules when you have a steady and reliable supply of ShotPods!	4	We know that coffee is like a daily ritual to many. Not having a good cup of coffee to kick-start your day is probably the worst thing that could happen, not to forget that much needed perk-me-up in the afternoon. That aroma of freshly roasted coffee is an additional bonus to look forward to. So at Hook, we strive to ensure you won't ever have to run out of the coffee you love. We also believe in always having a supply of freshly roasted coffee so we’d rather send you your beans frequently than let you stock up and accumulate stale coffee in your pantry! This is why we've built our Coffee Calculator to help you determine your delivery frequency based on your coffee consumption. You'll never have to worry you'll get more than you need, or worse, run out mid-week! \r\n\r\nWe promise to send out your coffee to you within a week of roasting – there’s no compromising on that. You only pay when your coffee is sent out to you and we cover all shipping costs. We currently do weekly or fortnightly subscriptions, but are working towards customising your subscription based on your personal rate of coffee consumption! It’s certainly not an easy task to do, but it’s our mission to ensure you drink only the best and freshest coffees.\r\n\r\nLikewise, you won't need to stock up on Nespresso capsules when you have a steady and reliable supply of ShotPods!	我们知道咖啡对很多人来说，就像是例行公事。如果不能喝上一杯好喝的咖啡来开始你的一天，那么这可能就是会发生的最糟糕的事情了，不要忘记在下午时分，那是非常需要的让我振作的好东西。新鲜烘焙的咖啡的香气也是让我们期待的另一个加分点。所以在Hook，我们努力确保你永远不会缺你爱的咖啡。我们还坚信永远提供新鲜烘焙的咖啡，所以相比让你储存和积累不新鲜的咖啡，我们更倾向于频繁地给你寄咖啡豆。这就是为什么我们建立了咖啡计算器来帮助你根据自己的需求量决定配送频率。你永远也不用担心你会拿到多于你的需求量的咖啡，或者更糟糕，在一星期的中间咖啡就喝完了！\r\n\r\n我们保证在你的咖啡刚烘焙好一周内发货 - 在这一点上没有妥协。你只在确定拿到咖啡之后才需要付款，并且我们包邮。我们目前采取的是每周或双周订阅，但是我们也在朝着基于你的个人咖啡需求量来私人订制自己的订阅模式这个方向发展。这当然不是一个简单的任务，但是确保你喝到最好最新鲜的咖啡是我们的使命。\r\n\r\n同样的，如果你有了稳定可靠的咖啡胶囊的供应来源，那么你就不再需要储存Nespresso胶囊了。	Why does Hook use a subscription model?	为什么 Hook 会使用订阅制呢？
41	How should I store my coffee to maximize its freshness?	Mum might have told you keeping coffees in the fridge or freezer, or any food/drink really, is the best way to preserve their freshness and extend their shelf life. Unfortunately, mum’s wrong this time (sorry, mum!). When it comes to storing coffee, the key elements to protect it from are excessive air, moisture, heat and light. The pouches we use to pack and deliver your coffees are perfect for doing all that, while allowing just enough carbon dioxide to escape through the little one-way valve to prevent bloating (coffee releases carbon dioxide after they’re roasted – that’s the degassing process we were talking about earlier). You can always transfer your coffees out, as long as it’s in an airtight container and kept in a cool, dry place.	8	Mum might have told you keeping coffees in the fridge or freezer, or any food/drink really, is the best way to preserve their freshness and extend their shelf life. Unfortunately, mum’s wrong this time (sorry, mum!). When it comes to storing coffee, the key elements to protect it from are excessive air, moisture, heat and light. The pouches we use to pack and deliver your coffees are perfect for doing all that, while allowing just enough carbon dioxide to escape through the little one-way valve to prevent bloating (coffee releases carbon dioxide after they’re roasted – that’s the degassing process we were talking about earlier). You can always transfer your coffees out, as long as it’s in an airtight container and kept in a cool, dry place.	妈妈们可能会告诉你把咖啡，或者任何食品/饮料，放在冰箱或冰柜里，是保持其新鲜度和延长保质期的最好方式。不幸的是，这次妈妈们是错的（抱歉，妈妈！）。当谈论到储存咖啡时，保存咖啡的关键要素是保证咖啡不会接触到过多的空气，水分，光和热。我们用来包装和运送的盒子就是如此设计的，在让足够的二氧化碳从单向气门嘴排出，以免膨胀（咖啡在烘焙后会排出二氧化碳 - 这就是我们早前提到的脱气过程）的同时，不会让咖啡接触到过多的空气，水分，光和热。你随时可以转移你的咖啡，只要咖啡保存在密封的容器里，并且保存在凉爽干燥处。	How should I store my coffee to maximize its freshness?	我应该如何储存我的咖啡来将其新鲜度最大化呢？
23	How do I start?	Just click on any of those yellow ‘GET STARTED’ buttons and we’ll bring you through 3 quick questions on how you brew and enjoy your coffee. Our intelligent recommendation engine will recommend something specially for you from our coffee range or ShotPods range. You can either go with our recommendation or choose something else if you’re feeling adventurous. \r\n\r\nIf you're not a Nespresso user, we’ll ask you to choose how you want your coffee to be packed – whole beans, ground according to your preferred brew method, or in our super convenient coffee drip bags! \r\n\r\nOur Coffee Calculator at checkout will help you determine your ideal delivery frequency, based on your coffee consumption. You can even choose if you want the same coffee each time, or ask to be surprised (which means we’ll send you different coffees from our range every time so you can try them all)! Finally, sit back, relax, and our coffee will be on its way to you.	4	Just click on any of those yellow ‘GET STARTED’ buttons and we’ll bring you through 3 quick questions on how you brew and enjoy your coffee. Our intelligent recommendation engine will recommend something specially for you from our coffee range or ShotPods range. You can either go with our recommendation or choose something else if you’re feeling adventurous. \r\n\r\nIf you're not a Nespresso user, we’ll ask you to choose how you want your coffee to be packed – whole beans, ground according to your preferred brew method, or in our super convenient coffee drip bags! \r\n\r\nOur Coffee Calculator at checkout will help you determine your ideal delivery frequency, based on your coffee consumption. You can even choose if you want the same coffee each time, or ask to be surprised (which means we’ll send you different coffees from our range every time so you can try them all)! Finally, sit back, relax, and our coffee will be on its way to you.	只需点击任意黄色的“开始”按钮，我们就会带你前往回答关于你如何烹煮咖啡，享受咖啡的3个快速问答。我们的智能推荐引擎会从我们的咖啡范围或咖啡胶囊范围中特别为你推荐一些。你可以选择听从我们的推荐，或者如果你喜欢冒险也可以选择其他的。\r\n\r\n如果你不是Nespresso用户，我们会请你选择你想要如何包装你的咖啡 - 根据你偏爱的烹煮方式，选择全豆，咖啡粉或者超级方便的滤挂咖啡！\r\n\r\n我们在结算页面的咖啡计算器会基于你的咖啡需求量，帮助你决定理想的配送频率。你甚至可以选择每次都要同样的咖啡，或者要求我们给你惊喜（这就意味着我们每次都会给你发不同的咖啡，便于你可以全都试一遍）！最后，坐下，放松，我们的咖啡即将在朝你飞奔而来的路上。	How do I start?	我如何开始呢？
31	Does Hook do wholesale/bulk order?	Yes we do! If you would like to make a bulk order, do email us at hola@hookcoffee.com.sg. 	6	Yes we do! If you would like to make a bulk order, do email us at hola@hookcoffee.com.sg. 	是的，我们做！如果你想要下批量订单，请给我们发送电子邮件：hola@hookcoffee.com.sg。\r\n	Does Hook do wholesale/bulk order?	Hook 做批发/批量订单吗？
26	Why do I need to pick flavours that I like?	Hold up! Just in case you’re wondering, no, we don’t add any flavouring to our coffees! If we had an ingredient list, there would only be coffee and love.\r\n\r\nSpecialty coffee is often likened to wine each batch of coffee has its own unique characteristics and nuanced flavours. In order for us to recommend you a coffee you’ll love, we’ll need to get to know your sensory taste profile. If you have no preference, that’s fine – we will recommend you a coffee based on how you make your coffee and how intense you like it. \r\n	5	Hold up! Just in case you’re wondering, no, we don’t add any flavouring to our coffees! If we had an ingredient list, there would only be coffee and love.\r\n\r\nSpecialty coffee is often likened to wine each batch of coffee has its own unique characteristics and nuanced flavours. In order for us to recommend you a coffee you’ll love, we’ll need to get to know your sensory taste profile. If you have no preference, that’s fine – we will recommend you a coffee based on how you make your coffee and how intense you like it. \r\n	等一下！以防你好奇，不，我们不在咖啡中添加任何调味剂！如果我们有成分列表的话，那也只会是咖啡和爱。\r\n\r\n精品咖啡通常被比作酒，每批咖啡都有自己的特点和微妙的口味。为了我们能够向你推荐一款你喜欢的咖啡，我们需要知道你的感官口味偏好。如果你没有任何偏好，也没关系 - 我们会根据你如何煮咖啡以及你喜欢的强度为你推荐一款咖啡。	Why do I need to pick flavours that I like?	为什么我需要选择我喜欢的口味？
44	What is the Hook Coffee Calculator?	We've built a Coffee Calculator to help you determine and customise your delivery frequency based on your coffee consumption. \r\n\r\nThe Coffee Calculator can be found on the checkout page (if you're placing an order for the first time) or your Account page (if you're an existing customer). \r\n\r\nYou'll never have to worry you'll get more than you need, or worse, run out mid-week!	4	We've built a Coffee Calculator to help you determine and customise your delivery frequency based on your coffee consumption. \r\n\r\nThe Coffee Calculator can be found on the checkout page (if you're placing an order for the first time) or your Account page (if you're an existing customer). \r\n\r\nYou'll never have to worry you'll get more than you need, or worse, run out mid-week!	我们建立了咖啡计算器，帮助你基于自己的咖啡需求量来决定并定制自己的配送频率。\r\n\r\n可以在结算页面（如果你是第一次下单的话）或者在账户页面（如果你是老客户）找到咖啡计算器。\r\n\r\n你永远也不用担心你会拿到多于你的需求量的咖啡，或者更糟糕，在一星期的中间咖啡就喝完了！	What is the Hook Coffee Calculator?	Hook 咖啡计算器是什么？
35	How do I change the frequency of delivery?	Under the ‘Preferences’ tab on your account page, use our Coffee Calculator to determine the ideal delivery frequency for you based on your coffee consumption. With our Coffee Calculator, you'll only drink the freshest coffees - you'll never have to worry you'll get more than you need, or worse, run out mid-week! Again, please make changes to your delivery frequency at least 48hours before your next coffee is due to be sent out to you, otherwise it will only take effect on the following order. Do remember to save your preferences.	7	Under the ‘Preferences’ tab on your account page, use our Coffee Calculator to determine the ideal delivery frequency for you based on your coffee consumption. With our Coffee Calculator, you'll only drink the freshest coffees - you'll never have to worry you'll get more than you need, or worse, run out mid-week! Again, please make changes to your delivery frequency at least 48hours before your next coffee is due to be sent out to you, otherwise it will only take effect on the following order. Do remember to save your preferences.	在你的账户页面的“偏好”下方，使用我们的咖啡计算器，基于你的咖啡需求量来决定你理想的送货频率。有了我们的咖啡计算器，你就可以喝上最新鲜的咖啡 - 你永远也不用担心你会拿到多于你的需求量的咖啡，或者更糟糕，在一星期的中间咖啡就喝完了！此外，请至少在我们下次为你发货前的48小时前修改送货频率，否则只会在接下来的订单中生效。请记住保存你的偏好。\r\n\r\n	How do I change the frequency of delivery?	我如何改变送货频率？
42	Where can I try Hook’s Coffees?	We’ll be having pop-ups around Singapore every now and then. Follow us on Facebook (@Hook Coffee) and Instagram (@hook_coffee) for updates. 	6	We’ll be having pop-ups around Singapore every now and then. Follow us on Facebook (@Hook Coffee) and Instagram (@hook_coffee) for updates. 	我们时常会在新加坡街头进行宣传。在Facebook（@Hook Coffee）和Instagram（@hook_coffee）上关注我们，了解更新信息。	Where can I try Hook’s Coffees?	我在哪里可以试喝 Hook 咖啡？
49	How does the redemption of a ‘free bag of coffee’ work?	When redeeming a free bag of coffee, your next subscription order of coffee will automatically be free.	9	When redeeming a free bag of coffee, your next subscription order of coffee will automatically be free.	当你获得一袋免费的咖啡，你下次的咖啡订阅订单就会自动免单。	How does the redemption of a ‘free bag of coffee’ work?	“免费咖啡”如何运作？
33	What is the cut-off time if I need to make changes to my subscription/order?	As promised, we won’t tie you to any contract – you can edit, pause or cancel your subscription at any time, with zero commitment. Our account management page has been engineered to allow you to change your preferred delivery date and frequency, choice of coffee (or ask to be surprised), how you want your coffee grounded, your delivery address etc. \r\n\r\nHowever, these changes have to be made 48hours before your next coffee is due to be sent out to you, otherwise it will only take effect on the following order. The advanced notice would be really helpful for our hardworking packers who caringly personalise and pack your coffees in time for delivery. We’re trying our best to improve this cut-off time to give you greater flexibility, and will let you know as soon as we do!\r\n	7	As promised, we won’t tie you to any contract – you can edit, pause or cancel your subscription at any time, with zero commitment. Our account management page has been engineered to allow you to change your preferred delivery date and frequency, choice of coffee (or ask to be surprised), how you want your coffee grounded, your delivery address etc. \r\n\r\nHowever, these changes have to be made 48hours before your next coffee is due to be sent out to you, otherwise it will only take effect on the following order. The advanced notice would be really helpful for our hardworking packers who caringly personalise and pack your coffees in time for delivery. We’re trying our best to improve this cut-off time to give you greater flexibility, and will let you know as soon as we do!\r\n	正如所承诺的，我们不会用任何合同来绑定你 - 你可以随时编辑，暂停或取消你的订阅，无需任何承诺。我们的账户管理页面已经被设计为允许你更改你的偏好配送日期和频率，选择的咖啡（或者要求惊喜），你想如何研磨你的咖啡，你的送货地址等等。\r\n\r\n然而，这些更改都必须在你的下一批咖啡发货前的48小时前进行修改，否则只会在接下来的订单中生效。对于我们勤劳的包装工而言，事先通知会很有用，他们满怀关爱地为你进行个性化的包装并且确保你的咖啡能够按时发出。我们尽力改善截止时间，让你有更大的灵活性，一旦我们能够明确，我们会即刻通知你！	What is the cut-off time if I need to make changes to my subscription/order?	如果我需要修改我的订阅/订单，截止时间是什么？
57	What is Hook Coffee’s affiliation with Nespresso®?	Hook Coffee and its products are not endorsed by, sponsored by, licensed by or approved by Nespresso® or any of their affiliates.	10	Hook Coffee and its products are not endorsed by, sponsored by, licensed by or approved by Nespresso® or any of their affiliates.	Hook 咖啡及其产品不是由Nespresso®或其附属机构支持，赞助，许可或核准的。\r\n	What is Hook Coffee’s affiliation with Nespresso®?	Hook 咖啡和Nespresso®有从属关系吗？
50	Are Hook’s Shot Pods compatible with all Nespresso® machines?	Yes! Our Shot Pods are compatible with most Nespresso® machines. We do receive some feedback, however, that it can have compatability issues in the Nespresso U machine. But we are working on it! \r\n\r\nThe foil base, compared to a rigid base of other compatible capsules, provides light piercing pressure at 2kg – exactly the same as Nespresso®’s capsules. The soft construction of the pods also provides better extraction and compatibility with all versions of Nespresso® machines.\r\n\r\nIf you have questions about your Nespresso® machine and whether our capsules will work in them, please contact us at hola@hookcoffee.com.sg.	10	Yes! Our Shot Pods are compatible with most Nespresso® machines. We do receive some feedback, however, that it can have compatability issues in the Nespresso U machine. But we are working on it! \r\n\r\nThe foil base, compared to a rigid base of other compatible capsules, provides light piercing pressure at 2kg – exactly the same as Nespresso®’s capsules. The soft construction of the pods also provides better extraction and compatibility with all versions of Nespresso® machines.\r\n\r\nIf you have questions about your Nespresso® machine and whether our capsules will work in them, please contact us at hola@hookcoffee.com.sg.	是的！我们的咖啡胶囊与大多数的Nespresso® 机器都兼容。但是，我们确实有收到一些反馈说，我们的咖啡胶囊和Nespresso® 机器有一些兼容问题。但是我们正在解决中！\r\n\r\n与其他兼容胶囊的刚性基座相比，金属箔基座的刺穿压力更小，只有2kg - 和Nespresso®胶囊一模一样。咖啡胶囊的软性结构还为所有版本的Nespresso®机器提供了更好的提取性和兼容性。\r\n\r\n如果你有关于Nespresso®机器以及我们的胶囊是否能够在机器中正常运作的问题，请随时联系我们：hola@hookcoffee.com.sg。	Are Hook’s Shot Pods compatible with all Nespresso® machines?	Hook 的咖啡胶囊与Nespresso® 所有的机器都兼容吗？
52	How much do the ShotPods cost?	The ShotPods are sold in sets of 20 pods and cost $16 (includes free delivery). That’s 80cents a pod! By selling directly to you without large corporate overhead and expensive retail stores, and because we don’t engage celebrity ambassadors to market our pods (#wedontneedGeorge), we can pass on the savings to you for an even greater experience overall, and let our pods speak for themselves.\r\n\r\n	10	The ShotPods are sold in sets of 20 pods and cost $16 (includes free delivery). That’s 80cents a pod! By selling directly to you without large corporate overhead and expensive retail stores, and because we don’t engage celebrity ambassadors to market our pods (#wedontneedGeorge), we can pass on the savings to you for an even greater experience overall, and let our pods speak for themselves.\r\n\r\n	咖啡胶囊是以20为一组出售的，价格是$16（￥107，包邮）。那也就是￥5.4一个咖啡胶囊！不经过大公司的间接费用和昂贵的零售店，我们直接出售给你，因为我们不请名人来我们宣传咖啡胶囊（#wedontneedGeorge），我们可以让剩下的这部分钱给你带来更好的咖啡体验，让我们的咖啡胶囊为自己代言。	How much do the ShotPods cost?	咖啡胶囊多少钱？
34	How do I change the coffee that I will receive?	Under your account page, you will be able to see which coffee we will be sending you next. If you decide that you want another coffee, simply go to Our Coffees page and click on the ‘Send me this next’ button of the coffee you want! Just remember to do so 48hours before your next coffee is due to be sent out to you, otherwise it will only take effect on the following order.\r\n\r\nIf you are the adventurous sort, you can always ask us to surprise you with different coffees each time by choosing the “Surprise Me” option under the ‘Preferences’ tab on your account page. Do remember to save your preferences.\r\n	7	Under your account page, you will be able to see which coffee we will be sending you next. If you decide that you want another coffee, simply go to Our Coffees page and click on the ‘Send me this next’ button of the coffee you want! Just remember to do so 48hours before your next coffee is due to be sent out to you, otherwise it will only take effect on the following order.\r\n\r\nIf you are the adventurous sort, you can always ask us to surprise you with different coffees each time by choosing the “Surprise Me” option under the ‘Preferences’ tab on your account page. Do remember to save your preferences.\r\n	在你的账户页面，你能够看到我们接下来会给你寄的是哪款咖啡。如果你决定你想要另一款咖啡，只需前往我们的咖啡页面，然后点击你想要的咖啡的相应按钮“下次给我发这款咖啡”！请记住要在你的下一批咖啡发货前的48小时前进行更改，否则只能在下一个订单时生效。\r\n\r\n如果你是爱冒险类型的，你随时可以通过在你的账户页面选择“偏好”下方的“给我惊喜”这一选项让我们给你惊喜，这样我们就会每次给你发不同的咖啡。请记住保存你的偏好。\r\n\r\n	How do I change the coffee that I will receive?	如何更改我即将收到的咖啡？
36	What happens when I pause my subscription?	If you are going away on a trip you can always pause your subscription, but let us know at least 48hrs before your next delivery is due. The “Pause” option is under the ‘Subscriptions’ tab on your account page. We’ll put your subscription on hold for a month while you enjoy your holiday! No deliveries will take place until a month later unless you manually resume your subscription (which makes sense if your trip is shorter than a month). When you resume your subscription, your subscription will start running from the date you resume your subscription. 	7	If you are going away on a trip you can always pause your subscription, but let us know at least 48hrs before your next delivery is due. The “Pause” option is under the ‘Subscriptions’ tab on your account page. We’ll put your subscription on hold for a month while you enjoy your holiday! No deliveries will take place until a month later unless you manually resume your subscription (which makes sense if your trip is shorter than a month). When you resume your subscription, your subscription will start running from the date you resume your subscription. 	如果你即将出门旅行，你随时可以暂停你的订阅，但是至少在我们下次为你发货前48小时之前通知我们。“暂停”选项在你的账户页面的“订阅”下方。在你享受假期的同时，我们会将你的订阅暂停一个月！除非你手动恢复你的订阅（如果你的旅程短于一个月，这就说得通了），否则一个月后我们依然不会为你送货。当你恢复订阅后，你的订阅就会从你恢复订阅的那天算起。	What happens when I pause my subscription?	当我暂停我的订阅时，会发生什么呢？
43	What happens when Hook Coffee runs out of my favourite coffee?	We understand that you might prefer sticking to one particular coffee you've fallen in love with, just as most people do with cologne or perfume! However, all specialty coffees are seasonal and we're bound to let go of certain coffees and replace them with others or wait for the next lot. In the event we've run out of your favourite beans, we'll notify you via email and give you the option of opting for another coffee you'd like to try or leaving it to our recommendation engine to choose one for you based on your brew method and sensory taste profile. Please don't fault us for this! We're trying our best to be well-stocked with everyone's favourites or at least, to have an extensive enough range so there'll always be at least one coffee you can't get enough of!	7	We understand that you might prefer sticking to one particular coffee you've fallen in love with, just as most people do with cologne or perfume! However, all specialty coffees are seasonal and we're bound to let go of certain coffees and replace them with others or wait for the next lot. In the event we've run out of your favourite beans, we'll notify you via email and give you the option of opting for another coffee you'd like to try or leaving it to our recommendation engine to choose one for you based on your brew method and sensory taste profile. Please don't fault us for this! We're trying our best to be well-stocked with everyone's favourites or at least, to have an extensive enough range so there'll always be at least one coffee you can't get enough of!	我们理解你可能更喜欢就喝你一直爱喝的那款咖啡，就像大多数人对于古龙水和香水的执着一样！但是，所有的精品咖啡都是季节性的，因此我们不得不季节性地放弃某些咖啡，用其他咖啡代替或者等下一块地出产。如果你最爱的咖啡豆，在我们店里卖光了，我们会通过电子邮件通知你，然后请你选择另一种你想要尝试的咖啡或者让我们的推荐引擎根据你的烹煮方式和感官口味偏好为你选择。请不要因此责怪我们！我们一直在努力至少备足每个人爱喝的咖啡货源，或者有足够广泛的范围，这样你就至少能够一直喝到你爱的一款咖啡！\r\n\r\n	What happens when Hook Coffee runs out of my favourite coffee?	如果Hook咖啡没有我最喜欢的咖啡了，怎么办？
40	Can you advise me on the different brew methods?	We’ve prepared a playlist of brew guide videos here (https://www.youtube.com/watch?v=z9jSCnXXuts&list=PLkyk5hA4H-AWEGxIk2cytVw28KlJJo2Qj) which includes information on making coffee with aa dripper (or commonly referred to as a V60 or Pourover), Stovetop Moka Pot, French press, Aeropress, and our super convenient Hook coffee drip bags! Our brew guide isn’t necessarily the best and it’s been simplified a little for those who aren’t as geeky as us. Let’s just say there’s no perfect brew method — it’s just a matter of personal preference. Then again, all our coffees are sourced from the world’s best farms and are freshly roasted, so they taste and smell divine regardless!	8	We’ve prepared a playlist of brew guide videos here (https://www.youtube.com/watch?v=z9jSCnXXuts&list=PLkyk5hA4H-AWEGxIk2cytVw28KlJJo2Qj) which includes information on making coffee with aa dripper (or commonly referred to as a V60 or Pourover), Stovetop Moka Pot, French press, Aeropress, and our super convenient Hook coffee drip bags! Our brew guide isn’t necessarily the best and it’s been simplified a little for those who aren’t as geeky as us. Let’s just say there’s no perfect brew method — it’s just a matter of personal preference. Then again, all our coffees are sourced from the world’s best farms and are freshly roasted, so they taste and smell divine regardless!	我们在这里准备了烹煮指导视频的播放列表 (https://www.youtube.com/watch?v=z9jSCnXXuts&list=PLkyk5hA4H-AWEGxIk2cytVw28KlJJo2Qj) ，包含了关于用滤杯（或者俗称V60或手冲咖啡），摩卡咖啡壶，法式滤压壶，爱乐压，以及我们超级便利的Hook滤挂咖啡来煮咖啡的信息！我们的烹煮指南不一定是最好的，并且已经为那些不像我们咖啡极客一样的人简化了一点。这么说吧，没有完美的烹煮方式 - 有的只是个人偏好。再次，我们所有的咖啡都是从世界上最好的农场搜集来的，并且是新鲜烘焙的，所以不管怎样，这些咖啡的味道和香味都是极好的！	Can you advise me on the different brew methods?	你能在不同的烹煮方式上给我建议吗？
28	How much are Hook’s coffees?	Very valid question! :) Our coffees are all priced at $18 (see next question for our rationale). Our ShotPods are all priced at $16 for 20 pods. The standard whole beans or ground coffee come in 250g bags which will make approximately 12-25 cups of coffee (depending on brew method), while our super convenient coffee drip bags come in 10 x 10g sachets. You only pay when your coffee is sent out to you and postage is free of charge!\r\n\r\nWe left the price out on Our Coffees and ShotPods pages because we wanted the spotlight to be on our coffees – their origins, their producers, and their characteristics. It’s these factors that define the quality of our beans, not the price. \r\n	6	Very valid question! :) Our coffees are all priced at $18 (see next question for our rationale). Our ShotPods are all priced at $16 for 20 pods. The standard whole beans or ground coffee come in 250g bags which will make approximately 12-25 cups of coffee (depending on brew method), while our super convenient coffee drip bags come in 10 x 10g sachets. You only pay when your coffee is sent out to you and postage is free of charge!\r\n\r\nWe left the price out on Our Coffees and ShotPods pages because we wanted the spotlight to be on our coffees – their origins, their producers, and their characteristics. It’s these factors that define the quality of our beans, not the price. \r\n	很有价值的问题！:)我们的咖啡售价为$18（￥121：你可以在下个问题中了解到我们定价的原因）。我们的咖啡胶囊是每20个$16（￥107）。标准的全豆或者咖啡粉是250g一袋，大约可以制作12-25杯咖啡（具体取决于烹煮方式），我们超级便利的滤挂咖啡是10 x 10g的咖啡包。你只需在收到咖啡后付款，并且我们包邮！\r\n\r\n我们没有将价格标注在我们的咖啡和咖啡胶囊页面上，因为我们希望客户关注的是我们的咖啡 - 咖啡的起源，生产商，还有咖啡的特征。这些因素才是决定咖啡质量的关键，而不是价格。	How much are Hook’s coffees?	Hook 的咖啡多少钱？
32	Does Hook do decaffeinated coffees?	At the moment, we don’t offer decaffeinated coffees. There are a couple of ways to decaffeinate coffees – most of them involve some form of chemical treatment and we very much prefer staying away from unnatural chemicals! The less common alternative uses activated carbon filters, but the process is a lot more complicated. If there’s enough demand for it, we’ll definitely work something out, so let us know if you would like us to offer decaf options!	6	At the moment, we don’t offer decaffeinated coffees. There are a couple of ways to decaffeinate coffees – most of them involve some form of chemical treatment and we very much prefer staying away from unnatural chemicals! The less common alternative uses activated carbon filters, but the process is a lot more complicated. If there’s enough demand for it, we’ll definitely work something out, so let us know if you would like us to offer decaf options!	目前，我们不提供无咖啡因的咖啡。有几种方式来生产无咖啡因的咖啡 - 大多数都涉及到化学处理，我们更倾向于远离不自然的化学物质！不太常见的替换物是使用活性炭过滤器，只是过程要复杂得多。如果有足够的需求量，我们绝对会想办法，所有如果你想要我们提供无咖啡因的咖啡，请告知我们！	Does Hook do decaffeinated coffees?	Hook 生产无咖啡因的咖啡吗？
53	How do I know the pods are safe and fresh?	All our Shot Pods are freshly roasted and packed immediately after roasting. The Thermoformed food grade PP (polypropylene) plastic material provides superior oxygen barrier properties and pods are hermetically sealed - this ensures optimum freshness and a shelf-life of 3 years! But of course there’s no need to stock up, since we’re able to deliver fresh pods straight to your door as soon as you run out!\r\n\r\nAlso, not to worry, our capsules do NOT contain BPA, phthalates or any toxic halogens. 	10	All our Shot Pods are freshly roasted and packed immediately after roasting. The Thermoformed food grade PP (polypropylene) plastic material provides superior oxygen barrier properties and pods are hermetically sealed - this ensures optimum freshness and a shelf-life of 3 years! But of course there’s no need to stock up, since we’re able to deliver fresh pods straight to your door as soon as you run out!\r\n\r\nAlso, not to worry, our capsules do NOT contain BPA, phthalates or any toxic halogens. 	我们所有的咖啡胶囊都是新鲜烘焙的，在烘焙之后即刻包装。热成型食品级PP（聚丙烯）塑料材料提供优越的氧气阻隔性能，并且咖啡胶囊都是密封的 - 这能确保最佳新鲜度和三年的保质期！但是当然，没必要备货，因为一旦你喝完了所有的咖啡胶囊，我们就会马上给你配送新鲜的咖啡胶囊，并且送货上门。\r\n\r\n此外，不要担心，我们的胶囊不包含BPA，邻苯二甲酸盐或任何有毒卤素。	How do I know the pods are safe and fresh?	我怎样才能知道咖啡胶囊是安全新鲜的呢？
29	Why are Hook’s coffees more expensive that those “fresh” coffees found in supermarkets?	Please don’t compare our coffees to what you find at the supermarkets? When you open your coffee bag and the aroma hits you, you will immediately know why. Yes, we’re that confident! When you taste the coffee, you’ll be even more convinced that coffee really tastes different when it’s freshly roasted.\r\n\r\nOur coffees are all specialty grade with a score of 80+ from the Specialty Coffee Association of America (SCAA) (which basically means they’re top quality stuff), sustainably grown and ethically produced, and as much as possible direct-traded. Direct-traded coffees are either bought directly from farmers or a co-operative of farmers. We’ve adopted the Direct Trade model to give you traceability of our coffees and ethical choices. Our farmers receive a bigger share of the final retail value (10-25% more than Fairtrade) and this is just one of the ways we show our appreciation for their skills and hard work as growing and processing specialty coffee is a real art. \r\n\r\nWe aren’t 100% Direct Trade yet, but we’re definitely getting there. Furthermore, all of Hook’s coffees are lovingly hand-roasted in Singapore with state-of-the-art roasters to tailor the roast profile according to the beans and to ensure consistency, then sent out to you within a week of roasting with absolutely no postage charge.	6	Please don’t compare our coffees to what you find at the supermarkets? When you open your coffee bag and the aroma hits you, you will immediately know why. Yes, we’re that confident! When you taste the coffee, you’ll be even more convinced that coffee really tastes different when it’s freshly roasted.\r\n\r\nOur coffees are all specialty grade with a score of 80+ from the Specialty Coffee Association of America (SCAA) (which basically means they’re top quality stuff), sustainably grown and ethically produced, and as much as possible direct-traded. Direct-traded coffees are either bought directly from farmers or a co-operative of farmers. We’ve adopted the Direct Trade model to give you traceability of our coffees and ethical choices. Our farmers receive a bigger share of the final retail value (10-25% more than Fairtrade) and this is just one of the ways we show our appreciation for their skills and hard work as growing and processing specialty coffee is a real art. \r\n\r\nWe aren’t 100% Direct Trade yet, but we’re definitely getting there. Furthermore, all of Hook’s coffees are lovingly hand-roasted in Singapore with state-of-the-art roasters to tailor the roast profile according to the beans and to ensure consistency, then sent out to you within a week of roasting with absolutely no postage charge.	请不要将我们的咖啡和你在超市找到的咖啡相提并论。当你打开你的咖啡袋，然后香气袭来，你立刻就会知道为什么。是的，我们就是这么自信！当你品尝这些咖啡时，你甚至会更加信服，咖啡在新鲜烘焙后，真的尝起来不一样。\r\n\r\n我们的咖啡都是精品级的，并且在美国精品咖啡协会（SCAA）的得分超过80（这基本意味着我们的咖啡是顶级的），可持续种植，生产时遵守企业道德概念并且尽可能的进行直接贸易。直接贸易类的咖啡要么是直接从咖啡种植户购买，要么是从咖啡种植户的合作社购买。我们采取直接贸易模式，便于你追踪我们的咖啡和道德选择。我们的咖啡种植户会收到最终零售价的较大份额（比互惠贸易所10-25%），而且这只是我们感谢他们的技术和辛勤工作的方式之一，因为种植和处理精品咖啡是一门真正的艺术。\r\n\r\n我们还不是100%的直接贸易，但是我们迟早有一天会是的。此外，Hook所有的咖啡都是在新加坡用顶尖的咖啡烘焙机满含深情地手工烘焙的，根据咖啡豆来调整烘焙曲线并且确保一致性，然后在烘焙好一周内发出，我们包邮。	Why are Hook’s coffees more expensive that those “fresh” coffees found in supermarkets?	为什么 Hook 的咖啡比超市里的“新鲜”咖啡更贵呢？
37	How do I pay for my order(s) and how do I know my payment information is safe?	Once you’ve chosen your coffee and told us how you want it packed and when/how frequently you want it delivered, we’ll bring you to the payment section. We accept almost any credit card! If you can’t place your order, please drop us an email and we’ll sort it out for you! Rest assured that you only pay when your coffee is sent out to you i.e. weekly or fortnightly.\r\n\r\nAll payments are processed by a company called Stripe. They use an extremely advanced and safe security system and handle payments for other online businesses such as Kickstarter, Twitter, Pinterest, Shopify, Fitbit and many more! Stripe has also been audited by a PCI-certified auditor and is certified to PCI Service Provider Level 1. This is the most stringent level of certification available.\r\n\r\nWe are currently also in the process of being SSL certified.	8	Once you’ve chosen your coffee and told us how you want it packed and when/how frequently you want it delivered, we’ll bring you to the payment section. We accept almost any credit card! If you can’t place your order, please drop us an email and we’ll sort it out for you! Rest assured that you only pay when your coffee is sent out to you i.e. weekly or fortnightly.\r\n\r\nAll payments are processed by a company called Stripe. They use an extremely advanced and safe security system and handle payments for other online businesses such as Kickstarter, Twitter, Pinterest, Shopify, Fitbit and many more! Stripe has also been audited by a PCI-certified auditor and is certified to PCI Service Provider Level 1. This is the most stringent level of certification available.\r\n\r\nWe are currently also in the process of being SSL certified.	一旦你选择你的咖啡并且告诉我们你想如何包装，你想要何时配送以及配送频率，我们会带你前往付款页面。我们接受几乎所有的信用卡！如果你不能下单，请给我们发送电子邮件，我们会为你解决问题！请放心，你只有在收到咖啡后才需付款，比如每周一次或者两周一次。\r\n\r\n所有付款都是由一家叫做Stripe的公司处理的。他们使用非常先进和安全的保障系统，为其他网上贸易处理付款，比如Kickstarter，Twitter，Pinterest，Shopify，Fitbit等等！Stripe还经过PCI认证的审计员的审计，并且有PCI服务提供者一级认证。这是现有的最严格的认证。\r\n\r\n我们目前还处于SSL认证过程中。	How do I pay for my order(s) and how do I know my payment information is safe?	我如何支付我的订单，我怎样才能知道我的付款信息是安全的呢？
48	How do I redeem my points?	Simply log into your account, and under the Rewards tab, you'll be able to see which items are available for redemption. We will constantly update the list of gifts redeemable! If there are any items in particular that you would like to see on the list, do drop us an email at hola@hookcoffee.com.sg! 	9	Simply log into your account, and under the Rewards tab, you'll be able to see which items are available for redemption. We will constantly update the list of gifts redeemable! If there are any items in particular that you would like to see on the list, do drop us an email at hola@hookcoffee.com.sg! 	只需登录到你的账户，在“奖品”下方，你会看到你能够免费获取的产品。我们会不断更新能够免费获取的礼品列表！如果有任何特定的产品，你想要在赠送列表上出现，请给我们发送电子邮件：hola@hookcoffee.com.sg！	How do I redeem my points?	我如何获得点数？
54	How do I recycle my pods?	We’re glad you asked! Our Shot Pods are made of Thermoformed food grade PP (polypropylene) plastic. Each component of your pod - including the capsule and foil seal - is recyclable but will need to be separated. To do this, simply peel off the foil, scoop out the coffee grounds (which are great plant fertilisers) and recycle accordingly!\r\n\r\nAs part of our commitment to sustainability, we're also currently doing research and development of our proprietary 100% biodegradeable pods. We can't wait to tell you when they're ready!	10	We’re glad you asked! Our Shot Pods are made of Thermoformed food grade PP (polypropylene) plastic. Each component of your pod - including the capsule and foil seal - is recyclable but will need to be separated. To do this, simply peel off the foil, scoop out the coffee grounds (which are great plant fertilisers) and recycle accordingly!\r\n\r\nAs part of our commitment to sustainability, we're also currently doing research and development of our proprietary 100% biodegradeable pods. We can't wait to tell you when they're ready!	我们很高兴你问了这个问题！我们的咖啡胶囊是由热成型食品级PP（聚丙烯）塑料制成的。你的咖啡胶囊的每个成分 - 包括胶囊和箔封口 - 都是可回收的，但是必须分开处理。为此，只需剥去箔，把咖啡渣舀出（这些都是很好的植物化肥）然后就能相应地回收了！\r\n\r\n我们作为可持续发展的一部分，目前我们还在研究开发我们专利的100%可生物降解的咖啡胶囊。当我们开发出来以后，我们会迫不及待地告诉你！	How do I recycle my pods?	我如何回收利用我的咖啡胶囊？
39	My order has not arrived, what should I do?	All new orders will be shipped out on the next working day. You'll only have to wait for your first bag as your subsequent bags will be sent out to reach you just as you're running out of coffee (and we'll know this through Hook's Coffee Calculator).\r\n\r\nWe ship all orders using SingPost normal mail. We’ve chosen to use the normal mail service because you don’t have to wait at home to receive your coffee or be afraid to miss the delivery – we’ve thoughtfully designed the packaging to fit standard mailboxes where your coffee will be dropped off, so no more postoffice runs necessary!\r\n\r\nWe find our local mail officers extremely reliable and efficient – this is Singapore after all! We’re confident SingPost will get the coffees to you within 2-4 working days (although SingPost says 3-5 on their website). However, if your coffee somehow doesn’t reach you after the fourth day, drop us an email or phone us and we’ll send you another bag the next day!	8	All new orders will be shipped out on the next working day. You'll only have to wait for your first bag as your subsequent bags will be sent out to reach you just as you're running out of coffee (and we'll know this through Hook's Coffee Calculator).\r\n\r\nWe ship all orders using SingPost normal mail. We’ve chosen to use the normal mail service because you don’t have to wait at home to receive your coffee or be afraid to miss the delivery – we’ve thoughtfully designed the packaging to fit standard mailboxes where your coffee will be dropped off, so no more postoffice runs necessary!\r\n\r\nWe find our local mail officers extremely reliable and efficient – this is Singapore after all! We’re confident SingPost will get the coffees to you within 2-4 working days (although SingPost says 3-5 on their website). However, if your coffee somehow doesn’t reach you after the fourth day, drop us an email or phone us and we’ll send you another bag the next day!	所有的新订单都会在隔天的工作日发出。你只需要等待第一个包裹，因为你的后续包裹都会在你即将喝光现有的咖啡时，被自动发出（我们会通过Hook的咖啡计算器了解到这一点）。\r\n\r\n我们使用新加坡邮政普通邮寄配送货物。我们选择使用普通邮寄服务，是因为这样的话，你就不必在家等候收货，或者担心会错过收货 - 我们很贴心地考虑到了这些，所以我们将包裹设计为便于放进邮箱的大小，这样你的咖啡就可以直接抵达你的邮箱，你再也不用跑到邮局去取货了！\r\n\r\n我们发现我们当地的邮局工作人员非常可靠高效 - 毕竟这是新加坡！我们确信新加坡邮政会在2-4个工作日内（尽管新加坡邮政的网站上说3-5个工作日）将咖啡送到你手中。但是，如果你在四天后还没有收到咖啡，那么请给我们发送电子邮件，我们会立刻在第二天为你再发一个包裹。	My order has not arrived, what should I do?	我的订单还没有到货，我该怎么做？
30	Why can’t Hook send out my coffee to me as soon as it’s roasted?	Apart from giving us time to sort out backend logistics, it takes on average 1 week for freshly roasted coffee to “degas”, which helps the beans to settle and gives you a more balanced cup. We’ll send out your coffee to you within a week of roasting and by the time you receive it, you’re all set for a perfect cup of coffee.	6	Apart from giving us time to sort out backend logistics, it takes on average 1 week for freshly roasted coffee to “degas”, which helps the beans to settle and gives you a more balanced cup. We’ll send out your coffee to you within a week of roasting and by the time you receive it, you’re all set for a perfect cup of coffee.	除了我们需要时间解决后端物流以外，新鲜烘焙好的咖啡平均需要1周的时间来“脱气”，这有助于咖啡放松，并且让你的咖啡尝起来更美味。我们会在咖啡新鲜烘焙好之后的一周内发货，在你收到货的时候，你就可以品尝到美味的咖啡了。	Why can’t Hook send out my coffee to me as soon as it’s roasted?	为什么 Hook 不能在咖啡烘焙好之后即刻寄给我？
27	Why do I need to indicate how intense I like my coffee? What does “intensity” mean anyway?	The intensity of your coffee depends very much on the roast profile of the beans so if you prefer a bold cup with more depth we would likely recommend you a coffee with a higher roast degree i.e. a darker roast, and vice versa. But don’t confuse intensity with strength – the caffeine level in all beans hardly varies, if at all. The brew method however, does affect the caffeine level, but only slightly. Not to get into the nitty-gritty details but just to debunk a myth, espresso coffees actually have the lowest caffeine level because of the high speed of extraction – espressos only seem more “strong” because of the high pressure during the extraction process which produces that characteristic crema.	5	The intensity of your coffee depends very much on the roast profile of the beans so if you prefer a bold cup with more depth we would likely recommend you a coffee with a higher roast degree i.e. a darker roast, and vice versa. But don’t confuse intensity with strength – the caffeine level in all beans hardly varies, if at all. The brew method however, does affect the caffeine level, but only slightly. Not to get into the nitty-gritty details but just to debunk a myth, espresso coffees actually have the lowest caffeine level because of the high speed of extraction – espressos only seem more “strong” because of the high pressure during the extraction process which produces that characteristic crema.	你的咖啡的强度很大程度上取决于咖啡豆的烘焙曲线，所以如果你更倾向于更有味道的，浓一点的咖啡，那我们向你推荐烘焙程度较高的咖啡，比如较高程度的烘焙，反之亦然。但是不要把咖啡的强度和咖啡因含量混淆 - 即使有的话，所有咖啡豆里的咖啡因等级几乎都一样。但是，烹煮方式，确实会影响咖啡因等级，但是只是轻微地影响。并非要详细阐述，只是想揭穿一个迷思，意式浓缩咖啡的咖啡因含量其实是最低的，因为高速的提炼 - 意式浓缩咖啡看起来更“浓”是因为在提取过程中的高压，会产生独特的咖啡脂。	Why do I need to indicate how intense I like my coffee? What does “intensity” mean anyway?	为什么我需要表明我喜欢的咖啡强度是多少？“强度”的意思是什么？
38	Help! I can’t log in to my account!\t	An account is only created after you've made your first purchase. If you haven't made a purchase with us before, you can go through "Get Started" and use our recommendation engine to choose which coffee you'd like.\r\n\r\nIf you’ve forgotten your password, you can reset it easily on the Log In page. If you still can’t log in, fret not! Email us with your full name, email address, home address (if you’ve ordered from us before) and we’ll make the necessary amendments for you.	8	An account is only created after you've made your first purchase. If you haven't made a purchase with us before, you can go through "Get Started" and use our recommendation engine to choose which coffee you'd like.\r\n\r\nIf you’ve forgotten your password, you can reset it easily on the Log In page. If you still can’t log in, fret not! Email us with your full name, email address, home address (if you’ve ordered from us before) and we’ll make the necessary amendments for you.	只有在你进行了第一次购买后才会创建一个新账户。如果你还没有从我们这里购买过产品，你可以点击“开始”，然后使用我们的推荐引擎来选择你喜欢的咖啡。\r\n\r\n如果你忘记了你的密码，你只需在登录页面重新设置密码。如果你仍然无法登陆，不用担心！将你的姓名、电子邮件地址、家庭地址以电子邮件的形式发送给我们（如果你以前从我们这里购买过产品的话），我们会为你进行必要的修改。	Help! I can’t log in to my account!\t	求助！我无法登入我的账户了！
25	Why do I need to specify my brew method?	The simple answer is that different coffees go better with different brew methods or apparatuses. For example, La Dulce Vida tastes so much better using the drip method, say in comparison to the espresso. There’s science behind that, but we’re not great at explaining scientific concepts. We’re coffee geeks though, and have been brewing our own coffee for years – hopefully that’s worth something!\r\n\r\nWhen viewing our full range of coffees, you can click on your preferred brew method(s) and we’ll reshuffle the coffees based on which coffees we feel are best suited to your chosen method.\r\n\r\nAnd of course, if you're using a Nespresso machine, we'll only recommend coffees from our ShotPods range.	5	The simple answer is that different coffees go better with different brew methods or apparatuses. For example, La Dulce Vida tastes so much better using the drip method, say in comparison to the espresso. There’s science behind that, but we’re not great at explaining scientific concepts. We’re coffee geeks though, and have been brewing our own coffee for years – hopefully that’s worth something!\r\n\r\nWhen viewing our full range of coffees, you can click on your preferred brew method(s) and we’ll reshuffle the coffees based on which coffees we feel are best suited to your chosen method.\r\n\r\nAnd of course, if you're using a Nespresso machine, we'll only recommend coffees from our ShotPods range.	答案很简单，不同的咖啡适合不同的烹煮方式或设备。比如，如果用滤杯煮La Dulce Vida，那味道比浓缩咖啡好多了。这背后是有科学道理的，但是我们不太擅长解释科学概念。我们是咖啡极客，烹煮我们自己的咖啡很多年了 - 希望这物有所值！\r\n\r\n当你在浏览我们所有种类的咖啡时，你可以点击你偏爱的烹煮方式，我们会根据我们觉得最适合你所选择的烹煮方式的咖啡来重新安排。\r\n\r\n当然，如果你使用的是Nespresso咖啡机，我们只从咖啡胶囊范围中为你推荐。	Why do I need to specify my brew method?	为什么我需要详细说明我的烹煮方式？
45	How does it work?	If you have an active subscription with Hook Coffee, with every bag of coffee you buy you accrue 200 points. If you've purchased a bag from the Black Gold edition, you'll get 300 points.\r\n\r\nIf you currently do not have an active subscription with Hook Coffee, with every bag of coffee you buy you accrue 50 points. If you've purchased a bag from the Black Gold edition, you'll get 75 points.\r\n	9	If you have an active subscription with Hook Coffee, with every bag of coffee you buy you accrue 200 points. If you've purchased a bag from the Black Gold edition, you'll get 300 points.\r\n\r\nIf you currently do not have an active subscription with Hook Coffee, with every bag of coffee you buy you accrue 50 points. If you've purchased a bag from the Black Gold edition, you'll get 75 points.\r\n	如果你在Hook咖啡已经有一个有效订阅，那么你每购买一袋咖啡，就可以获得200点积分。如果你从黑金版购买一袋咖啡，你就会获得300点积分。\r\n\r\n如果你目前在Hook咖啡没有有效订阅，那么每购买一袋咖啡，你可以获得50点积分，如果你从黑金版购买一袋咖啡，你可以获得75点积分。	How does it work?	如何运作？
46	Why subscribe and get more points?	When you subscribe, you get more points, so over a period of time, you'll accumulate more points and get to redeem more free gifts!\r\n\r\nAnd who doesn't love free gifts?	9	When you subscribe, you get more points, so over a period of time, you'll accumulate more points and get to redeem more free gifts!\r\n\r\nAnd who doesn't love free gifts?	当你订阅以后，你就会获得更多点数，所以通过一段时间，你就会积累更多的点数，这样你就能获得更多免费礼品！\r\n\r\n谁不爱免费礼品呢？	Why subscribe and get more points?	为什么要订阅，又为什么要获得更多点数呢？
47	Do my points ever expire?	Nope, just like our friendship, your points won't ever expire! :)	9	Nope, just like our friendship, your points won't ever expire! :)	不会，就像我们的友谊一样，你的点数永远不会过期！:)	Do my points ever expire?	我的点数会过期吗？
55	Are your pods compatible with other machines?	Nope, we’ve only perfected the Nespresso®-compatible pods, but we’ll be sure to let you know when we offer pods that are compatible with other brands.	10	Nope, we’ve only perfected the Nespresso®-compatible pods, but we’ll be sure to let you know when we offer pods that are compatible with other brands.	不兼容，我们只完善了与Nespresso®兼容的咖啡胶囊，但是如果我们有了和其他品牌兼容的咖啡胶囊，我们一定会通知你。	Are your pods compatible with other machines?	我们的咖啡胶囊和其他机器兼容吗？
58	Are the coffees flavoured? Why can’t I taste the “flavours”?	There are no additives/flavourings/sweeteners – the tasting notes are the natural characteristics and flavour-quirks of the coffees (depending on where they were grown)! \r\n\r\nThis also means that the tasting notes are delicate and nuanced, complementing the taste of coffee well. \r\n\r\nHitting it on the nail is a bit of a trial and error process. The grind size can make a big difference. If it’s too fine, the coffee would be over extracted and the nuanced flavours can't come through, and vice versa if the grounds are too coarse. \r\n\r\nRemember to use hot water between 90-95 deg celsius. Anything higher, the coffee would be “burnt” and any lower, it won’t be extracted well. \r\n\r\nLastly, we’d advise to let the coffee cool a bit before indulging because heat masks your taste buds! \r\n\r\nTo watch our video brew guides, go to https://goo.gl/bVlIZS.	6	There are no additives/flavourings/sweeteners – the tasting notes are the natural characteristics and flavour-quirks of the coffees (depending on where they were grown)! \r\n\r\nThis also means that the tasting notes are delicate and nuanced, complementing the taste of coffee well. \r\n\r\nHitting it on the nail is a bit of a trial and error process. The grind size can make a big difference. If it’s too fine, the coffee would be over extracted and the nuanced flavours can't come through, and vice versa if the grounds are too coarse. \r\n\r\nRemember to use hot water between 90-95 deg celsius. Anything higher, the coffee would be “burnt” and any lower, it won’t be extracted well. \r\n\r\nLastly, we’d advise to let the coffee cool a bit before indulging because heat masks your taste buds! \r\n\r\nTo watch our video brew guides, go to https://goo.gl/bVlIZS.	咖啡中不含添加剂/调味剂/甜味剂 - 咖啡的口味就是其自然独特的风味（具体取决于咖啡的生长地）！\r\n\r\n这还意味着咖啡的品尝特征是柔和的，细致入微的，补充了咖啡的味道。\r\n\r\n把咖啡做到最好是个反复试验的过程。研磨粒度的不同会产生很大的不同。如果太细，咖啡就会被过度提取，也就无法有微妙的味道，如果咖啡太粗，就会产生相反的效果。\r\n\r\n记得使用95摄氏度的热水。如果高于这个温度，咖啡就会被“烫伤”，如果太低，就无法把咖啡的味道很好地提取出来。\r\n\r\n最后，我们建议你让咖啡稍微凉一下，因为热度会掩盖你的味蕾！\r\n\r\n如果你想要观看我们的烹煮指南视频。请前往https://goo.gl/bVlIZS。\r\n	Are the coffees flavoured? Why can’t I taste the “flavours”?	咖啡经过调味吗？我为什么尝不出“味道”呢？
51	How do I order pods?	Just click on any of those yellow ‘GET STARTED’ buttons and we’ll bring you through 3 quick questions on how you brew and enjoy your coffee. Our intelligent recommendation engine will recommend you a coffee from our ShotPods range. You can either go with our recommendation or choose something else if you’re feeling adventurous. Our Coffee Calculator at checkout will help you determine your ideal delivery frequency, based on your pods consumption. You can even choose if you want the same coffee each time, or ask to be surprised (which means we’ll send you different coffees from our range every time so you can try them all)! Finally, sit back, relax, and our coffee will be on its way to you.\r\n\r\nAlternatively, you can go straight to our 'ShotPods' page to choose which pods you'd like.	10	Just click on any of those yellow ‘GET STARTED’ buttons and we’ll bring you through 3 quick questions on how you brew and enjoy your coffee. Our intelligent recommendation engine will recommend you a coffee from our ShotPods range. You can either go with our recommendation or choose something else if you’re feeling adventurous. Our Coffee Calculator at checkout will help you determine your ideal delivery frequency, based on your pods consumption. You can even choose if you want the same coffee each time, or ask to be surprised (which means we’ll send you different coffees from our range every time so you can try them all)! Finally, sit back, relax, and our coffee will be on its way to you.\r\n\r\nAlternatively, you can go straight to our 'ShotPods' page to choose which pods you'd like.	只需点击黄色的“开始”按钮，我们就会带你去回答关于你如何烹煮和享受咖啡的3个快速问答。我们的智能推荐引擎会从我们的咖啡胶囊中为你推荐一款。你可以选择听从我们的推荐，或者如果你喜欢冒险也可以选择其他的。我们在结算页面的咖啡计算器会基于你的咖啡需求量，帮助你决定理想的配送频率。你甚至可以选择每次都要同样的咖啡，或者要求我们给你惊喜（这就意味着我们每次都会给你发不同的咖啡，便于你可以全都试一遍）！最后，坐下，放松，我们的咖啡即将在朝你飞奔而来的路上。\r\n\r\n或者，你可以直奔我们的“咖啡胶囊”页面，选择你喜欢的咖啡胶囊。	How do I order pods?	我如何订购咖啡胶囊？
\.


--
-- Name: content_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_post_id_seq', 59, true);


--
-- Data for Name: content_review; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_review (id, author, message, author_en, author_zh_hans, message_en, message_zh_hans, is_workplace, logo) FROM stdin;
7	Daniel	Beautiful coffee. Great customer service.	Daniel	\N	Beautiful coffee. Great customer service.	\N	f	\N
8	Kelly	Truly impressed with the customer service so far!	Kelly	凯丽	Truly impressed with the customer service so far!	迄今为止，客户服务给我留下了深刻的印象！	f	\N
2	Clare	I can't wait for Hook Coffee to bring me better coffee at work! I don't share so I guess y'all just gonna have to subscribe to Hook Coffee too.	Clare	克莱尔	I can't wait for Hook Coffee to bring me better coffee at work! I don't share so I guess y'all just gonna have to subscribe to Hook Coffee too.	我等不及要看Hook咖啡给我在工作时带来更好的咖啡了！我不分享，所以我猜你们也都只能在Hook咖啡上订阅了。	f	\N
3	Kian Seh	Thanks for creating this startup, and bringing such great coffee to my mailbox for a really, really affordable price … The fact that I can drink all these without adding sugar shows that they all have strong and enjoyable flavours.	Kian Seh	基恩·瑟	Thanks for creating this startup, and bringing such great coffee to my mailbox for a really, really affordable price … The fact that I can drink all these without adding sugar shows that they all have strong and enjoyable flavours.	谢谢你创建这个新公司，把这么棒的咖啡以我负担得起的价格出售，并送到我的邮箱...无需加糖就能喝，说明这些咖啡的味道很强，很让人享受。	f	\N
5	Yiwen	Hook Coffee’s coffee drip bags — A lazy girl’s solution to a better cuppa in the morning.	Yiwen	Yiwen	Hook Coffee’s coffee drip bags — A lazy girl’s solution to a better cuppa in the morning.	Hook 咖啡的滤挂咖啡 - 懒女孩在早上喝杯较好咖啡的解决方法。	f	\N
1	Xiwei	Awesome concept, something we've always known we needed!	Xiwei	Xiwei	Awesome concept, something we've always known we needed!	很棒的概念，我们一直都知道我们所需要的！	f	\N
6	Ryan	Hooked.	Ryan	莱恩	Hooked.	我已经喝这咖啡喝上瘾了。	f	\N
4	Elizabeth	Mornings made better with Hook Coffee :)	Elizabeth	伊丽莎白	Mornings made better with Hook Coffee :)	有了Hook 咖啡，早晨变得更美好 :)	f	\N
\.


--
-- Name: content_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_review_id_seq', 8, true);


--
-- Data for Name: content_section; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_section (id, name, name_en, name_zh_hans) FROM stdin;
4	Hook's Subscription Model	Hook's Subscription Model	Hook 的订阅模式
5	Hook's Recommendation Engine	Hook's Recommendation Engine	Hook 的推荐引擎
6	Hook's Coffees	Hook's Coffees	Hook 的咖啡
7	Managing Your Account	Managing Your Account	管理你的账户
8	Help!	Help!	帮助！
9	Hook Rewards 	Hook Rewards 	Hook 的奖励
10	ShotPods (Nespresso compatible)	ShotPods (Nespresso compatible)	咖啡胶囊（与Nespresso兼容）
\.


--
-- Name: content_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_section_id_seq', 10, true);


--
-- Data for Name: content_topbar; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY content_topbar (id, block_text, button_text, link, visible) FROM stdin;
1	LOOKING FOR THE PERFECT GIFT FOR DAD?	SHOP HERE!	https://hookcoffee.com.sg/coffees/shop-gift-set	t
\.


--
-- Name: content_topbar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('content_topbar_id_seq', 1, true);


--
-- Data for Name: customauth_login; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customauth_login (id, username, password, accesstoken, created) FROM stdin;
\.


--
-- Name: customauth_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customauth_login_id_seq', 1, false);


--
-- Data for Name: customauth_myuser; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customauth_myuser (id, password, last_login, email, is_active, is_admin, is_superuser, created_at) FROM stdin;
1	pbkdf2_sha256$30000$Pw9j8YkMHqgn$AKKiB7UmXlqaBISOzf/SGeiR+t6cQaskG5hTECFGYbw=	2017-07-13 13:56:21.663985+00	dev@hookcoffee.com.sg	t	t	t	2017-07-01 19:15:55.715094+00
4	pbkdf2_sha256$30000$Niq28uDwFkN7$S3V3GVze3DKvBJq3ZS++CFP2tX3sWSIr4sOeBMZhwHI=	\N	constverum+test2@gmail.com	t	f	f	2017-07-13 22:11:06.337518+00
5	pbkdf2_sha256$30000$T3eEqnHwzvkH$9YPEKonKtvUWB8tFhhpfactZ/GlQ7ijxaLd1ROFdH6A=	2017-07-13 22:13:27.29706+00	constverum+test3@gmail.com	t	f	f	2017-07-13 22:13:27.0738+00
6	pbkdf2_sha256$30000$EJqU2Wd4bhJM$DDM32FlakBDQrgbUQ+07WYckwUXBkvrZOKYbl8b7zeo=	2017-07-15 16:57:31.986993+00	constverum+test12@gmail.com	t	f	f	2017-07-15 16:57:31.448363+00
7	pbkdf2_sha256$30000$uUiBdEeGoEy9$CCR0aILkv14NLntBXZPboEvcksgsvALGFLgbIvE57qw=	2017-07-31 18:16:56.477177+00	constverum+dasda@gmail.com	t	f	f	2017-07-31 18:16:56.143687+00
8	pbkdf2_sha256$30000$i73C8RWnRpgW$1ooouthOiPZtPAOw5/CpMhUvKX+x+XfVx+9QO3ihqC4=	2017-08-01 15:13:48.070282+00	constverum+dfs@gmail.com	t	f	f	2017-08-01 15:13:30.443953+00
9	pbkdf2_sha256$30000$JUwo6VqoOXfq$CrBLcMaZrvJsVVq6t1OqRaZNkS7Hg8Wr58EUz2nJUAQ=	2017-08-01 15:15:53.907903+00	constverum+fddfd@gmail.com	t	f	f	2017-08-01 15:15:38.904537+00
10	pbkdf2_sha256$30000$z6f8axUycqab$Dja28sk1YHWUXgJmtvgRTeU/4ZA+HaOYlV5wiFz0Trs=	2017-08-01 15:17:41.472718+00	constverum+dsfdsfsdfds@gmail.com	t	f	f	2017-08-01 15:17:26.252665+00
2	pbkdf2_sha256$30000$R8SG1qat5EKn$kybs3d7Mn5DJl7CsJxYgSepnteJWy2lNVVs/2+atCUA=	2017-08-02 05:58:37.752389+00	ernest@hookcoffee.com.sg	t	t	f	2017-07-13 22:05:51.080669+00
\.


--
-- Data for Name: customauth_myuser_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customauth_myuser_groups (id, myuser_id, group_id) FROM stdin;
1	1	2
\.


--
-- Name: customauth_myuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customauth_myuser_groups_id_seq', 2, false);


--
-- Name: customauth_myuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customauth_myuser_id_seq', 10, true);


--
-- Data for Name: customauth_myuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customauth_myuser_user_permissions (id, myuser_id, permission_id) FROM stdin;
\.


--
-- Name: customauth_myuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customauth_myuser_user_permissions_id_seq', 2, false);


--
-- Data for Name: customers_address; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_address (id, name, recipient_name, country, line1, line2, postcode, is_primary, customer_id) FROM stdin;
\.


--
-- Name: customers_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_address_id_seq', 1, false);


--
-- Data for Name: customers_cardfingerprint; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_cardfingerprint (id, fingerprint, customer_id) FROM stdin;
1	5zFrIxUZU7PLSMWL	2
2	5zFrIxUZU7PLSMWL	3
3	5zFrIxUZU7PLSMWL	4
4	5zFrIxUZU7PLSMWL	5
5	5zFrIxUZU7PLSMWL	7
6	5zFrIxUZU7PLSMWL	8
7	5zFrIxUZU7PLSMWL	9
\.


--
-- Name: customers_cardfingerprint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_cardfingerprint_id_seq', 7, true);


--
-- Data for Name: customers_charge; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_charge (id, amount, description, metadata, date, stripe_id, customer_id, product_id) FROM stdin;
\.


--
-- Name: customers_charge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_charge_id_seq', 1, false);


--
-- Data for Name: customers_coffeereview; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_coffeereview (id, rating, comment, created_at, coffee_id, order_id) FROM stdin;
\.


--
-- Name: customers_coffeereview_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_coffeereview_id_seq', 1, false);


--
-- Data for Name: customers_customer; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_customer (id, first_name, last_name, line1, line2, postcode, stripe_id, user_id, card_details, phone, amount, country, extra, discounts) FROM stdin;
1	Developer	X	First line #11	Second line #22	358599	cus_ApfNgprl1cK1QR	1	5556122020		0	SG	"answered_exp_survey"=>"True"	"referral"=>"[]"
2	Ernest	Ting	123	321	0000000	cus_B1I1bJeTUbfrIJ	2	4242122020		0	SG	"answered_exp_survey"=>"True"	"referral"=>"[]"
3	Ddsaas	asdas	das	das	24234232	cus_B1I6jZXPZnU7X1	4	4242122020		0	SG		"referral"=>"[]"
4	Kfdssf	DSADS	dassa	234	765432	cus_B1I9Gcd7JZuKlR	5	4242122020		0	SG		"referral"=>"[]"
5	Ofdshj	dassad	sadsa dassdsaas #23	eqw qwewqeq e	24234432	cus_B1xVvUJ1u4a2XB	6	4242122020		0	SG		"referral"=>"[]"
6	Bnmcxz	dsasfd	fdsds	fdss	42332432		7	0000000000		84	SG		"referral"=>"[]"
7	Mfhjsld	fdsfsd	dfsd	fsds	2343423	cus_B8If7muuK30rbo	8	4242122020		0	SG		"referral"=>"[]"
8	Tuyirew	fds	fdsfds	fsds	2423423423	cus_B8Ihb5hUmfgGqi	9	4242122020		0	SG		"referral"=>"[]"
9	Qertgvf	fdsdsf	fdsds	fsddsfsd	232432432	cus_B8IjX82wV6OT9H	10	4242122020		0	SG		"referral"=>"[]"
\.


--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_customer_id_seq', 9, true);


--
-- Data for Name: customers_customer_received_coffee_samples; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_customer_received_coffee_samples (id, customer_id, coffeetype_id) FROM stdin;
\.


--
-- Name: customers_customer_received_coffee_samples_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_customer_received_coffee_samples_id_seq', 1, true);


--
-- Data for Name: customers_customer_vouchers; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_customer_vouchers (id, customer_id, voucher_id) FROM stdin;
1	4	14
2	5	14
3	1	537
4	7	14
5	8	14
\.


--
-- Name: customers_customer_vouchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_customer_vouchers_id_seq', 5, true);


--
-- Data for Name: customers_facebookcustomer; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_facebookcustomer (id, facebook_id, first_name, last_name, email, gender, customer_id) FROM stdin;
\.


--
-- Name: customers_facebookcustomer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_facebookcustomer_id_seq', 1, false);


--
-- Data for Name: customers_gearorder; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_gearorder (id, date, shipping_date, price, status, details, customer_id, gear_id, tracking_number, voucher_id, address_id) FROM stdin;
1	2017-07-13 21:52:28.069756+00	2017-07-17 04:00:00+00	77.00	AC	"Quantity"=>"1"	1	17		\N	\N
\.


--
-- Name: customers_gearorder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_gearorder_id_seq', 1, true);


--
-- Data for Name: customers_order; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_order (id, different, date, shipping_date, amount, "interval", recurrent, status, package, brew_id, coffee_id, customer_id, voucher_id, feedback, details, resent, custom_price, address_id) FROM stdin;
1	f	2017-07-01 18:03:13.189873+00	2017-07-02 04:00:00+00	14.00	9	t	SH	DR	2	32	1	\N	\N		f	f	\N
16	t	2017-07-31 18:16:56.305088+00	2017-08-02 04:00:00+00	14.00	14	t	AC	WB	2	14	6	\N	\N	"friend"=>"dasas"	f	f	\N
17	t	2017-07-31 18:27:02.293552+00	2017-08-02 04:00:00+00	14.00	14	t	AC	WB	2	40	6	\N	\N		f	f	\N
3	t	2017-07-13 22:05:51.470722+00	2017-07-17 04:00:00+00	14.00	14	t	AC	WB	5	37	2	\N	\N		f	f	\N
4	t	2017-07-13 22:13:27.217976+00	2017-07-17 04:00:00+00	9.00	14	t	AC	GR	1	40	4	14	\N		f	f	\N
5	t	2017-07-15 16:57:31.798447+00	2017-07-17 04:00:00+00	9.00	14	t	AC	WB	3	14	5	14	\N		f	f	\N
2	f	2017-07-13 15:01:37.470962+00	2017-08-27 04:00:00+00	14.00	14	t	CA	GR	2	14	1	\N	\N		f	f	\N
6	f	2017-07-23 10:54:39.304084+00	2017-07-24 04:00:00+00	18.00	7	f	CA	WB	2	37	1	\N	\N		f	f	\N
7	t	2017-07-23 11:16:15.952727+00	2017-07-24 04:00:00+00	46.00	14	t	CA	WB	1	32	1	537	\N		f	f	\N
14	t	2017-07-23 12:15:48.378759+00	2017-08-24 04:00:00+00	46.00	28	t	AC	WB	2	40	1	537	\N	"AEROPRESS50"=>"true"	f	f	\N
18	t	2017-08-01 15:13:42.062805+00	2017-08-02 04:00:00+00	9.00	14	t	AC	WB	3	14	7	14	\N		f	f	\N
19	t	2017-08-01 15:15:48.720569+00	2017-08-02 04:00:00+00	9.00	14	t	AC	WB	1	40	8	14	\N		f	f	\N
20	f	2017-08-01 15:17:39.405952+00	2017-08-02 04:00:00+00	18.00	7	f	AC	PODS	6	27	9	\N	\N		f	f	\N
15	f	2017-07-28 09:03:32.029639+00	2017-08-31 04:00:00+00	35.00	30	t	AC	BO	8	42	1	\N	\N		f	f	\N
\.


--
-- Name: customers_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_order_id_seq', 20, true);


--
-- Data for Name: customers_plan; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_plan (id, plan, name, currency, amount, metadata, "interval", interval_count, stripe_id) FROM stdin;
\.


--
-- Name: customers_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_plan_id_seq', 1, false);


--
-- Data for Name: customers_postcard; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_postcard (id, customer_postcard) FROM stdin;
1	postcards/selection.pdf
\.


--
-- Name: customers_postcard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_postcard_id_seq', 1, true);


--
-- Data for Name: customers_preferences; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_preferences (id, package, decaf, different, cups, intense, "interval", force_coffee, brew_id, coffee_id, customer_id, present_next, different_pods, force_coffee_pods, interval_pods) FROM stdin;
1	WB	f	f	7	5	7	f	7	32	1	f	f	f	7
2	WB	f	t	7	5	14	f	5	37	2	f	t	f	14
3	WB	f	f	7	5	7	f	\N	11	3	f	f	f	7
5	GR	f	t	7	5	14	f	1	40	4	f	t	f	14
6	WB	f	t	7	3	14	f	3	14	5	f	t	f	14
7	WB	f	t	7	3	14	f	2	14	6	f	f	f	7
8	WB	f	t	7	3	14	f	3	14	7	f	t	f	14
9	WB	f	t	7	5	14	f	1	40	8	f	t	f	14
10	WB	f	f	7	5	7	f	7	27	9	f	f	f	7
\.


--
-- Data for Name: customers_preferences_flavor; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_preferences_flavor (id, preferences_id, flavor_id) FROM stdin;
1	1	3
2	6	3
3	7	2
4	8	6
\.


--
-- Name: customers_preferences_flavor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_preferences_flavor_id_seq', 4, true);


--
-- Name: customers_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_preferences_id_seq', 10, true);


--
-- Data for Name: customers_reference; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_reference (id, referred_id, referrer_id) FROM stdin;
\.


--
-- Name: customers_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_reference_id_seq', 1, false);


--
-- Data for Name: customers_referral; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_referral (id, aim, code, status, user_id) FROM stdin;
1	GE	DEV1236EQ9O	AC	1
2	GE	DSAADDAS5BS9O	AC	5
3	GE	DSDASA6FKDZ	AC	6
4	GE	DASSA7KKIA	AC	7
5	GE	DSADSAA89IGP	AC	8
6	GE	FDSFDS99MY0	AC	9
7	GE	FDSF10FU3B	AC	10
\.


--
-- Name: customers_referral_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_referral_id_seq', 7, true);


--
-- Data for Name: customers_shoppingcart; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_shoppingcart (customer_id, content, last_modified, first_reminder, second_reminder, voucher_id) FROM stdin;
1	[{"coffee":{"id":40,"name":"Appley Ever After ","price":"18.00","brew":"Aeropress","brew_id":3,"package":"WB"},"quantity":1}]	2017-07-31 18:22:51.925748+00	f	f	\N
6	[{"gear":{"id":18,"name":"Hario Hand Grinder","price":"45.00"},"quantity":1}]	2017-07-31 18:27:28.632468+00	f	f	\N
\.


--
-- Data for Name: customers_subscription; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_subscription (id, metadata, stripe_id, status, customer_id, plan_id) FROM stdin;
\.


--
-- Name: customers_subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_subscription_id_seq', 1, false);


--
-- Data for Name: customers_voucher; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_voucher (id, name, discount, count, discount2, mode, category_id, email, personal) FROM stdin;
57	YUAN	50	49	0	t	1		f
48	ERNEST	50	228	0	t	1		f
97	THREE20	0	39	2	t	10		f
101	M&G50	50	1	0	f	1		f
51	SHOTPODSSTARTER	0	31	0	t	1		f
71	SAM	50	11	0	t	1		f
108	RESTOCK5	0	8	5	t	2		f
98	FRESH5	0	6	9	t	1		f
124	P50	50	0	0	t	1		f
112	THK50	0	0	0	t	1		f
110	GIFTSET10	10	0	0	t	11		f
109	REFRESH50	50	0	0	t	2		f
111	TAKE10	0	43	10	t	1		f
107	CARDDAY5	0	5	9	t	1		f
77	SHOTPODS3.0	20	11	0	t	3		f
106	IGFREEBAG	0	6	12	t	1		f
105	IG50	50	0	0	t	1		f
103	PANIC5	0	9	9	t	1		f
102	TANGS50	50	7	0	t	1		f
85	NTUCHOOK	50	0	0	f	1		f
94	SWEET15	15	7	0	t	9		f
96	SPH50	50	0	0	t	1		f
114	MARCH10	10	19	0	f	11		f
104	TAKA50	50	1	0	t	1		f
88	HUAT8H!	8	27	0	t	7		f
91	HOOKED17	0	20	12	f	1		f
90	FB10	10	0	0	t	1		f
86	HOOKED50	50	3	0	t	1		f
87	FINAL15	15	98	0	t	7		f
84	HOHO15	15	33	0	t	7		f
76	CKGOTHOOKED	50	0	0	f	1		f
81	GIFT15	15	71	0	f	7		f
95	HUAT8	8	31	0	t	7		f
79	GIFT10	10	72	0	f	7		f
99	HUAT5	0	4	5	t	9		f
83	GLOBAL	0	0	3	t	6		f
73	COFFEESCRUB	0	6	0	t	3		f
75	NOW5	0	40	9	t	1		f
74	HOOKBOOKS50 	50	0	0	t	1		f
72	SCRUB	0	9	5	t	1		f
33	SHOTPODS50	50	9	0	t	3		f
70	TJC50	50	2	0	t	1		f
69	MICEYUAN50	50	0	0	f	1		f
68	MICEAISYAH50	50	3	0	f	1		f
67	MICESAM50	50	4	0	t	1		f
66	CLUB50	50	2	0	t	1		f
65	START50	50	8	0	t	1		f
63	M2020	50	0	0	f	1		f
78	GIVEME5	0	12	5	f	5		f
61	DBS58	58	2	0	t	1		f
60	YTS50	50	0	0	t	1		f
58	FAYE 	50	0	0	t	1		f
55	HOOK5	0	27	9	t	1		f
53	TRY5	0	81	9	t	1		f
52	GD50	50	0	0	t	1		f
50	DRIPSTARTER	0	61	0	t	1		f
49	80GSTARTER	0	73	0	t	1		f
47	startup50	50	1	0	t	1		f
44	RESTART5	0	8	5	f	1		f
43	MAGGIE50	50	0	0	t	1		f
41	CITICLUB	50	0	0	t	1		f
36	JEMMA50	50	0	0	t	1		f
35	WHOOPSIE10	10	31	0	f	1		f
34	PODS50	50	8	0	t	1		f
32	TEST50	50	0	0	f	1		f
64	YAY20	20	19	0	f	4		f
29	HI50	0	0	0	f	1		f
28	TK5EFV	0	7	10	f	1		f
12	KEPPEL50	50	1	0	t	1		f
10	HI50!	50	67	0	f	1		f
8	ASCENDAS50	50	1	0	f	1		f
7	klapsons50	50	0	0	f	1		f
6	Taster Pack	0	276	0	t	1		f
5	INSTA50	50	8	0	t	1		f
3	EARLYBIRD50	50	5	0	f	1		f
2	SC50	50	18	0	f	1		f
113	TRYANOTHER25	25	0	0	t	2		f
141	IAN	50	0	0	t	1		f
80	CWCHOOK	50	0	0	f	1		f
92	2017	17	33	0	t	1		f
56	RETURN5	0	24	5	t	1		f
46	TFC50	50	5	0	t	1		f
45	COMEBACK50	50	10	0	f	1		f
39	RESTART20	20	14	0	f	1		f
38	SIHANxHOOK	50	0	0	f	1		f
37	OCBC50	50	17	0	t	1		f
30	FB5	0	6	5	t	1		f
27	Taster 5x	0	70	0	t	1		f
17	Taster 3x80g	0	20	0	t	1		f
11	WELCOME50	50	47	0	t	1		f
149	EASTER10	10	24	0	f	11		f
429	PODS2	0	314	12	t	1		f
42	IPMAN	50	3	0	t	1		f
40	RACHxHOOK	50	0	0	t	1		f
62	HIGH5	0	289	9	t	1		f
1	TRYUS50	50	479	0	t	1		f
9	V60STARTER	0	412	0	t	1		f
538	DSAFDSFSDDUJHR$2	0	0	12	t	2	constverum+dasda@gmail.com	t
14	TAKEFIVE!	0	373	5	t	1		f
533	NHBGFVDCSXPCMZD$2	0	0	12	f	2	constverum+test1@gmail.com	t
534	FSDSFDSFGYANC$2	0	0	12	f	2	constverum+test1@gmail.com	t
537	AEROPRESS50	0	6	-32	t	10		f
536	HNBGVFCDSBHDLP$2	0	0	12	f	2	constverum+test12@gmail.com	t
535	DSADASVIBZJ$2	0	0	12	f	2	constverum+test2@gmail.com	t
539	DSASDSAZXDNQ$2	0	0	12	f	2	constverum+dfs@gmail.com	t
\.


--
-- Name: customers_voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_voucher_id_seq', 539, true);


--
-- Data for Name: customers_vouchercategory; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY customers_vouchercategory (id, name, "desc") FROM stdin;
1	Introductory	
2	Re-engagement	
3	Special	
4	Special holiday promo	
5	Re-engagement 5th nov 	
6	Worldwide	
7	GiftSets	
8	CNY GIFT SETS 	
9	Re-engagement on intercom 	
10	REUSABLE	
11	shopping cart	
12	discover pack	
13	special edition coffee	
\.


--
-- Name: customers_vouchercategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('customers_vouchercategory_id_seq', 13, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2017-07-13 15:04:03.376796+00	2	[2] Active | Jul, 13 (23:01) | Jul, 30 (12:00) | [SG] Developer X <dev@hookcoffee.com.sg> | Guji Liya from East Sidamo, Ethiopia	2	[{"changed": {"fields": ["shipping_date"]}}]	14	1
2	2017-07-13 17:46:02.414959+00	1	constverum+tt@gmail.com [Jul, 14 (01:43) => Jul, 14 (01:46)] : Welcome back! Your paused subscription is to be resumed.	2	[{"changed": {"fields": ["email", "scheduled"]}}]	62	1
3	2017-07-13 17:54:45.083843+00	1	dev@hookcoffee.com.sg [Jul, 14 (01:43) => Jul, 14 (01:46)] : Welcome back! Your paused subscription is to be resumed.	2	[{"changed": {"fields": ["email"]}}]	62	1
4	2017-07-23 10:52:24.502928+00	537	AEROPRESS50 (0)	1	[{"added": {}}]	8	1
5	2017-07-23 11:07:43.487562+00	537	AEROPRESS50 (0)	2	[{"changed": {"fields": ["discount2"]}}]	8	1
6	2017-07-23 11:09:12.693556+00	537	AEROPRESS50 (0)	2	[]	8	1
7	2017-07-28 08:48:12.905946+00	14	[14] Active | Jul, 23 (20:15) | Aug, 24 (12:00) | [SG] Developer X <dev@hookcoffee.com.sg> | Appley Ever After  from La Paz , Honduras	2	[{"changed": {"fields": ["shipping_date"]}}]	14	1
8	2017-07-28 09:04:03.239503+00	15	[15] Active | Jul, 28 (17:03) | Aug, 31 (12:00) | [SG] Developer X <dev@hookcoffee.com.sg> | Peach, Please! Cold Brew from Sidama, Guji, Ethiopia	2	[{"changed": {"fields": ["shipping_date"]}}]	14	1
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 8, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	sites	site
7	registration	registrationprofile
8	customers	voucher
9	customers	customer
10	customers	charge
11	customers	plan
12	customers	subscription
13	customers	preferences
14	customers	order
15	customauth	myuser
16	coffees	brewmethod
17	coffees	flavor
18	coffees	coffeetype
20	get_started	getstartedresponse
21	content	section
22	content	post
24	customers	referral
25	customers	reference
27	content	review
28	content	career
30	get_started	giftvoucher
31	customers	gearorder
32	coffees	coffeegear
33	wholesale	plan
34	get_started	podsearlybird
35	get_started	referralvoucher
36	loyale	setpoint
37	loyale	coffeetypepoints
38	loyale	point
39	loyale	item
40	loyale	redemitem
41	loyale	redempointlog
42	loyale	grantpointlog
43	loyale	orderpoints
44	loyale	helper
45	coffees	coffeesticker
46	coffees	sharedcoffeesticker
47	customers	vouchercategory
48	customers	facebookcustomer
49	customauth	login
50	djcelery	taskmeta
51	djcelery	tasksetmeta
52	djcelery	intervalschedule
53	djcelery	crontabschedule
54	djcelery	periodictasks
55	djcelery	periodictask
56	djcelery	workerstate
57	djcelery	taskstate
58	kombu_transport_django	queue
59	kombu_transport_django	message
61	manager	fyporderstats
62	reminders	reminder
63	coffees	rawbean
64	manager	mailchimpcampaignstats
65	manager	churnratedata
66	manager	rawbeanstats
67	manager	intercomlocal
68	coffees	coffeegearcolor
69	coffees	coffeegearimage
70	content	brewguide
71	content	brewguidestep
72	manager	threshold
73	manager	reportcard
74	manager	recommendation
75	manager	clusterdf
76	manager	customercluster
77	manager	rightssupport
78	content	greeting
79	customers	address
80	customers	coffeereview
81	coffees	farmphotos
82	content	instagrampost
83	blog	category
84	blog	tag
85	blog	post
86	customers	shoppingcart
87	customers	postcard
89	content	topbar
90	customers	cardfingerprint
94	registration	supervisedregistrationprofile
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('django_content_type_id_seq', 94, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	customauth	0001_initial	2016-01-02 20:23:27.798172+00
2	contenttypes	0001_initial	2016-01-02 20:23:27.825526+00
3	admin	0001_initial	2016-01-02 20:23:27.862645+00
4	contenttypes	0002_remove_content_type_name	2016-01-02 20:23:27.894774+00
5	auth	0001_initial	2016-01-02 20:23:27.971167+00
6	auth	0002_alter_permission_name_max_length	2016-01-02 20:23:27.989363+00
7	auth	0003_alter_user_email_max_length	2016-01-02 20:23:28.027005+00
8	auth	0004_alter_user_username_opts	2016-01-02 20:23:28.06383+00
9	auth	0005_alter_user_last_login_null	2016-01-02 20:23:28.101245+00
10	auth	0006_require_contenttypes_0002	2016-01-02 20:23:28.10553+00
11	coffees	0001_initial	2016-01-02 20:23:28.311657+00
12	content	0001_initial	2016-01-02 20:23:28.446295+00
13	content	0002_auto_20151231_0436	2016-01-02 20:23:28.492033+00
14	customers	0001_initial	2016-01-02 20:23:29.428884+00
15	get_started	0001_initial	2016-01-02 20:23:29.525435+00
16	registration	0001_initial	2016-01-02 20:23:29.601708+00
17	sessions	0001_initial	2016-01-02 20:23:29.679137+00
18	sites	0001_initial	2016-01-02 20:23:29.751666+00
19	get_started	0002_emails24	2016-01-14 09:19:39.847569+00
20	customers	0002_auto_20160118_0333	2016-01-17 19:34:01.596246+00
21	customers	0003_customer_card_details	2016-01-18 22:38:14.101199+00
22	get_started	0003_emails7	2016-01-21 17:33:06.039945+00
23	content	0003_review	2016-01-29 12:39:31.831878+00
24	customers	0004_auto_20160204_0743	2016-02-03 23:44:19.108627+00
25	customers	0005_customer_phone	2016-02-11 12:59:47.45995+00
26	customers	0006_order_details	2016-02-22 01:58:43.899992+00
27	content	0004_career	2016-02-27 23:11:31.30616+00
28	coffees	0002_coffeetype_mode	2016-03-05 19:03:33.437045+00
29	customers	0007_auto_20160321_0122	2016-03-20 17:23:30.82385+00
30	customers	0008_customer_amount	2016-03-25 07:54:38.767148+00
31	get_started	0004_giftvoucher	2016-03-25 07:54:38.858181+00
32	coffees	0003_coffeetype_special	2016-04-01 13:51:40.886366+00
33	coffees	0004_auto_20160403_2048	2016-04-03 12:48:48.291784+00
34	coffees	0005_coffeegear	2016-04-16 19:04:31.434251+00
35	customers	0009_auto_20160417_0304	2016-04-16 19:04:31.753419+00
36	get_started	0005_auto_20160417_0304	2016-04-16 19:04:32.08399+00
37	customers	0010_voucher_mode	2016-04-20 06:22:02.469368+00
38	get_started	0006_podsearlybird	2016-04-29 10:44:34.655096+00
39	get_started	0007_referralvoucher	2016-05-04 09:22:25.142545+00
40	loyale	0001_initial	2016-05-10 16:49:10.311375+00
41	customers	0011_auto_20160530_0208	2016-05-29 18:09:46.146784+00
42	loyale	0002_auto_20160530_0208	2016-05-29 18:09:46.339448+00
43	loyale	0003_helper	2016-06-01 16:56:18.870803+00
44	coffees	0006_coffeesticker	2016-07-27 12:13:36.452537+00
45	coffees	0007_sharedcoffeesticker	2016-07-31 19:45:07.752487+00
46	customers	0012_auto_20160802_1628	2016-08-02 08:29:20.648701+00
47	customers	0013_facebookcustomer	2016-08-08 17:16:17.010149+00
48	customauth	0002_login	2016-08-08 17:16:24.206614+00
49	djcelery	0001_initial	2016-08-08 17:16:34.783862+00
50	kombu_transport_django	0001_initial	2016-08-08 17:16:45.24341+00
51	coffees	0008_auto_20160814_0003	2016-08-13 16:04:20.709948+00
52	get_started	0008_emails48	2016-08-26 09:14:53.655217+00
53	coffees	0009_coffeetype_intensity	2016-08-28 16:26:55.057348+00
54	customers	0014_auto_20160829_0110	2016-08-28 17:10:58.668147+00
55	manager	0001_initial	2016-08-28 17:10:58.748122+00
56	coffees	0010_coffeetype_decaf	2016-09-07 17:09:33.983261+00
57	reminders	0001_initial	2016-09-20 10:19:00.508738+00
58	reminders	0002_data_migration	2016-09-20 10:20:58.10393+00
59	coffees	0011_rawbean	2016-09-20 19:17:08.020532+00
60	customauth	0003_myuser_account_creation_date	2016-09-20 19:17:08.172597+00
61	customers	0015_order_resent	2016-09-20 19:17:08.36539+00
62	manager	0002_churnratedata_mailchimpcampaignstats_rawbeanstats	2016-09-20 19:17:08.585094+00
63	coffees	0012_rawbean_created_date	2016-10-04 17:38:49.157235+00
64	manager	0003_auto_20161005_0138	2016-10-04 17:38:49.716698+00
65	coffees	0013_auto_20161019_2314	2016-10-19 15:16:15.660121+00
66	content	0005_auto_20161019_2314	2016-10-19 15:16:25.613136+00
67	wholesale	0001_initial	2016-10-19 15:29:53.480293+00
68	wholesale	0002_auto_20161019_2330	2016-10-19 15:30:25.006814+00
69	customers	0016_gearorder_tracking_number	2016-10-19 15:36:18.924903+00
70	content	0006_brewguide_brewguidestep	2016-10-23 10:02:15.693986+00
71	content	0007_brewguide_slug	2016-11-05 20:13:30.862448+00
72	customers	0017_customer_received_coffee_samples	2016-11-07 09:21:37.847239+00
73	content	0008_auto_20161111_0413	2016-11-10 20:13:50.486376+00
74	coffees	0014_auto_20161114_2053	2016-11-14 12:54:13.96819+00
75	coffees	0015_coffeegear_allow_choice_package	2016-11-20 15:57:35.922275+00
76	customers	0018_auto_20161120_2357	2016-11-20 15:57:45.604987+00
77	customauth	0004_auto_20161122_0108	2016-11-21 17:10:01.062592+00
78	customers	0019_order_custom_price	2016-11-21 17:10:01.578278+00
79	manager	0004_clusterdf_customercluster_recommendation_reportcard_rightssupport_threshold	2016-11-21 17:10:02.375053+00
80	reminders	0003_auto_20161122_0108	2016-11-21 17:10:02.585278+00
81	coffees	0016_auto_20161128_0558	2016-11-27 22:00:35.177884+00
82	customers	0020_auto_20161128_0558	2016-11-27 22:00:35.581373+00
83	loyale	0004_item_in_stock	2016-12-13 15:15:45.724909+00
84	coffees	0017_coffeegear_available	2017-01-02 09:04:02.65584+00
85	content	0009_greeting	2017-01-10 17:49:09.266481+00
86	reminders	0004_auto_20170111_0148	2017-01-10 17:49:09.456737+00
87	customers	0021_customer_extra	2017-01-15 11:18:42.249744+00
88	coffees	0018_auto_20170312_0258	2017-03-11 18:58:21.007284+00
89	content	0010_instagrampost	2017-03-11 18:58:21.05696+00
90	customers	0022_auto_20170312_0258	2017-03-11 18:58:23.155048+00
91	loyale	0005_auto_20170312_0258	2017-03-11 18:58:23.252061+00
92	content	0011_auto_20170314_2103	2017-03-14 13:03:43.165214+00
93	customers	0023_auto_20170402_1918	2017-04-02 11:18:30.140622+00
94	customauth	0005_myuser_created_at	2017-04-08 19:54:15.856639+00
95	customauth	0006_myuser_fill_created_at	2017-04-08 19:54:30.873354+00
96	customers	0024_auto_20170412_1944	2017-04-18 20:22:47.45565+00
97	customers	0025_auto_20170419_0421	2017-04-18 20:22:47.665629+00
98	reminders	0005_reminder_voucher	2017-04-18 20:22:47.953077+00
99	get_started	0009_getstartedresponse_sent_emails	2017-04-21 14:13:26.25643+00
100	customers	0026_auto_20170428_1403	2017-04-28 06:04:49.335161+00
101	coffees	0019_coffeetype_blend	2017-04-28 08:44:33.362447+00
102	customers	0027_auto_20170508_2340	2017-05-08 15:41:05.901254+00
103	loyale	0006_auto_20170510_2225	2017-05-10 14:25:48.753838+00
104	customers	0028_vouchercategory_desc	2017-05-11 21:36:07.713508+00
105	coffees	0020_coffeetype_discovery	2017-05-12 16:41:48.049578+00
106	coffees	0021_auto_20170513_0051	2017-05-12 16:51:44.110468+00
107	customers	0029_postcard	2017-05-13 07:10:04.748585+00
108	customauth	0007_remove_myuser_account_creation_date	2017-05-17 19:24:18.453149+00
109	customers	0030_auto_20170520_1535	2017-05-20 07:35:53.681854+00
110	coffees	0022_auto_20170524_1617	2017-05-24 08:17:23.1539+00
111	reminders	0006_reminder_recommended_coffee	2017-05-25 06:27:02.964703+00
112	coffees	0023_auto_20170602_1847	2017-06-02 10:47:17.378007+00
113	coffees	0024_coffeetype_unavailable	2017-06-06 06:42:17.886314+00
114	content	0012_topbar	2017-06-08 20:26:06.744347+00
115	customers	0031_auto_20170609_0425	2017-06-08 20:26:07.390844+00
116	get_started	0010_auto_20170609_0425	2017-06-08 20:26:07.753082+00
117	customers	0032_cardfingerprint	2017-06-12 20:50:32.964764+00
118	content	0013_auto_20170628_2215	2017-06-28 14:17:38.585807+00
119	wholesale	0003_plan_office_type	2017-06-28 14:20:07.377341+00
120	customers	0033_auto_20170629_0225	2017-06-28 18:25:56.42519+00
121	wholesale	0004_auto_20170630_2244	2017-06-30 14:49:01.819812+00
122	coffees	0025_auto_20170705_0256	2017-07-04 18:57:19.440272+00
123	customers	0034_auto_20170705_0256	2017-07-04 18:57:19.893917+00
124	customers	0035_customer_discounts	2017-07-15 21:09:18.799487+00
125	admin	0002_logentry_remove_auto_add	2017-08-01 19:27:57.266518+00
126	auth	0007_alter_validators_add_error_messages	2017-08-01 19:27:57.384903+00
127	auth	0008_alter_user_username_max_length	2017-08-01 19:27:57.652917+00
128	customers	0036_auto_20170801_2032	2017-08-01 19:27:57.786083+00
129	get_started	0011_auto_20170801_2032	2017-08-01 19:27:57.827561+00
130	registration	0002_registrationprofile_activated	2017-08-01 19:27:57.962884+00
131	registration	0003_migrate_activatedstatus	2017-08-01 19:27:57.97967+00
132	registration	0004_supervisedregistrationprofile	2017-08-01 19:27:58.118761+00
133	sites	0002_alter_domain_unique	2017-08-01 19:27:58.149517+00
\.


--
-- Data for Name: django_migrations_copy1; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY django_migrations_copy1 (id, app, name, applied) FROM stdin;
1	customauth	0001_initial	2016-01-02 20:23:27.798172+00
2	contenttypes	0001_initial	2016-01-02 20:23:27.825526+00
3	admin	0001_initial	2016-01-02 20:23:27.862645+00
4	contenttypes	0002_remove_content_type_name	2016-01-02 20:23:27.894774+00
5	auth	0001_initial	2016-01-02 20:23:27.971167+00
6	auth	0002_alter_permission_name_max_length	2016-01-02 20:23:27.989363+00
7	auth	0003_alter_user_email_max_length	2016-01-02 20:23:28.027005+00
8	auth	0004_alter_user_username_opts	2016-01-02 20:23:28.06383+00
9	auth	0005_alter_user_last_login_null	2016-01-02 20:23:28.101245+00
10	auth	0006_require_contenttypes_0002	2016-01-02 20:23:28.10553+00
11	coffees	0001_initial	2016-01-02 20:23:28.311657+00
12	content	0001_initial	2016-01-02 20:23:28.446295+00
13	content	0002_auto_20151231_0436	2016-01-02 20:23:28.492033+00
14	customers	0001_initial	2016-01-02 20:23:29.428884+00
15	get_started	0001_initial	2016-01-02 20:23:29.525435+00
16	registration	0001_initial	2016-01-02 20:23:29.601708+00
17	sessions	0001_initial	2016-01-02 20:23:29.679137+00
18	sites	0001_initial	2016-01-02 20:23:29.751666+00
19	get_started	0002_emails24	2016-01-14 09:19:39.847569+00
20	customers	0002_auto_20160118_0333	2016-01-17 19:34:01.596246+00
21	customers	0003_customer_card_details	2016-01-18 22:38:14.101199+00
22	get_started	0003_emails7	2016-01-21 17:33:06.039945+00
23	content	0003_review	2016-01-29 12:39:31.831878+00
24	customers	0004_auto_20160204_0743	2016-02-03 23:44:19.108627+00
25	customers	0005_customer_phone	2016-02-11 12:59:47.45995+00
26	customers	0006_order_details	2016-02-22 01:58:43.899992+00
27	content	0004_career	2016-02-27 23:11:31.30616+00
28	coffees	0002_coffeetype_mode	2016-03-05 19:03:33.437045+00
29	customers	0007_auto_20160321_0122	2016-03-20 17:23:30.82385+00
30	customers	0008_customer_amount	2016-03-25 07:54:38.767148+00
31	get_started	0004_giftvoucher	2016-03-25 07:54:38.858181+00
32	coffees	0003_coffeetype_special	2016-04-01 13:51:40.886366+00
33	coffees	0004_auto_20160403_2048	2016-04-03 12:48:48.291784+00
34	coffees	0005_coffeegear	2016-04-16 19:04:31.434251+00
35	customers	0009_auto_20160417_0304	2016-04-16 19:04:31.753419+00
36	get_started	0005_auto_20160417_0304	2016-04-16 19:04:32.08399+00
37	customers	0010_voucher_mode	2016-04-20 06:22:02.469368+00
38	get_started	0006_podsearlybird	2016-04-29 10:44:34.655096+00
39	get_started	0007_referralvoucher	2016-05-04 09:22:25.142545+00
40	loyale	0001_initial	2016-05-10 16:49:10.311375+00
41	customers	0011_auto_20160530_0208	2016-05-29 18:09:46.146784+00
42	loyale	0002_auto_20160530_0208	2016-05-29 18:09:46.339448+00
43	loyale	0003_helper	2016-06-01 16:56:18.870803+00
44	coffees	0006_coffeesticker	2016-07-27 12:13:36.452537+00
45	coffees	0007_sharedcoffeesticker	2016-07-31 19:45:07.752487+00
46	customers	0012_auto_20160802_1628	2016-08-02 08:29:20.648701+00
47	customers	0013_facebookcustomer	2016-08-08 17:16:17.010149+00
48	customauth	0002_login	2016-08-08 17:16:24.206614+00
49	djcelery	0001_initial	2016-08-08 17:16:34.783862+00
50	kombu_transport_django	0001_initial	2016-08-08 17:16:45.24341+00
51	coffees	0008_auto_20160814_0003	2016-08-13 16:04:20.709948+00
52	get_started	0008_emails48	2016-08-26 09:14:53.655217+00
53	coffees	0009_coffeetype_intensity	2016-08-28 16:26:55.057348+00
54	customers	0014_auto_20160829_0110	2016-08-28 17:10:58.668147+00
55	manager	0001_initial	2016-08-28 17:10:58.748122+00
56	coffees	0010_coffeetype_decaf	2016-09-07 17:09:33.983261+00
57	reminders	0001_initial	2016-09-20 10:19:00.508738+00
58	reminders	0002_data_migration	2016-09-20 10:20:58.10393+00
59	coffees	0011_rawbean	2016-09-20 19:17:08.020532+00
60	customauth	0003_myuser_account_creation_date	2016-09-20 19:17:08.172597+00
61	customers	0015_order_resent	2016-09-20 19:17:08.36539+00
62	manager	0002_churnratedata_mailchimpcampaignstats_rawbeanstats	2016-09-20 19:17:08.585094+00
63	coffees	0012_rawbean_created_date	2016-10-04 17:38:49.157235+00
64	manager	0003_auto_20161005_0138	2016-10-04 17:38:49.716698+00
65	coffees	0013_auto_20161019_2314	2016-10-19 15:16:15.660121+00
66	content	0005_auto_20161019_2314	2016-10-19 15:16:25.613136+00
67	wholesale	0001_initial	2016-10-19 15:29:53.480293+00
68	wholesale	0002_auto_20161019_2330	2016-10-19 15:30:25.006814+00
69	customers	0016_gearorder_tracking_number	2016-10-19 15:36:18.924903+00
70	content	0006_brewguide_brewguidestep	2016-10-23 10:02:15.693986+00
71	content	0007_brewguide_slug	2016-11-05 20:13:30.862448+00
72	customers	0017_customer_received_coffee_samples	2016-11-07 09:21:37.847239+00
73	content	0008_auto_20161111_0413	2016-11-10 20:13:50.486376+00
74	coffees	0014_auto_20161114_2053	2016-11-14 12:54:13.96819+00
75	coffees	0015_coffeegear_allow_choice_package	2016-11-20 15:57:35.922275+00
76	customers	0018_auto_20161120_2357	2016-11-20 15:57:45.604987+00
77	customauth	0004_auto_20161122_0108	2016-11-21 17:10:01.062592+00
78	customers	0019_order_custom_price	2016-11-21 17:10:01.578278+00
79	manager	0004_clusterdf_customercluster_recommendation_reportcard_rightssupport_threshold	2016-11-21 17:10:02.375053+00
80	reminders	0003_auto_20161122_0108	2016-11-21 17:10:02.585278+00
81	coffees	0016_auto_20161128_0558	2016-11-27 22:00:35.177884+00
82	customers	0020_auto_20161128_0558	2016-11-27 22:00:35.581373+00
83	loyale	0004_item_in_stock	2016-12-13 15:15:45.724909+00
84	coffees	0017_coffeegear_available	2017-01-02 09:04:02.65584+00
85	content	0009_greeting	2017-01-10 17:49:09.266481+00
86	reminders	0004_auto_20170111_0148	2017-01-10 17:49:09.456737+00
87	customers	0021_customer_extra	2017-01-15 11:18:42.249744+00
88	coffees	0018_auto_20170312_0258	2017-03-11 18:58:21.007284+00
89	content	0010_instagrampost	2017-03-11 18:58:21.05696+00
90	customers	0022_auto_20170312_0258	2017-03-11 18:58:23.155048+00
91	loyale	0005_auto_20170312_0258	2017-03-11 18:58:23.252061+00
92	content	0011_auto_20170314_2103	2017-03-14 13:03:43.165214+00
93	customers	0023_auto_20170402_1918	2017-04-02 11:18:30.140622+00
94	customauth	0005_myuser_created_at	2017-04-08 19:54:15.856639+00
95	customauth	0006_myuser_fill_created_at	2017-04-08 19:54:30.873354+00
96	customers	0024_auto_20170412_1944	2017-04-18 20:22:47.45565+00
97	customers	0025_auto_20170419_0421	2017-04-18 20:22:47.665629+00
98	reminders	0005_reminder_voucher	2017-04-18 20:22:47.953077+00
99	get_started	0009_getstartedresponse_sent_emails	2017-04-21 14:13:26.25643+00
100	customers	0026_auto_20170428_1403	2017-04-28 06:04:49.335161+00
101	coffees	0019_coffeetype_blend	2017-04-28 08:44:33.362447+00
102	customers	0027_auto_20170508_2340	2017-05-08 15:41:05.901254+00
103	loyale	0006_auto_20170510_2225	2017-05-10 14:25:48.753838+00
104	customers	0028_vouchercategory_desc	2017-05-11 21:36:07.713508+00
105	coffees	0020_coffeetype_discovery	2017-05-12 16:41:48.049578+00
106	coffees	0021_auto_20170513_0051	2017-05-12 16:51:44.110468+00
107	customers	0029_postcard	2017-05-13 07:10:04.748585+00
108	customauth	0007_remove_myuser_account_creation_date	2017-05-17 19:24:18.453149+00
109	customers	0030_auto_20170520_1535	2017-05-20 07:35:53.681854+00
110	coffees	0022_auto_20170524_1617	2017-05-24 08:17:23.1539+00
111	reminders	0006_reminder_recommended_coffee	2017-05-25 06:27:02.964703+00
112	coffees	0023_auto_20170602_1847	2017-06-02 10:47:17.378007+00
113	coffees	0024_coffeetype_unavailable	2017-06-06 06:42:17.886314+00
114	content	0012_topbar	2017-06-08 20:26:06.744347+00
115	customers	0031_auto_20170609_0425	2017-06-08 20:26:07.390844+00
116	get_started	0010_auto_20170609_0425	2017-06-08 20:26:07.753082+00
117	customers	0032_cardfingerprint	2017-06-12 20:50:32.964764+00
118	content	0013_auto_20170628_2215	2017-06-28 14:17:38.585807+00
119	wholesale	0003_plan_office_type	2017-06-28 14:20:07.377341+00
120	customers	0033_auto_20170629_0225	2017-06-28 18:25:56.42519+00
121	wholesale	0004_auto_20170630_2244	2017-06-30 14:49:01.819812+00
122	coffees	0025_auto_20170705_0256	2017-07-04 18:57:19.440272+00
123	customers	0034_auto_20170705_0256	2017-07-04 18:57:19.893917+00
124	customers	0035_customer_discounts	2017-07-15 21:09:18.799487+00
125	admin	0002_logentry_remove_auto_add	2017-07-20 14:41:42.235843+00
126	auth	0007_alter_validators_add_error_messages	2017-07-20 14:41:42.374688+00
127	auth	0008_alter_user_username_max_length	2017-07-20 14:41:42.525062+00
130	registration	0002_registrationprofile_activated	2017-07-20 15:06:25.691067+00
131	registration	0003_migrate_activatedstatus	2017-07-20 15:06:25.7198+00
132	registration	0004_supervisedregistrationprofile	2017-07-20 15:06:25.742983+00
133	sites	0002_alter_domain_unique	2017-07-20 15:07:49.449611+00
128	customers	0036_auto_20170801_2032	2017-08-01 19:27:57.786083+00
129	get_started	0011_auto_20170801_2032	2017-08-01 19:27:57.827561+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('django_migrations_id_seq', 133, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
yoa0szdscd4z7nkvbnvukluf5xl6iwhi	NzBlMDFlOWEwYzVhZjZiMDE5MWVkZjY4NjhlNDEyNDBlOTRkOWViZDp7Imxhc3RfbmFtZSI6ImRhc3NhZCIsImRlZmF1bHRfcGFjayI6IldCIiwibGFzdDQiOiI0MjQyIiwicG9zdGNvZGUiOiIyNDIzNDQzMiIsIl9zZXNzaW9uX2V4cGlyeSI6MCwiZmlyc3RfbmFtZSI6ImRzZGFzYSIsImV4cF95ZWFyIjoyMDIwLCJicmV3X3RpdGxlIjoiQWVyb3ByZXNzIiwiX2F1dGhfdXNlcl9pZCI6IjYiLCJsaW5lMiI6ImVxdyBxd2V3cWVxIGUiLCJsaW5lMSI6InNhZHNhIGRhc3Nkc2FhcyAjMjMiLCJ1c2VyX2luZm8iOiJ7XCJicmV3X3RpdGxlXCI6XCJBZXJvcHJlc3NcIixcImRlZmF1bHRfcGFja1wiOlwiV0JcIixcIm1ldGhvZFwiOjMsXCJmbGF2b3VyXCI6WzNdLFwiaW50ZW5zaXR5XCI6MyxcIm5hbWVcIjpcImhuYmd2ZmNkc1wiLFwiZW1haWxcIjpcImNvbnN0dmVydW0rdGVzdDEyQGdtYWlsLmNvbVwifSIsImlzX3dvcmxkd2lkZSI6ZmFsc2UsIl9hdXRoX3VzZXJfaGFzaCI6IjU4NjU5YTRlMWI5Y2E4ODBmNDZiYTQyZjUyNjJkMzg1M2NmNjRjNzUiLCJzdHJpcGVfaWQiOiJjdXNfQjF4VnZVSjF1NGEyWEIiLCJlbWFpbCI6ImNvbnN0dmVydW0rdGVzdDEyQGdtYWlsLmNvbSIsImNvZmZlZSI6MTQsImV4cF9tb250aCI6MTIsImRpZmZlcmVudCI6dHJ1ZSwicGhvbmUiOiIiLCJwYXNzd29yZCI6IjAiLCJmcm9tX2dldF9zdGFydGVkIjp0cnVlLCJuYW1lIjoiaG5iZ3ZmY2RzIiwicGFja2FnZSI6IldCIiwiY291bnRyeSI6IlNHIiwiaW50ZXJ2YWwiOjE0LCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsImZyb21fc2hvcHBpbmdfY2FydCI6ZmFsc2UsImJyZXciOjMsInZvdWNoZXIiOiIifQ==	2017-07-29 16:57:43.032006+00
ces0btp5m52mltdb0fmpi0carbakv7xw	ZGY4M2E3YzQ4ODUyMGNhYTM3MmM3ZWQwZjM2Njk0NzJmMGM5MTI0MTp7ImlzX3dvcmxkd2lkZSI6ZmFsc2UsIl9zZXNzaW9uX2V4cGlyeSI6MH0=	2017-08-02 20:38:26.529661+00
zibg2b1oub6r0orokajuorchzxw2pstn	OWY1NWE4MTE3YmI4YjQyZTE4MzY5NmMzZTY0MGZhYjYxMTFkODNkZDp7Imxhc3RfbmFtZSI6ImRzYXNmZCIsInJlZmVycmFsX3ZvdWNoZXIiOm51bGwsImRlZmF1bHRfcGFjayI6IldCIiwiYWxhY2FydGUiOmZhbHNlLCJzaG9wcGluZy1jYXJ0IjpbXSwiY29mZmVlX2Nvc3QiOjQ1LjAsInBvc3Rjb2RlIjoiNDIzMzI0MzIiLCJfc2Vzc2lvbl9leHBpcnkiOjAsInNoaXBwaW5nX2Nvc3QiOjAsImFjdGl2ZV90YWIiOiJhY3RpdmVfb25lX29mZnMiLCJmcm9tX3ByZXJlZ2lzdGVyIjpmYWxzZSwiZmlyc3RfbmFtZSI6ImRhc3NhIiwiYnJld190aXRsZSI6IkRyaXAiLCJfYXV0aF91c2VyX2lkIjoiNyIsImNhcnRfcXVhbnRpdHkiOjEsImxpbmUyIjoiZmRzcyIsImxpbmUxIjoiZmRzZHMiLCJuYW1lIjoiRHNhZmRzIGZzZCIsInVzZXJfaW5mbyI6IntcImJyZXdfdGl0bGVcIjpcIkRyaXBcIixcImRlZmF1bHRfcGFja1wiOlwiV0JcIixcIm1ldGhvZFwiOjIsXCJmbGF2b3VyXCI6WzJdLFwiaW50ZW5zaXR5XCI6MyxcIm5hbWVcIjpcIkRzYWZkcyBmc2RcIixcImVtYWlsXCI6XCJjb25zdHZlcnVtK2Rhc2RhQGdtYWlsLmNvbVwifSIsImlzX3dvcmxkd2lkZSI6ZmFsc2UsIl9hdXRoX3VzZXJfaGFzaCI6IjE1NzcxYjdmZDBmNTQxZTQ5ODFkZmE5MWU4N2Q3NThjNDIxMTdlNmUiLCJlbWFpbCI6ImNvbnN0dmVydW0rZGFzZGFAZ21haWwuY29tIiwiZnJpZW5kIjoiZGFzYXMiLCJjb2ZmZWUiOiI0MCIsImRpZmZlcmVudCI6dHJ1ZSwicGhvbmUiOiIiLCJwYXNzd29yZCI6IjAiLCJmcm9tX2dldF9zdGFydGVkIjpmYWxzZSwiaXNCb3R0bGVkIjoiIiwicGFja2FnZSI6IldCIiwiY291bnRyeSI6IlNHIiwiaW50ZXJ2YWwiOjE0LCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsImZyb21fc2hvcHBpbmdfY2FydCI6dHJ1ZSwiYnJldyI6MiwiY3JlZGl0cyI6ODQsInZvdWNoZXIiOiIifQ==	2017-08-14 18:27:38.657856+00
kmgghuyvvb7pf2wk190v7eja76sm2qm0	MWUwMzA2M2I0ZTFkM2IxZjZjMzIxZDg1YTM3YjdiM2U4NGJjZDRkMTp7IkFFUk9QUkVTUzUwIjp0cnVlLCJzaG9wcGluZy1jYXJ0IjpbeyJjb2ZmZWUiOnsibmFtZSI6IkFwcGxleSBFdmVyIEFmdGVyICIsInBhY2thZ2UiOiJXQiIsInByaWNlIjoiMTguMDAiLCJicmV3IjoiQWVyb3ByZXNzIiwiYnJld19pZCI6MywiaWQiOjQwfSwicXVhbnRpdHkiOjF9XSwicmVmZXJyYWxfdm91Y2hlciI6bnVsbCwiaXNCb3R0bGVkIjoiIiwiX2F1dGhfdXNlcl9pZCI6IjEiLCJzdHJpcGVfYW1vdW50IjoxODAwLCJzaGlwcGluZ19jb3N0IjowLCJjYXJ0X3F1YW50aXR5IjoxLCJjb2ZmZWUiOiIzMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiY29mZmVlX2Nvc3QiOjE4LjAsImFjdGl2ZV90YWIiOiJhY3RpdmVfc3Vic2NyaXB0aW9uc19ib3R0bGVkIiwidm91Y2hlciI6IkFFUk9QUkVTUzUwIiwiZnJvbV9zaG9wcGluZ19jYXJ0IjpmYWxzZSwiYWxhY2FydGUiOmZhbHNlLCJpc193b3JsZHdpZGUiOmZhbHNlLCJfYXV0aF91c2VyX2hhc2giOiJlMDczZDNjYzRjM2NkYjAzMzY3Njg5MWVmN2E5YzM0OWJhYTkxM2JiIiwiZnJvbV9wcmVyZWdpc3RlciI6dHJ1ZSwiZnJvbV9nZXRfc3RhcnRlZCI6ZmFsc2V9	2017-08-14 18:43:17.131122+00
enudrz74kebarnwe9rgcz14cuazpeayk	OGM2NTg4YjA0YTY1NjNkNTFkZDYyNDlmMWQyNTQyN2IzNzE1ZWZjZjp7ImlzX3dvcmxkd2lkZSI6ZmFsc2V9	2017-08-15 15:14:07.642804+00
6les15jgu4zfajwnukby58q3g3vufx0d	OTM5Zjc5NTgxNzAyZWQzOTBjM2Y5ZjdmMmNiOTg5ZDJkNTBmMmUzZTp7ImNvZmZlZSI6NDIsIm5hbWUiOiJuaGJnZnZkY3N4IiwiZGVmYXVsdF9wYWNrIjoiV0IiLCJ1c2VyX2luZm8iOiJ7XCJicmV3X3RpdGxlXCI6XCJDb2xkIEJyZXdcIixcImRlZmF1bHRfcGFja1wiOlwiV0JcIixcIm1ldGhvZFwiOjgsXCJmbGF2b3VyXCI6WzYsNl0sXCJpbnRlbnNpdHlcIjozLFwibmFtZVwiOlwibmhiZ2Z2ZGNzeFwiLFwiZW1haWxcIjpcImNvbnN0dmVydW0rdGVzdDFAZ21haWwuY29tXCJ9IiwiX3Nlc3Npb25fZXhwaXJ5IjowLCJpc193b3JsZHdpZGUiOmZhbHNlLCJmcm9tX2dldF9zdGFydGVkIjp0cnVlLCJmcm9tX3Nob3BwaW5nX2NhcnQiOmZhbHNlLCJlbWFpbCI6ImNvbnN0dmVydW0rdGVzdDFAZ21haWwuY29tIiwiYnJld190aXRsZSI6IkNvbGQgQnJldyJ9	2017-07-27 21:55:42.104981+00
w0gnerj4jdbktrqhrr7gvu8tokwycyfb	ZDU1OTkxZjAwZjczMGI3MzdjZDI3OWM3ZTUzNzliNGNiNDRlNjM1YTp7Imxhc3RfbmFtZSI6ImZkc2RzZiIsImNvZmZlZV9jb3N0IjoxOC4wLCJsYXN0NCI6IjQyNDIiLCJwb3N0Y29kZSI6IjIzMjQzMjQzMiIsInNoaXBwaW5nX2Nvc3QiOjAsImFjdGl2ZV90YWIiOiJhY3RpdmVfb25lX29mZnMiLCJmcm9tX3ByZXJlZ2lzdGVyIjpmYWxzZSwiZmlyc3RfbmFtZSI6ImZkc2YiLCJleHBfeWVhciI6MjAyMCwiX2F1dGhfdXNlcl9pZCI6IjEwIiwic3RyaXBlX2Ftb3VudCI6MTgwMCwiY2FydF9xdWFudGl0eSI6MSwibGluZTIiOiJmc2Rkc2ZzZCIsImxpbmUxIjoiZmRzZHMiLCJpc193b3JsZHdpZGUiOmZhbHNlLCJfYXV0aF91c2VyX2hhc2giOiI5NGJmMTRlNTc1NGU4OTY0NDcwYzBlNGM2NjQ1MjRiMTE5YmUzNWI1Iiwic3RyaXBlX2lkIjoiY3VzX0I4SWpYODJ3VjZPVDlIIiwiZW1haWwiOiJjb25zdHZlcnVtK2RzZmRzZnNkZmRzQGdtYWlsLmNvbSIsInNob3BwaW5nLWNhcnQiOltdLCJleHBfbW9udGgiOjEyLCJwaG9uZSI6IiIsInBhc3N3b3JkIjoiMCIsImZyb21fZ2V0X3N0YXJ0ZWQiOmZhbHNlLCJjb3VudHJ5IjoiU0ciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsImZyb21fc2hvcHBpbmdfY2FydCI6dHJ1ZX0=	2017-08-15 15:17:45.604109+00
gp0zm6j25ydeb1vtjvc9pxjsj2lnh3mc	Y2MzNGVlNzUxNDQ4NDc4ZDRiMzdiMTUyMTdiMTkzODE4YjIzOGM4Nzp7Imxhc3RfbmFtZSI6IkRTQURTIiwicmVmZXJyYWxfdm91Y2hlciI6bnVsbCwiZGVmYXVsdF9wYWNrIjoiV0IiLCJhbGFjYXJ0ZSI6ZmFsc2UsInNob3BwaW5nLWNhcnQiOlt7ImNvZmZlZSI6eyJuYW1lIjoiQXBwbGV5IEV2ZXIgQWZ0ZXIgIiwicGFja2FnZSI6IkdSIiwicHJpY2UiOiIxOC4wMCIsImJyZXciOiJBZXJvcHJlc3MiLCJicmV3X2lkIjozLCJpZCI6NDB9LCJxdWFudGl0eSI6MX1dLCJjb2ZmZWVfY29zdCI6MTguMCwibGFzdDQiOiI0MjQyIiwicG9zdGNvZGUiOiI3NjU0MzIiLCJfc2Vzc2lvbl9leHBpcnkiOjAsInNoaXBwaW5nX2Nvc3QiOjAsImFjdGl2ZV90YWIiOiJhY3RpdmVfc3Vic2NyaXB0aW9ucyIsImZyb21fcHJlcmVnaXN0ZXIiOnRydWUsImZpcnN0X25hbWUiOiJkc2FhZERBUyIsInBhc3N3b3JkIjoiMCIsImJyZXdfdGl0bGUiOiJDb2xkIEJyZXciLCJfYXV0aF91c2VyX2lkIjoiNSIsImNhcnRfcXVhbnRpdHkiOjEsImxpbmUyIjoiMjM0IiwibGluZTEiOiJkYXNzYSIsInVzZXJfaW5mbyI6IntcImJyZXdfdGl0bGVcIjpcIkNvbGQgQnJld1wiLFwiZGVmYXVsdF9wYWNrXCI6XCJXQlwiLFwibWV0aG9kXCI6OCxcImZsYXZvdXJcIjpbNl0sXCJpbnRlbnNpdHlcIjozLFwibmFtZVwiOlwiZHNhZGFzXCIsXCJlbWFpbFwiOlwiY29uc3R2ZXJ1bSt0ZXN0MkBnbWFpbC5jb21cIn0iLCJpc193b3JsZHdpZGUiOmZhbHNlLCJfYXV0aF91c2VyX2hhc2giOiJmY2Q0ZmQ2NDYxMmQ0MjRhZThhNjk0MWMxODY0NDk5ZWQ2Nzg0MzU4Iiwic3RyaXBlX2lkIjoiY3VzX0IxSTlHY2Q3Slp1S2xSIiwiZW1haWwiOiJjb25zdHZlcnVtK3Rlc3QzQGdtYWlsLmNvbSIsImNvZmZlZSI6IjQwIiwiZXhwX21vbnRoIjoxMiwiaXNCb3R0bGVkIjoiIiwiZGlmZmVyZW50Ijp0cnVlLCJwaG9uZSI6IiIsImV4cF95ZWFyIjoyMDIwLCJmcm9tX2dldF9zdGFydGVkIjpmYWxzZSwibmFtZSI6ImRzYWRhcyIsInBhY2thZ2UiOiJHUiIsImNvdW50cnkiOiJTRyIsImludGVydmFsIjoiMTQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsImZyb21fc2hvcHBpbmdfY2FydCI6ZmFsc2UsImJyZXciOjEsInZvdWNoZXIiOiIifQ==	2017-07-27 22:13:34.110963+00
34zavakzfawqua95e3wt5hdhqwrxo6q3	OGM2NTg4YjA0YTY1NjNkNTFkZDYyNDlmMWQyNTQyN2IzNzE1ZWZjZjp7ImlzX3dvcmxkd2lkZSI6ZmFsc2V9	2017-08-15 15:16:18.002723+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY django_site (id, domain, name) FROM stdin;
1	hookcoffee.com.sg	Hook Coffee
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: get_started_getstartedresponse; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY get_started_getstartedresponse (id, name, email, form_details, created, ct_id, sent_emails) FROM stdin;
1	nhbgfvdcsx	constverum+test1@gmail.com	"name"=>"nhbgfvdcsx", "email"=>"constverum+test1@gmail.com", "method"=>"8", "flavour"=>"[6, 6]", "intensity"=>"3", "brew_title"=>"Cold Brew", "default_pack"=>"WB"	2017-07-13 21:55:38.80859+00	42	[]
4	hnbgvfcds	constverum+test12@gmail.com	"name"=>"hnbgvfcds", "email"=>"constverum+test12@gmail.com", "method"=>"3", "flavour"=>"[3]", "intensity"=>"3", "brew_title"=>"Aeropress", "default_pack"=>"WB"	2017-07-15 16:47:24.922037+00	14	[]
2	fsdsfdsf	constverum+test1@gmail.com	"name"=>"fsdsfdsf", "email"=>"constverum+test1@gmail.com", "method"=>"5", "flavour"=>"[5, 6]", "intensity"=>"3", "brew_title"=>"Stove top", "default_pack"=>"WB"	2017-07-13 22:04:49.927844+00	37	["Activation Stage 1", "Activation Stage 2", "Activation Stage 3", "Activation Stage 4"]
3	dsadas	constverum+test2@gmail.com	"name"=>"dsadas", "email"=>"constverum+test2@gmail.com", "method"=>"8", "flavour"=>"[6]", "intensity"=>"3", "brew_title"=>"Cold Brew", "default_pack"=>"WB"	2017-07-13 22:10:19.80734+00	11	["Activation Stage 1", "Activation Stage 2", "Activation Stage 3", "Activation Stage 4"]
5	Dsafds fsd	constverum+dasda@gmail.com	"name"=>"Dsafds fsd", "email"=>"constverum+dasda@gmail.com", "method"=>"2", "flavour"=>"[2]", "intensity"=>"3", "brew_title"=>"Drip", "default_pack"=>"WB"	2017-07-31 18:16:15.339248+00	14	[]
6	dsasdsa	constverum+dfs@gmail.com	"name"=>"dsasdsa", "email"=>"constverum+dfs@gmail.com", "method"=>"3", "flavour"=>"[6]", "intensity"=>"3", "brew_title"=>"Aeropress", "default_pack"=>"WB"	2017-08-01 15:12:26.480222+00	14	[]
\.


--
-- Name: get_started_getstartedresponse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('get_started_getstartedresponse_id_seq', 6, true);


--
-- Data for Name: get_started_giftvoucher; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY get_started_giftvoucher (id, used, recipient, amount, code, created, sender_email, sender_fname, sender_lname) FROM stdin;
1	f	Fsds	84	5B1EBLBX	2017-07-31 17:50:02.57783+00	constverum@gmail.com	Dsad	dsaasd
2	f	Deniska	42	FDA06M8U	2017-07-31 17:57:58.528443+00	constverum@gmail.com	dasas	sdas
3	f	Deniska	84	WMOQA8YC	2017-07-31 18:00:03.718386+00	constverum@gmail.com	dasas	sdas
4	f	Deniska	84	M9C7D1WN	2017-07-31 18:09:57.049902+00	constverum@gmail.com	dasas	sdas
5	f	Deniska	84	L9T7RSEV	2017-07-31 18:11:31.836026+00	constverum@gmail.com	dasas	sdas
6	t	Deniska	84	7AX1DJH9	2017-07-31 18:13:51.896571+00	constverum@gmail.com	dasas	sdas
\.


--
-- Name: get_started_giftvoucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('get_started_giftvoucher_id_seq', 6, true);


--
-- Data for Name: get_started_podsearlybird; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY get_started_podsearlybird (id, email, date) FROM stdin;
\.


--
-- Name: get_started_podsearlybird_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('get_started_podsearlybird_id_seq', 1, false);


--
-- Data for Name: get_started_referralvoucher; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY get_started_referralvoucher (id, used, recipient_email, discount_percent, discount_sgd, code, date, sender_id) FROM stdin;
\.


--
-- Name: get_started_referralvoucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('get_started_referralvoucher_id_seq', 1, false);


--
-- Data for Name: loyale_coffeetypepoints; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_coffeetypepoints (id, status, points, coffee_type_id) FROM stdin;
\.


--
-- Name: loyale_coffeetypepoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_coffeetypepoints_id_seq', 1, false);


--
-- Data for Name: loyale_grantpointlog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_grantpointlog (id, points, added, user_id) FROM stdin;
1	200	2017-07-23 11:26:50.866487+00	1
2	200	2017-07-23 11:28:42.944056+00	1
\.


--
-- Name: loyale_grantpointlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_grantpointlog_id_seq', 2, true);


--
-- Data for Name: loyale_helper; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_helper (id, emails_rewards_sent, emails_rewards_sent_count) FROM stdin;
2	f	0
\.


--
-- Name: loyale_helper_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_helper_id_seq', 2, true);


--
-- Data for Name: loyale_item; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_item (id, name, description, points, added, updated, img, in_stock) FROM stdin;
7	Hario V60 Dripper Filters	Pack of 40 (01) 	700	2016-05-10 17:02:10.633544+00	2016-05-10 17:02:10.633601+00	./Screen_Shot_2016-05-11_at_00.59.46.png	t
8	Special surprise for invites	For invited friends by referral programme	0	2016-12-11 16:02:04.523224+00	2016-12-11 16:02:04.523255+00		t
4	Hario Cold Brew Bottle 		3500	2016-05-10 16:56:46.699837+00	2016-12-13 15:18:47.333976+00	./Screen_Shot_2016-05-09_at_23.18.19.png	f
9	Aeropress Kit 		8000	2017-04-05 12:50:28.152977+00	2017-04-05 12:50:28.153024+00	./E1_-_Aeropress.jpg	t
10	Drip Coffee Variety Box		3000	2017-04-05 12:51:06.921983+00	2017-04-05 12:51:06.922024+00	./IMG_4212_xPJW9wz.jpg	t
11	Clever Dripper 		4000	2017-04-05 12:51:56.915337+00	2017-04-05 12:51:56.915365+00	./clever-coffee-dripper-new-model.jpg	t
1	Free bag of coffee		1100	2016-05-10 16:52:51.764191+00	2017-06-05 09:10:14.313206+00	./generic_bag.png	t
3	Hario Hand Grinder		4000	2016-05-10 16:56:20.231982+00	2017-06-05 09:10:40.092027+00	./Screen_Shot_2016-05-09_at_23.28.10.png	f
6	Hario V60 Dripper		900	2016-05-10 17:01:01.572067+00	2017-06-05 09:11:18.349758+00	./Screen_Shot_2016-05-11_at_00.59.37.png	t
\.


--
-- Name: loyale_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_item_id_seq', 11, true);


--
-- Data for Name: loyale_orderpoints; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_orderpoints (id, sub_regular, sub_special, one_regular, one_special, credits, one_pod, sub_pod) FROM stdin;
1	200	300	50	75	1	50	200
\.


--
-- Name: loyale_orderpoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_orderpoints_id_seq', 1, true);


--
-- Data for Name: loyale_point; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_point (id, points, added, user_id) FROM stdin;
18	0	2017-07-13 22:13:31.682992+00	5
19	0	2017-07-15 16:57:40.79601+00	6
1	400	2016-07-01 16:00:14.486426+00	1
20	0	2017-07-31 18:17:01.899495+00	7
21	0	2017-08-01 15:13:54.622387+00	8
22	0	2017-08-01 15:16:00.464715+00	9
23	0	2017-08-01 15:17:43.371496+00	10
\.


--
-- Name: loyale_point_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_point_id_seq', 23, true);


--
-- Data for Name: loyale_redemitem; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_redemitem (id, status, points, shipping_date, added, item_id, user_id) FROM stdin;
\.


--
-- Name: loyale_redemitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_redemitem_id_seq', 1, false);


--
-- Data for Name: loyale_redempointlog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_redempointlog (id, points, added, item_id, user_id) FROM stdin;
\.


--
-- Name: loyale_redempointlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_redempointlog_id_seq', 1, false);


--
-- Data for Name: loyale_setpoint; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY loyale_setpoint (id, status, points) FROM stdin;
\.


--
-- Name: loyale_setpoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('loyale_setpoint_id_seq', 1, false);


--
-- Data for Name: manager_churnratedata; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_churnratedata (id, month_year, proportion_churned) FROM stdin;
2	Aug-2016	0.378481
3	Jul-2016	0.390769
4	Jun-2016	0.374765
5	May-2016	0.459459
6	Apr-2016	0.385301
7	Mar-2016	0.400966
8	Feb-2016	0.372470
9	Jan-2016	0.516908
10	Dec-2015	0.000000
11	Nov-2015	0.000000
12	Oct-2015	0.000000
13	Oct-2016	0.397012
1	Sep-2016	0.418889
14	May-2017	0.000000
15	Apr-2017	0.000000
17	Jun-2017	0.000000
16	Jul-2017	0.000000
18	Mar-2017	0.000000
19	Feb-2017	0.000000
20	Jan-2017	0.000000
21	Dec-2016	0.000000
22	Nov-2016	0.000000
\.


--
-- Name: manager_churnratedata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_churnratedata_id_seq', 22, true);


--
-- Data for Name: manager_clusterdf; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_clusterdf (id, data) FROM stdin;
1	gAJjcGFuZGFzLmNvcmUuZnJhbWUKRGF0YUZyYW1lCnEBKYFxAn1xAyhVCV9tZXRhZGF0YXEEXXEFVQRfdHlwcQZVCWRhdGFmcmFtZXEHVQVfZGF0YXEIY3BhbmRhcy5jb3JlLmludGVybmFscwpCbG9ja01hbmFnZXIKcQkpgXEKKF1xCyhjcGFuZGFzLmluZGV4ZXMuYmFzZQpfbmV3X0luZGV4CnEMY3BhbmRhcy5pbmRleGVzLmJhc2UKSW5kZXgKcQ19cQ4oVQRkYXRhcQ9jbnVtcHkuY29yZS5tdWx0aWFycmF5Cl9yZWNvbnN0cnVjdApxEGNudW1weQpuZGFycmF5CnERSwCFVQFih1JxEihLAUsIhWNudW1weQpkdHlwZQpxE1UCTzhLAEsBh1JxFChLA1UBfE5OTkr/////Sv////9LP3RiiV1xFShVAmlkcRZVCm51bV9vcmRlcnNxF1UfcmF0aW9fYW1vdW50X3NwZW50X2FnYWluc3RfdGltZXEYVQxudW1fdm91Y2hlcnNxGVUQYXZlcmFnZV9pbnRlcnZhbHEaVQ50b3RhbF9zcGVuZGluZ3EbVRJudW1fb25lX29mZl9vcmRlcnNxHFUHY2x1c3RlcnEdZXRiVQRuYW1lcR5OdYZScR9oDGNwYW5kYXMuaW5kZXhlcy5yYW5nZQpSYW5nZUluZGV4CnEgfXEhKFUFc3RhcnRxIksAVQRzdGVwcSNLAVUEc3RvcHEkSwRoHk51hlJxJWVdcSYoaBBoEUsAhVUBYodScScoSwFLBksEhmgTVQJmOEsASwGHUnEoKEsDVQE8Tk5OSv////9K/////0sAdGKJVcAAAAAAAAAAAAAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAAAAAAAAAAAAIkAAAAAAAAAsQAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAAAAAAAAAAAAAIkAAAAAAAAAsQAAAAAAAACxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0YmgQaBFLAIVVAWKHUnEpKEsBSwFLBIZoE1UCaThLAEsBh1JxKihLA1UBPE5OTkr/////Sv////9LAHRiiVUgAQAAAAAAAADsBAAAAAAAAOsEAAAAAAAA7QQAAAAAAAB0YmgQaBFLAIVVAWKHUnErKEsBSwFLBIZoE1UCaTRLAEsBh1JxLChLA1UBPE5OTkr/////Sv////9LAHRiiFUQAQAAAAAAAAACAAAAAQAAAHRiZV1xLShoDGgNfXEuKGgPaBBoEUsAhVUBYodScS8oSwFLBoVoFIldcTAoaBdoGGgZaBpoG2gcZXRiaB5OdYZScTFoDGgNfXEyKGgPaBBoEUsAhVUBYodScTMoSwFLAYVoFIldcTRoFmF0YmgeTnWGUnE1aAxoDX1xNihoD2gQaBFLAIVVAWKHUnE3KEsBSwGFaBSJXXE4aB1hdGJoHk51hlJxOWV9cTpVBjAuMTQuMXE7fXE8KFUEYXhlc3E9aAtVBmJsb2Nrc3E+XXE/KH1xQChVCG1ncl9sb2NzcUFjX19idWlsdGluX18Kc2xpY2UKcUJLAUsHSwGHUnFDVQZ2YWx1ZXNxRGgndX1xRShoQWhCSwBLAUsBh1JxRmhEaCl1fXFHKGhBaEJLB0sISwGHUnFIaERoK3VldXN0YnViLg==
2	gAJjcGFuZGFzLmNvcmUuZnJhbWUKRGF0YUZyYW1lCnEBKYFxAn1xAyhVCV9tZXRhZGF0YXEEXXEFVQRfdHlwcQZVCWRhdGFmcmFtZXEHVQVfZGF0YXEIY3BhbmRhcy5jb3JlLmludGVybmFscwpCbG9ja01hbmFnZXIKcQkpgXEKKF1xCyhjcGFuZGFzLmluZGV4ZXMuYmFzZQpfbmV3X0luZGV4CnEMY3BhbmRhcy5pbmRleGVzLmJhc2UKSW5kZXgKcQ19cQ4oVQRkYXRhcQ9jbnVtcHkuY29yZS5tdWx0aWFycmF5Cl9yZWNvbnN0cnVjdApxEGNudW1weQpuZGFycmF5CnERSwCFVQFih1JxEihLAUsIhWNudW1weQpkdHlwZQpxE1UCTzhLAEsBh1JxFChLA1UBfE5OTkr/////Sv////9LP3RiiV1xFShVAmlkcRZVCm51bV9vcmRlcnNxF1UfcmF0aW9fYW1vdW50X3NwZW50X2FnYWluc3RfdGltZXEYVQxudW1fdm91Y2hlcnNxGVUQYXZlcmFnZV9pbnRlcnZhbHEaVQ50b3RhbF9zcGVuZGluZ3EbVRJudW1fb25lX29mZl9vcmRlcnNxHFUHY2x1c3RlcnEdZXRiVQRuYW1lcR5OdYZScR9oDGNwYW5kYXMuaW5kZXhlcy5yYW5nZQpSYW5nZUluZGV4CnEgfXEhKFUFc3RhcnRxIksAVQRzdGVwcSNLAVUEc3RvcHEkSwRoHk51hlJxJWVdcSYoaBBoEUsAhVUBYodScScoSwFLBksEhmgTVQJmOEsASwGHUnEoKEsDVQE8Tk5OSv////9K/////0sAdGKJVcAAAAAAAAAAAAAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAAAAAAAAAAAAIkAAAAAAAAAsQAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAAAAAAAAAAAAAIkAAAAAAAAAsQAAAAAAAACxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0YmgQaBFLAIVVAWKHUnEpKEsBSwFLBIZoE1UCaThLAEsBh1JxKihLA1UBPE5OTkr/////Sv////9LAHRiiVUgAQAAAAAAAADsBAAAAAAAAOsEAAAAAAAA7QQAAAAAAAB0YmgQaBFLAIVVAWKHUnErKEsBSwFLBIZoE1UCaTRLAEsBh1JxLChLA1UBPE5OTkr/////Sv////9LAHRiiFUQAQAAAAAAAAACAAAAAQAAAHRiZV1xLShoDGgNfXEuKGgPaBBoEUsAhVUBYodScS8oSwFLBoVoFIldcTAoaBdoGGgZaBpoG2gcZXRiaB5OdYZScTFoDGgNfXEyKGgPaBBoEUsAhVUBYodScTMoSwFLAYVoFIldcTRoFmF0YmgeTnWGUnE1aAxoDX1xNihoD2gQaBFLAIVVAWKHUnE3KEsBSwGFaBSJXXE4aB1hdGJoHk51hlJxOWV9cTpVBjAuMTQuMXE7fXE8KFUEYXhlc3E9aAtVBmJsb2Nrc3E+XXE/KH1xQChVCG1ncl9sb2NzcUFjX19idWlsdGluX18Kc2xpY2UKcUJLAUsHSwGHUnFDVQZ2YWx1ZXNxRGgndX1xRShoQWhCSwBLAUsBh1JxRmhEaCl1fXFHKGhBaEJLB0sISwGHUnFIaERoK3VldXN0YnViLg==
3	gAJjcGFuZGFzLmNvcmUuZnJhbWUKRGF0YUZyYW1lCnEBKYFxAn1xAyhVCV9tZXRhZGF0YXEEXXEFVQRfdHlwcQZVCWRhdGFmcmFtZXEHVQVfZGF0YXEIY3BhbmRhcy5jb3JlLmludGVybmFscwpCbG9ja01hbmFnZXIKcQkpgXEKKF1xCyhjcGFuZGFzLmluZGV4ZXMuYmFzZQpfbmV3X0luZGV4CnEMY3BhbmRhcy5pbmRleGVzLmJhc2UKSW5kZXgKcQ19cQ4oVQRkYXRhcQ9jbnVtcHkuY29yZS5tdWx0aWFycmF5Cl9yZWNvbnN0cnVjdApxEGNudW1weQpuZGFycmF5CnERSwCFVQFih1JxEihLAUsIhWNudW1weQpkdHlwZQpxE1UCTzhLAEsBh1JxFChLA1UBfE5OTkr/////Sv////9LP3RiiV1xFShVAmlkcRZVCm51bV9vcmRlcnNxF1UfcmF0aW9fYW1vdW50X3NwZW50X2FnYWluc3RfdGltZXEYVQxudW1fdm91Y2hlcnNxGVUQYXZlcmFnZV9pbnRlcnZhbHEaVQ50b3RhbF9zcGVuZGluZ3EbVRJudW1fb25lX29mZl9vcmRlcnNxHFUHY2x1c3RlcnEdZXRiVQRuYW1lcR5OdYZScR9oDGNwYW5kYXMuaW5kZXhlcy5yYW5nZQpSYW5nZUluZGV4CnEgfXEhKFUFc3RhcnRxIksAVQRzdGVwcSNLAVUEc3RvcHEkSwhoHk51hlJxJWVdcSYoaBBoEUsAhVUBYodScScoSwFLBksIhmgTVQJmOEsASwGHUnEoKEsDVQE8Tk5OSv////9K/////0sAdGKJVIABAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAAAAAAAAAAAAAYQAAAAAAAABBAAAAAAAAAFEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8D8AAAAAAAAAAAAAAAAAAAAAAAAAAAAA8D8AAAAAAADwPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAACxAAAAAAAAAGEAAAAAAAAAsQAAAAAAAACxAAAAAAAAAAAAAAAAAAAA3QAAAAAAAACxAAAAAAAAALEAAAAAAAAAiQAAAAAAAACJAAAAAAAAALEAAAAAAAAAsQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0YmgQaBFLAIVVAWKHUnEpKEsBSwFLCIZoE1UCaThLAEsBh1JxKihLA1UBPE5OTkr/////Sv////9LAHRiiVVAAQAAAAAAAADsBAAAAAAAAOsEAAAAAAAA7QQAAAAAAADuBAAAAAAAAO8EAAAAAAAA8AQAAAAAAADxBAAAAAAAAHRiaBBoEUsAhVUBYodScSsoSwFLAUsIhmgTVQJpNEsASwGHUnEsKEsDVQE8Tk5OSv////9K/////0sAdGKIVSABAAAAAAAAAAIAAAACAAAAAQAAAAEAAAABAAAAAQAAAHRiZV1xLShoDGgNfXEuKGgPaBBoEUsAhVUBYodScS8oSwFLBoVoFIldcTAoaBdoGGgZaBpoG2gcZXRiaB5OdYZScTFoDGgNfXEyKGgPaBBoEUsAhVUBYodScTMoSwFLAYVoFIldcTRoFmF0YmgeTnWGUnE1aAxoDX1xNihoD2gQaBFLAIVVAWKHUnE3KEsBSwGFaBSJXXE4aB1hdGJoHk51hlJxOWV9cTpVBjAuMTQuMXE7fXE8KFUEYXhlc3E9aAtVBmJsb2Nrc3E+XXE/KH1xQChVCG1ncl9sb2NzcUFjX19idWlsdGluX18Kc2xpY2UKcUJLAUsHSwGHUnFDVQZ2YWx1ZXNxRGgndX1xRShoQWhCSwBLAUsBh1JxRmhEaCl1fXFHKGhBaEJLB0sISwGHUnFIaERoK3VldXN0YnViLg==
4	gAJjcGFuZGFzLmNvcmUuZnJhbWUKRGF0YUZyYW1lCnEBKYFxAn1xAyhVCV9tZXRhZGF0YXEEXXEFVQRfdHlwcQZVCWRhdGFmcmFtZXEHVQVfZGF0YXEIY3BhbmRhcy5jb3JlLmludGVybmFscwpCbG9ja01hbmFnZXIKcQkpgXEKKF1xCyhjcGFuZGFzLmluZGV4ZXMuYmFzZQpfbmV3X0luZGV4CnEMY3BhbmRhcy5pbmRleGVzLmJhc2UKSW5kZXgKcQ19cQ4oVQRkYXRhcQ9jbnVtcHkuY29yZS5tdWx0aWFycmF5Cl9yZWNvbnN0cnVjdApxEGNudW1weQpuZGFycmF5CnERSwCFVQFih1JxEihLAUsIhWNudW1weQpkdHlwZQpxE1UCTzhLAEsBh1JxFChLA1UBfE5OTkr/////Sv////9LP3RiiV1xFShVAmlkcRZVCm51bV9vcmRlcnNxF1UfcmF0aW9fYW1vdW50X3NwZW50X2FnYWluc3RfdGltZXEYVQxudW1fdm91Y2hlcnNxGVUQYXZlcmFnZV9pbnRlcnZhbHEaVQ50b3RhbF9zcGVuZGluZ3EbVRJudW1fb25lX29mZl9vcmRlcnNxHFUHY2x1c3RlcnEdZXRiVQRuYW1lcR5OdYZScR9oDGNwYW5kYXMuaW5kZXhlcy5yYW5nZQpSYW5nZUluZGV4CnEgfXEhKFUFc3RhcnRxIksAVQRzdGVwcSNLAVUEc3RvcHEkSxBoHk51hlJxJWVdcSYoaBBoEUsAhVUBYodScScoSwFLBksQhmgTVQJmOEsASwGHUnEoKEsDVQE8Tk5OSv////9K/////0sAdGKJVAADAAAAAAAAAAAAAAAAAAAAAAhAAAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAACEAAAAAAAADwPwAAAAAAAAAAAAAAAAAAEEAAAAAAAAAAQAAAAAAAAABAAAAAAAAAAEAAAAAAAAAQQAAAAAAAABBAAAAAAAAAEEAAAAAAAAAAQAAAAAAAAABAAAAAAAAAAEAAAAAAAAAAQAAAAAAAAABAAAAAAAAAAEAAAAAAAAAYQAAAAAAAAABAAAAAAAAAAAAAAAAAAADwPwAAAAAAAAAAAAAAAAAA8D8AAAAAAADwPwAAAAAAAAAAAAAAAAAAAAAAAAAAAADwPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8D8AAAAAAAAAAAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAABhAAAAAAAAALEAAAAAAAAAsQAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAACxAAAAAAAAAKEAAAAAAAAAsQAAAAAAAAAAAAAAAAACAQkAAAAAAAAAsQAAAAAAAACJAAAAAAAAAIkAAAAAAAAAsQAAAAAAAACxAAAAAAAAALEAAAAAAAAAcQAAAAAAAABxAAAAAAAAAHEAAAAAAAAAcQAAAAAAAABxAAAAAAAAAHEAAAAAAAABJQAAAAAAAACJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPA/AAAAAAAAAAB0YmgQaBFLAIVVAWKHUnEpKEsBSwFLEIZoE1UCaThLAEsBh1JxKihLA1UBPE5OTkr/////Sv////9LAHRiiVWAAQAAAAAAAADsBAAAAAAAAO0EAAAAAAAA7gQAAAAAAADvBAAAAAAAAPAEAAAAAAAA8QQAAAAAAADyBAAAAAAAAPMEAAAAAAAA9AQAAAAAAAD1BAAAAAAAAPYEAAAAAAAA9wQAAAAAAAD4BAAAAAAAAOsEAAAAAAAA+QQAAAAAAAB0YmgQaBFLAIVVAWKHUnErKEsBSwFLEIZoE1UCaTRLAEsBh1JxLChLA1UBPE5OTkr/////Sv////9LAHRiiFVAAAAAAAEAAAAAAAAAAAAAAAAAAAACAAAAAgAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAHRiZV1xLShoDGgNfXEuKGgPaBBoEUsAhVUBYodScS8oSwFLBoVoFIldcTAoaBdoGGgZaBpoG2gcZXRiaB5OdYZScTFoDGgNfXEyKGgPaBBoEUsAhVUBYodScTMoSwFLAYVoFIldcTRoFmF0YmgeTnWGUnE1aAxoDX1xNihoD2gQaBFLAIVVAWKHUnE3KEsBSwGFaBSJXXE4aB1hdGJoHk51hlJxOWV9cTpVBjAuMTQuMXE7fXE8KFUEYXhlc3E9aAtVBmJsb2Nrc3E+XXE/KH1xQChVCG1ncl9sb2NzcUFjX19idWlsdGluX18Kc2xpY2UKcUJLAUsHSwGHUnFDVQZ2YWx1ZXNxRGgndX1xRShoQWhCSwBLAUsBh1JxRmhEaCl1fXFHKGhBaEJLB0sISwGHUnFIaERoK3VldXN0YnViLg==
5	gAJjcGFuZGFzLmNvcmUuZnJhbWUKRGF0YUZyYW1lCnEBKYFxAn1xAyhVCV9tZXRhZGF0YXEEXXEFVQRfdHlwcQZVCWRhdGFmcmFtZXEHVQVfZGF0YXEIY3BhbmRhcy5jb3JlLmludGVybmFscwpCbG9ja01hbmFnZXIKcQkpgXEKKF1xCyhjcGFuZGFzLmluZGV4ZXMuYmFzZQpfbmV3X0luZGV4CnEMY3BhbmRhcy5pbmRleGVzLmJhc2UKSW5kZXgKcQ19cQ4oVQRkYXRhcQ9jbnVtcHkuY29yZS5tdWx0aWFycmF5Cl9yZWNvbnN0cnVjdApxEGNudW1weQpuZGFycmF5CnERSwCFVQFih1JxEihLAUsIhWNudW1weQpkdHlwZQpxE1UCTzhLAEsBh1JxFChLA1UBfE5OTkr/////Sv////9LP3RiiV1xFShVAmlkcRZVCm51bV9vcmRlcnNxF1UfcmF0aW9fYW1vdW50X3NwZW50X2FnYWluc3RfdGltZXEYVQxudW1fdm91Y2hlcnNxGVUQYXZlcmFnZV9pbnRlcnZhbHEaVQ50b3RhbF9zcGVuZGluZ3EbVRJudW1fb25lX29mZl9vcmRlcnNxHFUHY2x1c3RlcnEdZXRiVQRuYW1lcR5OdYZScR9oDGNwYW5kYXMuaW5kZXhlcy5yYW5nZQpSYW5nZUluZGV4CnEgfXEhKFUFc3RhcnRxIksAVQRzdGVwcSNLAVUEc3RvcHEkSxBoHk51hlJxJWVdcSYoaBBoEUsAhVUBYodScScoSwFLBksQhmgTVQJmOEsASwGHUnEoKEsDVQE8Tk5OSv////9K/////0sAdGKJVAADAAAAAAAAAAAAAAAAAAAAAAhAAAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAA8D8AAAAAAADwPwAAAAAAAPA/AAAAAAAACEAAAAAAAADwPwAAAAAAAAAAAAAAAAAAEEAAAAAAAAAAQAAAAAAAAABAAAAAAAAAAEAAAAAAAAAQQAAAAAAAABBAAAAAAAAAEEAAAAAAAAAAQAAAAAAAAABAAAAAAAAAAEAAAAAAAAAAQAAAAAAAAABAAAAAAAAAAEAAAAAAAAAYQAAAAAAAAABAAAAAAAAAAAAAAAAAAADwPwAAAAAAAAAAAAAAAAAA8D8AAAAAAADwPwAAAAAAAAAAAAAAAAAAAAAAAAAAAADwPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8D8AAAAAAAAAAAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAABhAAAAAAAAALEAAAAAAAAAsQAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAACxAAAAAAAAALEAAAAAAAAAsQAAAAAAAACxAAAAAAAAAKEAAAAAAAAAsQAAAAAAAAAAAAAAAAACAQkAAAAAAAAAsQAAAAAAAACJAAAAAAAAAIkAAAAAAAAAsQAAAAAAAACxAAAAAAAAALEAAAAAAAAAcQAAAAAAAABxAAAAAAAAAHEAAAAAAAAAcQAAAAAAAABxAAAAAAAAAHEAAAAAAAABJQAAAAAAAACJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPA/AAAAAAAAAAB0YmgQaBFLAIVVAWKHUnEpKEsBSwFLEIZoE1UCaThLAEsBh1JxKihLA1UBPE5OTkr/////Sv////9LAHRiiVWAAQAAAAAAAADsBAAAAAAAAO0EAAAAAAAA7gQAAAAAAADvBAAAAAAAAPAEAAAAAAAA8QQAAAAAAADyBAAAAAAAAPMEAAAAAAAA9AQAAAAAAAD1BAAAAAAAAPYEAAAAAAAA9wQAAAAAAAD4BAAAAAAAAOsEAAAAAAAA+QQAAAAAAAB0YmgQaBFLAIVVAWKHUnErKEsBSwFLEIZoE1UCaTRLAEsBh1JxLChLA1UBPE5OTkr/////Sv////9LAHRiiFVAAQAAAAAAAAABAAAAAQAAAAEAAAACAAAAAgAAAAIAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAAAAAAAAQAAAHRiZV1xLShoDGgNfXEuKGgPaBBoEUsAhVUBYodScS8oSwFLBoVoFIldcTAoaBdoGGgZaBpoG2gcZXRiaB5OdYZScTFoDGgNfXEyKGgPaBBoEUsAhVUBYodScTMoSwFLAYVoFIldcTRoFmF0YmgeTnWGUnE1aAxoDX1xNihoD2gQaBFLAIVVAWKHUnE3KEsBSwGFaBSJXXE4aB1hdGJoHk51hlJxOWV9cTpVBjAuMTQuMXE7fXE8KFUEYXhlc3E9aAtVBmJsb2Nrc3E+XXE/KH1xQChVCG1ncl9sb2NzcUFjX19idWlsdGluX18Kc2xpY2UKcUJLAUsHSwGHUnFDVQZ2YWx1ZXNxRGgndX1xRShoQWhCSwBLAUsBh1JxRmhEaCl1fXFHKGhBaEJLB0sISwGHUnFIaERoK3VldXN0YnViLg==
\.


--
-- Name: manager_clusterdf_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_clusterdf_id_seq', 5, true);


--
-- Data for Name: manager_customercluster; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_customercluster (id, cluster_number, cluster_name, cluster_description, mean_orders, mean_ratio_amount_time, mean_vouchers_used, mean_interval, mean_total_spending, mean_one_off_orders, cluster_revenue, customers, percentage_brew_methods) FROM stdin;
1	0	Committed Customers	Customers who are extremely committed to Hook Coffee	3.00	5.00	0.50	13.00	43.50	0.50	87.00	"customers"=>"[1260, 1259]"	"Drip"=>"0.0", "None"=>"0.0", "Espresso"=>"0.0", "Aeropress"=>"66.67", "Cold Brew"=>"0.0", "Nespresso"=>"16.67", "Stove top"=>"0.0", "French press"=>"16.67"
2	1	Benefit Seekers	Customers who only order when there are extra benefits for them	0.91	1.82	0.27	12.00	7.55	0.00	83.00	"customers"=>"[1, 1261, 1262, 1263, 1267, 1268, 1269, 1270, 1271, 1272, 1273]"	"Drip"=>"20.0", "None"=>"0.0", "Espresso"=>"30.0", "Aeropress"=>"30.0", "Cold Brew"=>"10.0", "Nespresso"=>"10.0", "Stove top"=>"0.0", "French press"=>"0.0"
3	2	Surfers	Customers with fast turnover and are continually seeking for new experiences	1.00	4.00	0.33	14.00	14.00	0.00	42.00	"customers"=>"[1264, 1265, 1266]"	"Drip"=>"66.67", "None"=>"0.0", "Espresso"=>"33.33", "Aeropress"=>"0.0", "Cold Brew"=>"0.0", "Nespresso"=>"0.0", "Stove top"=>"0.0", "French press"=>"0.0"
\.


--
-- Name: manager_customercluster_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_customercluster_id_seq', 3, true);


--
-- Data for Name: manager_fyporderstats; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_fyporderstats (id, date, order_id) FROM stdin;
\.


--
-- Name: manager_fyporderstats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_fyporderstats_id_seq', 6, true);


--
-- Data for Name: manager_intercomlocal; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_intercomlocal (id, event, data, added_timestamp, customer_id) FROM stdin;
1	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/14/", "value": "Guji Liya"}, "Msg 0": "You will now receive your coffee every <big>9</big> days", "Msg 1": "Your order's packaging is changed to <big>Drip bags (x10)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 1400.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1501387200, "details": null, "created_date": 1499958097, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/2/", "value": 2}, "is-shotpods": false, "voucher": null}	2017-07-13 15:04:25.55463+00	1
2	logged-in	{}	2017-07-13 17:25:13.805993+00	1
3	logged-out	{}	2017-07-13 17:25:13.82927+00	1
4	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/14/", "value": "Guji Liya"}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 1400.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1501387200, "details": null, "created_date": 1499958097, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/2/", "value": 2}, "is-shotpods": false, "voucher": null}	2017-07-13 17:25:15.673855+00	1
5	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/14/", "value": "Guji Liya"}, "Msg 0": "You will now receive your coffee every <big>14</big> days", "Msg 1": "Your order's packaging is changed to <big>Ground (200g)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 1400.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1501387200, "details": null, "created_date": 1499958097, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/2/", "value": 2}, "is-shotpods": false, "voucher": null}	2017-07-13 17:26:17.295091+00	1
6	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/14/", "value": "Guji Liya"}, "Msg 0": "Your order's brewing method is changed to <big>Drip</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 1400.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1501387200, "details": null, "created_date": 1499958097, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/2/", "value": 2}, "is-shotpods": false, "voucher": null}	2017-07-13 17:31:01.860761+00	1
7	cart-charge	{"country": "SG", "overall-weight": 500, "overall-cost": 77.0, "charge": "ch_1AfFEVGenOFgcvuHAg9N7EEP", "coffees": "Hario Drip Coffee Scale (x1)", "shipping-cost": 0}	2017-07-31 17:36:59.459619+00	1
8	signed-up	{"credits": 0.0}	2017-07-31 17:37:05.274907+00	2
9	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/37/", "value": "Shake Your Bun Bun!"}, "stripe_customer": "cus_B1I1bJeTUbfrIJ", "price": {"currency": "SGD", "amount": 1400.0}, "shipping_address": "[Base address] fds fsd 0000000", "shipping_date": 1500264000, "details": null, "created_date": 1499983551, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/3/", "value": 3}, "is-shotpods": false, "voucher": null}	2017-07-31 17:37:06.298366+00	2
10	signed-up	{"credits": 0.0}	2017-07-31 17:37:16.598213+00	4
11	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": "cus_B1I9Gcd7JZuKlR", "price": {"currency": "SGD", "amount": 900.0}, "shipping_address": "[Base address] dassa 234 765432", "shipping_date": 1500264000, "details": null, "created_date": 1499984007, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/4/", "value": 4}, "is-shotpods": false, "voucher": "TAKEFIVE!"}	2017-07-31 17:37:17.257879+00	4
12	logged-in	{}	2017-07-31 17:37:18.20202+00	4
13	signed-up	{"credits": 0.0}	2017-07-31 17:37:24.214195+00	5
14	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/14/", "value": "Guji Liya"}, "stripe_customer": "cus_B1xVvUJ1u4a2XB", "price": {"currency": "SGD", "amount": 900.0}, "shipping_address": "[Base address] sadsa dassdsaas #23 eqw qwewqeq e 24234432", "shipping_date": 1500264000, "details": null, "created_date": 1500137851, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/5/", "value": 5}, "is-shotpods": false, "voucher": "TAKEFIVE!"}	2017-07-31 17:37:25.280264+00	5
15	logged-in	{}	2017-07-31 17:37:25.886262+00	5
16	cart-charge	{"country": "SG", "overall-weight": 200, "overall-cost": 18.0, "charge": "ch_1AihjOGenOFgcvuHo2LPqtDj", "coffees": "Shake Your Bun Bun! (x1)", "shipping-cost": 0}	2017-07-31 17:37:27.010007+00	1
17	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/32/", "value": "Give me S'mores"}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1500868800, "details": null, "created_date": 1500808575, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/7/", "value": 7}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:37:30.407497+00	1
18	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:37:52.837415+00	1
19	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive <big>different</big> coffee every time", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:02.059229+00	1
20	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>9</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:03.654997+00	1
46	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/14/", "value": "Guji Liya"}, "stripe_customer": null, "price": {"currency": "SGD", "amount": 1400.0}, "shipping_address": "[Base address] fdsds fdss 42332432", "shipping_date": 1501646400, "details": "{\\"friend\\": \\"dasas\\"}", "created_date": 1501525016, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/16/", "value": 16}, "is-shotpods": false, "voucher": null}	2017-07-31 18:17:03.04522+00	6
21	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive <big>the same</big> coffee every time", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:05.386762+00	1
22	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive <big>different</big> coffee every time", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:07.046875+00	1
23	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>8</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:08.632782+00	1
24	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>4</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:10.427107+00	1
25	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/42/", "value": "Peach, Please! Cold Brew"}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 3500.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1504152000, "details": null, "created_date": 1501232612, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/15/", "value": 15}, "is-shotpods": false, "voucher": null}	2017-07-31 17:38:12.087797+00	1
26	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>28</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:13.890327+00	1
27	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:15.546567+00	1
28	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:17.249421+00	1
29	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:18.9596+00	1
30	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>5</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:20.755058+00	1
31	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>4</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:22.529497+00	1
32	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>3</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:24.25758+00	1
48	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": null, "price": {"currency": "SGD", "amount": 1400.0}, "shipping_address": "[Base address] fdsds fdss 42332432", "shipping_date": 1501646400, "details": null, "created_date": 1501525622, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/17/", "value": 17}, "is-shotpods": false, "voucher": null}	2017-07-31 18:27:04.498286+00	6
33	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>28</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:26.06387+00	1
34	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/42/", "value": "Peach, Please! Cold Brew"}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 3500.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1504152000, "details": null, "created_date": 1501232612, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/15/", "value": 15}, "is-shotpods": false, "voucher": null}	2017-07-31 17:38:27.732561+00	1
35	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/42/", "value": "Peach, Please! Cold Brew"}, "Msg 0": "You will now receive your coffee every <big>14</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 3500.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1504152000, "details": null, "created_date": 1501232612, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/15/", "value": 15}, "is-shotpods": false, "voucher": null}	2017-07-31 17:38:29.489551+00	1
36	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/42/", "value": "Peach, Please! Cold Brew"}, "Msg 0": "You will now receive your coffee every <big>30</big> days", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 3500.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1504152000, "details": null, "created_date": 1501232612, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/15/", "value": 15}, "is-shotpods": false, "voucher": null}	2017-07-31 17:38:31.153643+00	1
37	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "Your order's packaging is changed to <big>Wholebeans (200g)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:32.871064+00	1
38	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive <big>the same</big> coffee every time", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:34.612444+00	1
39	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive <big>different</big> coffee every time", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:36.451727+00	1
40	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:43.73735+00	1
41	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>23</big> days", "Msg 1": "Your order's packaging is changed to <big>Drip bags (x10)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:38:45.462011+00	1
42	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive <big>the same</big> coffee every time", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:40:49.596644+00	1
43	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive <big>different</big> coffee every time", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:42:02.612149+00	1
44	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>28</big> days", "Msg 1": "Your order's packaging is changed to <big>Wholebeans (200g)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 17:42:51.5328+00	1
45	signed-up	{"credits": 84.0}	2017-07-31 18:17:01.192028+00	6
47	logged-in	{}	2017-07-31 18:17:04.871332+00	6
49	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>23</big> days", "Msg 1": "Your order's packaging is changed to <big>Drip bags (x10)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 18:40:41.08935+00	1
50	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "You will now receive your coffee every <big>28</big> days", "Msg 1": "Your order's packaging is changed to <big>Wholebeans (200g)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 18:42:43.172836+00	1
51	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "Your order's packaging is changed to <big>Ground (200g)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 18:43:01.103189+00	1
52	changed-order-preferences	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "Msg 0": "Your order's brewing method is changed to <big>Drip</big>", "Msg 1": "Your order's packaging is changed to <big>Wholebeans (200g)</big>", "stripe_customer": "cus_ApfNgprl1cK1QR", "price": {"currency": "SGD", "amount": 4600.0}, "shipping_address": "[Base address] First line #11 Second line #22 358599", "shipping_date": 1503547200, "details": "{\\"AEROPRESS50\\": \\"true\\"}", "created_date": 1500812148, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/14/", "value": 14}, "is-shotpods": false, "voucher": "AEROPRESS50"}	2017-07-31 18:43:13.797255+00	1
53	signed-up	{"credits": 0.0}	2017-08-01 15:13:44.447295+00	7
54	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/14/", "value": "Guji Liya"}, "stripe_customer": "cus_B8If7muuK30rbo", "price": {"currency": "SGD", "amount": 900.0}, "shipping_address": "[Base address] dfsd fsds 2343423", "shipping_date": 1501646400, "details": null, "created_date": 1501600422, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/18/", "value": 18}, "is-shotpods": false, "voucher": "TAKEFIVE!"}	2017-08-01 15:13:46.223442+00	7
55	logged-in	{}	2017-08-01 15:13:48.081911+00	7
56	logged-out	{}	2017-08-01 15:14:04.144184+00	7
57	signed-up	{"credits": 0.0}	2017-08-01 15:15:50.476196+00	8
58	created-subscription	{"coffee": {"url": "https://hookcoffee.com.sg/admin/coffees/coffeetype/40/", "value": "Appley Ever After "}, "stripe_customer": "cus_B8Ihb5hUmfgGqi", "price": {"currency": "SGD", "amount": 900.0}, "shipping_address": "[Base address] fdsfds fsds 2423423423", "shipping_date": 1501646400, "details": null, "created_date": 1501600548, "order": {"url": "https://hookcoffee.com.sg/admin/customers/order/19/", "value": 19}, "is-shotpods": false, "voucher": "TAKEFIVE!"}	2017-08-01 15:15:52.15767+00	8
59	logged-in	{}	2017-08-01 15:15:53.925438+00	8
60	logged-out	{}	2017-08-01 15:16:14.729853+00	8
61	cart-charge	{"country": "SG", "charge": "ch_1Am27oGenOFgcvuHvoDtXB5m", "overall-cost": 18.0, "overall-weight": 200, "voucher": "", "coffees": "The Godfather ShotPods (x1)", "shipping-cost": 0}	2017-08-01 15:17:37.618634+00	9
62	logged-in	{}	2017-08-01 15:17:41.508383+00	9
\.


--
-- Name: manager_intercomlocal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_intercomlocal_id_seq', 62, true);


--
-- Data for Name: manager_mailchimpcampaignstats; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_mailchimpcampaignstats (id, action, email, campaign_id, order_id) FROM stdin;
\.


--
-- Name: manager_mailchimpcampaignstats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_mailchimpcampaignstats_id_seq', 1, false);


--
-- Data for Name: manager_rawbeanstats; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_rawbeanstats (id, date, raw_bean_id, status, stock) FROM stdin;
1	2016-10-11 11:50:45.722884+00	1	t	60.00
2	2016-10-11 11:51:22.597103+00	1	t	44.00
3	2016-11-06 06:39:41.655979+00	2	t	21.00
4	2016-11-06 06:40:01.584475+00	3	t	28.00
5	2016-11-06 06:41:08.500135+00	4	t	2.00
6	2016-11-06 06:42:36.649546+00	5	t	35.00
7	2016-11-06 06:43:27.956168+00	6	t	120.00
8	2016-11-06 06:46:09.371595+00	7	t	0.00
9	2016-11-21 17:23:04.692523+00	3	t	148.00
10	2016-11-21 17:23:04.716804+00	1	t	104.00
11	2016-11-21 17:23:04.724871+00	5	t	155.00
12	2016-11-21 17:23:04.733189+00	2	t	90.00
13	2016-11-21 17:23:19.028869+00	4	f	0.00
14	2016-11-21 17:23:37.871634+00	7	f	0.00
15	2016-11-21 17:23:53.146881+00	4	t	0.00
16	2016-11-21 17:24:07.041202+00	4	f	0.00
21	2016-11-24 13:54:24.482+00	5	t	0.00
22	2016-11-24 13:54:32.153502+00	5	t	155.00
\.


--
-- Name: manager_rawbeanstats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_rawbeanstats_id_seq', 24, true);


--
-- Data for Name: manager_recommendation; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_recommendation (id, date, facebook_advertising_cost, adwords_cost, new_coffees, email_campaigns, roadshows, blog_posts, budget, expected_demand, demand_actualising) FROM stdin;
4	2016-11-22 14:50:10.903591+00	744.86	404.44	3	7	3	2	6745	22.4955794781990832	0
5	2016-12-01 08:01:36.430979+00	1648.29	454.41	3	8	1	3	6580	6.0605749901912267	0
6	2017-01-11 07:08:09.484289+00	106.35	397.30	2	6	7	5	6082	29.2320710291955166	0
7	2017-02-02 06:24:27.736787+00	841.54	359.71	1	6	8	9	6625	11.4846444781766159	0
8	2017-03-06 14:09:19.711826+00	2453.10	586.11	3	8	1	9	7071	6.2525102745169896	0
9	2017-04-06 13:45:49.03403+00	1758.35	973.01	1	12	6	7	8350	25.0419697295935499	0
10	2017-05-14 02:36:33.527562+00	2622.68	519.58	2	14	6	5	10135	29.3306528458210494	0
\.


--
-- Name: manager_recommendation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_recommendation_id_seq', 10, true);


--
-- Data for Name: manager_reportcard; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_reportcard (id, date, active_customers, orders, churn, new_signups, expected_demand, demand_actualising, deviation, actions, percentage_changes) FROM stdin;
\.


--
-- Name: manager_reportcard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_reportcard_id_seq', 2, false);


--
-- Data for Name: manager_threshold; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY manager_threshold (id, amount, date) FROM stdin;
\.


--
-- Name: manager_threshold_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('manager_threshold_id_seq', 1, false);


--
-- Data for Name: reminders_reminder; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY reminders_reminder (id, username, email, from_email, subject, template_name, created, resumed, scheduled, completed, order_id, voucher_id, recommended_coffee_id) FROM stdin;
\.


--
-- Name: reminders_reminder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('reminders_reminder_id_seq', 29, true);


--
-- Data for Name: wholesale_plan; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY wholesale_plan (id, name, goal_1, goal_2, goal_2_note, description_1, description_2, description_2_note, comments, price, img, comments_en, comments_zh_hans, description_1_en, description_1_zh_hans, description_2_en, description_2_note_en, description_2_note_zh_hans, description_2_zh_hans, goal_1_en, goal_1_zh_hans, goal_2_en, goal_2_note_en, goal_2_note_zh_hans, goal_2_zh_hans, name_en, name_zh_hans, office_type, the_order) FROM stdin;
1	SHOTPODS 	For coffee at your fingertips	Nespresso-compatible pods and Machine plan	\N	Curated set of ShotPods, with different intensity and flavours	Option to Lease/Purchase compatible machine 	\N	FREE delivery. Customised delivery frequency.	\N	./HC-78_copy_0XXZkm8.jpg	FREE delivery. Customised delivery frequency.	免费送货。客户自定义送货频率。	Curated set of ShotPods, with different intensity and flavours	为你选择咖啡胶囊组，有不同强度和口味	Option to Lease/Purchase compatible machine 	\N	\N	选择租赁/购买兼容的机器	For coffee at your fingertips	指尖的咖啡	Nespresso-compatible pods and Machine plan	\N	\N	关于与Nespresso兼容的咖啡胶囊和机器的方案	SHOTPODS 	咖啡胶囊	WO	0
3	Hook's Drip Coffee Bags 	For a quick caffeine fix in the office	Hook coffee drip bags	\N	Variety of Hook’s coffees in individually wrapped coffee drip bags (each bag makes 1 cup)	Quick and easy, no brew equipment required	\N	FREE delivery. Customisable delivery frequency.	\N	./HC-85_copy_KpXDtXO.jpg	FREE delivery. Customisable delivery frequency.	免费送货。客户自定义送货频率。	Variety of Hook’s coffees in individually wrapped coffee drip bags (each bag makes 1 cup)	各种 Hook 的咖啡，独立包装的滤挂咖啡（每袋可以泡制一杯咖啡）	Quick and easy, no brew equipment required	\N	\N	快速又简单，无需烹煮设备	For a quick caffeine fix in the office		Hook coffee drip bags	\N	\N	Hook 滤挂咖啡	Hook's Drip Coffee Bags 	HOOK 的滤挂咖啡	WO	0
2	Whole Beans	For the (coffee) geek offices	Freshly Roasted Whole Beans	\N	Choose from Hook's full range of coffees (freshly roasted in Singapore)	Min. order quantity of 4kg ~ approx. 180 cups	\N	FREE delivery. Customisable delivery frequency.	\N	./HC-90_c0qjK64.jpg	FREE delivery. Customisable delivery frequency.	免费送货。客户自定义送货频率。	Choose from Hook's full range of coffees (freshly roasted in Singapore)	从Hook全系列咖啡（在新加坡新鲜烘焙）中选择	Min. order quantity of 4kg ~ approx. 180 cups	\N	\N	最低订单数量为3千克 ~ 大约180杯	For the (coffee) geek offices	（咖啡）爱好者办公室	Freshly Roasted Whole Beans	\N	\N	新鲜烘焙的全豆咖啡	Whole Beans	全豆咖啡	WO	0
4	Hook's Some Bags	For a quick caffeine fix in the office	Hook coffee drip bags	\N	Variety of Hook’s coffees in individually wrapped coffee drip bags (each bag makes 1 cup)	Quick and easy, no brew equipment required	\N	FREE delivery. Customisable delivery frequency.	\N	./HC-85_copy_KpXDtXO.jpg	FREE delivery. Customisable delivery frequency.		Variety of Hook’s coffees in individually wrapped coffee drip bags (each bag makes 1 cup)		Quick and easy, no brew equipment required	\N	\N		For a quick caffeine fix in the office		Hook coffee drip bags	\N	\N		Hook's Some Bags		WO	0
5	Hook's Drip Coffee Bags	For a quick caffeine fix in the office	Hook coffee drip bags	\N	Variety of Hook’s coffees in individually wrapped coffee drip bags (each bag makes 1 cup)	Quick and easy, no brew equipment required	\N	FREE delivery. Customisable delivery frequency.	\N	./HC-85_copy_KpXDtXO.jpg	FREE delivery. Customisable delivery frequency.		Variety of Hook’s coffees in individually wrapped coffee drip bags (each bag makes 1 cup)		Quick and easy, no brew equipment required	\N	\N		For a quick caffeine fix in the office		Hook coffee drip bags	\N	\N		Hook's Drip Coffee Bags		WO	0
\.


--
-- Name: wholesale_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('wholesale_plan_id_seq', 5, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: blog_category blog_category_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_category
    ADD CONSTRAINT blog_category_pkey PRIMARY KEY (id);


--
-- Name: blog_category blog_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_category
    ADD CONSTRAINT blog_category_slug_key UNIQUE (slug);


--
-- Name: blog_post blog_post_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post
    ADD CONSTRAINT blog_post_pkey PRIMARY KEY (id);


--
-- Name: blog_post blog_post_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post
    ADD CONSTRAINT blog_post_slug_key UNIQUE (slug);


--
-- Name: blog_post_tags blog_post_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post_tags
    ADD CONSTRAINT blog_post_tags_pkey PRIMARY KEY (id);


--
-- Name: blog_post_tags blog_post_tags_post_id_tag_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post_tags
    ADD CONSTRAINT blog_post_tags_post_id_tag_id_key UNIQUE (post_id, tag_id);


--
-- Name: blog_tag blog_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_tag
    ADD CONSTRAINT blog_tag_pkey PRIMARY KEY (id);


--
-- Name: blog_tag blog_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_tag
    ADD CONSTRAINT blog_tag_slug_key UNIQUE (slug);


--
-- Name: coffees_brewmethod coffees_brewmethod_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_brewmethod
    ADD CONSTRAINT coffees_brewmethod_pkey PRIMARY KEY (id);


--
-- Name: coffees_coffeegear_brew_methods coffees_coffeegear_brew_methods_coffeegear_id_brewmethod_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegear_brew_methods
    ADD CONSTRAINT coffees_coffeegear_brew_methods_coffeegear_id_brewmethod_id_key UNIQUE (coffeegear_id, brewmethod_id);


--
-- Name: coffees_coffeegear_brew_methods coffees_coffeegear_brew_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegear_brew_methods
    ADD CONSTRAINT coffees_coffeegear_brew_methods_pkey PRIMARY KEY (id);


--
-- Name: coffees_coffeegear coffees_coffeegear_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegear
    ADD CONSTRAINT coffees_coffeegear_pkey PRIMARY KEY (id);


--
-- Name: coffees_coffeegearcolor coffees_coffeegearcolor_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegearcolor
    ADD CONSTRAINT coffees_coffeegearcolor_pkey PRIMARY KEY (id);


--
-- Name: coffees_coffeegearimage coffees_coffeegearimage_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegearimage
    ADD CONSTRAINT coffees_coffeegearimage_pkey PRIMARY KEY (id);


--
-- Name: coffees_coffeesticker coffees_coffeesticker_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeesticker
    ADD CONSTRAINT coffees_coffeesticker_pkey PRIMARY KEY (id);


--
-- Name: coffees_coffeetype_brew_method coffees_coffeetype_brew_method_coffeetype_id_brewmethod_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeetype_brew_method
    ADD CONSTRAINT coffees_coffeetype_brew_method_coffeetype_id_brewmethod_id_key UNIQUE (coffeetype_id, brewmethod_id);


--
-- Name: coffees_coffeetype_brew_method coffees_coffeetype_brew_method_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeetype_brew_method
    ADD CONSTRAINT coffees_coffeetype_brew_method_pkey PRIMARY KEY (id);


--
-- Name: coffees_coffeetype coffees_coffeetype_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeetype
    ADD CONSTRAINT coffees_coffeetype_pkey PRIMARY KEY (id);


--
-- Name: coffees_farmphotos coffees_farmphotos_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_farmphotos
    ADD CONSTRAINT coffees_farmphotos_pkey PRIMARY KEY (id);


--
-- Name: coffees_flavor coffees_flavor_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_flavor
    ADD CONSTRAINT coffees_flavor_pkey PRIMARY KEY (id);


--
-- Name: coffees_rawbean coffees_rawbean_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_rawbean
    ADD CONSTRAINT coffees_rawbean_name_key UNIQUE (name);


--
-- Name: coffees_rawbean coffees_rawbean_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_rawbean
    ADD CONSTRAINT coffees_rawbean_pkey PRIMARY KEY (id);


--
-- Name: coffees_sharedcoffeesticker coffees_sharedcoffeesticker_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_sharedcoffeesticker
    ADD CONSTRAINT coffees_sharedcoffeesticker_pkey PRIMARY KEY (id);


--
-- Name: content_brewguide content_brewguide_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_brewguide
    ADD CONSTRAINT content_brewguide_pkey PRIMARY KEY (id);


--
-- Name: content_brewguide content_brewguide_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_brewguide
    ADD CONSTRAINT content_brewguide_slug_key UNIQUE (slug);


--
-- Name: content_brewguidestep content_brewguidestep_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_brewguidestep
    ADD CONSTRAINT content_brewguidestep_pkey PRIMARY KEY (id);


--
-- Name: content_career content_career_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_career
    ADD CONSTRAINT content_career_pkey PRIMARY KEY (id);


--
-- Name: content_greeting content_greeting_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_greeting
    ADD CONSTRAINT content_greeting_pkey PRIMARY KEY (id);


--
-- Name: content_instagrampost content_instagrampost_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_instagrampost
    ADD CONSTRAINT content_instagrampost_pkey PRIMARY KEY (id);


--
-- Name: content_post content_post_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_post
    ADD CONSTRAINT content_post_pkey PRIMARY KEY (id);


--
-- Name: content_review content_review_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_review
    ADD CONSTRAINT content_review_pkey PRIMARY KEY (id);


--
-- Name: content_section content_section_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_section
    ADD CONSTRAINT content_section_pkey PRIMARY KEY (id);


--
-- Name: content_topbar content_topbar_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_topbar
    ADD CONSTRAINT content_topbar_pkey PRIMARY KEY (id);


--
-- Name: customauth_login customauth_login_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_login
    ADD CONSTRAINT customauth_login_pkey PRIMARY KEY (id);


--
-- Name: customauth_myuser customauth_myuser_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser
    ADD CONSTRAINT customauth_myuser_email_key UNIQUE (email);


--
-- Name: customauth_myuser_groups customauth_myuser_groups_myuser_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_groups
    ADD CONSTRAINT customauth_myuser_groups_myuser_id_group_id_key UNIQUE (myuser_id, group_id);


--
-- Name: customauth_myuser_groups customauth_myuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_groups
    ADD CONSTRAINT customauth_myuser_groups_pkey PRIMARY KEY (id);


--
-- Name: customauth_myuser customauth_myuser_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser
    ADD CONSTRAINT customauth_myuser_pkey PRIMARY KEY (id);


--
-- Name: customauth_myuser_user_permissions customauth_myuser_user_permissions_myuser_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_user_permissions
    ADD CONSTRAINT customauth_myuser_user_permissions_myuser_id_permission_id_key UNIQUE (myuser_id, permission_id);


--
-- Name: customauth_myuser_user_permissions customauth_myuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_user_permissions
    ADD CONSTRAINT customauth_myuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: customers_address customers_address_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_address
    ADD CONSTRAINT customers_address_pkey PRIMARY KEY (id);


--
-- Name: customers_cardfingerprint customers_cardfingerprint_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_cardfingerprint
    ADD CONSTRAINT customers_cardfingerprint_pkey PRIMARY KEY (id);


--
-- Name: customers_charge customers_charge_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_charge
    ADD CONSTRAINT customers_charge_pkey PRIMARY KEY (id);


--
-- Name: customers_coffeereview customers_coffeereview_order_id_132e267d7dd42101_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_coffeereview
    ADD CONSTRAINT customers_coffeereview_order_id_132e267d7dd42101_uniq UNIQUE (order_id, coffee_id);


--
-- Name: customers_coffeereview customers_coffeereview_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_coffeereview
    ADD CONSTRAINT customers_coffeereview_pkey PRIMARY KEY (id);


--
-- Name: customers_customer customers_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT customers_customer_pkey PRIMARY KEY (id);


--
-- Name: customers_customer_received_coffee_samples customers_customer_received_coffe_customer_id_coffeetype_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_received_coffee_samples
    ADD CONSTRAINT customers_customer_received_coffe_customer_id_coffeetype_id_key UNIQUE (customer_id, coffeetype_id);


--
-- Name: customers_customer_received_coffee_samples customers_customer_received_coffee_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_received_coffee_samples
    ADD CONSTRAINT customers_customer_received_coffee_samples_pkey PRIMARY KEY (id);


--
-- Name: customers_customer customers_customer_user_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT customers_customer_user_id_key UNIQUE (user_id);


--
-- Name: customers_customer_vouchers customers_customer_vouchers_customer_id_voucher_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_vouchers
    ADD CONSTRAINT customers_customer_vouchers_customer_id_voucher_id_key UNIQUE (customer_id, voucher_id);


--
-- Name: customers_customer_vouchers customers_customer_vouchers_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_vouchers
    ADD CONSTRAINT customers_customer_vouchers_pkey PRIMARY KEY (id);


--
-- Name: customers_facebookcustomer customers_facebookcustomer_email_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_facebookcustomer
    ADD CONSTRAINT customers_facebookcustomer_email_key UNIQUE (email);


--
-- Name: customers_facebookcustomer customers_facebookcustomer_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_facebookcustomer
    ADD CONSTRAINT customers_facebookcustomer_pkey PRIMARY KEY (id);


--
-- Name: customers_gearorder customers_gearorder_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_gearorder
    ADD CONSTRAINT customers_gearorder_pkey PRIMARY KEY (id);


--
-- Name: customers_order customers_order_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_order
    ADD CONSTRAINT customers_order_pkey PRIMARY KEY (id);


--
-- Name: customers_plan customers_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_plan
    ADD CONSTRAINT customers_plan_pkey PRIMARY KEY (id);


--
-- Name: customers_plan customers_plan_plan_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_plan
    ADD CONSTRAINT customers_plan_plan_key UNIQUE (plan);


--
-- Name: customers_postcard customers_postcard_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_postcard
    ADD CONSTRAINT customers_postcard_pkey PRIMARY KEY (id);


--
-- Name: customers_preferences customers_preferences_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences
    ADD CONSTRAINT customers_preferences_customer_id_key UNIQUE (customer_id);


--
-- Name: customers_preferences_flavor customers_preferences_flavor_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences_flavor
    ADD CONSTRAINT customers_preferences_flavor_pkey PRIMARY KEY (id);


--
-- Name: customers_preferences_flavor customers_preferences_flavor_preferences_id_flavor_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences_flavor
    ADD CONSTRAINT customers_preferences_flavor_preferences_id_flavor_id_key UNIQUE (preferences_id, flavor_id);


--
-- Name: customers_preferences customers_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences
    ADD CONSTRAINT customers_preferences_pkey PRIMARY KEY (id);


--
-- Name: customers_reference customers_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_reference
    ADD CONSTRAINT customers_reference_pkey PRIMARY KEY (id);


--
-- Name: customers_reference customers_reference_referrer_id_10495307c838c6fa_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_reference
    ADD CONSTRAINT customers_reference_referrer_id_10495307c838c6fa_uniq UNIQUE (referrer_id, referred_id);


--
-- Name: customers_referral customers_referral_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_referral
    ADD CONSTRAINT customers_referral_pkey PRIMARY KEY (id);


--
-- Name: customers_referral customers_referral_user_id_416b1e3466b2f3e7_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_referral
    ADD CONSTRAINT customers_referral_user_id_416b1e3466b2f3e7_uniq UNIQUE (user_id, aim);


--
-- Name: customers_shoppingcart customers_shoppingcart_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_shoppingcart
    ADD CONSTRAINT customers_shoppingcart_pkey PRIMARY KEY (customer_id);


--
-- Name: customers_shoppingcart customers_shoppingcart_voucher_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_shoppingcart
    ADD CONSTRAINT customers_shoppingcart_voucher_id_key UNIQUE (voucher_id);


--
-- Name: customers_subscription customers_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_subscription
    ADD CONSTRAINT customers_subscription_pkey PRIMARY KEY (id);


--
-- Name: customers_voucher customers_voucher_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_voucher
    ADD CONSTRAINT customers_voucher_pkey PRIMARY KEY (id);


--
-- Name: customers_vouchercategory customers_vouchercategory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_vouchercategory
    ADD CONSTRAINT customers_vouchercategory_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_45f3b1d93ec8c61c_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_copy1 django_migrations_copy1_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_migrations_copy1
    ADD CONSTRAINT django_migrations_copy1_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: get_started_getstartedresponse get_started_getstartedresponse_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_getstartedresponse
    ADD CONSTRAINT get_started_getstartedresponse_pkey PRIMARY KEY (id);


--
-- Name: get_started_giftvoucher get_started_giftvoucher_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_giftvoucher
    ADD CONSTRAINT get_started_giftvoucher_pkey PRIMARY KEY (id);


--
-- Name: get_started_podsearlybird get_started_podsearlybird_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_podsearlybird
    ADD CONSTRAINT get_started_podsearlybird_pkey PRIMARY KEY (id);


--
-- Name: get_started_referralvoucher get_started_referralvoucher_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_referralvoucher
    ADD CONSTRAINT get_started_referralvoucher_pkey PRIMARY KEY (id);


--
-- Name: loyale_coffeetypepoints loyale_coffeetypepoints_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_coffeetypepoints
    ADD CONSTRAINT loyale_coffeetypepoints_pkey PRIMARY KEY (id);


--
-- Name: loyale_grantpointlog loyale_grantpointlog_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_grantpointlog
    ADD CONSTRAINT loyale_grantpointlog_pkey PRIMARY KEY (id);


--
-- Name: loyale_helper loyale_helper_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_helper
    ADD CONSTRAINT loyale_helper_pkey PRIMARY KEY (id);


--
-- Name: loyale_item loyale_item_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_item
    ADD CONSTRAINT loyale_item_pkey PRIMARY KEY (id);


--
-- Name: loyale_orderpoints loyale_orderpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_orderpoints
    ADD CONSTRAINT loyale_orderpoints_pkey PRIMARY KEY (id);


--
-- Name: loyale_point loyale_point_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_point
    ADD CONSTRAINT loyale_point_pkey PRIMARY KEY (id);


--
-- Name: loyale_redemitem loyale_redemitem_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redemitem
    ADD CONSTRAINT loyale_redemitem_pkey PRIMARY KEY (id);


--
-- Name: loyale_redempointlog loyale_redempointlog_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redempointlog
    ADD CONSTRAINT loyale_redempointlog_pkey PRIMARY KEY (id);


--
-- Name: loyale_setpoint loyale_setpoint_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_setpoint
    ADD CONSTRAINT loyale_setpoint_pkey PRIMARY KEY (id);


--
-- Name: loyale_setpoint loyale_setpoint_status_49d586e070eda46b_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_setpoint
    ADD CONSTRAINT loyale_setpoint_status_49d586e070eda46b_uniq UNIQUE (status, points);


--
-- Name: manager_churnratedata manager_churnratedata_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_churnratedata
    ADD CONSTRAINT manager_churnratedata_pkey PRIMARY KEY (id);


--
-- Name: manager_clusterdf manager_clusterdf_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_clusterdf
    ADD CONSTRAINT manager_clusterdf_pkey PRIMARY KEY (id);


--
-- Name: manager_customercluster manager_customercluster_cluster_number_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_customercluster
    ADD CONSTRAINT manager_customercluster_cluster_number_key UNIQUE (cluster_number);


--
-- Name: manager_customercluster manager_customercluster_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_customercluster
    ADD CONSTRAINT manager_customercluster_pkey PRIMARY KEY (id);


--
-- Name: manager_fyporderstats manager_fyporderstats_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_fyporderstats
    ADD CONSTRAINT manager_fyporderstats_pkey PRIMARY KEY (id);


--
-- Name: manager_intercomlocal manager_intercomlocal_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_intercomlocal
    ADD CONSTRAINT manager_intercomlocal_pkey PRIMARY KEY (id);


--
-- Name: manager_mailchimpcampaignstats manager_mailchimpcampaignstats_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_mailchimpcampaignstats
    ADD CONSTRAINT manager_mailchimpcampaignstats_pkey PRIMARY KEY (id);


--
-- Name: manager_rawbeanstats manager_rawbeanstats_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_rawbeanstats
    ADD CONSTRAINT manager_rawbeanstats_pkey PRIMARY KEY (id);


--
-- Name: manager_recommendation manager_recommendation_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_recommendation
    ADD CONSTRAINT manager_recommendation_pkey PRIMARY KEY (id);


--
-- Name: manager_reportcard manager_reportcard_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_reportcard
    ADD CONSTRAINT manager_reportcard_pkey PRIMARY KEY (id);


--
-- Name: manager_threshold manager_threshold_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_threshold
    ADD CONSTRAINT manager_threshold_pkey PRIMARY KEY (id);


--
-- Name: reminders_reminder reminders_reminder_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY reminders_reminder
    ADD CONSTRAINT reminders_reminder_pkey PRIMARY KEY (id);


--
-- Name: wholesale_plan wholesale_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY wholesale_plan
    ADD CONSTRAINT wholesale_plan_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_253ae2a6331666e8_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_name_253ae2a6331666e8_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: blog_category_slug_57b612bb1be2f496_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX blog_category_slug_57b612bb1be2f496_like ON blog_category USING btree (slug varchar_pattern_ops);


--
-- Name: blog_post_b583a629; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX blog_post_b583a629 ON blog_post USING btree (category_id);


--
-- Name: blog_post_slug_67896a0ddb3eb704_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX blog_post_slug_67896a0ddb3eb704_like ON blog_post USING btree (slug varchar_pattern_ops);


--
-- Name: blog_post_tags_76f094bc; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX blog_post_tags_76f094bc ON blog_post_tags USING btree (tag_id);


--
-- Name: blog_post_tags_f3aa1999; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX blog_post_tags_f3aa1999 ON blog_post_tags USING btree (post_id);


--
-- Name: blog_tag_slug_2e64ff2729adacab_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX blog_tag_slug_2e64ff2729adacab_like ON blog_tag USING btree (slug varchar_pattern_ops);


--
-- Name: coffees_brewmethod_2dbcba41; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_brewmethod_2dbcba41 ON coffees_brewmethod USING btree (slug);


--
-- Name: coffees_coffeegear_brew_methods_756f9d40; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_coffeegear_brew_methods_756f9d40 ON coffees_coffeegear_brew_methods USING btree (brewmethod_id);


--
-- Name: coffees_coffeegear_brew_methods_9fdf1e7a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_coffeegear_brew_methods_9fdf1e7a ON coffees_coffeegear_brew_methods USING btree (coffeegear_id);


--
-- Name: coffees_coffeegearimage_056ab27d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_coffeegearimage_056ab27d ON coffees_coffeegearimage USING btree (coffee_gear_id);


--
-- Name: coffees_coffeegearimage_399a0583; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_coffeegearimage_399a0583 ON coffees_coffeegearimage USING btree (color_id);


--
-- Name: coffees_coffeesticker_48943028; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_coffeesticker_48943028 ON coffees_coffeesticker USING btree (coffee_id);


--
-- Name: coffees_coffeetype_brew_method_4ce4f38d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_coffeetype_brew_method_4ce4f38d ON coffees_coffeetype_brew_method USING btree (coffeetype_id);


--
-- Name: coffees_coffeetype_brew_method_756f9d40; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_coffeetype_brew_method_756f9d40 ON coffees_coffeetype_brew_method USING btree (brewmethod_id);


--
-- Name: coffees_farmphotos_48943028; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_farmphotos_48943028 ON coffees_farmphotos USING btree (coffee_id);


--
-- Name: coffees_rawbean_name_5410edf94a808e49_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_rawbean_name_5410edf94a808e49_like ON coffees_rawbean USING btree (name varchar_pattern_ops);


--
-- Name: coffees_sharedcoffeesticker_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX coffees_sharedcoffeesticker_cb24373b ON coffees_sharedcoffeesticker USING btree (customer_id);


--
-- Name: content_brewguidestep_8d32aa2f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX content_brewguidestep_8d32aa2f ON content_brewguidestep USING btree (brew_guide_id);


--
-- Name: content_post_730f6511; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX content_post_730f6511 ON content_post USING btree (section_id);


--
-- Name: customauth_myuser_email_50f44962fe63e0a4_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customauth_myuser_email_50f44962fe63e0a4_like ON customauth_myuser USING btree (email varchar_pattern_ops);


--
-- Name: customauth_myuser_groups_0e939a4f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customauth_myuser_groups_0e939a4f ON customauth_myuser_groups USING btree (group_id);


--
-- Name: customauth_myuser_groups_8b14fb18; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customauth_myuser_groups_8b14fb18 ON customauth_myuser_groups USING btree (myuser_id);


--
-- Name: customauth_myuser_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customauth_myuser_user_permissions_8373b171 ON customauth_myuser_user_permissions USING btree (permission_id);


--
-- Name: customauth_myuser_user_permissions_8b14fb18; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customauth_myuser_user_permissions_8b14fb18 ON customauth_myuser_user_permissions USING btree (myuser_id);


--
-- Name: customers_address_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_address_cb24373b ON customers_address USING btree (customer_id);


--
-- Name: customers_cardfingerprint_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_cardfingerprint_cb24373b ON customers_cardfingerprint USING btree (customer_id);


--
-- Name: customers_charge_9bea82de; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_charge_9bea82de ON customers_charge USING btree (product_id);


--
-- Name: customers_charge_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_charge_cb24373b ON customers_charge USING btree (customer_id);


--
-- Name: customers_coffeereview_48943028; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_coffeereview_48943028 ON customers_coffeereview USING btree (coffee_id);


--
-- Name: customers_customer_received_coffee_samples_4ce4f38d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_customer_received_coffee_samples_4ce4f38d ON customers_customer_received_coffee_samples USING btree (coffeetype_id);


--
-- Name: customers_customer_received_coffee_samples_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_customer_received_coffee_samples_cb24373b ON customers_customer_received_coffee_samples USING btree (customer_id);


--
-- Name: customers_customer_vouchers_3e8639ee; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_customer_vouchers_3e8639ee ON customers_customer_vouchers USING btree (voucher_id);


--
-- Name: customers_customer_vouchers_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_customer_vouchers_cb24373b ON customers_customer_vouchers USING btree (customer_id);


--
-- Name: customers_facebookcustomer_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_facebookcustomer_cb24373b ON customers_facebookcustomer USING btree (customer_id);


--
-- Name: customers_facebookcustomer_email_8772ef50c90254_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_facebookcustomer_email_8772ef50c90254_like ON customers_facebookcustomer USING btree (email varchar_pattern_ops);


--
-- Name: customers_gearorder_3e8639ee; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_gearorder_3e8639ee ON customers_gearorder USING btree (voucher_id);


--
-- Name: customers_gearorder_47af909e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_gearorder_47af909e ON customers_gearorder USING btree (gear_id);


--
-- Name: customers_gearorder_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_gearorder_cb24373b ON customers_gearorder USING btree (customer_id);


--
-- Name: customers_gearorder_ea8e5d12; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_gearorder_ea8e5d12 ON customers_gearorder USING btree (address_id);


--
-- Name: customers_order_37674b46; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_order_37674b46 ON customers_order USING btree (brew_id);


--
-- Name: customers_order_3e8639ee; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_order_3e8639ee ON customers_order USING btree (voucher_id);


--
-- Name: customers_order_48943028; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_order_48943028 ON customers_order USING btree (coffee_id);


--
-- Name: customers_order_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_order_cb24373b ON customers_order USING btree (customer_id);


--
-- Name: customers_order_ea8e5d12; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_order_ea8e5d12 ON customers_order USING btree (address_id);


--
-- Name: customers_plan_plan_fff92021335fbeb_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_plan_plan_fff92021335fbeb_like ON customers_plan USING btree (plan varchar_pattern_ops);


--
-- Name: customers_preferences_37674b46; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_preferences_37674b46 ON customers_preferences USING btree (brew_id);


--
-- Name: customers_preferences_48943028; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_preferences_48943028 ON customers_preferences USING btree (coffee_id);


--
-- Name: customers_preferences_flavor_dd3f198d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_preferences_flavor_dd3f198d ON customers_preferences_flavor USING btree (flavor_id);


--
-- Name: customers_preferences_flavor_e7a82d8e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_preferences_flavor_e7a82d8e ON customers_preferences_flavor USING btree (preferences_id);


--
-- Name: customers_reference_1552dc70; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_reference_1552dc70 ON customers_reference USING btree (referrer_id);


--
-- Name: customers_reference_275723de; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_reference_275723de ON customers_reference USING btree (referred_id);


--
-- Name: customers_referral_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_referral_e8701ad4 ON customers_referral USING btree (user_id);


--
-- Name: customers_subscription_60fb6a05; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_subscription_60fb6a05 ON customers_subscription USING btree (plan_id);


--
-- Name: customers_subscription_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_subscription_cb24373b ON customers_subscription USING btree (customer_id);


--
-- Name: customers_voucher_b583a629; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX customers_voucher_b583a629 ON customers_voucher USING btree (category_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_461cfeaa630ca218_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_session_key_461cfeaa630ca218_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_site_domain_a2e37b91_like ON django_site USING btree (domain varchar_pattern_ops);


--
-- Name: get_started_getstartedresponse_c1cb2d1b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX get_started_getstartedresponse_c1cb2d1b ON get_started_getstartedresponse USING btree (ct_id);


--
-- Name: get_started_referralvoucher_924b1846; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX get_started_referralvoucher_924b1846 ON get_started_referralvoucher USING btree (sender_id);


--
-- Name: loyale_coffeetypepoints_2d8326c6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX loyale_coffeetypepoints_2d8326c6 ON loyale_coffeetypepoints USING btree (coffee_type_id);


--
-- Name: loyale_grantpointlog_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX loyale_grantpointlog_e8701ad4 ON loyale_grantpointlog USING btree (user_id);


--
-- Name: loyale_point_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX loyale_point_e8701ad4 ON loyale_point USING btree (user_id);


--
-- Name: loyale_redemitem_82bfda79; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX loyale_redemitem_82bfda79 ON loyale_redemitem USING btree (item_id);


--
-- Name: loyale_redemitem_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX loyale_redemitem_e8701ad4 ON loyale_redemitem USING btree (user_id);


--
-- Name: loyale_redempointlog_82bfda79; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX loyale_redempointlog_82bfda79 ON loyale_redempointlog USING btree (item_id);


--
-- Name: loyale_redempointlog_e8701ad4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX loyale_redempointlog_e8701ad4 ON loyale_redempointlog USING btree (user_id);


--
-- Name: manager_fyporderstats_69dfcb07; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX manager_fyporderstats_69dfcb07 ON manager_fyporderstats USING btree (order_id);


--
-- Name: manager_intercomlocal_cb24373b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX manager_intercomlocal_cb24373b ON manager_intercomlocal USING btree (customer_id);


--
-- Name: manager_mailchimpcampaignstats_69dfcb07; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX manager_mailchimpcampaignstats_69dfcb07 ON manager_mailchimpcampaignstats USING btree (order_id);


--
-- Name: manager_rawbeanstats_70ae40bf; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX manager_rawbeanstats_70ae40bf ON manager_rawbeanstats USING btree (raw_bean_id);


--
-- Name: reminders_reminder_3e8639ee; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX reminders_reminder_3e8639ee ON reminders_reminder USING btree (voucher_id);


--
-- Name: reminders_reminder_69dfcb07; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX reminders_reminder_69dfcb07 ON reminders_reminder USING btree (order_id);


--
-- Name: reminders_reminder_e18282a9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX reminders_reminder_e18282a9 ON reminders_reminder USING btree (recommended_coffee_id);


--
-- Name: reminders_reminder D3a1f5ded4689713b546e7f44b6f07a3; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY reminders_reminder
    ADD CONSTRAINT "D3a1f5ded4689713b546e7f44b6f07a3" FOREIGN KEY (recommended_coffee_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_content_type_id_508cf46651277a81_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_post blog_post_category_id_42ac2d1ab38dd922_fk_blog_category_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post
    ADD CONSTRAINT blog_post_category_id_42ac2d1ab38dd922_fk_blog_category_id FOREIGN KEY (category_id) REFERENCES blog_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_post_tags blog_post_tags_post_id_f385a4e5bab89b5_fk_blog_post_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post_tags
    ADD CONSTRAINT blog_post_tags_post_id_f385a4e5bab89b5_fk_blog_post_id FOREIGN KEY (post_id) REFERENCES blog_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_post_tags blog_post_tags_tag_id_12f83b29ba9842bc_fk_blog_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY blog_post_tags
    ADD CONSTRAINT blog_post_tags_tag_id_12f83b29ba9842bc_fk_blog_tag_id FOREIGN KEY (tag_id) REFERENCES blog_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_coffeegearimage coffee_coffee_gear_id_57d07051520458ce_fk_coffees_coffeegear_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegearimage
    ADD CONSTRAINT coffee_coffee_gear_id_57d07051520458ce_fk_coffees_coffeegear_id FOREIGN KEY (coffee_gear_id) REFERENCES coffees_coffeegear(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_coffeegear_brew_methods coffees_brewmethod_id_23b6ad81a4ef45b1_fk_coffees_brewmethod_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegear_brew_methods
    ADD CONSTRAINT coffees_brewmethod_id_23b6ad81a4ef45b1_fk_coffees_brewmethod_id FOREIGN KEY (brewmethod_id) REFERENCES coffees_brewmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_coffeetype_brew_method coffees_brewmethod_id_470f2553eb01c80a_fk_coffees_brewmethod_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeetype_brew_method
    ADD CONSTRAINT coffees_brewmethod_id_470f2553eb01c80a_fk_coffees_brewmethod_id FOREIGN KEY (brewmethod_id) REFERENCES coffees_brewmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_coffeesticker coffees_cof_coffee_id_16977dd164ac0212_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeesticker
    ADD CONSTRAINT coffees_cof_coffee_id_16977dd164ac0212_fk_coffees_coffeetype_id FOREIGN KEY (coffee_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_coffeegear_brew_methods coffees_coffeegear_id_40a21e84a935cf3d_fk_coffees_coffeegear_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegear_brew_methods
    ADD CONSTRAINT coffees_coffeegear_id_40a21e84a935cf3d_fk_coffees_coffeegear_id FOREIGN KEY (coffeegear_id) REFERENCES coffees_coffeegear(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_coffeetype_brew_method coffees_coffeetype_id_6e57e31b383cc84b_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeetype_brew_method
    ADD CONSTRAINT coffees_coffeetype_id_6e57e31b383cc84b_fk_coffees_coffeetype_id FOREIGN KEY (coffeetype_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_coffeegearimage coffees_color_id_2208b29428a79949_fk_coffees_coffeegearcolor_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_coffeegearimage
    ADD CONSTRAINT coffees_color_id_2208b29428a79949_fk_coffees_coffeegearcolor_id FOREIGN KEY (color_id) REFERENCES coffees_coffeegearcolor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_farmphotos coffees_far_coffee_id_6f8fac97d9ef4109_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_farmphotos
    ADD CONSTRAINT coffees_far_coffee_id_6f8fac97d9ef4109_fk_coffees_coffeetype_id FOREIGN KEY (coffee_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: coffees_sharedcoffeesticker coffees_sh_customer_id_9e10fb4af75ad49_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY coffees_sharedcoffeesticker
    ADD CONSTRAINT coffees_sh_customer_id_9e10fb4af75ad49_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_brewguidestep content__brew_guide_id_62f23a71def7f540_fk_content_brewguide_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_brewguidestep
    ADD CONSTRAINT content__brew_guide_id_62f23a71def7f540_fk_content_brewguide_id FOREIGN KEY (brew_guide_id) REFERENCES content_brewguide(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_post content_post_section_id_1caeea154419dc18_fk_content_section_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY content_post
    ADD CONSTRAINT content_post_section_id_1caeea154419dc18_fk_content_section_id FOREIGN KEY (section_id) REFERENCES content_section(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_voucher cu_category_id_6153e9f3317acdb1_fk_customers_vouchercategory_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_voucher
    ADD CONSTRAINT cu_category_id_6153e9f3317acdb1_fk_customers_vouchercategory_id FOREIGN KEY (category_id) REFERENCES customers_vouchercategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_preferences_flavor cus_preferences_id_3db0e1e4bd39d16c_fk_customers_preferences_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences_flavor
    ADD CONSTRAINT cus_preferences_id_3db0e1e4bd39d16c_fk_customers_preferences_id FOREIGN KEY (preferences_id) REFERENCES customers_preferences(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customauth_myuser_groups customauth_m_myuser_id_2c64355ca2e67c27_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_groups
    ADD CONSTRAINT customauth_m_myuser_id_2c64355ca2e67c27_fk_customauth_myuser_id FOREIGN KEY (myuser_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customauth_myuser_user_permissions customauth_m_myuser_id_49e4cf2e62f0918b_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_user_permissions
    ADD CONSTRAINT customauth_m_myuser_id_49e4cf2e62f0918b_fk_customauth_myuser_id FOREIGN KEY (myuser_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customauth_myuser_groups customauth_myuser_gr_group_id_70354ccbc091e44a_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_groups
    ADD CONSTRAINT customauth_myuser_gr_group_id_70354ccbc091e44a_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customauth_myuser_user_permissions customauth_permission_id_5a8b110281451bad_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customauth_myuser_user_permissions
    ADD CONSTRAINT customauth_permission_id_5a8b110281451bad_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_customer_received_coffee_samples customer_coffeetype_id_a1e340947b5cde3_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_received_coffee_samples
    ADD CONSTRAINT customer_coffeetype_id_a1e340947b5cde3_fk_coffees_coffeetype_id FOREIGN KEY (coffeetype_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_facebookcustomer customers__customer_id_1cdc194d255e131a_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_facebookcustomer
    ADD CONSTRAINT customers__customer_id_1cdc194d255e131a_fk_customauth_myuser_id FOREIGN KEY (customer_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_gearorder customers__customer_id_d0b452d7f873a90_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_gearorder
    ADD CONSTRAINT customers__customer_id_d0b452d7f873a90_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_charge customers__product_id_2e229704bd4ca0b6_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_charge
    ADD CONSTRAINT customers__product_id_2e229704bd4ca0b6_fk_coffees_coffeetype_id FOREIGN KEY (product_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_reference customers__referred_id_393d29b9d645a925_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_reference
    ADD CONSTRAINT customers__referred_id_393d29b9d645a925_fk_customauth_myuser_id FOREIGN KEY (referred_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_reference customers__referrer_id_5d2cb8f002a07d6b_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_reference
    ADD CONSTRAINT customers__referrer_id_5d2cb8f002a07d6b_fk_customauth_myuser_id FOREIGN KEY (referrer_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_coffeereview customers_c_coffee_id_4b9485de74ff3d98_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_coffeereview
    ADD CONSTRAINT customers_c_coffee_id_4b9485de74ff3d98_fk_coffees_coffeetype_id FOREIGN KEY (coffee_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_customer_vouchers customers_c_voucher_id_799e33164c7a66dc_fk_customers_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_vouchers
    ADD CONSTRAINT customers_c_voucher_id_799e33164c7a66dc_fk_customers_voucher_id FOREIGN KEY (voucher_id) REFERENCES customers_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_cardfingerprint customers_cardfin_customer_id_aa5957ba_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_cardfingerprint
    ADD CONSTRAINT customers_cardfin_customer_id_aa5957ba_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_coffeereview customers_coffe_order_id_48daa59afaf98811_fk_customers_order_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_coffeereview
    ADD CONSTRAINT customers_coffe_order_id_48daa59afaf98811_fk_customers_order_id FOREIGN KEY (order_id) REFERENCES customers_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_customer customers_cust_user_id_6546646630fa41b3_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer
    ADD CONSTRAINT customers_cust_user_id_6546646630fa41b3_fk_customauth_myuser_id FOREIGN KEY (user_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_subscription customers_customer_id_16aa948df6ce9ba3_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_subscription
    ADD CONSTRAINT customers_customer_id_16aa948df6ce9ba3_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_customer_vouchers customers_customer_id_1bebd517aaeb541f_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_vouchers
    ADD CONSTRAINT customers_customer_id_1bebd517aaeb541f_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_address customers_customer_id_1dc0906129babe29_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_address
    ADD CONSTRAINT customers_customer_id_1dc0906129babe29_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_charge customers_customer_id_4911b056f56954a0_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_charge
    ADD CONSTRAINT customers_customer_id_4911b056f56954a0_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_customer_received_coffee_samples customers_customer_id_4eee94bdcb6b1295_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_customer_received_coffee_samples
    ADD CONSTRAINT customers_customer_id_4eee94bdcb6b1295_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_shoppingcart customers_customer_id_538c7dd4b6c3ede4_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_shoppingcart
    ADD CONSTRAINT customers_customer_id_538c7dd4b6c3ede4_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_preferences customers_customer_id_6e809e0d605843df_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences
    ADD CONSTRAINT customers_customer_id_6e809e0d605843df_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_order customers_customer_id_78e2f1bc42632713_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_order
    ADD CONSTRAINT customers_customer_id_78e2f1bc42632713_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_gearorder customers_g_address_id_2a009ce83c81425b_fk_customers_address_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_gearorder
    ADD CONSTRAINT customers_g_address_id_2a009ce83c81425b_fk_customers_address_id FOREIGN KEY (address_id) REFERENCES customers_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_gearorder customers_g_voucher_id_288a621948e9b773_fk_customers_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_gearorder
    ADD CONSTRAINT customers_g_voucher_id_288a621948e9b773_fk_customers_voucher_id FOREIGN KEY (voucher_id) REFERENCES customers_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_gearorder customers_gea_gear_id_72b17b0a679416e7_fk_coffees_coffeegear_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_gearorder
    ADD CONSTRAINT customers_gea_gear_id_72b17b0a679416e7_fk_coffees_coffeegear_id FOREIGN KEY (gear_id) REFERENCES coffees_coffeegear(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_order customers_o_address_id_1a90ce983f1f2dd8_fk_customers_address_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_order
    ADD CONSTRAINT customers_o_address_id_1a90ce983f1f2dd8_fk_customers_address_id FOREIGN KEY (address_id) REFERENCES customers_address(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_order customers_o_coffee_id_40641705485a699f_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_order
    ADD CONSTRAINT customers_o_coffee_id_40641705485a699f_fk_coffees_coffeetype_id FOREIGN KEY (coffee_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_order customers_o_voucher_id_19f489b26df8f90a_fk_customers_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_order
    ADD CONSTRAINT customers_o_voucher_id_19f489b26df8f90a_fk_customers_voucher_id FOREIGN KEY (voucher_id) REFERENCES customers_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_order customers_ord_brew_id_644c6f963ed34473_fk_coffees_brewmethod_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_order
    ADD CONSTRAINT customers_ord_brew_id_644c6f963ed34473_fk_coffees_brewmethod_id FOREIGN KEY (brew_id) REFERENCES coffees_brewmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_preferences customers_p_coffee_id_7079f539499d403b_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences
    ADD CONSTRAINT customers_p_coffee_id_7079f539499d403b_fk_coffees_coffeetype_id FOREIGN KEY (coffee_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_preferences customers_pre_brew_id_7ec6a7f4603f273f_fk_coffees_brewmethod_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences
    ADD CONSTRAINT customers_pre_brew_id_7ec6a7f4603f273f_fk_coffees_brewmethod_id FOREIGN KEY (brew_id) REFERENCES coffees_brewmethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_preferences_flavor customers_prefe_flavor_id_2328de63a18c9115_fk_coffees_flavor_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_preferences_flavor
    ADD CONSTRAINT customers_prefe_flavor_id_2328de63a18c9115_fk_coffees_flavor_id FOREIGN KEY (flavor_id) REFERENCES coffees_flavor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_referral customers_refe_user_id_1374417524715bbc_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_referral
    ADD CONSTRAINT customers_refe_user_id_1374417524715bbc_fk_customauth_myuser_id FOREIGN KEY (user_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_shoppingcart customers_s_voucher_id_781409da41974c19_fk_customers_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_shoppingcart
    ADD CONSTRAINT customers_s_voucher_id_781409da41974c19_fk_customers_voucher_id FOREIGN KEY (voucher_id) REFERENCES customers_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers_subscription customers_subscri_plan_id_21aa261286851d64_fk_customers_plan_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY customers_subscription
    ADD CONSTRAINT customers_subscri_plan_id_21aa261286851d64_fk_customers_plan_id FOREIGN KEY (plan_id) REFERENCES customers_plan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log djan_content_type_id_697914295151027a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_l_user_id_52fdd58701c5f563_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_l_user_id_52fdd58701c5f563_fk_customauth_myuser_id FOREIGN KEY (user_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: get_started_getstartedresponse get_started_get_ct_id_3c8ee622f7ef9cb0_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_getstartedresponse
    ADD CONSTRAINT get_started_get_ct_id_3c8ee622f7ef9cb0_fk_coffees_coffeetype_id FOREIGN KEY (ct_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: get_started_referralvoucher get_started_sender_id_1c775191f1cd31a0_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY get_started_referralvoucher
    ADD CONSTRAINT get_started_sender_id_1c775191f1cd31a0_fk_customers_customer_id FOREIGN KEY (sender_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loyale_coffeetypepoints loyale_coffee_type_id_1f36d507722a635b_fk_coffees_coffeetype_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_coffeetypepoints
    ADD CONSTRAINT loyale_coffee_type_id_1f36d507722a635b_fk_coffees_coffeetype_id FOREIGN KEY (coffee_type_id) REFERENCES coffees_coffeetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loyale_grantpointlog loyale_grantpo_user_id_70c21c40a0ad3ddc_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_grantpointlog
    ADD CONSTRAINT loyale_grantpo_user_id_70c21c40a0ad3ddc_fk_customauth_myuser_id FOREIGN KEY (user_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loyale_point loyale_point_user_id_343d07bbb69d1a88_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_point
    ADD CONSTRAINT loyale_point_user_id_343d07bbb69d1a88_fk_customauth_myuser_id FOREIGN KEY (user_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loyale_redemitem loyale_redemit_user_id_31d5bbc9037c2954_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redemitem
    ADD CONSTRAINT loyale_redemit_user_id_31d5bbc9037c2954_fk_customauth_myuser_id FOREIGN KEY (user_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loyale_redemitem loyale_redemitem_item_id_3c44419d26afef68_fk_loyale_item_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redemitem
    ADD CONSTRAINT loyale_redemitem_item_id_3c44419d26afef68_fk_loyale_item_id FOREIGN KEY (item_id) REFERENCES loyale_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loyale_redempointlog loyale_redempo_user_id_5267e7f4bdcc0357_fk_customauth_myuser_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redempointlog
    ADD CONSTRAINT loyale_redempo_user_id_5267e7f4bdcc0357_fk_customauth_myuser_id FOREIGN KEY (user_id) REFERENCES customauth_myuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: loyale_redempointlog loyale_redempointlog_item_id_6ada6e7bc8aa54d_fk_loyale_item_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY loyale_redempointlog
    ADD CONSTRAINT loyale_redempointlog_item_id_6ada6e7bc8aa54d_fk_loyale_item_id FOREIGN KEY (item_id) REFERENCES loyale_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manager_fyporderstats manager_fyporde_order_id_3a32158dc2286fce_fk_customers_order_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_fyporderstats
    ADD CONSTRAINT manager_fyporde_order_id_3a32158dc2286fce_fk_customers_order_id FOREIGN KEY (order_id) REFERENCES customers_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manager_intercomlocal manager_i_customer_id_1d0fe91e50364eb3_fk_customers_customer_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_intercomlocal
    ADD CONSTRAINT manager_i_customer_id_1d0fe91e50364eb3_fk_customers_customer_id FOREIGN KEY (customer_id) REFERENCES customers_customer(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manager_mailchimpcampaignstats manager_mailchim_order_id_41035ef632820ec_fk_customers_order_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_mailchimpcampaignstats
    ADD CONSTRAINT manager_mailchim_order_id_41035ef632820ec_fk_customers_order_id FOREIGN KEY (order_id) REFERENCES customers_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: manager_rawbeanstats manager_rawb_raw_bean_id_1b91a0c94eb96854_fk_coffees_rawbean_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY manager_rawbeanstats
    ADD CONSTRAINT manager_rawb_raw_bean_id_1b91a0c94eb96854_fk_coffees_rawbean_id FOREIGN KEY (raw_bean_id) REFERENCES coffees_rawbean(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reminders_reminder reminders_r_voucher_id_226ad102d686f1bb_fk_customers_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY reminders_reminder
    ADD CONSTRAINT reminders_r_voucher_id_226ad102d686f1bb_fk_customers_voucher_id FOREIGN KEY (voucher_id) REFERENCES customers_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reminders_reminder reminders_remin_order_id_4a026456ef3ddf75_fk_customers_order_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY reminders_reminder
    ADD CONSTRAINT reminders_remin_order_id_4a026456ef3ddf75_fk_customers_order_id FOREIGN KEY (order_id) REFERENCES customers_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

